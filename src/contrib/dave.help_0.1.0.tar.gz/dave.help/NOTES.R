#NOTES

# update manual on github
git branch -d github gh-pages


#update index.html
git checkout gh-pages
git checkout master -- ./inst/manual.html
git checkout master -- ./inst/assets
mv inst/manual.html index.html
rm -rf inst/


#remove all and create index.html
git checkout gh-pages
cp inst/manual.html index.html
mkdir assets
cp -R inst/assets  assets/.
find . -type f -not -name "index.html" -not -path "./.git/\*" -not -path "./assets/\*" -delete 
git rm -rf inst
git rm -rf R
git rm -rf .Rproj.user
#.gitignore


#update with
eval `ssh-agent -s`
ssh-add /mnt/c/Users/think/Dropbox/.ssh/no_pass

#build help pages for each package here
#make UI for unified help pages
#use bookdown for pages?

#help pages
-[ ] dave.main
-[ ] dave.preproc
-[ ] dave.stats
-[ ] dave.cluster
-[ ] dave.multivariate
-[ ] dave.pathway
-[ ] dave.rf
-[ ] dave.network