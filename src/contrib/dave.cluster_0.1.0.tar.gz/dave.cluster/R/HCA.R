
###############################
# Export functions
###############################



#' Title
#'
#' @param data 
#' @param type 
#' @param cor.opt 
#' @param row_group 
#' @param col_group 
#' @param row_labels 
#' @param col_labels 
#' @param dist.opt 
#' @param hclust.opt 
#' @param scale 
#' @param ... 
#'
#' @return
#' @export
#'
#' @examples
hca_clustering <- function(data,
                           type = 'column',
                           cor.opt = 'spearman',
                           row_group = NULL,
                           col_group = NULL,
                           row_labels = NULL,
                           col_labels = NULL,
                           dist.opt = 'euclidean',
                           hclust.opt = 'complete',
                           scale=FALSE,
                           ...) {
 
  #remove factors from data 
  fct<-sapply(data,is.factor)
  if(any(fct)){
    .data<-data[,!fct]

  } else {
    .data<-data
  }
  
  if(scale){
    .data<-scale(.data)
  }
  
  prep_data<-function(.data,type,method=cor.opt){
    
    if(type=='row'){
      
      if(!is.null(cor.opt)){
        .names<-rownames(.data)
        .data<-t(.data) 
        .data<-cor(.data,method=cor.opt,use="pairwise.complete.obs")
        rownames(.data)<-.names
      } 
    }
    
    if(type=='column'){
      if(!is.null(cor.opt)){
        .data<-cor(.data,method=cor.opt,use="pairwise.complete.obs")
      } else {
        .data<- t(.data)
      }
    }
    
    return(.data)
    
  }
  
  get_hclust<-function(.data,dist.opt,hclust.opt){
    
    if(!is.null(dist.opt) & !is.null(hclust.opt)){
      out<-.data %>%
        dist(method=dist.opt) %>%
        hclust(method=hclust.opt) 
    } else {
      out<-NULL
    }
    
    return(out)
  }
  
  #control for row, column or both
  row_clust<-col_clust<-NULL
  if(type  %in% c('row','column')){
    
    ..data<- prep_data(.data,type,method)
    clust<-get_hclust(..data,dist.opt,hclust.opt)
  
    if(!is.null(cor.opt)){
      .data<-..data
    }
    
    if(type == 'column'){
      col_clust<-clust
      if(!is.null(cor.opt)) row_clust<-clust
    }
    
    if(type == 'row'){
      row_clust<-clust
      if(!is.null(cor.opt)) col_clust<-clust
    }
    
  }
  
  if(type  == 'both'){
   
    ..data<- prep_data(.data,type='row',method)
    row_clust<-get_hclust(..data,dist.opt,hclust.opt)
    
    ..data<- prep_data(.data,type='column',method)
    col_clust<-get_hclust(..data,dist.opt,hclust.opt)
    
  }
  
  #custom names
  #column
  if (!is.null(col_labels) && ncol(.data) == length(col_labels)) {
    colnames(.data)<-make.unique(as.character(col_labels))
  }
  #row
  if (!is.null(row_labels) && nrow(.data) == length(row_labels)) {
    rownames(.data)<-make.unique(as.character(row_labels)) 
  }
  
  
  #call
  .call<-match.call(expand.dots=TRUE)
  #exclude data 
  .call$data<-NULL
  
  out <-
    list(
      row_clust = row_clust,
      col_clust = col_clust,
      data = .data,
      row_group = row_group,
      col_group = col_group,
      method = list(
        type = type,
        dist = dist.opt,
        link = hclust.opt,
        cor = cor.opt
      ),
      call = .call
    )
  
  class(out)<-"hclust_obj"
  return(out)
}

#' @title cut.hca_cluster
#' @param obj obj returned by /code{hca_clustering}
#' @param k int number of groups to extract defaults to 3
#' @export cut.hclust_obj
cut.hclust_obj<-function(obj,k=3){
  
  #columns
  if(!is.null(obj$col_clust)){
    clusters<-cutree(obj$col_clust,k=k)
    
    if(!is.null(obj$col_group)){
      obj$col_group$hca_clusters<-factor(clusters) 
    } else {
      obj$col_group<-data.frame(hca_clusters=factor(clusters))
    }
    
  }
  
  #rows
  if(!is.null(obj$row_clust)){
    clusters<-cutree(obj$row_clust,k=k)
    
    if(!is.null(obj$row_group)){
      obj$row_group$hca_clusters<-factor(clusters) 
    } else {
      obj$row_group<-data.frame(hca_clusters=factor(clusters))
    }
    
  }
  
  return(obj)
}

#' Summary method
#' @param obj of class hclust_obj
#' @export summary.hclust_obj
#' @details summarize data object
#' @importFrom dplyr case_when
summary.hclust_obj<-function(obj, ...){
  
  #Describe input method
  .call <- as.list(obj$call)
  
  #detect type based row/column and correlation
  .type <- .call$type
  .cor <- if (is.null(obj$method$cor)) FALSE else TRUE
  
  if (.type != 'both') {
    type <- case_when(
      .type == 'row' & .cor ~ ' sample correlations',
      .type == 'row' & !.cor ~ ' sample data',
      .type != 'row' & .cor ~ ' variable correlations',
      .type != 'row' & !.cor ~ ' variable data'
    )
  } else {
    type <- ' sample and variable data'
    .call$cor.opt<- NULL # not used
    
  }
  
  
  .desc<-paste0('Hierarchical clustering (HCA) was conducted on',type,'.')
  if(!is.null(.call$cor.opt)){
    .desc<-c(.desc,
             paste0('Correlations were calculated based on the ',.call$cor.opt, ' method.')
    )
  }
  .dist<-if(is.null(.call$dist.opt)) 'euclidean' else .call$dist.opt
  .link<-if(is.null(.call$hclust.opt)) 'complete' else .call$hclust.opt
  .desc<-c(.desc,
           paste0('Clustering was done using ',.dist,
           ' distance and ',.link,' linkage method.')
  )
  
  #do this for row and col separately
  #group message and table
  clust_summary<-function(obj, type='column', n_names=5){
    
    if(type == 'column'){
      group<-obj$col_group$hca_clusters
      .names<-colnames(obj$data)
    } else {
      group<-obj$row_group$hca_clusters
      .names<-rownames(obj$data)
    }
    
    
    if(!is.null(group)){
      .clust<-group
      n_clus<-length(unique(.clust))
      .desc<-c(.desc,
               paste0('The data was clustered into ',n_clus,' groups.')
      )
      
      clus_tbl<-table(.clust) %>%
        data.frame() %>%
        setNames(.,c('cluster','number'))
      
      #get n names for clustered entities
      tmp<-data.frame(cluster=as.integer(.clust),names=.names)
      .names<-split(tmp,tmp$cluster) %>%
        lapply(., function(i){na.omit(i$names[1:n_names]) %>% paste0(.,collapse=', ') %>% paste0(.,', ...', collapse='')})
      
      clus_tbl$names<-.names
      
      start<-paste0('The selected ',type,' clusters contain the following number of data points: ')
      end<-'.'
      clus_summary<-lapply(1:nrow(clus_tbl),function(i){
        paste0('cluster ',i,' (',clus_tbl[i,]$number,')') 
      }) %>%
        unlist() %>%
        grammatical_paste() %>%
        paste0(start,.,end)
      
    } else {
      clus_summary<-NULL
      clus_tbl<-NULL
    }
    
    .clus_tbl<-switch (type,
      'row' = list(row = clus_tbl),
      'column' = list(column = clus_tbl)
    )
    
    
    list(summary = clus_summary,table = .clus_tbl)
    
  }
  
  if(.type == 'both'){
    row_summary<-clust_summary(obj,'row')
    col_summary<-clust_summary(obj,'column')
    
    #combine
    
    out <- list(summary = paste(c(
      row_summary$summary, col_summary$summary
    ), collapse = " "),
    table = list(row = row_summary$table$row, column = col_summary$table$column))
    
  } else {
    out<-clust_summary(obj,.type)
   
  }
  
  #combine descriptions
  .desc<-paste(c(.desc,out$summary),collapse=" ")
  
  return(list(description=.desc,cluster=out$table))
}

#tests
test<-function(){
 
  
  library(dave.cluster) 
  
  #example data
  library(dave.stat) 
  data("dave_stat")
  
  #both
  .data<-dave_stat
  col_meta<-dave_stat_col_meta
  row_meta<-dave_stat_row_meta
  obj <-
    hca_clustering(
      .data,
      type = 'both',
      cor.opt = 'spearman',
      row_group = row_meta %>% select(class,age),
      col_group = col_meta %>% select(FC_non.diabetic.._diabetic..,kruskal_selected),
      row_labels = row_meta %>% select(label),
      col_labels = col_meta %>% select(name),
      scale=TRUE
    ) 
  
  obj<-cut(obj,k=3)
  
  plot(obj)
  
  
  #column
  #with meta data
  library(dave.preproc)
  data("dave_")
  .data<-dave_
  obj<-hca_clustering(.data,type='column',cor.opt=NULL) 
  obj<-hca_clustering(.data,type='column',cor.opt='spearman') 

  #group
  data("dave_var_meta")
  group<-data.frame(fake=rep(c(TRUE,FALSE),nrow(dave_var_meta))[1:nrow(dave_var_meta)] %>% as.factor())
  obj<-hca_clustering(.data,type='column',cor.opt=NULL,group=group) 
  obj<-hca_clustering(.data,type='column',cor.opt='spearman',group=group) 
  
  #label
  label<-dave_var_meta$name
  obj<-hca_clustering(.data,type='column',cor.opt=NULL,group=group,label=label) 
  obj<-hca_clustering(.data,type='column',cor.opt='spearman',group=group,label=label) 
  
  obj<-hca_cluster_cut(obj,k=2)
  summary(obj)
  plot(obj)
  plot(obj,interactive = TRUE)
  
  #row
  #---------------
  obj<-hca_clustering(.data,type='row',cor.opt=NULL) 
  obj<-hca_clustering(.data,type='row',cor.opt='spearman') 
  
  #group
  group<-dave_ %>% select(one_of('class'))
  obj<-hca_clustering(.data,type='row',cor.opt=NULL,group=group) 
  obj<-hca_clustering(.data,type='row',cor.opt='spearman',group=group) 
  
  #label
  label<-dave_$label
  obj<-hca_clustering(.data,type='row',cor.opt=NULL,group=group,label=label) 
  obj<-hca_clustering(.data,type='row',cor.opt='spearman',group=group,label=label) 
  
  obj<-hca_cluster_cut(obj,k=2)
  summary(obj)
  
 
  plot(obj,interactive=FALSE)
  plot(obj,interactive=TRUE)
  plot(obj,type='dendrogram',interactive=TRUE)
  dvm_Heatmap.clust_obj(obj)
  dvm_ggtree_heatmap.clust_obj(obj)
  dvm_d3heatmap.clust_obj(obj)
  
  #no group
  .data<-aq_data[,3:100] 
  obj<-hca_clustering(.data,type='row',cor.opt=NULL)
  summary(obj)
  dvm_Heatmap.clust_obj(obj)
  
  #correlation
  #--------
  obj<-hca_clustering(.data,type='row',cor.opt='spearman')
  dvm_Heatmap.clust_obj(obj)
  dvm_ggtree_heatmap.clust_obj(obj)
  dvm_d3heatmap.clust_obj(obj)
  
  #column data
  #--------
  obj<-hca_clustering(.data,type='column',cor.opt=NULL)
  dvm_Heatmap.clust_obj(obj)
  dvm_ggtree_heatmap.clust_obj(obj)
  dvm_d3heatmap.clust_obj(obj)
  
  
  
  #correlation (can error on zero variance or missing data)
  #--------
  .data<-mtcars
  obj<-hca_clustering(.data,type='column',cor.opt='spearman')
  dvm_Heatmap.clust_obj(obj)
  dvm_ggtree_heatmap.clust_obj(obj)
  dvm_d3heatmap.clust_obj(obj)
  
  #adding cluster
  obj<-hca_clustering(.data,type='row',cor.opt='spearman') %>% 
    hca_cluster_cut(.,k=3)
  dvm_Heatmap.clust_obj(obj)
  
  
  
}
