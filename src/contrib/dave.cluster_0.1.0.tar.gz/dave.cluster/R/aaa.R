#' dave.cluster
#'
#' @name dave.cluster
#' @docType package
#' @import dplyr
NULL


#' Sample data
#' @details Sample data based PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_data
#' @usage data(dave_data)
NULL

#' Sample  meta data
#' @details Sample data based PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_data_row_meta
#' @usage data(dave_data_row_meta)
NULL

#' Variable meta data
#' @details data based PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_data_col_meta
#' @usage data(dave_data_col_meta)
NULL

