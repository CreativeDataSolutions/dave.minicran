
#' @title hclust_table
#' @param obj summary.hclust_obj
#' @param which one row or column
#' @details pretty print table for cluster stats
#' @return formattable object
#' @export
#' @import formattable
hclust_table <- function(obj,
                         which = 'row',
                         for_pdf = FALSE) {
  tab <- switch(which,
                'row' = obj$cluster$row,
                'column' = obj$cluster$column)
  
  if (is.null(tab)) {
    message(paste('No', which, 'clusters calculated.'))
    return()
  }
  
  
  if (for_pdf) {
    kbl(tab) %>%
      kable_styling(bootstrap_options = c("striped", "hover", "condensed", "responsive"),latex_options="scale_down")
  } else {
    formattable(tab,
                list(`number` = color_bar("#00bc8c")))
  }
  
}