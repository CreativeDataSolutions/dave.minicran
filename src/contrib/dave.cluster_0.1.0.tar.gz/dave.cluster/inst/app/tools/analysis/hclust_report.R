hclust_params<-reactive({
  
  #TODO:create plots of available from explore but not plotted yet
  #for now warn user these need to be created

  isolate({
    tmp<-reactiveValuesToList(hclust_report_values)
    check<-list(tmp[['dendrogram']],tmp[['heatmap']])
    absent<-lapply(check, is.null) %>% unlist()
   .absent<-c('dendrogram','heatmap')[absent]
    
   if(any(absent)) {
     shiny::showNotification(
       paste0(
         'The following plots have not been created yet: ',
         grammatical_paste(.absent),
         '. Use the `Explore` or `Plot` tabs to add these to the report.',collapse = ''),
         type = 'warning'
       )
   }
   
  })
  
  list(obj=get_hclust_obj(),
       plots= reactiveValuesToList(hclust_report_values))

})


hclust_report_obj<-function(){
  .package<-'dave.cluster'
  report_name<-'hclust_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path=getOption("dave.report.rmd.path")
  html_save_path= getOption('dave.report.html.path')
  
  .report_obj<-get_report_obj(.package = .package,
                              report_name= report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)
  
  return(.report_obj)
}




name<-'hclust'

preproc_report<-callModule(reportGenerator, name,
                           report_params = hclust_params,
                           report_obj=hclust_report_obj(),
                           .available = hclust_available)