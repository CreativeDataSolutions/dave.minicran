


hclust_values <- reactiveValues()
hclust_report_values <- reactiveValues()



## choice lists for plots
hclust_plots <-
  c("heatmap" = "heatmap", "dendrogram" = "dendrogram")

# main fun hclust
## list of function arguments
hclust_args <- as.list(formals(init_data))

## list of function inputs selected by user
hclust_inputs <- reactive({
  ## loop needed because reactive values don't allow single bracket indexing
  # hclust_args$arg<-input$something
  # hclust_args$
  
  for (i in r_drop(names(hclust_args)))
    hclust_args[[i]] <- input[[paste0("hclust_", i)]]
  hclust_args
})

###############################
# Left menu
###############################

#cluster focus
output$cluster_dim_ui <- renderUI({
  #get all data set names
  fluidRow(column(
    12,
    radioButtons(
      'cluster_dim',
      label = NULL,
      choices = list(
        'samples' = 'row',
        'variables' = 'column',
        'both' = 'both'
      ),
      selected = 'both',
      inline = TRUE
    )
  ))
})

#filter dim label and group to omit numeric
.allow <- function(vars) {
  check <- sapply(vars, class)
  check %in% c('factor', 'logical', 'character')
}

#separate row and column UI
#row ui
output$cluster_group_row_ui <- renderUI({
  if (is.null(input$dataset) || is.null(input$cluster_dim))
    return()
  vars <- .getdata_cube()$row_meta %>% colnames()
  
  if (any(.allow(vars))) {
    vars2 <- vars[.allow(vars)]
  } else {
    vars2 <- NULL
  }
  
  fluidRow(column(
    12,
    selectInput(
      inputId = "cluster_group_row_var",
      label = "Row group(s):",
      choices = vars,
      selected = state_multiple("cluster_group_row_var",vars, NULL),
      multiple = TRUE
    ),
    selectInput(
      inputId = "cluster_group_row_dim_names",
      label = "Row labels:",
      choices = vars2,
      selected = state_single("cluster_group_row_dim_names",vars2, NULL),
      multiple = FALSE
    )
  ))
})

#column
output$cluster_group_col_ui <- renderUI({
  if (is.null(input$dataset) || is.null(input$cluster_dim))
    return()
  
  vars <- .getdata_cube()$col_meta %>% colnames()
  
  
  if (any(.allow(vars))) {
    vars2 <- vars[.allow(vars)]
  } else {
    vars2 <- NULL
  }
  
  fluidRow(column(
    12,
    selectInput(
      inputId = "cluster_group_col_var",
      label = "Column group(s):",
      choices = vars,
      selected = state_multiple("cluster_group_col_var",vars, NULL),
      multiple = TRUE
    ),
    selectInput(
      inputId = "cluster_group_col_dim_names",
      label = "Column labels:",
      choices = vars2,
      selected = state_single("cluster_group_col_dim_names",vars2, NULL),
      multiple = FALSE
    )
  ))
})

#annotation data
output$cluster_group_ui <- renderUI({
  input$cluster_dim
  tagList(
    conditionalPanel(condition = "input.cluster_dim == 'row' | input.cluster_dim == 'both'",
                     tagList(fluidRow(
                       column(12,
                              uiOutput('cluster_group_row_ui'))
                     ))),
    conditionalPanel(condition = "input.cluster_dim == 'column' | input.cluster_dim == 'both'",
                     tagList(fluidRow(
                       column(12,
                              uiOutput('cluster_group_col_ui'))
                     )))
    
  )
  
})

#update based on dimension
observeEvent(input$cluster_dim, {
  #NULL exit conditions
  
  check <-
    c('cluster_dim',
      'cluster_group_row_var',
      'cluster_group_col_var')
  
  any <- lapply(check, function(x) {
    !is.null(input[[x]])
  }) %>% unlist()
  if (!all(any))
    return()
  
  if (input$cluster_dim == 'row' | input$cluster_dim == 'both') {
    row_vars <- .getdata_cube()$row_meta
    if (any(.allow(row_vars))) {
      vars2 <- row_vars[, .allow(row_vars), drop = FALSE] %>% colnames()
      
      updateSelectInput(
        session = session,
        'cluster_group_row_var',
        choices = vars2 
      )
      updateSelectInput(
        session = session,
        'cluster_group_row_dim_names',
        choices = vars2 
      )
    }
  }
  
  if (input$cluster_dim == 'column' | input$cluster_dim == 'both') {
    col_vars <- .getdata_cube()$col_meta
    if (any(.allow(col_vars))) {
      vars2 <- col_vars[, .allow(col_vars), drop = FALSE] %>% colnames()
      
      updateSelectInput(
        session = session,
        'cluster_group_col_var',
        choices = vars2
      )
      updateSelectInput(
        session = session,
        'cluster_group_col_dim_names',
        choices = vars2 
      )
    }
  }
})

#data ui
output$cluster_data_ui <- renderUI({
  fluidRow(column(10,
                  column(4,
                         uiOutput('cluster_dim_ui')),
                  column(
                    12,
                    uiOutput('ui_hclust_scale'),
                    uiOutput('cluster_group_ui')
                  )))
  
})

#scale option
output$ui_hclust_scale <- renderUI({
  checkboxInput(inputId = "scale_hclust",
                label = "scale data",
                value = TRUE)
})

#not working - not working
# outputOptions(output, "ui_hclust_scale", suspendWhenHidden = FALSE)

#cor option
output$ui_cor_option <- renderUI({
  vars <-
    list(
      none = NA,
      "spearman" = "spearman",
      "kendall" = "kendall",
      "pearson" = "pearson"
    )
  selectInput(
    inputId = "cor_option",
    label = "Correlation:",
    choices = vars,
    multiple = FALSE
  )
})

#dist option
output$ui_dist_option <- renderUI({
  vars <-
    c("euclidean",
      "binary",
      "canberra",
      "manhattan",
      "maximum",
      "minkowski")
  selectInput(
    inputId = "dist_option",
    label = "Distance:",
    choices = vars,
    selected = "euclidean",
    multiple = FALSE
  )
})

#hclust option
output$ui_hclust_option <- renderUI({
  vars <-
    c(
      "complete",
      "average",
      "centroid",
      "mcquitty",
      "median",
      "single",
      "ward.D",
      "ward.D2"
    )
  selectInput(
    inputId = "hclust_option",
    label = "Linkage:",
    choices = vars,
    selected = "ward.D",
    multiple = FALSE
  )
})

#No of clusters
output$ui_cluster_k_group <- renderUI({
  #TODO need to control max based on number of groups
  numericInput(
    'cluster_k_group',
    label = "Number of clusters:",
    min = 1,
    max = 10,
    value = 3,
    step = 1
  )
})

#calculate button
output$ui_hclust_calculate <- renderUI({
  #check data
  
  actionButton("hclust_calculate", "Calculate", icon = icon('check'))
})

output$cluster_methods_ui <- renderUI({
  fluidRow(column(
    12,
    #h3('Methods:'),
    uiOutput('ui_cor_option'),
    uiOutput('ui_dist_option'),
    uiOutput('ui_hclust_option'),
    uiOutput('ui_cluster_k_group')
  ))
})

#init when UI is closed
#not working
# outputOptions(output, "ui_cor_option", suspendWhenHidden = FALSE)
# outputOptions(output, "ui_hclust_option", suspendWhenHidden = FALSE)
# outputOptions(output, "ui_cluster_k_group", suspendWhenHidden = FALSE)

#TODO state if column or row and haw many
hclust_save_text <- reactive({
  available <- hclust_available()
  if (available != 'available')
    return('Nothing calculated')
  
  type <- input$cluster_dim
  groups <- input$cluster_k_group
  if (is.null(groups))
    groups <- 3 #....
  
  paste('Save', groups, type, "clusters?")
  
})

# #save
# #Store data
output$ui_hclust_save <- renderUI({
  available <- hclust_available()
  if (available != 'available')
    return('Nothing calculated' %>% helpText())
  
  fluidRow(column(
    12,
    helpText(hclust_save_text()),
    tags$td(actionButton("hclust_save", "Save"), style = "padding-top:30px;")
  ))
})

# canvas ------------------------------------------------------------------

hclust_canvas <- callModule(vis_canvas_visInput, 'hclust')

#ugly glue to deal with null module vals
hclust_plot <- eventReactive(input$plot_hclust_activate, {
  # reactive({
  
  plh <- hclust_canvas()$height %>%
    {
      if (!is.null(.))
        .
      else
        700
    }
  plw <- hclust_canvas()$width %>%
    {
      if (!is.null(.))
        .
      else
        1100
    }
  
  list(width = plw, height = plh)
})


###############################
# renderUI output
###############################
output$ui_hclust <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel(
      condition = "input.tabs_hclust == 'Calculate'",
      tagList(
        fluidRow(column(12,
                        uiOutput(
                          'ui_hclust_calculate'
                        ))),
        br(),
        bs_accordion(id = "cluster_collapse_panel") %>%
          bs_append(
            title = tags$label(class = 'bsCollapsePanel', icon("circle") , "Nodes"),
            content =
              fluidRow(column(12,
                              uiOutput(
                                'cluster_data_ui'
                              )))
          ) %>%
          bs_append(
            title = tags$label(class = 'bsCollapsePanel', icon("cogs") , "Method"),
            content =
              fluidRow(column(12,
                              uiOutput(
                                'cluster_methods_ui'
                              )))
          ) %>%
          bs_append(
            title = tags$label(class = 'bsCollapsePanel', icon("save") , "Save"),
            content =
              fluidRow(column(12,
                              uiOutput('ui_hclust_save')))
          )
      )
    ),
    conditionalPanel(
      condition = "input.tabs_hclust != 'Calculate' & input.tabs_hclust != 'Report'",
      tagList(
        uiOutput('plot_hclust_activate_ui'),
        br(),
        bs_accordion(id = "cluster_plot_collapse_panel") %>%
          bs_append(
            title = tags$label(class = 'bsCollapsePanel', icon("bar-chart") , "Plot"),
            content =
              fluidRow(column(
                12,
                selectizeInput(
                  inputId = "hclust_plots",
                  label = "Plot type:",
                  choices = hclust_plots,
                  selected = state_multiple("hclust_plots", hclust_plots, "heatmap"),
                  multiple = FALSE
                )
              ))
          ) %>%
          bs_append(
            title = tags$label(class = 'bsCollapsePanel', icon("square") , "Canvas"),
            content =
              fluidRow(column(12,
                              vis_canvas_visUI('hclust')
                              # uiOutput('vis_canvas_plot_dim')))
                              
              )
              )
          )
      )
    ),
    fluidRow(column(
      12, align = "right", modalModuleUI(id = "hclust_help")
    ))
  )
})

###############################
# main functions
###############################

#initialize data
hclust_init <- reactive({
  .data <- .getdata_cube()$data
  
  #keep row and transpose data
  #to smoothly bind meta data
  type <- input$cluster_dim
  
  cor.opt <-
    if (is.null(input$cor_option) ||
        input$cor_option == 'NA')
      NULL
  else
    input$cor_option
  #starts null, can't initialize?
  dist.opt <-
    if (is.null(input$dist_option))
      'euclidean'
  else
    input$dist_option
  hclust.opt <-
    if (is.null(input$hclust_option))
      'ward.D'
  else
    input$hclust_option
  k_cluster <-
    if (is.null(input$cluster_k_group))
      3
  else
    input$cluster_k_group
  
  
  return(
    list(
      data = .data,
      type = type,
      cor.opt = cor.opt,
      dist.opt = dist.opt,
      hclust.opt = hclust.opt,
      k_cluster = k_cluster,
      scale = input$scale_hclust
    )
  )
})

annotate_hclust <- reactive({
  #meta data for groups and labels
  col_group <- row_group <- col_labels <- row_labels <- NULL
  if (input$cluster_dim == 'row' |
      input$cluster_dim == 'both') {
    .group <- .getdata_cube()$row_meta
    
    group <- input$cluster_group_row_var
    label <- input$cluster_group_row_dim_names
    
    row_group <-
      if (!is.null(group))
        .group %>% select(group)
    else
      NULL
    row_labels <-
      if (!is.null(label))
        .group %>% select(label)
    else
      NULL
    
  }
  
  if (input$cluster_dim == 'column' | input$cluster_dim == 'both') {
    .group <- .getdata_cube()$col_meta
    
    group <- input$cluster_group_col_var
    label <- input$cluster_group_col_dim_names
    
    col_group <-
      if (!is.null(group))
        .group %>% select(group)
    else
      NULL
    col_labels <-
      if (!is.null(label))
        .group %>% select(label)
    else
      NULL
  }
  
  return(
    list(
      col_group = col_group,
      row_group = row_group,
      col_labels = col_labels,
      row_labels = row_labels
    )
  )
  
  
})

hclust_available <- reactive({
  if (is.null(input$hclust_calculate) ||
      input$hclust_calculate == 0) {
    return(
      "Carry out hierarchical cluster analysis to calculate a hierarchy of sample and variable groups.  Select accordingly and then select calculate to proceed."
    )
  }
  if (is.na(input$hclust_calculate))
    return("Please choose a comparison value")
  "available"
})

#separate cluster, cut and annotate

observeEvent(input$hclust_calculate, {
  if (hclust_available() != "available")
    return(hclust_available())
  
  
  isolate({
    # msg<-'\u2713 Calculating...'#tags$label('Saving',icon('check')) %>% as.character() %>% HTML()
    # withProgress(message=msg,value=1,{
    hclust_values[['obj']] <-
      tryCatch(
        do.call('hca_clustering', hclust_init()),
        error = function(e) {
          NULL
        }
      )
    # })
  })
  
})

get_hclust_obj <- reactive({
  
  
  if (is.null(hclust_values[['obj']]))
    return()
  
  isolate({ # NEW
    obj <- cut(hclust_values[['obj']], hclust_init()$k_cluster)
    
    #collect meta data -no easy way to add dynamic fields
    . <- annotate_hclust()
    
    obj <-
      annotate_obj(
        obj,
        row_group = .$row_group,
        col_group = .$col_group,
        col_labels = .$col_labels,
        row_labels = .$row_labels
      )
    
    hclust_values[['obj']] <- obj
    
    return(hclust_values[['obj']])
  })
})

.summary_hclust <- reactive({
  
  
  #triggering twice
  if (hclust_available() != "available")
    return(hclust_available() %>% html_text_format(.))
  
  obj <-
    tryCatch(
      list(results = get_hclust_obj()),
      error = function(e) {
        list(error = 'Could not calculate', results = NULL)
      }
    )
  if (is.null(obj$results))
    return(obj$error)
  else
    obj <- obj$results
  
  msg <-
    '\u2713 Calculating...'#tags$label('Saving',icon('check')) %>% as.character() %>% HTML()
  out <- withProgress(message = msg, value = 1, {
    tryCatch(
      summary(obj),
      error = function(e) {
        as.character(e)
      }
    )
  })
  
  if(is.character(out)) return(out)
  
  
  list(
    desc=out$description %>% html_paragraph_format(.) %>% HTML(),
    row_table=hclust_table(out, 'row'),
    col_table = hclust_table(out, 'column')
  )
  
})

#separated to debug issues with reactive re rendering
summary_hclust_ui_obj<-function(){
  . <- .summary_hclust()
  
  row_desc<-col_desc<-NULL
  #need to control rendering of empty formattable
  row_table<-col_table<- formattable(data.frame(empty=logical())) # prevent render error
  
  # browser()
  
  if(!is.list(.)) .<-list(desc=.) # fix to return list upstream
  
  if (!is.null(.$row_table)) {
    row_desc<- h4('Sample clusters') 
    row_table<-.$row_table
    # row_table<-formattableOutput('hclust_row_table')
  }
  
  if (!is.null(.$col_table)) {
    col_desc<- h4('Variable clusters') 
    col_table<-.$col_table
    # col_table<-formattableOutput('hclust_col_table')
  }
  
  
  list(desc=HTML(.$desc),
       row_desc = row_desc,
       row_table = row_table,
       col_desc = col_desc,
       col_table = col_table
  )
}

output$summary_hclust_ui <- renderUI({
  
  
  tmp<-summary_hclust_ui_obj()
  
  if (nrow(tmp$row_table)>0) {
    tmp$row_table<-formattableOutput('hclust_row_table')
  } else {
    tmp$row_table<-NULL
  }
  
  if (nrow(tmp$col_table)>0) {
    tmp$col_table<-formattableOutput('hclust_col_table')
  } else {
    tmp$col_table<-NULL
  }
  
  fluidRow(tmp$desc,
           tmp$row_desc,
           tmp$row_table,
           tmp$col_desc,
           tmp$col_table
  )
  
  # fluidRow(HTML(.$desc),
  #          HTML(as.character(rnorm(1))),
  #          row_desc,
  #          row_table,
  #          col_desc,
  #          col_table
  #          )
  
  
})

#create tables for row clusters
output$hclust_row_table <-
  renderFormattable({
    
    summary_hclust_ui_obj()$row_table
    
    #WTF!!!!
    
    # . <- .summary_hclust()
    # if (!is.list(.) && is.null(.$row_table)) return(data.frame(NULL))
    # 
    # .$row_table
  })

output$hclust_col_table <-
  renderFormattable({
    
    summary_hclust_ui_obj()$col_table
    
    # . <- .summary_hclust()
    # if (!is.list(.) && is.null(.$col_table)) return(data.frame(NULL))
    # 
    # .$col_table
  })


output$plot_hclust_activate_ui <- renderUI({
  fluidRow(column(
    12,
    align = 'left',
    actionButton('plot_hclust_activate', 'Plot', icon = icon('check'))
  ))
})


#plotting
#-----

.plot_hclust <- eventReactive(input$plot_hclust_activate, {
  # reactive({
  
  
  msg <- hclust_available()
  
  isolate({
    validate(need(msg == "available", msg))
    #if (hclust_available() != "available") return(hclust_available())
    
    #need to isolate better below
    #or make interactive added to plot later
    #TODO CHECK!
    # if (!input$tabs_hclust %in% c('Plot', 'Explore'))
    #   return()
    
    obj <- get_hclust_obj()
    
    validate(need(!is.null(obj) == TRUE, 'Not available'))
    
    .type <- input$hclust_plots
    
    #need to create separate plots for both dendrograms
    if (.type == 'dendrogram' & obj$method$type == 'both') {
      .obj <- obj
      .obj$method$type <- 'row'
      row_dend <-
        list(fun = 'plot',
             args = list(.obj, type = .type, plot = FALSE))
      .obj <- obj
      .obj$method$type <- 'column'
      col_dend <-
        list(fun = 'plot',
             args = list(.obj, type = .type, plot = FALSE))
      hclust_values[['plot_obj']] <- list(row_dend, col_dend)
    } else {
      hclust_values[['plot_obj']] <-
        list(list(
          fun = 'plot',
          args = list(obj, type = .type, plot = FALSE)
        ))
    }
    
    return(hclust_values[['plot_obj']])
    
  })
})

get_plot_obj <- eventReactive(input$plot_hclust_activate,{
  msg <- hclust_available()
  
  isolate({
    validate(need(msg == "available", msg))
    
    
    if (!input$tabs_hclust %in% c('Explore','Plot'))
      return()
    p <- .plot_hclust()
    
    validate(need(!is.null(p), 'Error plotting'))
    
    return(p)
    
  })
})

#interactive plot
#handling of for multiple dendrograms
output$explore_hclust1 <- renderIheatmap({
  
  p <- get_plot_obj()
  if(is.null(p)) return()  #when in plot tab
  msg <- '\u2713 Plotting...'
  i <- p[[1]]
  
  withProgress(message = msg, value = 1, {
    do.call(i$fun, i$args)
  })
  
})

output$explore_hclust2 <- renderIheatmap({
  
  p <- get_plot_obj()
  if(is.null(p)) return()  #when in plot tab
  msg <- '\u2713 Plotting...'
  
  if (length(p) > 1) {
    i <- p[[2]]
    
    withProgress(message = msg, value = 1, {
      do.call(i$fun, i$args)
    })
    
  } else {
    return()
  }
  
})

#render interactive explore
output$explore_hclust_ui <- renderUI({
  fluidRow(column(
    12,
    iheatmaprOutput(
      'explore_hclust1',
      width = hclust_plot()$width,
      height = hclust_plot()$height
    )
  ),
  column(
    12,
    iheatmaprOutput(
      'explore_hclust2',
      width = hclust_plot()$width,
      height = hclust_plot()$height
    )
  ))
  
})

#collect plot type and object
#use in report
#reference saved plots
observe({
  input$dataset
  isolate({
    hclust_plots <- reactiveVal()
  })
})

#create static plots, used in plot and/or report if plot is absent
hclust_static_plot<-function(i=NULL){
  
  # i <- reactiveValuesToList(hclust_values)[['plot_obj']][[1]]
  
  #create image
  msg <- '\u2713 Plotting...'
  withProgress(message = msg, value = 1, {
    if (is.null(i)) {
      # Generate an empty png
      outfile <- tempfile(fileext = '.png') %>% normalizePath(.,winslash = '/') # need this for pdf conversion
      png(outfile, width = 1, height = 1)
      dev.off()
      i[['src']] = outfile
      
    } else {
      x <- invisible(do.call(i$fun, i$args))
      
      file <- tempfile(tmpdir = tempdir(), fileext = ".png") %>% normalizePath(.,winslash = '/') 
      x %>% save_iheatmap(file)
      i[['src']] <- file
      
    }
  })  
  
  i[['contentType']] <- "image/png"
  
  return(i)
}

#render static plots


#plot static
#static plot - render image from explore
output$plot_hclust1 <- renderImage({
  hclust_available()
  
  input$plot_hclust_activate
  #trigger plot if explore is not triggered yet
  
  isolate({
    
    p<-get_plot_obj()
    
    
    i <-
      hclust_static_plot(p[[1]])
    
    if (is.null(i)) {
      shiny::showNotification('Calculate before plotting.', type = 'warning')
      return()
    }
    
    hclust_report_values[[i$args$type]][['plot1']] <-
      i # save for report
    
    
    return(list(src = i[['src']],
                contentType = i[['contentType']]))
  })
}, deleteFile = FALSE)

output$plot_hclust2 <- renderImage({
  
  hclust_available()
  input$plot_hclust_activate
  
  #first plot is trigger
  isolate({
    obj<-tryCatch(reactiveValuesToList(hclust_values)[['plot_obj']][[2]], error=function(e){}) # can be empty
    
    
    i <- hclust_static_plot(obj)
    
    #if empty copy args from non empty
    if(is.null(obj)){
      type<-reactiveValuesToList(hclust_values)[['plot_obj']][[1]]$args$type
    } else {
      type<-i$args$type
    }
    
    
    hclust_report_values[[type]][['plot2']] <-
      i # save for report
    
    
    return(list(src = i[['src']],
                contentType = i[['contentType']]))
  })
}, deleteFile=FALSE)


output$plot_hclust_ui <- renderUI({
  fluidRow(column(
    12,
    plotOutput(
      "plot_hclust1",
      width = hclust_plot()$width,
      height = hclust_plot()$height
    )
  ),
  tryCatch(
    column(
      12,
      plotOutput(
        "plot_hclust2",
        width = hclust_plot()$width,
        height = hclust_plot()$height
      )
    ),
    error = function(e) {
    }
  ))
})

output$hclust <- renderUI({
  hclust_output_panels <- tabsetPanel(
    id = "tabs_hclust",
    tabPanel(
      "Calculate",
      icon = icon("sliders"),
      uiOutput('summary_hclust_ui')
    ),
    #verbatimTextOutput("summary_hclust")
    tabPanel(
      "Explore",
      icon = icon('pencil-square-o'),
      uiOutput("explore_hclust_ui", height = "100%")
    ),
    tabPanel("Plot", icon = icon("bar-chart"),
             uiOutput('plot_hclust_ui')),
    tabPanel(
      "Report",
      icon = icon('file-text-o'),
      tabPanel("Report", reportGeneratorUI('hclust'))
    )
  )
  
  stat_tab_panel(
    menu = tags$span(class = 'cer_menue', HTML(paste0(
      icon('snowflake-o'), as.character(" Clustering")
    ))),
    tool = tags$span(class = 'cer_menue', HTML(paste0(
      icon('sitemap'), as.character(" Hierarchical (HCA)")
    ))),
    tool_ui = "ui_hclust",
    output_panels = hclust_output_panels
  )
})



#save cluster information
observeEvent(input$hclust_save, {
  #control adding meta data
  obj <- .getdata_cube()
  names <- .makedata_cube_names(input$dataset)
  .names <- list(NULL)
  res <- hclust_values[['hclust_row']]$group$hca_cluster
  if (!is.null(res)) {
    obj$row_meta$hca_cluster <- res
    r_data[[names$row]] <- obj$row_meta
    .names <- c(.names, names$row)
  }
  
  
  res <- hclust_values[['hclust_col']]$group$hca_cluster
  if (!is.null(res)) {
    obj$col_meta$hca_cluster <- res
    r_data[[names$col]] <- obj$col_meta
    .names <- c(.names, names$col)
  }
  
  #data cube obj won't be null
  #but the datasetlist might be null
  if (!is.null(.names)) {
    add_data <- .names[!.names %in% r_data[['datasetlist']]] %>% unlist()
    if (length(add_data) > 0) {
      r_data[['datasetlist']] %<>% c(add_data, .) %>% unique # don't need any more?
    }
  }
  
  msg <-
    '\u2713 Saving'#tags$label('Saving',icon('check')) %>% as.character() %>% HTML()
  withProgress(message = msg, value = 1, {
    Sys.sleep(.15)
  })
  
})
