
source(system.file(package='dave.app','app/global.R'),local = TRUE)