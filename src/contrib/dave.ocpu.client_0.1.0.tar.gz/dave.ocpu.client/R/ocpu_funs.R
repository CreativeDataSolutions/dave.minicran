
# dave.help.uils ----------------------------------------------------------


#' @title ocpu_get_help_html
#' @param connection
#' @param body
#' @param pkg_url
#' @param return_value
#'
#' @return
#' @export
#'
#' @examples
ocpu_get_help_html  <-
  function(connection,
           body = NULL,
           pkg_url =  'ocpu/library/dave.help.utils/R/get_help_html',
           return_value = TRUE) {

    ocpu_post(
      connection,
      body = body,
      pkg_url = pkg_url,
      encode = 'json',
      return_value = return_value
    )
  }

# dave.ml -------------------------------------------------------

#' @title ocpu_multi_create_predictive_mode
#' @param connection
#' @param body
#' @param pkg_url
#'
#' @return
#' @export
#'
#' @examples
ocpu_multi_create_predictive_model  <-
  function(connection,
           body = NULL,
           pkg_url =  'ocpu/library/dave.ml/R/multi_create_predictive_model',
           return_value = FALSE) {

    ocpu_post(
      connection,
      body = body,
      pkg_url = pkg_url,
      encode = 'form',
      return_value = return_value
    )
  }


#' @title  ocpu_create_fit_control
#' @param connection
#' @param body
#' @param pkg_url
#'
#' @return
#' @export
#'
#' @examples
ocpu_create_fit_control<-function(connection,
                                  body = NULL,
                                  pkg_url =  'ocpu/library/dave.ml/R/create_fit_control',
                                  return_value = FALSE) {

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )

}

#' @title ocpu_get_model_perf
#' @export
#' @import ocpuclient
ocpu_get_model_perf <- function(connection,
                                body = NULL,
                                pkg_url = 'ocpu/library/dave.ml/R/.ocpu_get_model_perf',
                                return_value = TRUE) {
  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'form',
    return_value = return_value
  )

}


# dave.ml rfe -------------------------------------------------------------

#' @title ocpu_create_rfe_control
#' @export
#' @import ocpuclient
ocpu_create_rfe_control <- function(connection,
                                    body = NULL,
                                    pkg_url = 'ocpu/library/dave.ml/R/create_rfe_control',
                                    return_value=FALSE) {
  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'form',
    return_value = return_value
  )

}

#' @title ocpu_create_rfe
#' @export
#' @import ocpuclient
ocpu_create_rfe <- function(connection,
                            body = NULL,
                            pkg_url = 'ocpu/library/dave.ml/R/create_rfe',
                            return_value = FALSE) {

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'form',
    return_value = return_value
  )

}

#' @title ocpu_rebuild_rfe
#' @param connection
#' @param body
#' @param pkg_url
#'
#' @return
#' @export
#'
#' @examples
ocpu_rebuild_rfe <- function(connection,
                            body = NULL,
                            pkg_url = 'ocpu/library/dave.ml/R/rebuild_rfe',
                            return_value = TRUE) {

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'form',
    return_value = return_value
  )

}


# dave.ml general ---------------------------------------------------------


#' @title ocpu_create_model_data
#' @export
#' @import ocpuclient
ocpu_create_model_data<-function(connection,
                                 body=NULL,
                                 pkg_url = 'ocpu/library/dave.ml/R/create_model_data',
                                 return_value=FALSE){

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )

}



# dave.multivariate -------------------------------------------------------

#' @title ocpu_dvmPCA_methods
#' @export
#' @import ocpuclient
ocpu_dvmPCA_methods  <- function(connection,
                                 body = NULL,
                                 pkg_url = 'ocpu/library/dave.multivariate/R/dvmPCA_methods',
                                 return_value = TRUE) {

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )
}


#' @title ocpu_dvmPCA
#' @export
#' @import ocpuclient
ocpu_dvmPCA  <- function(connection,
                         body = NULL,
                         pkg_url = 'ocpu/library/dave.multivariate/R/dvmPCA',
                         return_value = TRUE) {

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )

}



# dave.pathway ------------------------------------------------------------

#' @title ocpu_pathway_mapping
#' @export
#' @details drop in replacement for dave.pathway::pathway.mapping
ocpu_pathway_mapping <-
  function(connection,
           body = NULL,save.dir='.') {

    results <-
      ocpu_pathway_mapping_call(dave_path_connection,body=body)

     ocpu_get_pathway_image(connection,results,save.dir=save.dir)
  }

#' @title ocpu_pathway_mapping
#' @import ocpuclient
ocpu_pathway_mapping_call  <- function(connection,
                                       body = NULL,
                                       pkg_url = 'ocpu/library/dave.pathway/R/pathway.mapping',
                                       return_value =TRUE) {

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )

}

#' @title get_ocpu_pathway_mapping
#' @import png httr ocpuclient
#' @details download image file from ocpu server
ocpu_get_pathway_image<-function(connection,results,save.dir='.'){

  .results<-results$results
  file<-.results$inputs$image

  # img<-ocpu_get(connection,path=file) # getting 404 for crul$get?

  tmp<-unlist(strsplit(file,'/'))
  key<-tmp[4]
  .file<-basename(file)
  #account for proxy
  url<-paste0(connection$url,handle_proxy(connection,paste0('ocpu/tmp/',key,'/files/',.file)))

  img<-content(GET(url))

  .file<-paste0(save.dir,'/',.file)
  writePNG(img,.file)

  .results$inputs$image<-.file

  .results

}


# dave.stats --------------------------------------------------------------

#' @title ocpu_kruskal_test
#' @export
#' @import ocpuclient
ocpu_kruskal_test  <- function(fun='.ocpu_kruskal_test',
                                   body=NULL,
                                   pkg_url = getOption('dave.stats_url'),
                                   base_url = getOption('open_cpu_url')) {

  ocpu_call(fun,
            body,
            pkg_url,
            base_url)
}

# dave.network ------------------------------------------------------------

#' @title ocpu_metabolic_network
#' @export
#' @import ocpuclient
ocpu_metabolic_network  <- function(connection,
                                    body = NULL,
                                    pkg_url = 'ocpu/library/dave.network/R/metabolic_network',
                                    return_value = TRUE) {

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )

}

#get DB infor for debugging
#' @title ocpu_CID_SDF_DB_stats
#' @export
#' @import ocpuclient
ocpu_CID_SDF_DB_stats  <- function(connection,
                                   body = NULL,
                                   pkg_url = 'ocpu/library/dave.network/R/CID_SDF_DB_stats',
                                   return_value = TRUE) {

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )

}


#' @title ocpu_get_cor_mat
#' @export
#' @import ocpuclient
ocpu_get_cor_mat <- function(connection,
                             body = NULL,
                             pkg_url = 'ocpu/library/dave.network/R/get_cor_mat',
                             return_value = FALSE) {

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )

}

#' @title ocpu_get_huge_obj
#' @export
#' @import ocpuclient
ocpu_get_huge_obj <- function(connection,
                              body = NULL,
                              pkg_url = 'ocpu/library/dave.network/R/get_huge_obj',
                              return_value = FALSE) {

 #TODO: only care about returning the lambda

   ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )

}

#' @title ocpu_get_huge_edges
#' @export
#' @import ocpuclient
ocpu_get_huge_edges <- function(connection,
                                body = NULL,
                                pkg_url = 'ocpu/library/dave.network/R/get_huge_edges',
                                return_value = TRUE) {

  body<- format_crul_input(body)

  ocpu_post(
    connection,
    body = body,
    pkg_url = pkg_url,
    encode = NULL,
    return_value = return_value
  )

}

