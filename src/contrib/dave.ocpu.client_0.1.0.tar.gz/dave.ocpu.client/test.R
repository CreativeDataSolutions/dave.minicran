#set server urls
library(dave.ocpu.client)
source(system.file('app/src/API.R',package='dave.app'))

# #dev functions
# .get_ocpu_obj<-function(session,connection){
#
#   .url<-connection$url
#   session_url<-paste0(.url,'ocpu/tmp/',session,'/R/.val/rds')
#   readRDS(gzcon(curl::curl(session_url)))
# }



# dave.help.utils ---------------------------------------------------------
#no API calling in package? or need to install dave.help on the server
# dave_ml_connection <- HttpClient$new(url = getOption("open_cpu_url"),opts = list(timeout = 10))


#model help
body<-list(fun = "randomForest", lib = "randomForest")
ocpu_get_help_html(dave_ml_connection,body)



# dave.ml -------------------------------------------------------
# options('open_cpu_url' = 'http://localhost:8085/') # local dev

# #need connection for each endpoint
# set_headers( 'Content-Type' = 'application/json')
# dave_ml_connection <- HttpClient$new(url = getOption("open_cpu_url"),opts = list(timeout = 10))


# #small testing data
# #----------------
small_class<-function(){
  data("mtcars")
  tmp<-mtcars

  #binary
  library(dplyr)
  tmp$vs<-factor(tmp$vs%>% make.names())
  y<-'vs'

  .metric<-'Accuracy'
  .method<-c('rf')#'rf'#'pls'#AdaBoost.M1'#'pls'
  classProbs<-TRUE
  tuneN<-1
  tuneGrid<-NULL
}

#dave class
dave_class<-function(){
  library(dave.stat)
  data("dave_data")

  tmp<-dave_data
  y<-'class'
  .y<-dave_data_row_meta$class
  tmp[y]<-.y


  .metric<-'Accuracy'
  .method<-c('rf')#'rf'#'pls'#AdaBoost.M1'#'pls'
  classProbs<-TRUE
  tuneN<-1
  tuneGrid<-NULL
}


#make train test data
body<-list(data=tmp,y=y)
.data<-ocpu_create_model_data(dave_ml_connection ,body=body)

# get_ocpu_obj(ocpu_session(.data))

#define cross validation
body<-list(method="repeatedcv",num=7,rep=3,classProbs=classProbs)  #this need to be flattened to a string
fitControl <- ocpu_create_fit_control(dave_ml_connection ,body=body)
# get_ocpu_obj(ocpu_session(fitControl))


# create model
# # #---------------
body <-
  list(
    data = .data,
    y = y,
    metric = .metric,
    method = .method,
    fitControl = fitControl,
    tuneN = tuneN,
    tuneGrid = tuneGrid,
    seed= 1234
  )



mod<-ocpu_multi_create_predictive_model(dave_ml_connection ,body = body)

#local debug
.mod<-get_ocpu_obj("x090ae30108c444",open_cpu_url=dave_ml_connection$url %>% sub('^/?(.*?)/?$', '\\1', .))
dave.ml.app::get_model_perf(.mod,select_best='train')
dave.ml.app::summary.model_list(.mod)
# mod_res<-ocpu_get_model_perf(dave_ml_connection ,body = body)$results
# get_ocpu_obj('x0ac4acb6ae90c')

#summary
body<-list(multi_mod=mod)
mod_res<-ocpu_get_model_perf(dave_ml_connection ,body = body)$results # API call

mod_res<-ocpu_get_model_perf(dave_ml_connection ,body = body)$results

#show best summary
library(dave.help)
list(
  description = paste0(mod_res$description, mod_res$best$description, collapse = ' ') %>% html_paragraph_format(.),
  table = mod_res$table[,-(ncol(mod_res$table)), drop = FALSE],
  best = list(
    description = mod_res$best$description %>% html_paragraph_format(.),
    table = mod_res$best
  )
)

#RFE - recursive feature selection
#----

func<-'rfFuncs'
# eval(parse(text=func))
body<-list(func=func)
ctrl<-ocpu_create_rfe_control(dave_ml_connection ,body) # get session
# get_ocpu_obj(ocpu_session(ctrl))

#create RFE model
#train.data
body<-list(obj=.data,
           name='train.data')

train_data<-get_ocpu_list_item(dave_ml_connection ,body)
# get_ocpu_obj(ocpu_session(train_data))  #this needs to be fixed to work with a proxy -- currently modified in post_ocpu

# subset<-seq(1,ncol(get_ocpu_obj(ocpu_session(train_data))),by=5)
tuneLength<-1
seed<-123

#need to create subset
#debug inputs serialization
connection <- dave_ml_connection
body <- list(from=1,to=5,by=1)
pkg_url <-  'ocpu/library/base/R/seq'
return_value <- FALSE

.subset<-ocpu_post(
  connection,
  body = body,
  pkg_url = pkg_url,
  encode = 'json',
  return_value = return_value
)

#RFE feature selection
body <-
  list(data = train_data,
       y = y,
       subset = .subset,
       ctrl = ctrl,
       tuneLength = tuneLength,
       seed = seed)


rfe<-ocpu_create_rfe(dave_ml_connection ,body)
connection<-dave_ml_connection


obj<-.get_ocpu_obj(ocpu_session(rfe),dave_ml_connection)
plot(obj)

#pick subset
best<- 'PickSizeBest' #'pickSizeTolerance' #"PickSizeBest"#'pickSizeTolerance'
metric<-'ROC'
body<-list(rfRFE=rfe,best=best, metric=metric)

best<- 'pickSizeTolerance'
tolerance<-5
body<-list(rfRFE=rfe,best=best,tolerance=tolerance)


#get top model variables
selected_rfe<-ocpu_rebuild_rfe(dave_ml_connection ,body)
.selected_rfe<-get_ocpu_obj(ocpu_session(selected_rfe))


#get variables
.selected_rfe$selected

library(dave.ml.app)
plot(.selected_rfe,metric = metric)
summary(.selected_rfe)


# CTSgetR -----------------------------------------------------------------
options('open_cpu_url' = 'http://localhost:8084/ocpu/')
library(ocpuclient)
library(dave.ocpu.client)

#ocpu server handle
ctsgetr_connection <- HttpClient$new(url = getOption("open_cpu_url"),opts = list(timeout = 10000))


trans_args<-function(){list(url = "http://localhost:8084/ocpu/library/CTSgetR/R/CTSgetR", body = list(
  id = c("C00310", "C00379", "C01762", "C00385", "C00183",
         "C02067", "C00299", "C00366", "C00086", "C00106", "C00082",
         "C00078", "", "C06771", "C01083", "C01157", "C02477", "C00178",
         "C00214", "C00188", "", "", "C00245", "D09007", "C00059",
         "C00089", "C00042", "C01530", "C00794", "C08250", "C00493",
         "C00065", "C00213", "C00818", "C00199", "C00121", "C00474",
         "C00507", "C00022", "C00013", "", "C02457", "C00148", "",
         "C00009", "C00346", "", "C00079", "C07086", "C01601", "C00864",
         "C08362", "C00249", "C01879", "C00209", "C00295", "C00077",
         "C00712", "C02721", "C00253", "C00153", "", "", "C00624",
         "", "C00645", "C03136", "", "C02989", "C00073", "", "", "C00208",
         "C00149", "C07272", "", "C00047", "C06427", "C01595", "C01725",
         "", "C02679 ", "", "C00186", "C00328", "", "C00407", "C00311",
         "", "", "C00294", "C02043", "C00954", "C16526", "C00262",
         "C00192", "", "C05629", "C00263", "C01817", "C00135", "",
         "C00387", "C00160", "C00037", "C00093", "C05401", "C00258",
         "C00489", "C00064", "C00025", "C00191", "C00092", "C00031",
         "C00257", "", "C00446", "C00124", "C00880", "C01235", "C00122",
         "C01018", "C01019", "C00085", "C00095", "C00189", "C00503",
         "C08374", "", "C00112", "", "C00097", "C00791", "", "C00327",
         "C00158", "C00695", "C00187", "", "C06423", "C01571", "C03044",
         "C00099", "C00180", "C08281", "C00049", "C00152", "", "C06425",
         "C01904", "C00259", "C00872", "C00026", "C01551", "C00499",
         "C00041", "C06104", "C00020", "C00212", "C00417", "C05659",
         "", "C01015", "C07588", "C00989", "C00156", "", "C00197",
         "", "C01013", "C01089", "", "C06474", "", "C00629", "C02112",
         "C00233", "", "C02630", "C05984", "", "", "C00956", "", "D01947",
         "", "C01885", "C07326"), from = "KEGG", to = c("KEGG", "InChIKey"
         ), db_name = "/ctsgetr/inst/ctsgetr.sqlite", from_obj = "KEGG"))}


body<-trans_args()$body

x<-ocpu_post(
  ctsgetr_connection,
  body = body,
  pkg_url = 'ocpu/library/CTSgetR/R/CTSgetR',
  encode = 'json',
  return_value = TRUE
)

x$results

# dave.multivariate -------------------------------------------------------
options('open_cpu_url' = 'http://localhost:8083/ocpu/')
# library(ocpuclient)
library(dave.ocpu.client)

#ocpu server handle
dave_multivariate_connection <- HttpClient$new(url = getOption("open_cpu_url"),opts = list(timeout = 10000))


x<-ocpu_dvmPCA_methods(dave_multivariate_connection)
x$results

#PCA
library(dave.multivariate.app)
data("dave_data")
data<-dave_data


body <- list(
  data=data,
  pca.components = 2,
  pca.cv = 'q2',
  pca.algorithm = "svd",
  pca.center = TRUE,
  pca.scaling = "uv",
  seed = 123,
  return = "list"
)

x<-ocpu_dvmPCA(dave_multivariate_connection,body=body)
.pca<-x$results
summary(.pca)
p<-plot(.pca)
ggplotly(p)


# dave.network ------------------------------------------------------------
options('open_cpu_url' = 'http://localhost:8081/ocpu/')
options('open_cpu_url' = 'http://ec2-52-22-43-130.compute-1.amazonaws.com/network/')
library(dave.ocpu.client)
#ocpu server handle
dave_network_connection <- HttpClient$new(url = getOption("open_cpu_url"),opts = list(timeout = 10000))


library(dave.network.app)
data("dave_network")
data("dave_network_col_meta")

#chemical similarity
data<-dave_network_col_meta
idcolumn<-'CID'
net_index<-'id'
type<-'CID'
DB <- '/open_cpu/CID.SDF.DB'


body<-list(data=data,
           idcolumn=idcolumn,
           type = type,
           net_index = net_index,
           DB=DB)

net <-
  ocpu_metabolic_network(dave_network_connection, body = body)

#biochemical
data<-dave_network_col_meta
idcolumn<-'KEGG'
net_index<-'id'
type<-'KEGG'
DB <- '/open_cpu/CID.SDF.DB'


body<-list(data=data,
           idcolumn=idcolumn,
           type = type,
           net_index = net_index,
           DB=DB)

net <-
  ocpu_metabolic_network(dave_network_connection, body = body)


body<-list(DB=DB)
ocpu_CID_SDF_DB_stats(dave_network_connection, body = body)



#-----empirical network
options('open_cpu_url' = 'http://localhost:8081/ocpu/')
# library(ocpuclient)
library(dave.ocpu.client)

#ocpu server handle
dave_network_connection <- HttpClient$new(url = getOption("open_cpu_url"),opts = list(timeout = 10000))


library(dave.network.app)

data("dave_network")
tmp_data<-dave_network

#calculate correlations edgelist
#--------
body <- list(
  data = tmp_data,
  cor_method = 'spearman',
  cor_FDR = TRUE,
  cor_cutoff = .05,
  lambda = NULL,
  huge_method = 'manual'
)

x <-
  ocpu_get_cor_mat(dave_network_connection,
                   body = body)


#regularize and select
body <-
  list(
    data = tmp_data,
    nlambda = 10,
    paranorm = TRUE,
    lambda.min.ratio = .1,
    check.cor = FALSE
  )


huge_obj<-
  ocpu_get_huge_obj(dave_network_connection,
                    body = body,
                    return_value = TRUE)

# get_ocpu_obj(ocpu_session(huge_edges))
names(huge_obj$results) #$lambda

body <-
  list(
    huge_obj=huge_obj,
    lambda=NULL, #round(huge_obj$results$lambda[5],4), # legacy shenanigans for manual
    opt='stars'
  )

huge_edges<-
  ocpu_get_huge_edges(dave_network_connection,
                      body = body)



# dave.pathway ------------------------------------------------------------
# library(dave.pathway)
options('open_cpu_url' = 'http://localhost:8082/ocpu/')
# library(ocpuclient)
library(dave.ocpu.client)

#ocpu server handle
dave_path_connection <- HttpClient$new(url = getOption("open_cpu_url"),opts = list(timeout = 10000))



#small data object for testing
small_x<-function(){
  x <-
    structure(
      list(
        data = structure(
          list(
            id = structure(
              c(2L, 1L),
              .Label = c("C00236",
                         "C00668"),
              class = "factor"
            ),
            FC = c(-1, 1)
          ),
          .Names = c("id", "FC"),
          row.names = c(NA,-2L),
          class = "data.frame"
        ),
        kegg.col = "id",
        cpd.FC = "FC",
        pathway.code = "hsa00030",
        organism.code = "hsa",
        work.dir = "inst/app/tools/ptw/figures",
        suffix = "Map_aq_data_stat"
      ),
      .Names = c(
        "data",
        "kegg.col",
        "cpd.FC",
        "pathway.code",
        "organism.code",
        "work.dir",
        "suffix"
      )
    )
}

test_obj<-function(){
  list(data = structure(list(ID = c("var1", "var2", "var3", "var4",
                                    "var5", "var6", "var7", "var8", "var9", "var10", "var11", "var12",
                                    "var13", "var14", "var15", "var16", "var17", "var18", "var19",
                                    "var20", "var21", "var22", "var23", "var24", "var25", "var26",
                                    "var27", "var28", "var29", "var30", "var31", "var32", "var33",
                                    "var34", "var35", "var36", "var37", "var38", "var39", "var40",
                                    "var41", "var42", "var43", "var44", "var45", "var46", "var47",
                                    "var48", "var49", "var50", "var51", "var52", "var53", "var54",
                                    "var55", "var56", "var57", "var58", "var59", "var60", "var61",
                                    "var62", "var63", "var64", "var65", "var66", "var67", "var68",
                                    "var69", "var70", "var71", "var72", "var73", "var74", "var75",
                                    "var76", "var77", "var78", "var79", "var80", "var81", "var82",
                                    "var83", "var84", "var85", "var86", "var87", "var88", "var89",
                                    "var90", "var91", "var92", "var93", "var94", "var95", "var96",
                                    "var97", "var98", "var99", "var100", "var101", "var102", "var103",
                                    "var104", "var105", "var106", "var107", "var108", "var109", "var110",
                                    "var111", "var112", "var113", "var114", "var115", "var116", "var117",
                                    "var118", "var119", "var120", "var121", "var122", "var123", "var124",
                                    "var125", "var126", "var127", "var128", "var129", "var130", "var131",
                                    "var132", "var133", "var134", "var135", "var136", "var137", "var138",
                                    "var139", "var140", "var141", "var142", "var143", "var144", "var145",
                                    "var146", "var147", "var148", "var149", "var150", "var151", "var152",
                                    "var153", "var154", "var155", "var156", "var157", "var158", "var159",
                                    "var160", "var161", "var162", "var163", "var164", "var165", "var166",
                                    "var167", "var168", "var169", "var170", "var171", "var172", "var173",
                                    "var174", "var175", "var176", "var177", "var178", "var179", "var180",
                                    "var181", "var182", "var183", "var184", "var185", "var186", "var187",
                                    "var188"), name = c("xylulose", "xylitol", "xanthosine", "xanthine",
                                                        "valine", "uridine", "uridine", "uric acid + myo-inositol", "urea",
                                                        "uracil", "tyrosine", "tryptophan", "trisaccharide", "triethanolamine",
                                                        "trehalose", "trans-4-hydroxyproline", "tocopherol alpha", "thymine",
                                                        "thymidine", "threonine", "threonic acid", "threitol", "taurine",
                                                        "tagatose", "sulfuric acid", "sucrose", "succinic acid", "stearic acid",
                                                        "sorbitol", "sophorose", "shikimic acid", "serine", "sarcosine",
                                                        "saccharic acid", "ribulose-5-phosphate", "ribose", "ribitol",
                                                        "rhamnose", "pyruvic acid", "pyrophosphate", "pyrazine 2,5-dihydroxy",
                                                        "propane-1,3-diol", "proline", "pipecolic acid", "phosphoric acid",
                                                        "phosphoethanolamine", "phenylethylamine", "phenylalanine", "phenylacetic acid",
                                                        "pelargonic acid", "pantothenic acid", "palmitoleic acid", "palmitic acid",
                                                        "oxoproline", "oxalic acid", "orotic acid", "ornithine", "oleic acid",
                                                        "N-methylalanine", "nicotinic acid", "nicotinamide", "N-hexanoylglycine",
                                                        "N-acetylglycine", "N-acetylglutamate", "N-acetyl-D-tryptophan",
                                                        "N-acetyl-D-mannosamine", "N-acetyl-D-hexosamine", "methylhexadecanoic acid",
                                                        "methionine sulfoxide", "methionine", "methanolphosphate", "melibiose",
                                                        "maltose", "malic acid", "maleimide", "lyxose", "lysine", "linolenic acid",
                                                        "linoleic acid", "levanbiose", "leucine", "lauric acid", "lactobionic acid",
                                                        "lactic acid", "kynurenine", "isothreonic acid", "isoleucine",
                                                        "isocitric acid", "inulotriose", "inositol allo-", "inosine",
                                                        "indole-3-lactate", "indole-3-acetate", "icosenoic acid", "hypoxanthine + ornithine",
                                                        "hydroxylamine", "hydroxycarbamate", "hydrocinnamic acid", "homoserine",
                                                        "homocystine", "histidine", "hexuronic acid", "guanosine", "glycolic acid",
                                                        "glycine", "glycerol-alpha-phosphate", "glycerol-3-galactoside",
                                                        "glyceric acid", "glutaric acid", "glutamine", "glutamic acid",
                                                        "glucuronic acid", "glucose-6-phosphate", "glucose", "gluconic acid",
                                                        "glucoheptose", "galactose-6-phosphate", "galactose", "galactonic acid",
                                                        "galactinol", "fumaric acid", "fucose + rhamnose", "fucose",
                                                        "fructose-6-phosphate", "fructose", "ethanolamine", "erythritol",
                                                        "dodecane", "digalacturonic acid", "cytidine-5'-diphosphate",
                                                        "cystine", "cysteine", "creatinine", "conduritol beta epoxide",
                                                        "citrulline", "citric acid", "cholic acid", "cholesterol", "cellobiotol",
                                                        "caprylic acid", "capric acid", "butane-2,3-diol", "beta-alanine",
                                                        "benzoic acid", "behenic acid", "aspartic acid", "asparagine",
                                                        "arachidonic acid", "arachidic acid", "arabitol", "arabinose",
                                                        "aminomalonic acid", "alpha ketoglutaric acid", "allantoin",
                                                        "allantoic acid", "alanine", "adipic acid", "adenosine-5-phosphate",
                                                        "adenosine", "aconitic acid", "5-methoxytryptamine", "5-hydroxyindole-3-acetic acid",
                                                        "4-hydroxyproline", "4-hydroxyhippuric acid", "4-hydroxybutyric acid",
                                                        "4-hydroxybenzoate", "3-ureidopropionate", "3-phosphoglycerate",
                                                        "3-methyl-1-oxobutylglycine", "3-hydroxypropionic acid", "3-hydroxybutanoic acid",
                                                        "3,6-dihydro-3,6-dimethyl-2,5-bishydroxypyrazine", "3,6-anhydrogalactose",
                                                        "3,6-anhydro-D-hexose", "2-oxogluconic acid", "2-monoolein",
                                                        "2-ketoisocaproic acid", "2-hydroxyvaleric acid", "2-hydroxyglutaric acid",
                                                        "2-hydroxybutanoic acid", "2-hydroxy-2-methylbutanoic acid",
                                                        "2-deoxytetronic acid", "2-aminoadipic acid", "2,3-dihydroxybutanoic acid",
                                                        "1-monostearin", "1-monopalmitin", "1-monoolein", "1,5-anhydroglucitol"
                                    ), KEGG = c("C00310", "C00379", "C01762", "C00385", "C00183",
                                                "C02067", "C00299", "C00366", "C00086", "C00106", "C00082", "C00078",
                                                "", "C06771", "C01083", "C01157", "C02477", "C00178", "C00214",
                                                "C00188", "", "", "C00245", "D09007", "C00059", "C00089", "C00042",
                                                "C01530", "C00794", "C08250", "C00493", "C00065", "C00213", "C00818",
                                                "C00199", "C00121", "C00474", "C00507", "C00022", "C00013", "",
                                                "C02457", "C00148", "", "C00009", "C00346", "", "C00079", "C07086",
                                                "C01601", "C00864", "C08362", "C00249", "C01879", "C00209", "C00295",
                                                "C00077", "C00712", "C02721", "C00253", "C00153", "", "", "C00624",
                                                "", "C00645", "C03136", "", "C02989", "C00073", "", "", "C00208",
                                                "C00149", "C07272", "", "C00047", "C06427", "C01595", "C01725",
                                                "", "C02679 ", "", "C00186", "C00328", "", "C00407", "C00311",
                                                "", "", "C00294", "C02043", "C00954", "C16526", "C00262", "C00192",
                                                "", "C05629", "C00263", "C01817", "C00135", "", "C00387", "C00160",
                                                "C00037", "C00093", "C05401", "C00258", "C00489", "C00064", "C00025",
                                                "C00191", "C00092", "C00031", "C00257", "", "C00446", "C00124",
                                                "C00880", "C01235", "C00122", "C01018", "C01019", "C00085", "C00095",
                                                "C00189", "C00503", "C08374", "", "C00112", "", "C00097", "C00791",
                                                "", "C00327", "C00158", "C00695", "C00187", "", "C06423", "C01571",
                                                "C03044", "C00099", "C00180", "C08281", "C00049", "C00152", "",
                                                "C06425", "C01904", "C00259", "C00872", "C00026", "C01551", "C00499",
                                                "C00041", "C06104", "C00020", "C00212", "C00417", "C05659", "",
                                                "C01015", "C07588", "C00989", "C00156", "", "C00197", "", "C01013",
                                                "C01089", "", "C06474", "", "C00629", "C02112", "C00233", "",
                                                "C02630", "C05984", "", "", "C00956", "", "D01947", "", "C01885",
                                                "C07326"), CID = c("5289590", "6912", "64959", "1188", "6287",
                                                                   "15047", "6029", "1175", "1176", "1174", "6057", "6305", "",
                                                                   "7618", "7427", "5810", "14985", "1135", "5789", "6288", "",
                                                                   "169019", "1123", "92092", "1118", "5988", "1110", "5281", "5780",
                                                                   "441432", "8742", "5951", "1088", "33037", "439184", "5779",
                                                                   "827", "25310", "1060", "1023", "23368901", "10442", "145742",
                                                                   "", "1004", "1015", "", "6140", "999", "8158", "6613", "445638",
                                                                   "985", "7405", "971", "967", "6262", "445639", "5288725", "938",
                                                                   "936", "99463", "10972", "70914", "", "65150", "439281", "10465",
                                                                   "158980", "6137", "13130", "11458", "6255", "222656", "10935",
                                                                   "65550", "5962", "5280934", "5280450", "439555", "", "3893",
                                                                   "517381", "612", "161166", "151152", "6306", "5318532", "16219508",
                                                                   "53714838", "6021", "92904", "802", "5282767", "790", "787",
                                                                   "16639161", "107", "12647", "439579", "6274", "19770757", "6802",
                                                                   "757", "750", "754", "656504", "439194", "743", "5961", "33032",
                                                                   "94715", "5958", "107526", "10690", "76599", "99058", "6036",
                                                                   "128869", "439451", "444972", "94270", "94270", "69507", "5984",
                                                                   "700", "222285", "8182", "6857565", "290", "", "594", "588",
                                                                   "", "9750", "311", "221493", "5997", "160514", "379", "2969",
                                                                   "262", "239", "243", "8215", "5960", "236", "5312542", "10467",
                                                                   "94154", "229", "100714", "51", "204", "203", "5950", "196",
                                                                   "6083", "60961", "309", "1833", "", "825", "10253", "10413",
                                                                   "105001", "", "724", "193872", "68152", "92135", "n/a", "441040",
                                                                   "", "3035456", "5319879", "70", "98009", "43", "94318", "95433",
                                                                   "150929", "469", "13120900", "24699", "14900", "5283468", "64960"
                                                ), id = 1:188, mean_diabetic.. = c(1223.17391304348, 6672.08695652174,
                                                                                   345.695652173913, 2007.04347826087, 231977.913043478, 22035.4347826087,
                                                                                   1067.04347826087, 21026.5217391304, 288334.434782609, 4730.69565217391,
                                                                                   110102.869565217, 84168.8434782609, 2304.65217391304, 969.217391304348,
                                                                                   2966.08695652174, 1872.47826086957, 1766.08695652174, 314.304347826087,
                                                                                   838.086956521739, 21377.3043478261, 18245.5217391304, 675.608695652174,
                                                                                   25409.9130434783, 1134.39130434783, 9369.69565217391, 442.565217391304,
                                                                                   35425.4347826087, 211393.173913043, 15924.2608695652, 1114.73913043478,
                                                                                   336.608695652174, 106175.217391304, 16039.9130434783, 1596.13043478261,
                                                                                   199.173913043478, 1640.60869565217, 786.608695652174, 8808.08695652174,
                                                                                   4829.26086956522, 649.304347826087, 2510.4347826087, 1563.4347826087,
                                                                                   70828.347826087, 1286.21739130435, 78555.347826087, 1368.78260869565,
                                                                                   3083.69565217391, 44032.1739130435, 319.173913043478, 16374.4347826087,
                                                                                   4967.13043478261, 5926.73913043478, 40409.652173913, 141636.47826087,
                                                                                   39281.652173913, 604.695652173913, 34261.1304347826, 4328.60869565217,
                                                                                   4987.95652173913, 1583, 32.9565217391304, 190.95652173913, 358.695652173913,
                                                                                   523, 470.434782608696, 4209.73913043478, 1183.5652173913, 6863.47826086957,
                                                                                   11589.5652173913, 8810.5652173913, 936.304347826087, 562.04347826087,
                                                                                   6460.04347826087, 12541.652173913, 2235, 1405.52173913043, 75986.1304347826,
                                                                                   3135, 5701.17391304348, 1307.86956521739, 191336.217391304, 7025.73913043478,
                                                                                   4434.17391304348, 466268.608695652, 449.217391304348, 2238.52173913043,
                                                                                   85817.347826087, 2632.47826086957, 1763.5652173913, 2158.95652173913,
                                                                                   5442.04347826087, 5647.91304347826, 3272.4347826087, 2988.52173913043,
                                                                                   1831.17391304348, 2701.60869565217, 754, 2740.95652173913, 359.695652173913,
                                                                                   841.304347826087, 33410.4347826087, 15522.3043478261, 230.521739130435,
                                                                                   6405.34782608696, 210119.47826087, 7325.73913043478, 1783.39130434783,
                                                                                   3138.60869565217, 1426.21739130435, 146534.695652174, 13399.1304347826,
                                                                                   29686, 1244.34782608696, 376619.608695652, 796.95652173913, 434.521739130435,
                                                                                   200.826086956522, 46650.4347826087, 707.347826086957, 1890.95652173913,
                                                                                   1155.08695652174, 8875.82608695652, 2674.13043478261, 402.739130434783,
                                                                                   156194.782608696, 13362.7391304348, 2779.91304347826, 429.913043478261,
                                                                                   174.95652173913, 1279.26086956522, 8070.65217391304, 1858.60869565217,
                                                                                   9671.52173913043, 525.478260869565, 4984.26086956522, 150780.956521739,
                                                                                   215.826086956522, 158224.47826087, 1346.4347826087, 1681.5652173913,
                                                                                   2180.82608695652, 2673.60869565217, 125.913043478261, 12034.0434782609,
                                                                                   1731.5652173913, 4420.95652173913, 11182.0869565217, 3010.69565217391,
                                                                                   2341.47826086957, 657.434782608696, 5344.30434782609, 3523.34782608696,
                                                                                   2084.13043478261, 7020.69565217391, 5714.60869565217, 368815.608695652,
                                                                                   619.347826086957, 391.173913043478, 600.304347826087, 209.826086956522,
                                                                                   15328.5652173913, 580, 1316.5652173913, 208.869565217391, 643.782608695652,
                                                                                   904.173913043478, 89, 698.304347826087, 440.130434782609, 3539.34782608696,
                                                                                   206165.217391304, 326.565217391304, 9799, 1816.5652173913, 253.04347826087,
                                                                                   765.260869565217, 2579.21739130435, 2463, 1462.26086956522, 12337.2608695652,
                                                                                   1122.13043478261, 997.086956521739, 833.130434782609, 444.652173913043,
                                                                                   166.739130434783, 391.391304347826, 6285.39130434783, 13482.6956521739
                                                ), mean_non.diabetic.. = c(764.075471698113, 3617.69811320755,
                                                                           161.169811320755, 1141.24528301887, 128295.528301887, 12634.7358490566,
                                                                           730.981132075472, 14938.3018867925, 446484.716981132, 3285.83018867925,
                                                                           117015.58490566, 96812.2339622641, 457.660377358491, 169.132075471698,
                                                                           805.22641509434, 3600.56603773585, 2034.75471698113, 518.867924528302,
                                                                           1023.05660377358, 18425.4339622641, 23196.1132075472, 671.320754716981,
                                                                           50291.5471698113, 472.433962264151, 9567.03773584906, 469.830188679245,
                                                                           13313.1509433962, 225719.830188679, 8463.28301886793, 577.962264150943,
                                                                           244, 73393.9433962264, 24644.5849056604, 542.358490566038, 336.584905660377,
                                                                           1091.71698113208, 940.490566037736, 6903.94339622641, 3098.07547169811,
                                                                           590.547169811321, 1968.41509433962, 1622.50943396226, 51432.6226415094,
                                                                           614.754716981132, 68499.1320754717, 1678.58490566038, 2155.2641509434,
                                                                           36917.7924528302, 162.584905660377, 18819.8113207547, 2017.8679245283,
                                                                           14203.7358490566, 48022.7547169811, 194013.886792453, 36087.1886792453,
                                                                           566.377358490566, 53031.2264150943, 6415.81132075472, 4237.35849056604,
                                                                           1427.50943396226, 128.698113207547, 236.339622641509, 213.056603773585,
                                                                           757.471698113208, 338.679245283019, 3572.77358490566, 1045.8679245283,
                                                                           4971.75471698113, 16041.8490566038, 7876.01886792453, 1432.84905660377,
                                                                           307.283018867925, 2100.77358490566, 7260.2641509434, 2092.66037735849,
                                                                           1538.33962264151, 137715.698113208, 4186.96226415094, 5802.83018867925,
                                                                           1382.07547169811, 100876.150943396, 7406.15094339623, 1769.35849056604,
                                                                           399784.547169811, 450.245283018868, 1604.43396226415, 54072.5283018868,
                                                                           2081.50943396226, 349.264150943396, 1288.62264150943, 5601.47169811321,
                                                                           3585.69811320755, 2702.20754716981, 1340.8679245283, 1258.7358490566,
                                                                           2667.11320754717, 769.867924528302, 1125.35849056604, 402.622641509434,
                                                                           541.490566037736, 40536.4528301887, 7559.47169811321, 258.245283018868,
                                                                           5638.37735849057, 220593.622641509, 12989.2641509434, 1232.52830188679,
                                                                           2851.32075471698, 310.358490566038, 132936.773584906, 15466.8113207547,
                                                                           19418.9622641509, 525.433962264151, 615852.320754717, 360.849056603774,
                                                                           191.339622641509, 200.056603773585, 43590.5849056604, 382.660377358491,
                                                                           582.037735849057, 1483.03773584906, 8838.24528301887, 2488.64150943396,
                                                                           421.622641509434, 42819.2641509434, 11683.1698113208, 1858.84905660377,
                                                                           301.264150943396, 104.867924528302, 1082.39622641509, 4334.66037735849,
                                                                           2730.07547169811, 12627.8490566038, 1239.54716981132, 3907.20754716981,
                                                                           127274.962264151, 34.6792452830189, 175388.679245283, 554.981132075472,
                                                                           1737.39622641509, 2641.03773584906, 1423.79245283019, 219.415094339623,
                                                                           10233.0754716981, 1654.35849056604, 5561.81132075472, 9269.03773584906,
                                                                           4809.03773584906, 3032.32075471698, 494.962264150943, 3049.03773584906,
                                                                           4393.22641509434, 688.981132075472, 3554.39622641509, 6440.90566037736,
                                                                           314951.716981132, 563.77358490566, 1845.56603773585, 294.11320754717,
                                                                           117.660377358491, 22723.0754716981, 310.603773584906, 3839.50943396226,
                                                                           289.867924528302, 295.339622641509, 752.452830188679, 44.0754716981132,
                                                                           726.320754716981, 147.924528301887, 2293.45283018868, 26436.2641509434,
                                                                           806.358490566038, 2241.83018867925, 1610.92452830189, 224.528301886792,
                                                                           732.415094339623, 1444.84905660377, 1069.37735849057, 1254.15094339623,
                                                                           7231.39622641509, 541.490566037736, 775.207547169811, 1358.39622641509,
                                                                           350.320754716981, 194.301886792453, 349.283018867925, 6829.37735849057,
                                                                           64420.3018867925), sd_diabetic.. = c(514.873210533332, 5713.77035139307,
                                                                                                                813.524287774138, 2732.18296802227, 118125.313390219, 11763.4449995279,
                                                                                                                1474.85664875857, 18014.2633636126, 158374.465194713, 3505.02421771925,
                                                                                                                44578.2307841602, 40785.9897241891, 2909.36165458235, 2155.72592617306,
                                                                                                                2173.13575095871, 1125.62047009094, 910.76321206914, 186.450440595937,
                                                                                                                629.290286610348, 19383.5497415974, 9933.60411051829, 266.623455820518,
                                                                                                                24885.6483264644, 936.778752336986, 7903.94228697865, 496.436925050262,
                                                                                                                68806.4316548613, 93653.5048558598, 11020.633248665, 638.795188217725,
                                                                                                                614.409601245591, 81136.6347118223, 8466.52971686985, 997.819044641764,
                                                                                                                273.738370807189, 1680.82151827152, 487.375973885612, 3969.87792247666,
                                                                                                                5052.02553633321, 249.1530078965, 1468.98455422559, 676.11919511866,
                                                                                                                44454.9639079297, 2474.9896777842, 60335.5188836926, 539.003116580781,
                                                                                                                2808.06098474929, 10243.6769350755, 296.699059681372, 5028.56806679312,
                                                                                                                1991.03779025247, 6979.13958110096, 16317.8421607334, 71449.915331631,
                                                                                                                14753.4828757289, 456.136984486679, 18706.4930275908, 3368.88207434307,
                                                                                                                2779.21747453325, 1730.26637465817, 16.6800868235956, 100.196841839573,
                                                                                                                223.286696013445, 306.08139143342, 235.243747107887, 2281.55443856299,
                                                                                                                494.109467636378, 1662.31213209371, 9833.78001319056, 6097.97827768342,
                                                                                                                326.703289738092, 546.841881605881, 3035.0800869808, 9494.69286979308,
                                                                                                                883.259716772325, 815.224278653383, 35719.1828501467, 3148.24424373043,
                                                                                                                4100.92277478412, 748.479871858339, 106350.776811266, 5374.71690770264,
                                                                                                                3537.26292044844, 242697.811991437, 138.459694339262, 748.663467882795,
                                                                                                                35717.9358466618, 812.580282442923, 2161.36877561182, 645.198030083567,
                                                                                                                4964.95690247944, 3346.67252537425, 1243.90959281566, 2259.5712559841,
                                                                                                                3890.82040486642, 1158.28069055077, 261.262842224593, 2648.02870896036,
                                                                                                                308.2263682282, 373.433994993226, 9780.64052013925, 4926.7902462389,
                                                                                                                439.539828536124, 4429.25724954068, 68655.5006628083, 4031.76460596904,
                                                                                                                764.298236597732, 1147.39379540728, 3857.89572832041, 58502.0430345928,
                                                                                                                5441.52845593579, 24803.2559226332, 1231.64482072831, 167393.300968038,
                                                                                                                326.233390836135, 319.032182697668, 109.708975423789, 20157.2078239253,
                                                                                                                291.289079890134, 2034.58259016574, 749.636815885683, 3972.76933010182,
                                                                                                                1040.9151700808, 242.672285077353, 111065.26283593, 8724.92313702737,
                                                                                                                1173.41846806064, 333.924993352955, 171.790961308655, 1972.86854414837,
                                                                                                                6232.88629046619, 1608.40759022226, 3906.07256681609, 333.779713633411,
                                                                                                                1231.64997305504, 48100.1858449238, 394.897184797847, 55699.4517729423,
                                                                                                                1061.49940376324, 448.296961854422, 825.629052308487, 1700.12843737093,
                                                                                                                63.5895310448035, 9326.96340762172, 657.133639797385, 2291.01266768175,
                                                                                                                9580.21893331654, 1605.42425530627, 656.46801968532, 240.333447543003,
                                                                                                                3601.18852141879, 1291.04163754754, 2338.13722095852, 6044.39316778768,
                                                                                                                4142.954147368, 202646.489473157, 449.069098620656, 1524.40219735099,
                                                                                                                2187.30054539593, 165.887873460554, 10544.2191651336, 253.574805172323,
                                                                                                                2065.66533032749, 246.459162087911, 358.815216627994, 584.18440832061,
                                                                                                                54.4392906239268, 669.31066538523, 737.949327180509, 1745.48791325978,
                                                                                                                286194.067195822, 311.666171362151, 12089.9991841492, 486.321706662926,
                                                                                                                60.8347076928874, 553.811685863714, 2044.05139048815, 1575.91185724906,
                                                                                                                740.596210519317, 6174.53779806739, 852.993301921258, 355.287196637962,
                                                                                                                652.513622591884, 219.076700702092, 77.5178673780816, 181.010481647896,
                                                                                                                3745.06286801377, 26441.8232909271), sd_non.diabetic.. = c(313.071314624382,
                                                                                                                                                                           4313.0513854191, 609.076562569204, 1956.14441131273, 52491.781095712,
                                                                                                                                                                           5249.7549801833, 1663.6843900323, 15910.6119154009, 418648.730305398,
                                                                                                                                                                           1809.07830055326, 29968.4617270544, 54616.4113660091, 1175.55593956804,
                                                                                                                                                                           246.401176768532, 1281.52684838632, 2235.33627232299, 611.317709971991,
                                                                                                                                                                           265.1532240434, 469.577527599762, 9112.99517280645, 6238.48277801205,
                                                                                                                                                                           385.865798391941, 36300.1510150313, 509.107269542781, 7418.25127113025,
                                                                                                                                                                           592.412626983574, 34147.2803750934, 108407.524801935, 4213.06547620868,
                                                                                                                                                                           379.342496061082, 365.490555491994, 19565.4105467307, 9025.53007911439,
                                                                                                                                                                           410.774647855433, 402.978928345957, 1218.63822765348, 449.995197523156,
                                                                                                                                                                           2312.03018025862, 3130.97130940996, 243.731375307209, 2266.28120865237,
                                                                                                                                                                           525.556504414478, 23108.1573818778, 1510.37313150478, 49398.352880917,
                                                                                                                                                                           796.267360249401, 1232.77409420541, 8280.17584669852, 111.975861746777,
                                                                                                                                                                           5791.55980735562, 1200.4685629712, 30292.0560303236, 17142.2887764841,
                                                                                                                                                                           40442.9178242716, 12344.0296547587, 279.995207817171, 15211.0358503311,
                                                                                                                                                                           3239.62317405426, 2981.21041560135, 1765.82058308313, 411.427280466131,
                                                                                                                                                                           115.31577772431, 69.281314800973, 454.317264770133, 147.178433514313,
                                                                                                                                                                           3370.48312356135, 537.51193323912, 1777.255911031, 8551.87988419511,
                                                                                                                                                                           5464.38008480153, 595.776397014415, 297.373979602381, 1750.30881496677,
                                                                                                                                                                           4967.57036321559, 804.370799095987, 901.430976567391, 52436.0033013082,
                                                                                                                                                                           2645.40011487476, 2988.20477837993, 844.271735536169, 48677.637608358,
                                                                                                                                                                           3255.01133990832, 1505.32711873456, 164622.683310907, 296.527979329774,
                                                                                                                                                                           647.33226248593, 17854.1668801644, 711.135728217722, 881.053088222868,
                                                                                                                                                                           954.011172052288, 5933.42456118067, 1972.61944734275, 1499.34761913936,
                                                                                                                                                                           1012.55759641946, 3103.4596151277, 1066.58341410566, 242.075245591741,
                                                                                                                                                                           1656.20170285854, 119.906730807275, 394.349250842522, 12686.6714834689,
                                                                                                                                                                           3943.75826028038, 496.318752480561, 1225.23384308741, 70389.1139494285,
                                                                                                                                                                           4514.74547008485, 662.226506792792, 1349.04554256226, 204.027627686096,
                                                                                                                                                                           65955.0187317788, 5648.85823064001, 13474.0801412339, 433.047630593731,
                                                                                                                                                                           146998.645056389, 223.257646628148, 201.047922281482, 121.162861645349,
                                                                                                                                                                           23911.9370603519, 223.025519701931, 1015.28540819175, 1354.031913075,
                                                                                                                                                                           2767.92167175788, 717.004347544475, 268.409720276748, 49293.8178165263,
                                                                                                                                                                           3404.94281402249, 795.724763881873, 144.990337999494, 91.382130414382,
                                                                                                                                                                           1048.4311235149, 2523.09184520925, 2100.82202637496, 5195.31857095414,
                                                                                                                                                                           565.252719723928, 1297.90073637409, 42188.5688951596, 14.5942211757648,
                                                                                                                                                                           63455.3154204333, 382.681354220355, 486.34940509025, 635.668695828506,
                                                                                                                                                                           1034.76718597601, 193.244209184037, 1609.40986376345, 1437.62346753163,
                                                                                                                                                                           2245.30889648587, 2397.01598115933, 1623.60087652136, 3712.92277454747,
                                                                                                                                                                           288.200448557287, 2357.18049439664, 1831.78761619007, 1358.24522667705,
                                                                                                                                                                           2799.93908134021, 2952.5267553282, 131892.76803195, 650.818113593293,
                                                                                                                                                                           3879.07058411119, 474.279277526899, 143.600801288238, 10150.9327079017,
                                                                                                                                                                           266.921505288514, 3467.05543776893, 268.39021804769, 135.325099070041,
                                                                                                                                                                           476.216885222146, 27.4140959366385, 823.226129640269, 115.017364751957,
                                                                                                                                                                           587.11797943061, 39345.6205671419, 631.499744026369, 1698.97489155904,
                                                                                                                                                                           436.312601814544, 85.3991991886397, 387.641856613226, 1351.87504253318,
                                                                                                                                                                           637.513505932803, 653.314254581574, 5427.85866667235, 387.893751443986,
                                                                                                                                                                           310.082455441636, 614.508256801968, 114.258777408145, 86.992171377584,
                                                                                                                                                                           131.267544960443, 4008.04517970474, 25100.6962978695), diabetic..__mean_and_sd = c("1220 +/- 510",
                                                                                                                                                                                                                                                              "6670 +/- 5700", "346 +/- 810", "2010 +/- 2700", "232000 +/- 120000",
                                                                                                                                                                                                                                                              "22000 +/- 12000", "1070 +/- 1500", "21000 +/- 18000", "288000 +/- 160000",
                                                                                                                                                                                                                                                              "4730 +/- 3500", "110000 +/- 45000", "84200 +/- 41000", "2300 +/- 2900",
                                                                                                                                                                                                                                                              "969 +/- 2200", "2970 +/- 2200", "1870 +/- 1100", "1770 +/- 910",
                                                                                                                                                                                                                                                              "314 +/- 190", "838 +/- 630", "21400 +/- 19000", "18200 +/- 9900",
                                                                                                                                                                                                                                                              "676 +/- 270", "25400 +/- 25000", "1130 +/- 940", "9370 +/- 7900",
                                                                                                                                                                                                                                                              "443 +/- 500", "35400 +/- 69000", "211000 +/- 94000", "15900 +/- 11000",
                                                                                                                                                                                                                                                              "1110 +/- 640", "337 +/- 610", "106000 +/- 81000", "16000 +/- 8500",
                                                                                                                                                                                                                                                              "1600 +/- 1000", "199 +/- 270", "1640 +/- 1700", "787 +/- 490",
                                                                                                                                                                                                                                                              "8810 +/- 4000", "4830 +/- 5100", "649 +/- 250", "2510 +/- 1500",
                                                                                                                                                                                                                                                              "1560 +/- 680", "70800 +/- 44000", "1290 +/- 2500", "78600 +/- 60000",
                                                                                                                                                                                                                                                              "1370 +/- 540", "3080 +/- 2800", "44000 +/- 10000", "319 +/- 300",
                                                                                                                                                                                                                                                              "16400 +/- 5000", "4970 +/- 2000", "5930 +/- 7000", "40400 +/- 16000",
                                                                                                                                                                                                                                                              "142000 +/- 71000", "39300 +/- 15000", "605 +/- 460", "34300 +/- 19000",
                                                                                                                                                                                                                                                              "4330 +/- 3400", "4990 +/- 2800", "1580 +/- 1700", "33 +/- 17",
                                                                                                                                                                                                                                                              "191 +/- 100", "359 +/- 220", "523 +/- 310", "470 +/- 240", "4210 +/- 2300",
                                                                                                                                                                                                                                                              "1180 +/- 490", "6860 +/- 1700", "11600 +/- 9800", "8810 +/- 6100",
                                                                                                                                                                                                                                                              "936 +/- 330", "562 +/- 550", "6460 +/- 3000", "12500 +/- 9500",
                                                                                                                                                                                                                                                              "2240 +/- 880", "1410 +/- 820", "76000 +/- 36000", "3140 +/- 3100",
                                                                                                                                                                                                                                                              "5700 +/- 4100", "1310 +/- 750", "191000 +/- 110000", "7030 +/- 5400",
                                                                                                                                                                                                                                                              "4430 +/- 3500", "466000 +/- 240000", "449 +/- 140", "2240 +/- 750",
                                                                                                                                                                                                                                                              "85800 +/- 36000", "2630 +/- 810", "1760 +/- 2200", "2160 +/- 650",
                                                                                                                                                                                                                                                              "5440 +/- 5000", "5650 +/- 3300", "3270 +/- 1200", "2990 +/- 2300",
                                                                                                                                                                                                                                                              "1830 +/- 3900", "2700 +/- 1200", "754 +/- 260", "2740 +/- 2600",
                                                                                                                                                                                                                                                              "360 +/- 310", "841 +/- 370", "33400 +/- 9800", "15500 +/- 4900",
                                                                                                                                                                                                                                                              "231 +/- 440", "6410 +/- 4400", "210000 +/- 69000", "7330 +/- 4000",
                                                                                                                                                                                                                                                              "1780 +/- 760", "3140 +/- 1100", "1430 +/- 3900", "147000 +/- 59000",
                                                                                                                                                                                                                                                              "13400 +/- 5400", "29700 +/- 25000", "1240 +/- 1200", "377000 +/- 170000",
                                                                                                                                                                                                                                                              "797 +/- 330", "435 +/- 320", "201 +/- 110", "46700 +/- 20000",
                                                                                                                                                                                                                                                              "707 +/- 290", "1890 +/- 2000", "1160 +/- 750", "8880 +/- 4000",
                                                                                                                                                                                                                                                              "2670 +/- 1000", "403 +/- 240", "156000 +/- 110000", "13400 +/- 8700",
                                                                                                                                                                                                                                                              "2780 +/- 1200", "430 +/- 330", "175 +/- 170", "1280 +/- 2000",
                                                                                                                                                                                                                                                              "8070 +/- 6200", "1860 +/- 1600", "9670 +/- 3900", "525 +/- 330",
                                                                                                                                                                                                                                                              "4980 +/- 1200", "151000 +/- 48000", "216 +/- 390", "158000 +/- 56000",
                                                                                                                                                                                                                                                              "1350 +/- 1100", "1680 +/- 450", "2180 +/- 830", "2670 +/- 1700",
                                                                                                                                                                                                                                                              "126 +/- 64", "12000 +/- 9300", "1730 +/- 660", "4420 +/- 2300",
                                                                                                                                                                                                                                                              "11200 +/- 9600", "3010 +/- 1600", "2340 +/- 660", "657 +/- 240",
                                                                                                                                                                                                                                                              "5340 +/- 3600", "3520 +/- 1300", "2080 +/- 2300", "7020 +/- 6000",
                                                                                                                                                                                                                                                              "5710 +/- 4100", "369000 +/- 200000", "619 +/- 450", "391 +/- 1500",
                                                                                                                                                                                                                                                              "600 +/- 2200", "210 +/- 170", "15300 +/- 11000", "580 +/- 250",
                                                                                                                                                                                                                                                              "1320 +/- 2100", "209 +/- 250", "644 +/- 360", "904 +/- 580",
                                                                                                                                                                                                                                                              "89 +/- 54", "698 +/- 670", "440 +/- 740", "3540 +/- 1700", "206000 +/- 290000",
                                                                                                                                                                                                                                                              "327 +/- 310", "9800 +/- 12000", "1820 +/- 490", "253 +/- 61",
                                                                                                                                                                                                                                                              "765 +/- 550", "2580 +/- 2000", "2460 +/- 1600", "1460 +/- 740",
                                                                                                                                                                                                                                                              "12300 +/- 6200", "1120 +/- 850", "997 +/- 360", "833 +/- 650",
                                                                                                                                                                                                                                                              "445 +/- 220", "167 +/- 78", "391 +/- 180", "6290 +/- 3700",
                                                                                                                                                                                                                                                              "13500 +/- 26000"), non.diabetic..__mean_and_sd = c("764 +/- 310",
                                                                                                                                                                                                                                                                                                                  "3620 +/- 4300", "161 +/- 610", "1140 +/- 2000", "128000 +/- 52000",
                                                                                                                                                                                                                                                                                                                  "12600 +/- 5200", "731 +/- 1700", "14900 +/- 16000", "446000 +/- 420000",
                                                                                                                                                                                                                                                                                                                  "3290 +/- 1800", "117000 +/- 30000", "96800 +/- 55000", "458 +/- 1200",
                                                                                                                                                                                                                                                                                                                  "169 +/- 250", "805 +/- 1300", "3600 +/- 2200", "2030 +/- 610",
                                                                                                                                                                                                                                                                                                                  "519 +/- 270", "1020 +/- 470", "18400 +/- 9100", "23200 +/- 6200",
                                                                                                                                                                                                                                                                                                                  "671 +/- 390", "50300 +/- 36000", "472 +/- 510", "9570 +/- 7400",
                                                                                                                                                                                                                                                                                                                  "470 +/- 590", "13300 +/- 34000", "226000 +/- 110000", "8460 +/- 4200",
                                                                                                                                                                                                                                                                                                                  "578 +/- 380", "244 +/- 370", "73400 +/- 20000", "24600 +/- 9000",
                                                                                                                                                                                                                                                                                                                  "542 +/- 410", "337 +/- 400", "1090 +/- 1200", "940 +/- 450",
                                                                                                                                                                                                                                                                                                                  "6900 +/- 2300", "3100 +/- 3100", "591 +/- 240", "1970 +/- 2300",
                                                                                                                                                                                                                                                                                                                  "1620 +/- 530", "51400 +/- 23000", "615 +/- 1500", "68500 +/- 49000",
                                                                                                                                                                                                                                                                                                                  "1680 +/- 800", "2160 +/- 1200", "36900 +/- 8300", "163 +/- 110",
                                                                                                                                                                                                                                                                                                                  "18800 +/- 5800", "2020 +/- 1200", "14200 +/- 30000", "48000 +/- 17000",
                                                                                                                                                                                                                                                                                                                  "194000 +/- 40000", "36100 +/- 12000", "566 +/- 280", "53000 +/- 15000",
                                                                                                                                                                                                                                                                                                                  "6420 +/- 3200", "4240 +/- 3000", "1430 +/- 1800", "129 +/- 410",
                                                                                                                                                                                                                                                                                                                  "236 +/- 120", "213 +/- 69", "757 +/- 450", "339 +/- 150", "3570 +/- 3400",
                                                                                                                                                                                                                                                                                                                  "1050 +/- 540", "4970 +/- 1800", "16000 +/- 8600", "7880 +/- 5500",
                                                                                                                                                                                                                                                                                                                  "1430 +/- 600", "307 +/- 300", "2100 +/- 1800", "7260 +/- 5000",
                                                                                                                                                                                                                                                                                                                  "2090 +/- 800", "1540 +/- 900", "138000 +/- 52000", "4190 +/- 2600",
                                                                                                                                                                                                                                                                                                                  "5800 +/- 3000", "1380 +/- 840", "101000 +/- 49000", "7410 +/- 3300",
                                                                                                                                                                                                                                                                                                                  "1770 +/- 1500", "400000 +/- 160000", "450 +/- 300", "1600 +/- 650",
                                                                                                                                                                                                                                                                                                                  "54100 +/- 18000", "2080 +/- 710", "349 +/- 880", "1290 +/- 950",
                                                                                                                                                                                                                                                                                                                  "5600 +/- 5900", "3590 +/- 2000", "2700 +/- 1500", "1340 +/- 1000",
                                                                                                                                                                                                                                                                                                                  "1260 +/- 3100", "2670 +/- 1100", "770 +/- 240", "1130 +/- 1700",
                                                                                                                                                                                                                                                                                                                  "403 +/- 120", "541 +/- 390", "40500 +/- 13000", "7560 +/- 3900",
                                                                                                                                                                                                                                                                                                                  "258 +/- 500", "5640 +/- 1200", "221000 +/- 70000", "13000 +/- 4500",
                                                                                                                                                                                                                                                                                                                  "1230 +/- 660", "2850 +/- 1300", "310 +/- 200", "133000 +/- 66000",
                                                                                                                                                                                                                                                                                                                  "15500 +/- 5600", "19400 +/- 13000", "525 +/- 430", "616000 +/- 150000",
                                                                                                                                                                                                                                                                                                                  "361 +/- 220", "191 +/- 200", "200 +/- 120", "43600 +/- 24000",
                                                                                                                                                                                                                                                                                                                  "383 +/- 220", "582 +/- 1000", "1480 +/- 1400", "8840 +/- 2800",
                                                                                                                                                                                                                                                                                                                  "2490 +/- 720", "422 +/- 270", "42800 +/- 49000", "11700 +/- 3400",
                                                                                                                                                                                                                                                                                                                  "1860 +/- 800", "301 +/- 140", "105 +/- 91", "1080 +/- 1000",
                                                                                                                                                                                                                                                                                                                  "4330 +/- 2500", "2730 +/- 2100", "12600 +/- 5200", "1240 +/- 570",
                                                                                                                                                                                                                                                                                                                  "3910 +/- 1300", "127000 +/- 42000", "34.7 +/- 15", "175000 +/- 63000",
                                                                                                                                                                                                                                                                                                                  "555 +/- 380", "1740 +/- 490", "2640 +/- 640", "1420 +/- 1000",
                                                                                                                                                                                                                                                                                                                  "219 +/- 190", "10200 +/- 1600", "1650 +/- 1400", "5560 +/- 2200",
                                                                                                                                                                                                                                                                                                                  "9270 +/- 2400", "4810 +/- 1600", "3030 +/- 3700", "495 +/- 290",
                                                                                                                                                                                                                                                                                                                  "3050 +/- 2400", "4390 +/- 1800", "689 +/- 1400", "3550 +/- 2800",
                                                                                                                                                                                                                                                                                                                  "6440 +/- 3000", "315000 +/- 130000", "564 +/- 650", "1850 +/- 3900",
                                                                                                                                                                                                                                                                                                                  "294 +/- 470", "118 +/- 140", "22700 +/- 10000", "311 +/- 270",
                                                                                                                                                                                                                                                                                                                  "3840 +/- 3500", "290 +/- 270", "295 +/- 140", "752 +/- 480",
                                                                                                                                                                                                                                                                                                                  "44.1 +/- 27", "726 +/- 820", "148 +/- 120", "2290 +/- 590",
                                                                                                                                                                                                                                                                                                                  "26400 +/- 39000", "806 +/- 630", "2240 +/- 1700", "1610 +/- 440",
                                                                                                                                                                                                                                                                                                                  "225 +/- 85", "732 +/- 390", "1440 +/- 1400", "1070 +/- 640",
                                                                                                                                                                                                                                                                                                                  "1250 +/- 650", "7230 +/- 5400", "541 +/- 390", "775 +/- 310",
                                                                                                                                                                                                                                                                                                                  "1360 +/- 610", "350 +/- 110", "194 +/- 87", "349 +/- 130", "6830 +/- 4000",
                                                                                                                                                                                                                                                                                                                  "64400 +/- 25000"), FC_non.diabetic.._diabetic.. = c(0.62, 0.54,
                                                                                                                                                                                                                                                                                                                                                                       0.47, 0.57, 0.55, 0.57, 0.69, 0.71, 1.55, 0.69, 1.06, 1.15, 0.2,
                                                                                                                                                                                                                                                                                                                                                                       0.17, 0.27, 1.92, 1.15, 1.65, 1.22, 0.86, 1.27, 0.99, 1.98, 0.42,
                                                                                                                                                                                                                                                                                                                                                                       1.02, 1.06, 0.38, 1.07, 0.53, 0.52, 0.72, 0.69, 1.54, 0.34, 1.69,
                                                                                                                                                                                                                                                                                                                                                                       0.67, 1.2, 0.78, 0.64, 0.91, 0.78, 1.04, 0.73, 0.48, 0.87, 1.23,
                                                                                                                                                                                                                                                                                                                                                                       0.7, 0.84, 0.51, 1.15, 0.41, 2.4, 1.19, 1.37, 0.92, 0.94, 1.55,
                                                                                                                                                                                                                                                                                                                                                                       1.48, 0.85, 0.9, 3.91, 1.24, 0.59, 1.45, 0.72, 0.85, 0.88, 0.72,
                                                                                                                                                                                                                                                                                                                                                                       1.38, 0.89, 1.53, 0.55, 0.33, 0.58, 0.94, 1.09, 1.81, 1.34, 1.02,
                                                                                                                                                                                                                                                                                                                                                                       1.06, 0.53, 1.05, 0.4, 0.86, 1, 0.72, 0.63, 0.79, 0.2, 0.6, 1.03,
                                                                                                                                                                                                                                                                                                                                                                       0.63, 0.83, 0.45, 0.69, 0.99, 1.02, 0.41, 1.12, 0.64, 1.21, 0.49,
                                                                                                                                                                                                                                                                                                                                                                       1.12, 0.88, 1.05, 1.77, 0.69, 0.91, 0.22, 0.91, 1.15, 0.65, 0.42,
                                                                                                                                                                                                                                                                                                                                                                       1.64, 0.45, 0.44, 1, 0.93, 0.54, 0.31, 1.28, 1, 0.93, 1.05, 0.27,
                                                                                                                                                                                                                                                                                                                                                                       0.87, 0.67, 0.7, 0.6, 0.85, 0.54, 1.47, 1.31, 2.36, 0.78, 0.84,
                                                                                                                                                                                                                                                                                                                                                                       0.16, 1.11, 0.41, 1.03, 1.21, 0.53, 1.74, 0.85, 0.96, 1.26, 0.83,
                                                                                                                                                                                                                                                                                                                                                                       1.6, 1.3, 0.75, 0.57, 1.25, 0.33, 0.51, 1.13, 0.85, 0.91, 4.72,
                                                                                                                                                                                                                                                                                                                                                                       0.49, 0.56, 1.48, 0.54, 2.92, 1.39, 0.46, 0.83, 0.5, 1.04, 0.34,
                                                                                                                                                                                                                                                                                                                                                                       0.65, 0.13, 2.47, 0.23, 0.89, 0.89, 0.96, 0.56, 0.43, 0.86, 0.59,
                                                                                                                                                                                                                                                                                                                                                                       0.48, 0.78, 1.63, 0.79, 1.17, 0.89, 1.09, 4.78), class_p.values = c(0.00013247611713078,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0125852573608362, 0.330616930090488, 0.0669898329703896, 0.0000217873599043288,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000555616679964263, 0.0740160672871194, 0.0255415586954265,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.00334473758036081, 0.00774994293803237, 0.159217378798376,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.381224472380369, 0.000737432942751694, 0.306115436761261, 0.000000691408808269841,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.000737865847603209, 0.319729614752614, 0.000296537965961606,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0178430285553088, 0.922493239111305, 0.00885644246043925, 0.402739336791048,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.00183913781735487, 0.0000148703277195747, 0.990978532605559,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.8519986610823, 0.137052620616627, 0.781765548895103, 0.00022275869962358,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000130719081376934, 0.00469729415206854, 0.0312430157834494,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.000599936708894342, 0.0000000553565027404295, 0.0139182019507169,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.11472126649097, 0.298224381790142, 0.0369675407227932, 0.10836155752796,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.533998877301088, 0.00856642369565556, 0.24189483981252, 0.0999381794213703,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0290891892229376, 0.655147717759432, 0.157546464013025, 0.290419395052671,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.00478636652907965, 0.0035927883738908, 0.0695612842373027,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000000273917640212414, 0.0390629959625746, 0.0597548367721401,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.00000775358512686766, 0.445334887754439, 0.452106025138195,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000160631304623284, 0.00495778825145399, 0.0511221575779087,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.124107572876406, 0.730053932438778, 0.101069535122302, 0.0074909854115916,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0459701606418919, 0.00930309032257201, 0.102288738119422, 0.109610187685777,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000852479121743573, 0.0233882281786058, 0.688129464532222,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.000507257626859199, 0.00504256547091168, 0.0000000211200237879886,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.01010146614907, 0.469279866961109, 0.659231108451358, 0.00000106665213595976,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.011876780549789, 0.614851558154238, 0.80792927165508, 0.000178082572190917,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.24189483981252, 0.0000187178838605376, 0.362714329173515, 0.117337391998207,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000294215317228595, 0.000345396526918768, 0.00299646003777842,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000182409405974512, 0.000000311413144258172, 0.923434306642474,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.000625384312504974, 0.0290913897775489, 0.000194833944461882,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.107117011623501, 0.89207134783201, 0.860876841366528, 0.00180406604342175,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.000960530475981237, 0.0000656874471429125, 0.0195499998875369,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000000311715761603076, 0.270209311884237, 0.265388809578794,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.152624515237854, 0.000000897635867582717, 0.00119761334727174,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.18399307356101, 0.0605186284934802, 0.260573704024938, 0.0867113451585117,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.146241477297742, 0.00134753821546495, 0.000000445224473718236,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000000142264193702338, 0.000302965704916221, 0.742973721516236,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.285294265431165, 0.000000267886866746697, 0.000135532645378263,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.807927984445487, 0.479764729347349, 0.630827259558772, 0.700636979604957,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.00000168057205969043, 0.515597572581605, 0.000612511099251282,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.124102430792893, 0.0510856442428471, 0.860876841366528, 0.0015761893706231,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.00915376424435182, 0.0255415586954265, 0.0000000173398161830983,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.00210152179965851, 0.0312430157834494, 0.00124079261534583,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.237376101272772, 0.0000036524687413184, 0.618829285899158,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.000707822347871747, 0.000466158893182672, 0.00621296299172045,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.923434306642474, 0.0354560278199935, 0.0274628733623205, 0.73019937068615,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000555616679964263, 0.534015650414443, 0.0033443053341097,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000672791602391949, 0.0286780219716822, 0.0511158071008007,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.00386577248105326, 0.0645043888932274, 0.515597572581605, 0.0101009530759647,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.105847974042227, 0.626792479689219, 0.00142840018705733, 0.0107814071434478,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000030147551176968, 0.000186281337301595, 0.0181183887204882,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.00000309690418839037, 0.195438469064116, 0.000137795547556683,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.843146240986887, 0.0000156362112437507, 0.00160681287935155,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.000000311470861585697, 0.000428106659182151, 0.00000000229054353297253,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0888073474532999, 0.0739943378023965, 0.883139395540967, 0.0130697246369588,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000358572461446099, 0.285290972689946, 0.000345396526918768,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.000259950280643419, 0.00340551235238783, 0.000194774937012038,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0846406366649042, 0.173022638677702, 0.295583078688929, 0.696469562764653,
                                                                                                                                                                                                                                                                                                                                                                                                                                           0.0000000590491829941253), class_FDR.p.values = c(0.000700150349747471,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0268866861799683, 0.408920939848762, 0.11145211149056, 0.000151704580074586,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000336954631720263, 0.11995707456878, 0.0500188857785436, 0.00911319804504105,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0184429021816466, 0.221724942326627, 0.465390914334476, 0.00247712105981077,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.38366468074078, 0.00000999883507344077, 0.00247712105981077,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.398073957440341, 0.00126572338942777, 0.0368625205318469, 0.928372458014894,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0205556936118837, 0.488483840753013, 0.00531935245634946, 0.000125827855288239,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.990978532605559, 0.889257396576413, 0.196686203633022, 0.835067745410678,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000997110369743644, 0.00011702470142316, 0.0120971411039573,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0575851663459655, 0.00221153139749287, 0.00000138765580036194,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0290735774081642, 0.169823607088995, 0.376283112594273, 0.0668259389988955,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.162975782522052, 0.615919891275554, 0.0201310956847906, 0.32252645308336,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.156569814426814, 0.0546918127817919, 0.733141493683174, 0.221035337570512,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.371420722924505, 0.0121599582090132, 0.0095132987928376, 0.114715100321166,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000000976709386356305, 0.0699413641996574, 0.102126448301476,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000072883700192556, 0.536685633960477, 0.541375367681405, 0.000125827855288239,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0124275225503113, 0.088173996556393, 0.179478643852033, 0.788951044189634,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.157033657875974, 0.0180551956074259, 0.0815319830252422, 0.0210720600077535,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.157625268577469, 0.163545359404175, 0.000471370808493505, 0.0467764563572115,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.760990231365046, 0.00190728867699059, 0.0124737145859394, 0.000000976709386356305,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0223420663061783, 0.558383639168915, 0.733345848454765, 0.0000133687067706956,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0256647671650613, 0.704829834957298, 0.853318556579523, 0.00088104009399717,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.32252645308336, 0.000135344698683887, 0.445688195324319, 0.172339294497366,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0001975445701392, 0.00138158610767507, 0.00840797741943796,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000135344698683887, 0.00000532332017982828, 0.928372458014894,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00221834435379123, 0.0546918127817919, 0.000893384916069117,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.162403211171114, 0.911464203219662, 0.889257396576413, 0.00529944400255139,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00316806542955215, 0.000383287337120262, 0.0395204298801822,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000000976709386356305, 0.35277326829331, 0.348902770635058,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.215739916276064, 0.0000120539673646822, 0.00388191912563942,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.252486845470583, 0.102500019430399, 0.34498490392034, 0.13815027872712,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.20828331615133, 0.00422228640845684, 0.0000069751834215857,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000000976709386356305, 0.00126572338942777, 0.798166055114585,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.367365218500404, 0.00000532332017982828, 0.000700150349747471,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.853318556579523, 0.567268988159129, 0.710152843096103, 0.765812512591464,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000197467217013626, 0.602064246244359, 0.0022144632049854,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.179478643852033, 0.088173996556393, 0.889257396576413, 0.0047794129302765,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0209866789992456, 0.0500188857785436, 0.000000976709386356305,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00598615300508786, 0.0575851663459655, 0.00395371206245791,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.321055446325764, 0.000036140217019361, 0.705090337872979, 0.00246427039629423,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00178852799833352, 0.0151693122395253, 0.928372458014894, 0.0647158566034833,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0532270122898583, 0.788951044189634, 0.000336954631720263,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.615919891275554, 0.00911319804504105, 0.000383287337120262,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0546918127817919, 0.088173996556393, 0.0100939614783057, 0.108275224213632,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.602064246244359, 0.0223420663061783, 0.161783895284054, 0.709861362539598,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00440228254371766, 0.0235686574763742, 0.0000323454437454105,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000893384916069117, 0.0370245334723021, 0.0000323454437454105,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.2662495085801, 0.000700150349747471, 0.885539068746004, 0.000125827855288239,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00479493367171574, 0.00000532332017982828, 0.00167675108179676,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000000430622184198835, 0.1403006833716, 0.11995707456878, 0.907268887222414,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0276079576600927, 0.00023245387155816, 0.367365218500404, 0.00138158610767507,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00113652680839448, 0.00914623317498446, 0.000893384916069117,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.136003758059846, 0.239178353466236, 0.375470397253504, 0.76570922689915,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00000138765580036194), post.hoc_non.diabetic.._diabetic.. = c(0.000132518233772916,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0137050200372165, 0.330855033983511, 0.0669935655863414, 0.000021787359904657,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000555616679965842, 0.0740200181361862, 0.0255415586955399,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00334473758036213, 0.00774994293804399, 0.159217378798373,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.387051103219748, 0.000737865847603048, 0.306178260490972, 0.000000691529666307922,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000737865847603048, 0.319732922563198, 0.000296651316441077,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0178461532927654, 0.923434306642427, 0.00885644246045469, 0.402755414960104,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0018391378173549, 0.0000148743265349083, 0.990978594267607,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.852002660922515, 0.137052620616626, 0.781765548895086, 0.000222758699623737,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000130772474729035, 0.00470268311784783, 0.0312430157836048,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000599936708894244, 0.0000000554257142404424, 0.0139227652373968,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.114723746028098, 0.2982309870559, 0.0369675407227924, 0.108366383426271,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.534021241052734, 0.00856732901983293, 0.241894839812515, 0.0999381794213703,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0290924900748741, 0.655147717759434, 0.157549303101988, 0.290422692338366,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00478636652908304, 0.00359668217476594, 0.0695612842373023,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000000273917791782097, 0.0390643346294326, 0.0597548367721399,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00000775358512761226, 0.445334887754439, 0.452106025138182,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000160631304625403, 0.00495778825145776, 0.051123745219007,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.124112714915258, 0.730199370686132, 0.10110917942773, 0.00749343576000561,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0459701606418912, 0.00930646512729438, 0.10229108365929, 0.109615040363975,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000852479121746796, 0.0233882281787038, 0.688129464532228,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000507302590171954, 0.0050455645119416, 0.0000000211200390509703,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0101019792348807, 0.469285941954764, 0.659235472775549, 0.00000106665213739365,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0118767805498178, 0.614853976000843, 0.807929271655093, 0.000178082572191096,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.241894839812515, 0.0000187178838608748, 0.362714329173521,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.117347415658254, 0.0000294215317232505, 0.000345396526918673,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00299685563046892, 0.0000182481526370681, 0.000000311470871539044,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.923434306642427, 0.000625438066576112, 0.0290924900748741,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000194833944461847, 0.107129009306486, 0.892072081039981, 0.860877782617789,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00180419671674925, 0.000961303615691023, 0.0000657025648880261,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0195499998876091, 0.0000000311715907530541, 0.270278083941488,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.265395343331515, 0.152624515237853, 0.000000897635869301361,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00119770633715266, 0.183993073561011, 0.0605256626396533, 0.260573704024936,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0867134992573257, 0.146241477297739, 0.00134825662099847, 0.000000445224475842387,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000000142457619034531, 0.00030319669403045, 0.742987280094423,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.285294265431165, 0.000000268037456896408, 0.000135589939358138,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.807929271655093, 0.479764729347351, 0.630841270263562, 0.700656454191,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00000168057206095806, 0.51559757258161, 0.000612563910178943,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.124112714915258, 0.051123745219007, 0.860877782617789, 0.0015761893706232,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00915424038485568, 0.0255415586955402, 0.000000017355349712922,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00210166994914296, 0.0312430157836048, 0.00124607177129676,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.237376101272775, 0.00000365358548870542, 0.618834080847604,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000708120982348182, 0.000466158893182467, 0.00621402258215109,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.923434306642427, 0.035458540545099, 0.027464989147552, 0.730199370686132,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000555616679965842, 0.534021241052734, 0.00334473758036213,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000672868808833105, 0.0286780219718182, 0.051123745219007,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00386577248105513, 0.0645043888932281, 0.51559757258161, 0.0101019792348807,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.10590285524371, 0.626827824819805, 0.0014299087761328, 0.0107814071434712,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00000301569210148234, 0.000186281337301697, 0.0181207581845373,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.00000309978605772532, 0.195444577357043, 0.000138728633738983,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.843146240986921, 0.0000156571435835362, 0.00160705038761622,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000000311470871539044, 0.000428145539837055, 0.00000000229113561456273,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0888138922332371, 0.0740200181361862, 0.883140188581356, 0.0130697246369932,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000358572461447437, 0.285294265431165, 0.000345396526918673,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.000260076701112499, 0.00340617027355328, 0.000194833944461736,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0846533961973974, 0.173046136493991, 0.29561278956768, 0.696471534367634,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             0.0000000590491964214124), kruskal_selected = c(TRUE, TRUE, FALSE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             FALSE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, FALSE, FALSE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             FALSE, TRUE, TRUE, FALSE, TRUE, TRUE, FALSE, TRUE, FALSE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, FALSE, FALSE, FALSE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, TRUE, FALSE, FALSE, TRUE, FALSE, FALSE, TRUE, FALSE, FALSE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, FALSE, FALSE, FALSE, TRUE, TRUE, FALSE, TRUE, TRUE, FALSE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, FALSE, FALSE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, TRUE, FALSE, FALSE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, FALSE, FALSE, TRUE, TRUE, FALSE, FALSE, TRUE, FALSE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             FALSE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, FALSE, FALSE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             FALSE, FALSE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, TRUE, TRUE, FALSE, FALSE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             FALSE, FALSE, TRUE, FALSE, TRUE, FALSE, FALSE, FALSE, TRUE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, FALSE, TRUE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, FALSE, TRUE, TRUE, FALSE, TRUE, FALSE, TRUE, TRUE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             FALSE, TRUE, FALSE, FALSE, TRUE, FALSE, FALSE, TRUE, TRUE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, TRUE, TRUE, FALSE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, FALSE, FALSE, FALSE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             TRUE, FALSE, FALSE, FALSE, FALSE, TRUE)), class = "data.frame", row.names = c(NA,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           -188L)), kegg.col = "KEGG", cpd.FC = "FC_non.diabetic.._diabetic..",
       pathway.code = "ko07110", organism.code = "ko", suffix = "Map_dave_stat",
       kegg.dir = "/dave_pathway/figures")
}


x<-test_obj()

# for(i in 1:length(x)){
#   assign(names(x)[i],x[[i]])
# }


#directories
x$kegg.dir <-'/dave_pathway/figures'

body<-list(data=x$data,
           kegg.col = x$kegg.col,
           cpd.FC = x$cpd.FC,
           pathway.code = x$pathway.code,
           organism.code = x$organism.code,
           suffix  = x$suffix,
           kegg.dir = x$kegg.dir)

path_call <-ocpu_pathway_mapping(dave_path_connection,body=body,save.dir='.')
