library(testthat)
library(dave.preproc)

test_check("dave.preproc")
