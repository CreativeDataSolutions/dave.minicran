context("preproc dave_ full")

library(dave.preproc)


#shared funs
#-----------
test_info<-function(test_data='data',test_fun_name='function'){
  paste0('data: ',test_data,"\nfunction: ",test_fun_name)
}


#set up data
#---------------
data(dave_)
data(dave_var_meta)

#set data
data<-dave_
meta<-dave_var_meta

#variable ID
var.id<-'ID'

#row group
row_meta<-c('lable','class','age')

#general error wil also break the test
init_obj<-preproc_init_data(data,meta,var.id,row_meta)
check_data<-check(init_obj)
obj<-merge_data(init_obj)

#auto tests
#----------
test_that(test_info('dave','preproc_init_data'), {
  expect_true(class(init_obj) == 'cer_init')
})


test_that(test_info('dave','preproc check'), {
  expect_true(check_data$valid)
})


test_that(test_info('dave','preproc merge'), {
  expect_true(class(obj) == 'cer_obj')
})


test_that(test_info('dave','preproc summary'), {
  expect_true(class(invisible(summary(obj))) == 'list')
})


test_that(test_info('dave','preproc plot'), {
  expect_true('ggplot' %in% class(plot(obj)))
})


context("preproc dave_ missing row data")

#variable ID
var.id<-'ID'

#row group
row_meta<-c('lable','class','age')

#missing in class
percent<-.1
data2<-data
data2$class[sample(1:nrow(data),floor(nrow(data)*percent))]<- NA

#general error wil also break the test
init_obj<-preproc_init_data(data2,meta,var.id,row_meta)
check_data<-check(init_obj)
obj<-merge_data(init_obj)

test_that(test_info('dave missing','preproc_init_data'), {
  expect_true(class(init_obj) == 'cer_init')
})


test_that(test_info('dave missing','preproc check'), {
  expect_true(check_data$valid)
})


test_that(test_info('dave missing','preproc merge'), {
  expect_true(class(obj) == 'cer_obj')
})


test_that(test_info('dave missing','preproc summary'), {
  expect_true(class(invisible(summary(obj))) == 'list')
})


test_that(test_info('dave','preproc plot'), {
  expect_true('ggplot' %in% class(plot(obj)))
})
