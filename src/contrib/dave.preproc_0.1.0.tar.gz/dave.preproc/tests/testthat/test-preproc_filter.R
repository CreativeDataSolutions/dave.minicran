context("preproc_filter dave_ full")

library(dave.preproc)

#shared funs
#-----------
test_info<-function(test_data='data',test_fun_name='function'){
  paste0('data: ',test_data,"\nfunction: ",test_fun_name)
}


#set up data
#---------------
data(dave_)
data(dave_var_meta)

#set data
data<-dave_
meta<-dave_var_meta

#row group
row_meta<-c('lable','class','age')

#group
group<-'class'

#need to make sure data and col_meta are validated and merged
main<-list(data=data %>% dplyr::select(-one_of(row_meta)),
          col_meta=dave_var_meta,
          row_meta=data %>% dplyr::select(one_of(row_meta)))


#to work out mech when vars need to be part of data
#and when seperate
.data<-data.frame(main$data,main$row_meta %>% dplyr::select(one_of(group)))
obj<-filter_missing(.data,group=group)

test_that(test_info('dave','filter missing'), {
  expect_true(class(obj) == 'filter_obj')
})


test_that(test_info('dave','summary'), {
  expect_true(class(invisible(summary(obj))) == 'list')
})


test_that(test_info('dave','plot'), {
  expect_true('ggplot' %in% class(plot(obj)))
})

#filter object
id<-obj$percent$full<=50
obj<-col_filt_obj(main,id)


test_that(test_info('dave','column filter'), {
  expect_true('data_cube' %in% class(obj))
})


test_that(test_info('dave','summary'), {
  expect_true(class(summary(obj)) == 'list')
})


test_that(test_info('dave','plot'), {
  expect_true('ggplot' %in% class(plot(obj)))
})

