## source shared functions
source(file.path(getOption("dave.path.data"),"app/init.R"), encoding = getOption("dave.encoding"), local = TRUE)
source(file.path(getOption("dave.path.data"),"app/dave.R"), encoding = getOption("dave.encoding"), local = TRUE)

source(file.path(getOption("dave.path.report"),"app/init.R"), encoding = getOption("dave.encoding"), local = TRUE)
source(list.files(file.path(getOption("dave.path.report"),"app/tools/analysis"),full.names = TRUE),encoding = getOption("dave.encoding"), local = TRUE)


## source data & app tools from dave.data
for (file in list.files(c(file.path(getOption("dave.path.data"),"app/tools/app"),file.path(getOption("dave.path.data"),"app/tools/data")),pattern = "\\.(r|R)$", full.names = TRUE)){source(file, encoding = getOption("dave.encoding"), local = TRUE)}

## list of dave menus to include
#hack to block in dev

if(Sys.getenv('APP_NAME') !='') {
  #dave. data is ignored
  rmenus<-c("dave.data",paste0('dave.',Sys.getenv('APP_NAME')),'dave.report')

} else {
  rmenus <-
    c(
      "dave.data",
      "dave.preproc",
      "dave.stat",
      "dave.cluster",
      "dave.multivariate",
      "dave.pathway",
      "dave.rf",
      "dave.network",
      "dave.report"
    ) # need to have xx.xx package name to be loaded correctly
}



## packages to use for example data
options(dave.example.data = c("dave.preproc","dave.stat","dave.network"))


# browser()
#TODO figure out if this is needed
#no clue why like this vs source?
# first is dave data which already sourced above
## "sourcing" dave"s package functions in the server.R environment
for (i in rmenus[-1]) {
  eval(parse(text = paste0("dave.data::copy_all(", i, ")")))
  ipath <-
    paste0(strsplit(i, "\\.")[[1]], collapse = ".path.")

  for (file in list.files(
    file.path("tools/analysis"),
    pattern = "\\.(r|R)$",
    full.names = TRUE
  )) {
    source(file,
           encoding = getOption("dave.encoding"),
           local = TRUE)
  }
}

#tons of dep overwritting namespace problems...
select<-dplyr::select

## save state on refresh or browser close
saveStateOnRefresh(session)

