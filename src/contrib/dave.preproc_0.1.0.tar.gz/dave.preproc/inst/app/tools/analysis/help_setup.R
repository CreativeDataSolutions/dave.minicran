preproc_help_lookup <-
  list(
    url = 'https://creativedatasolutions.github.io/dave.docs/partial/preprocess.html',
    preproc = list(
      Calculate = 'calculate',
      Plot = 'explore-and-plot',
      Explore = 'explore-and-plot',
      Report = 'report'
    ),
    filter = list(
      Calculate = 'calculate-1',
      Plot = 'explore-and-plot-1',
      Explore = 'explore-and-plot-1',
      Report = 'report-1'
    )
  )

map_preproc_help <-
  function(tab = input$tabs_preproc,
           id = 'preproc',
           lookup = preproc_help_lookup,
           url = preproc_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }

map_preproc_filter_help <-
  function(tab = input$tabs_preproc_filter,
           id = 'filter',
           lookup = preproc_help_lookup,
           url = preproc_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }


callModule(modalModule,id='preproc_filter_help',content=map_preproc_filter_help)
callModule(modalModule,id='preproc_help',content=map_preproc_help)
