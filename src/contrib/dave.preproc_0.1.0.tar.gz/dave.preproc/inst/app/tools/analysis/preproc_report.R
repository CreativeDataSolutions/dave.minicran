preproc_params<-reactive({

  list(obj=preproc_values[['preproc']],
       summary=preproc_values[['summary']])

  })



preproc_report_obj<-function(){
  .package<-'dave.preproc'
  report_name<-'preproc_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path=getOption("dave.report.rmd.path")
  html_save_path= getOption('dave.report.html.path')

  .report_obj<-get_report_obj(.package = .package,
                              report_name= report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)

  return(.report_obj)
}


name<-'preproc'

preproc_report<-callModule(reportGenerator, name,
                                  report_params = preproc_params,
                                  report_obj=preproc_report_obj(),
                                  .available = preproc_available)

# })
