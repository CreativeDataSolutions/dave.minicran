#storage used in report
preproc_values<-reactiveValues()

## choice lists for compare means
preproc_plots <- c("overview" ='overview','missing'='missing')

# main fun preproc
## list of function arguments
# preproc_args <- as.list(formals(preproc_init_data))

## list of function inputs selected by user
preproc_inputs <- reactive({
  ## loop needed because reactive values don't allow single bracket indexing
  # preproc_args$arg<-input$something
  # preproc_args$

  for (i in r_drop(names(preproc_args)))
    preproc_args[[i]] <- input[[paste0("preproc_",i)]]
  preproc_args
})

###############################
# initialize and pre process data
###############################

#need controls for when only column meta is supplied
#e.g. for networks

output$ui_preproc_data_type <- renderUI({
  #req(input$dataset)
  if(is.null(input$dataset) || input$dataset =='') return()

  radioButtons(
    'preproc_data_type',
    'Data type',
    choices = c('samples', 'variables'),
    selected = 'samples',
    inline = TRUE
  )

})

#set factor
output$ui_preproc_row_factor <- renderUI({
  #req(input$dataset)
  if(is.null(input$dataset) || input$dataset =='') return()

  vars<- colnames(r_data[[input$dataset]])

  #conditionalPanel(condition = "input.preproc_data_type == 'samples'",
    selectizeInput(inputId = "preproc_row_factor",
                label = "Row meta data",
                choices = vars,
                # selected = state_single("preproc_row_factor",vars),
                multiple = TRUE,
                options = list(plugins = list("remove_button")))
 # )

})


#variable meta data
output$ui_preproc_data2 <- renderUI({

  #what sets select?
  #get all data set names

  vars <-r_data[['datasetlist']] # no clue why auto selecting

  selectizeInput(inputId = "preproc_data2",
              label = "Meta data",
              choices = vars,
              # selected = '',
              multiple = FALSE,
              options = list(plugins = list("remove_button")))
})

#variable unique key
output$ui_preproc_data2_var <- renderUI({
  if (is.null(input$preproc_data2)) return()
  # req(input$preproc_data2)

  vars<- '' #colnames(r_data[[input$preproc_data2]])

  selectizeInput(inputId = "preproc_data2_var",
              label = "Variable index:",
              choices = vars,
              # selected = state_single("preproc_data2_var",vars),
              multiple = FALSE,
              options = list(plugins = list("remove_button")))
})

#react to data types
#for col meta expect only data input
observeEvent(input$preproc_data_type,{

  if(input$preproc_data_type == 'variables') {
      updateSelectizeInput(session,'preproc_row_factor',selected=NULL)
      updateSelectizeInput(session,'preproc_data2_var',selected=NULL)
      updateSelectizeInput(session,'preproc_data2',selected=NULL)

      disable('preproc_row_factor')
      disable('preproc_data2_var')
      disable('preproc_data2')

    } else {
      enable('preproc_row_factor')
      enable('preproc_data2_var')
      enable('preproc_data2')
    }

})

#NULL events
#----------------------
observeEvent(input$preproc_data2,{

    if(is.null(input$preproc_data2) ) return()
    if(input$preproc_data2 =='') {
        vars<-''
      } else {

        vars<- colnames(r_data[[input$preproc_data2]])
    }

    updateSelectizeInput(session = session, inputId = "preproc_data2_var", choices=vars,selected=NULL)
})

#calculate button
output$ui_preproc_calculate <- renderUI({
  # browser()
  actionButton("preproc_calculate", "Calculate",icon=icon('check'))
})


output$ui_preproc <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel(condition = "input.tabs_preproc  == 'Calculate'",
      tagList(
             fluidRow(column(12,
                             uiOutput('ui_preproc_calculate'),
                             uiOutput('ui_preproc_data_type')
                             )
      ),
      br(),
      bs_accordion(id="preproc_collapse_panel") %>%
        bs_append(title = tags$label(class='bsCollapsePanel', icon("ellipsis-v") , "Samples"),
                  content=
                    fluidRow(column(12,
                        uiOutput("ui_preproc_row_factor")
                        )
                      )
          ) %>%
        bs_append(title = tags$label(class='bsCollapsePanel', icon("ellipsis-h") , "Variables"),
                  content=
                    fluidRow(column(12,
                      uiOutput("ui_preproc_data2"),
                      uiOutput("ui_preproc_data2_var")
                      )
                    )
        ) %>%
        bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                  content=
                    uiOutput("ui_preproc_merge_save")
        )
      )
    ),
    conditionalPanel(condition = "input.tabs_preproc  == 'Plot'| input.tabs_preproc  == 'Explore'",
                     tagList(
                       bs_accordion(id="preproc_plot_collapse_panel") %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("bar-chart"), "Plot"),
                                   content=
                                     tagList(
                                       selectizeInput(inputId = "preproc_plots", label = "Select plots:",
                                                             choices = preproc_plots,
                                                             selected = state_single("preproc_plots", preproc_plots, "overview"),
                                                             multiple = FALSE,
                                                             options = list(plugins = list('remove_button', 'drag_drop'))),
                                       conditionalPanel("input.preproc_plots == 'missing'",
                                                        checkboxInput('preproc_par_coords',label = 'sample trends',value=TRUE)
                                                        )
                                     )


                         )
                     )
    ),
    fluidRow(
      column(12,align="right",modalModuleUI(id="preproc_help")))
    # help_modal('Merge','preproc_help',inclMD(file.path(getOption("dave.path.preproc"),"app/tools/help/demo.md")))
  )
})


preproc_plot <- reactive({
  list(plot_width = 650, plot_height = 400 * length(input$preproc_plots))
})

preproc_plot_width <- function()
  preproc_plot() %>% { if (is.list(.)) .$plot_width else 650 }

preproc_plot_height <- function()
  preproc_plot() %>% { if (is.list(.)) .$plot_height else 400 }



preproc_available <- reactive({
  if(is.null(input$preproc_calculate) || input$preproc_calculate ==0) {
    return("This analysis is used to link compatible sample and variable meta data. Select accordingly and then calculate.")
  }

  isolate({
    if(!is.null(input$preproc_data2) && input$preproc_data2 != ''){
      if(is.null(input$preproc_data2_var) || input$preproc_data2_var == ''){
        return('Select a variable join index matching data column names to proceed.')

      }
    }

  })

  "available"
})

#main fun
#shared in filter
.preproc <- reactive({

  input$preproc_calculate

  isolate({
    #merge data and meta data
    data<-if(is.null(input$dataset)) NULL else r_data[[input$dataset]]
    meta<-if(is.null(input$preproc_data2)) NULL else r_data[[input$preproc_data2]]
    var.id<-input$preproc_data2_var

    #need to make the index unique and
    #make sure names does not conflict with dave.network 'id'

    #could check if this even exists
    row_meta.id<-input$preproc_row_factor

    replicate<-if(input$preproc_data_type == 'variables') TRUE else FALSE



    #need to allow update of an existing data cube
    #check if object has row and col meta
    if(!replicate){

      cols<-.getdata_col_meta()
      rows<-.getdata_row_meta()

      if(!is.null(rows) | !is.null(cols)){

        obj<-list()
        obj$data<-data
        if(is.null(meta)) obj$col_meta<-cols
        obj$row_meta<-rows

        data<-obj
        class(data)<-c('data_cube',class(obj))
      }

    }


    #this will create
    out<-dave_init_data(data,meta,row_meta.id,var.id,replicate)

    #various validations
    #noramalize network index sets index to 'id'
    out$col_meta<-format_net_index(out$col_meta)

    preproc_values[['preproc']]<-out

    return(preproc_values[['preproc']])
  })

})

.summary_preproc <-reactive({
  if (preproc_available() != "available") {
    preproc_values[['summary']]<-html_text_format(preproc_available())
    return(preproc_values[['summary']])
  }
  # browser()
  isolate({
    msg<-'\u2713 Calculating...'#tags$label('Saving',icon('check')) %>% as.character() %>% HTML()
    withProgress(message=msg,value=1,{
      Sys.sleep(.1)
      #create summary which will be used in the report here?
      preproc_values[['summary']]<-list(summary(.preproc())$description) %>%
        html_paragraph_format(.)
      return(preproc_values[['summary']])
    })
  })

})

output$summary_preproc_ui<-renderUI({
  .summary_preproc() %>% enc2native () %>% HTML()
})

.plot_preproc <- reactive({
  if (preproc_available() != "available") return(preproc_available())

  if(!input$tabs_preproc == "Explore" & !input$tabs_preproc == "Plot") return() # need plot button else will trigger plot on tab change (should cache image)
  .plotly<-FALSE
  if(input$tabs_preproc == "Explore"){ .plotly<- TRUE}
  # type<-input$preproc_plots

  # browser()
  #need to better bundle plot arguments
  plot_args<-list(obj=.preproc(),
                  type=input$preproc_plots,
                  par_coords=input$preproc_par_coords)

  # #allow if a data cube
  # #problem needsa
  # obj<-.preproc()
  # # if(!'data_cube' %in% +class(obj)) return(preproc_available())
  #
  # p<-plot(obj,type=type)

  p<-do.call('plot',plot_args)
  if(.plotly) return(p) else print(p)

})

#plotly
output$plotly_preproc <- renderPlotly({
  msg<-'\u2713 Plotting...'#tags$label('Saving',icon('check')) %>% as.character() %>% HTML()
  withProgress(message=msg,value=1,{
  obj<-.plot_preproc()
  validate(need(!is.null(obj)==TRUE && is.character(obj) != TRUE,'Calculate to view plots'))
  ggplotly(obj)
  })
})

#save merged objects
output$ui_preproc_merge_save<-renderUI({
  tags$table(
    tags$td(textInput("preproc_merge_dataset", "Save as", input$dataset)),
    tags$td(actionButton("preproc_merge_save", "Save"), style="padding-top:30px;")
  )
})


#save logic
#---------
observeEvent(input$preproc_merge_save, {
  ## saving to a new dataset if specified
  isolate({
    dataset <- input$preproc_merge_dataset # name
    #main
    obj<-.preproc()
    #list(data=.data,row_meta=row.meta,row_meta_assigned=row.meta_assigned,col_meta=col.meta)
    #objects
    data <- obj$data
    row_meta<-obj$row_meta
    col_meta<-obj$col_meta

    #errors when same name saved as active data set
    #and app tries to recalculate
    #overwrite and save
    r_data[[dataset]] <- data
    r_data[[paste0(dataset,"_descr")]] <- r_data[[paste0(input$dataset,"_descr")]]
    .save_list<-c(dataset)


    # browser()
    #save meta data objects
    if(!is.null(row_meta)){
      name_row<-paste0(dataset,'_row_meta')
      r_data[[name_row]]<-row_meta
      .save_list<-c(.save_list,name_row)
    }

    if(!is.null(col_meta)){
      name_col<-paste0(dataset,'_col_meta')
      r_data[[name_col]]<-col_meta
      .save_list<-c(.save_list,name_col)
    }

    #de duplicate
    r_data[['datasetlist']] %<>% c(.save_list) %>% unique

    msg<-'\u2713 Saving...'#tags$label('Saving',icon('check')) %>% as.character() %>% HTML()

    #!!!TODO!!!
    #should not update this? else this will trigger view reload
    #need data set reload in data view?
    withProgress(message=msg,value=1,{
      Sys.sleep(.1)
      cat('<---- updating dataset list ---->')
      updateSelectInput(session = session, inputId = "dataset", selected = dataset)
    })
  })

  #updateSelectInput(session,"preproc_row_factor",selected = NULL)
  #updateSelectInput(session,"preproc_data2",selected = NULL)

})


# output is called from the main dave ui.R
output$preproc <- renderUI({
  #browser()
  register_print_output("summary_preproc", ".summary_preproc" )
  register_plot_output("plot_preproc", ".plot_preproc",
                       height_fun = "preproc_plot_height")

  # two separate tabs
  preproc_output_panels <- tabsetPanel(
    # type= 'pills',
    id = "tabs_preproc",
    # tabPanel("Calculate", verbatimTextOutput("summary_preproc"),icon = icon("sliders")),
    tabPanel("Calculate", uiOutput('summary_preproc_ui'),icon = icon("sliders")),
    tabPanel("Explore",icon=icon('pencil-square-o'),plotlyOutput("plotly_preproc", height = "100%")),
    tabPanel("Plot",icon = icon("bar-chart"),
             plot_downloader("preproc", height = preproc_plot_height()),
             plotOutput("plot_preproc", height = "100%")),

    tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('preproc'))
  )

  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('scissors'),as.character(" Preprocess")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('tasks'),as.character(" Merge")))),
                 tool_ui = "ui_preproc",
                 output_panels = preproc_output_panels)
})

# observeEvent(input$preproc_report, {
#   figs <- FALSE
#   outputs <- c("summary")
#   inp_out <- list(list(show = input$preproc_show), "")
#   if (length(input$preproc_plots) > 0) {
#     outputs <- c("summary","plot")
#     inp_out[[2]] <- list(plots = input$preproc_plots)
#     figs <- TRUE
#   }
#   update_report(inp_main = clean_args(preproc_inputs(), preproc_args),
#                 fun_name = ".preproc",
#                 inp_out = inp_out, outputs = outputs, figs = figs,
#                 fig.width = preproc_plot_width(),
#                 fig.height = preproc_plot_height())
# })
