# data import
# filter functions
#TODO update dave to limit data size for previews



#' NULL_empty
#'
#' @param x
#' @details conver empty quotes to NULL, useful for formatting shiny UI objects
#' @return
#' @export
#'
#' @examples
NULL_empty<-function(x){
  if(!is.null(x) && x =='' ) NULL else x
}

#' format_cube
#'
#' @param obj data_cube
#' @details convert empty to NULLS
#' @return
#' @export
#'
#' @examples
format_cube<-function(obj){

  if(!'data.frame' %in% class(obj)){
   obj<-lapply(obj,NULL_empty) %>%
    setNames(.,names(obj))
  }

}

#' dave_cube_row
#' @details manipulate data columns and row meta
#' @return
#' @export
#'
#' @examples
dave_cube_row<-function(obj,vars){

  #remove columns from data and add to row meta
  #make sure col meta is updated based on name accordingly
  obj<-format_cube(obj)

  if(is.null(obj$data)) {
    obj<-list()
    obj$data<-obj
  }

  if(is.null(vars)) return(obj)

  row.meta<-obj$data %>% dplyr::select(one_of(vars))
  obj$data<-obj$data %>% dplyr::select(-one_of(vars))


  if(!is.null(obj$row_meta)){
    obj$row_meta<-cbind(obj$row_meta,row.meta)
  } else {
    obj$row_meta<-row.meta
  }


  obj
}

#' dave_replicate_data
#' @details format placeholder data when only col meta is supplied
#' @return
#' @export
#'
#' @examples
dave_replicate_data<-function(data,type='data'){


  if(type=='list'){
    .data<-data.frame(key=colnames(data),values=NA)
    tmp<-as.list(data)
    for(i in 1:nrow(.data)){
      .data$values[i]<-tmp[i]
    }
    class(.data)<-c('col_data',class(.data))
    return(.data)
  }

  if(type=='summary'){
   # get summary stats for each variable
  #number of unique, NA, 5 values

  }

  if(type=='data'){
    class(data)<-c('col_data',class(data))
    return(data)
  }

}


#' dave_cube_col_init
#'
#' @param obj
#' @details combine
#' @return
#' @export
#'
#' @examples
dave_cube_col_init<-function(obj,meta=NULL,var.id='names',replicate=FALSE){


  #already init
  if(!is.null(obj$col_meta)) return(obj)

  obj<-format_cube(obj)

  if(is.null(obj$data)) {
    obj<-list()
    obj$data<-obj
  }

  data<-obj$data

  #init column meta
  #control for when  col_data
  if(replicate){

    #add row_meta if present
    if(!is.null(obj$row_meta)){
      data<-cbind(obj$row_meta,obj$data)
    }


    obj$data<-dave_replicate_data(data)
    # obj$col_meta<-cbind(data.frame(id=c(1:nrow(data)) %>% as.character(),stringsAsFactors = FALSE),data) %>%
    #   setNames(.,make.unique(colnames(.))) # handle duplicates.. upstream?
    obj$col_meta<-data %>% setNames(.,make.unique(colnames(.)))
    class(obj)<-c('data_cube',"cer_obj",class(obj))
    return(obj)
  }

  if(is.null(meta)) {
    #using character for joins; what about uploads
    # obj$col_meta<- data.frame(id=c(1:ncol(data)) %>% as.character(),names=colnames(data))
    obj$col_meta<-data.frame(names=colnames(data))
    class(obj)<-c('data_cube',"cer_obj",class(obj))
    return(obj)
  }


  #assume order is correct already
  #create join id based on colnames
  #have to have a join ID!
  if(is.null(var.id)){
    var.id<-'names' # this should be present
  }

  meta[[var.id]]<-as.character(meta[[var.id]]) #
  # }
  #use check to gate errors prior to join
  #allow as character vs integer index join

  #need to check for compatibility

  obj$col_meta<-left_join(data.frame(colnames(data)) %>% setNames(.,var.id),meta,by=var.id)


  class(obj)<-c('data_cube',"cer_obj",class(obj))
  obj
}

#' @title dave_init_data
#' @param data
#' @param meta variable meta data
#' @param var.id column in variable meta to set as variable unique key
#' @return list of components obj
#' @export
dave_init_data<-function(data,meta,row_meta,var.id,replicate=FALSE){

  #prepare merge for 3 types
  #1) only data
  #2) only meta
  #3) data and meta

  #create col meta ID (rename id present)
  #create col meta name (rename id present) this is the column names


  #1) initialize meta
  #with column index from data
  #account for row_meta
  # require_merge<-FALSE

  #2) duplicate data to col meta
  # set attribute to control how col meta calcs are put
  # create fake data? since useless anyway... could grow like row meta
  #merge if var.id supplied

  #3) merge as expected

  #initialize data cube
  obj<-list()

  meta<-if(replicate) NULL else NULL_empty(meta)

  #allow modification of existing cube?
  #have to ignore or merge if me
  if( 'data_cube' %in% class(data)) {

     obj$data<-NULL_empty(data$data) # ...wtf
     obj$row_meta<-data$row_meta
     if(is.null(meta)) meta<-data$col_meta

  } else {
     obj$data<-NULL_empty(data)

  }

  # row_meta<-if(replicate) NULL else NULL_empty(row_meta)
  row_meta<-NULL_empty(row_meta)



  #row_meta
  obj<-dave_cube_row(obj,row_meta)

  #column meta create 'id' index for networks
  obj<-dave_cube_col_init(obj,meta=meta,var.id,replicate)

  obj
}


#' #' dave_merge_col
#' #' @details merge data columns and col meta, base on data colnames and col meta names
#' #' @return
#' #' @export
#' #'
#' #' @examples
#' dave_merge_col<-function(obj){
#'
#' }
#'
#' #' dave_cube_col
#' #' @details manipulate data columns and col meta rows
#' #' @return
#' #' @export
#' #'
#' #' @examples
#' dave_cube_col<-function(){
#'
#' }

#' @title check
#' @rdname check
#' @param obj
#' @export
check <- function(x,...) UseMethod("check", x)

#' Check method
#' @method check data_cube
#' @param obj of class data_cube
#' @import dplyr
#' @export
#' @details description
check.data_cube<-function(obj,n=5){

  #sumarise data cube

  #describe row_meta
  x<-colnames(obj$row_meta)
  if(is.null(x)) {
    row_meta_n<-0
    row_meta_names<-NULL
  } else {
    row_meta_n<-length(x)
    row_meta_names<-grammatical_paste(x[1:n] %>% na.omit())
  }


  #describe the data
  col_data<-if('col_data' %in% class(obj$data)) TRUE else FALSE
  if(col_data) {

    data_desc<-'The variable data was formatted.'
    data_col_n<-nrow(obj$col_meta)
    data_row_n<-0
    data_NA<-is.na(obj$col_meta) %>%
      sum()
    col_meta_names<-NULL
    col_meta_n<-NULL

  } else {

    data_desc<-'The data was formatted.'
    data_col_n<-ncol(obj$data) - row_meta_n
    data_row_n<-nrow(obj$data)
    data_NA<-is.na(obj$data) %>%
      sum()
    col_meta_names<-grammatical_paste(colnames(obj$col_meta)[1:n] %>% na.omit())
    col_meta_n<-ncol(obj$col_meta)
  }


  #compile description
  # Describe data. Row meta. Col meta. Merge.
  desc<-c(data_desc)
  desc<-c(desc,
          paste0(
            'There were ',
            ifelse(data_row_n == 0, '', paste0(data_row_n, ' samples, ')),
            data_col_n,
            ' variables and ',
            ifelse(data_NA == 0, 'no', data_NA),
            ' missing values.'
          ))
  desc<-c(desc,if(!is.null(row_meta_names)){
    paste0('The row meta data contained ', row_meta_n,' object(s) (e.g. ',row_meta_names,').')} else {NULL})
  desc<-c(desc,if(!is.null(col_meta_names)){
    paste0('The column meta data contained ',col_meta_n,' objects(s) (e.g. ',col_meta_names,').')} else {NULL})

  desc<-paste0(desc,collapse=' ')

  list(
    description = desc
  )

}


#' @export
data_cube<-function(x,...){
  UseMethod("data_cube")
}

#try to convert existing to an index
#just create a new numeric one?

#' @export
format_net_index<-function(obj){


  tmp<-1:nrow(obj)

  #account for column names in data
  if(!is.null(obj$id)) {

    obj$id.1<-obj$id

  }

  obj$id<-tmp

  return(obj)

}


#' @title summary.data_cube
#' @param obj of class filter_obj
#' @method summary data_cube
#' @export
#' @details show filtered results
summary.data_cube<-function(obj,.print=FALSE){

  samples<-if('col_data' %in% class(obj$data)) 0 else nrow(obj$data)
  tmp<-list(samples=samples,
            variables=ncol(obj$data),
            row_meta =  colnames(obj$row_meta),
            column_meta = colnames(obj$col_meta)
  )

  desc<-check(obj)

  tmp<-list(obj=tmp,description=desc)

  if(.print) {
    print(tmp, row.names = FALSE, right = FALSE)
  } else {
    return(tmp)
  }
}

#' @title plot_data_cube
#' @export
#' @details view missing data or zeros
plot_data_cube<-function(obj,type='missing',...){

  if(type =='missing'){
    #if all missing
    data<-obj$data
    tmp<-is.na(data) #| data == 0

    if(sum(tmp) >0){
      rows<-matrix(1:nrow(data),nrow(data),ncol(data))
      cols<-matrix(1:ncol(data),nrow(data),ncol(data),byrow = TRUE)
      df<-data.frame(y=as.vector(rows),x=as.vector(cols),id=as.vector(tmp))
      df<- df  %>% filter(id)

      #allow parallel coords plots
      #hack for ellipses expansion
      par_coords<-list(...)$par_coords
      if(!is.null(par_coords) && par_coords) {


        # width missing across variables for a sample
        df<-df %>% group_by(y) %>%
          dplyr::summarise(sample=n()) %>%
          mutate(sample={ (sample/max(df$y))*100} %>% round(.,2) ) %>%
          left_join(df,.,by='y')


        p<-ggplot(df, aes(x=x,y=y,color=id)) +
          geom_path(aes(color = id,group=y,size=sample), color='gray40',alpha = 0.5,lineend = 'round', linejoin = 'round') +
          scale_size_continuous(name = 'sample %\nmissing',range=c(.25,1.25)) +
          guides(size = FALSE) +
          geom_point(size=1) +
          scale_color_manual(values = c("red"),name='Missing') +
          theme_classic()+
          ylab('sample #') + xlab('variable #')

      } else {


        p<-ggplot(df, aes(x=x,y=y,color=id)) +
          # geom_tile() +
          geom_point(size=1) +
          scale_color_manual(values = c("red"),name='Missing') +
          theme_classic()+
          ylab('sample #') + xlab('variable #')
      }
    } else {

      p<-message_plot(message='No missing values found.')


    }


  }

  if(type == 'overview'){
    #used to be OOO but not using this class anymore
    p<-plot_cer_obj(obj)
  }

  return(p)

}

#' Plot method
#' @param obj of class data_cube
#' @method plot data_cube
#' @export
#' @details plot missing overview
plot.data_cube<-function(obj,...){
  plot_data_cube(obj=obj,...)
}


#' @param obj of class cer_obj
#' @export
#' @import reshape2 ggplot2
#' @details test plot, removed OOO since not using class anymore
plot_cer_obj <- function(obj, ...) {
  .obj <- summary(obj)$obj
  .obj <-
    data.frame(
      samples = .obj$samples,
      variables = .obj$variables,
      col_meta = length(.obj$column_meta),
      row_meta = length(.obj$row_meta)
    ) %>%
    reshape2::melt()
  ggplot(.obj, aes(x = variable, y = value)) + geom_bar(stat = 'identity') +
    geom_text(aes(label = value, x = variable, y = value + 10)) +
    scale_y_log10() +
    theme_classic()
  #plotly used in shiny app
}



test<- function(){



  library(dave.stat) #only correct dave_data
  dave_data[1:5,3:5]<-NA

  obj<-dave_init_data(dave_,dave_data_col_meta,row_meta=c('label','class','age'),var.id = 'ID')
  #misisng values plot
  obj$data[1:5,3:5]<-NA
  plot(obj,'missing')

  test_data<-function(){

    #load data
    data(dave_)
    data(dave_var_meta)

    #set data
    data<<-dave_
    meta<<-dave_var_meta

    #variable ID
    var.id<<-'ID'

    #row group
    row_meta<<-c('lable','class','age')
  }

  #add missing values to the meta data
  data("dave_")

  data<-data.frame(id=c(NA,1:3,NA),foo='A')
  data<-data.frame(id=c('A','D',NA,''),foo='A')
  id<-'id'
  id<-'foo'



  format_net_index(data,id,fix_NA = TRUE)

  format_net_index<-function(obj,id,fix_NA=TRUE){



    #makesure the id is unique, numeric and
    #properly named
    #bit of wtf ... to make sure all end up numeric
    tmp<-data[[id]] %>%
      as.character() %>%
      make.unique() %>%
      as.factor() %>%
      as.numeric()


    if(fix_NA){

      #treat as missing
      tmp[tmp == '']<-NA

      ind<-is.na(tmp)
      start<-max(tmp,na.rm = TRUE )+1
      end<-start + sum(ind) -1
      tmp[ind]<-start:end
    }

    #account for column names in data
    if(!is.null(data$id)) {

      data$id.1<-data$id

    }

    data$id<-tmp

    return(data)

  }

  # .row<-nrow(dave_)
  # .col<-c(5,15,23)
  # missing<-lapply(1:length(.col),function(x){sample(1:.row,floor(.row*.3))})
  #
  # for(i in 1:length(.col)){
  #   dave_[missing[[i]],.col[i]]<-NA
  # }
  #
  # save(dave_,file='data/dave_.rda')


  #load data
  library(dave.preproc)
  data(dave_)
  data(dave_var_meta)

  #data and meta requiring join
  test_1<-function(){

    data<-dave_
    meta<-dave_var_meta
    var.id<-'ID'
    # var.id<-NULL  # have to have this

    #row group
    row_meta<-c('label','class')

    obj<-dave_init_data(data,meta,row_meta,var.id)
    check(obj)
    summary(obj)
    plot(obj)


    #partial add
    row_meta<-'age'
    .obj<-dave_init_data(obj,meta,row_meta,var.id)
    summary(.obj)
  }

  #test join
  test_2<-function(){

    data<-dave_[,1:20]
    meta<-dave_var_meta
    var.id<-'ID'

    #row group
    row_meta<-c('label','class','age')

    obj<-dave_init_data(data,meta,row_meta,var.id)
    summary(obj)
    check(obj)
    plot(obj,type='overview')
  }

  #replicate data to meta
  test_3<-function(){

    data<-dave_var_meta
    meta<-NULL
    var.id<-'ID'
    var.id<-NULL

    #row group
    #handle row meta
    row_meta<-c('CID')

    obj<-dave_init_data(data,meta,row_meta,var.id,replicate=TRUE)
    summary(obj)
    check(obj)
    plot(obj)
    plot(obj,type='overview')

   }

  OLDER<-function(){
    #check
    check_data<-check(init_obj)
    obj<-merge_data(init_obj)

    #data summary
    summary(obj)
    plot(obj)
    plot(obj,type='overview')

    #meta only
    #---------
    #set data
    library(dave.preproc)
    data(diamonds)
    data<-NULL
    meta<-diamonds[1:100,]

    #variable ID
    var.id<-'cut' # handle when NULL, has to exist, bad idea?
    var.id<-NULL

    #row group
    row_meta<-NULL# bad can be different?
    row_meta<-'depth'# bad can be different?

    #data object
    init_obj<-preproc_init_data(data,meta,var.id,row_meta)
    check(init_obj)
    obj<-merge_data(init_obj)

    #data only
    #------
    data(diamonds)
    data<-diamonds[1:100,]
    meta<-NULL

    #variable ID
    var.id<-NULL

    #row group
    row_meta<-NULL# bad can be different?

    #data object
    init_obj<-preproc_init_data(data,meta,var.id,row_meta)
    check(init_obj)
    (obj<-merge_data(init_obj))

    #data summary
    summary(obj)
    plot(obj)
    plot(obj,type='overview')



    #filter based on missing
    group<-'class'
    data<-data.frame(obj$data,obj$row_meta %>% dplyr::select(one_of(group)))
    x<-filter_missing(data,group=group)

    thresh<-30
    plot(x,thresh=thresh)
    summary(x,thresh=thresh)

    id<-x$percent$full<thresh
    obj<-col_filt_obj(obj,id)

    plot(obj,thresh=thresh)
    summary(obj)


    summary(filt_data)
    plot(filt_data)

    #only column meta
    data<-dave_data
    meta<-dave_var_meta
    #variable ID
    var.id<-'X.PeakId'
    #row group
    row_meta<-NULL

    #data object
    init_obj<-preproc_init_data(data,meta,var.id,row_meta)
    #check
    check_data<-check(init_obj)
    obj<-merge_data(init_obj)

    #only row meta
    data<-dave_data
    meta<-NULL
    #variable ID
    var.id<-'X.PeakId'
    #row group
    row_meta<-c('cellType','SampleID')

    #data object
    init_obj<-preproc_init_data(data,meta,var.id,row_meta)
    #check
    check_data<-check(init_obj)
    obj<-merge_data(init_obj)

    #filter based on missing
    data<-data.frame(obj$data,obj$row_meta %>% dplyr::select(one_of(group)))
    filt_data<-filter_missing(data[,1939:1950],group=group)

    updated_data<-col_filt_obj(obj,filt=filt_data$drop)
    results_state<-col_filt_obj(obj,filt=filt_data$drop,thresh=1)
    summary(results_state)

    #testing plotly
    library(plotly)
    library(ggplot2)

    p<-ggplot(mtcars, aes(x = mtcars$wt, y = mtcars$mpg)) + geom_point()

    ggplotly(p)


    #wrong var id
    var.id<-'PeakBin'
    var.id<-'X.PeakId'
    init_obj<-preproc_init_data(data,meta,var.id,row_meta)
    check(init_obj)
    obj<-merge_data(init_obj)
    # #filter based on missing
    # data<-data.frame(obj$data,obj$row_meta %>% select(one_of(group)))
    # filt_data<-filter_missing(data,group=group)
    #
    # updated_data<-col_filt_obj(obj,filt=filt_data$percent$full,thresh=40)
    # summary(updated_data)
  }

}
