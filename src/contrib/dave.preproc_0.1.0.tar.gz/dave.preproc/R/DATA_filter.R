#' filter_missing
#' @param data
#' @param group subset rows for induvidual calculation
#' @import dplyr
#' @return maximum percent NA per group per variable
#' @export
#' @details calculate percent NA  across groups returning the minimum
filter_missing<-function(data,group=NULL,ignore=NULL){

  .data<-data[,!colnames(data) %in% c(group,ignore)]

  tmp<-is.na(.data) #| .data==0 # main filter
  if(!is.null(group)){
    .group<-as.factor(data[ ,group])
    .tmp<-split(data.frame(tmp),.group)
    .names<-levels(.group)
  } else {
    .tmp<-list(data.frame(tmp))
    .names<-'full'
  }

  res<-lapply(seq_along(.tmp), function(i){
    apply(.tmp[[i]],2,sum)
  }) %>%
    do.call("cbind",.) %>%
    data.frame() %>%
    setNames(.,.names)

  #get percent missing
  len<-sapply(.tmp, function(x) dim(x)[1])

  prct<-lapply(1:ncol(res),function(i){
    round(res[,i]/len[i]*100,1)
  }) %>%
    do.call('cbind',.) %>%
    data.frame() %>%
    setNames(.,colnames(res))

  #overall stats
  if(!is.null(group)){
   res$full<-apply(res,1,max)
   prct$full<-apply(prct,1,max)
  }


  out<-list(raw=res,percent=prct,group=group,.names=colnames(.data))
  class(out)<-"filter_obj"
  return(out)
}

#' impute_missing
#' @param data
#' @param type
#' @import dplyr
#' @return each variable imputed
#' @export
#' @details impute missing values
impute_missing<-function(data, method="min", scalar=1){
  # data should be a matrix or data frame (samples as rows)
  # methods can be any function
  # scalar will be used to multiply imputed value and can be length one or longer
  # for example a random normal distribution can be used to generate a scalar to slightly randomize imputed value

  na.id<-is.na(data)
  fill<-apply(data,2,method,na.rm=TRUE)*scalar

  #impute
  fixed<-do.call("cbind",lapply(1:ncol(data), function(i)
  {
    #what is being replaced
    obj<-data[,i]
    #id where replacements should go
    obj[na.id[,i]]<-fill[i]
    obj
  }))

  dimnames(fixed)<-dimnames(data)
  return(data.frame(fixed))

}

#TODO convert to OOO..?
#' @export
summary_impute_missing<-function(method,value=0,scalar=1){

  if(method == 'none') return(NULL)

  x<-'Missing values were imputed based on '
  if(method == 'value') return(paste0(x,'a single value set to ',value,'.'))

  if(method != 'value') return(paste0(x,'on each variables ',method,' and multiplied by ',scalar, '.'))

}

#' @title plot_filter_obj
#' @param obj filtered object
#' @param data data object
#' @param type one of overview or summary
#' @param thresh threshold for dropping variables based on missing
#' @export
#' @import ggplot2 reshape2
plot_filter_obj<-function(obj,thresh=50,size_inc=1,...){

    d2<-obj$percent %>% data.frame(id=1:nrow(.),.) %>%
      reshape2::melt(.,id.vars='id') %>%
      mutate(dropped=value>thresh,y=1)

    # #avoid plotting if none are missing
    # if(!any(d2$value>0)) {
    #
    #   message_plot('No missing values')
    # } else {

      ggplot(d2,aes(y=value,x=id,color=dropped)) +
      #geom_bar(stat = "identity") +
      geom_point(aes(size=dropped)) +
      scale_size_manual(values=c(.25,1)*size_inc,guide = 'none') +
      facet_grid(variable ~ .) +
      theme_classic() +
      scale_color_manual(values = c("black",'red'),name='dropped\nvariable(s)') +
      ylab('initial percent missing') + xlab('variable')

    # }

}

#' @export
filter_obj<-function(x,...){
 UseMethod("filter_obj")
}

#' @param obj of class filter_obj
#' @export
#' @method plot filter_obj
#' @details plot missing overview
plot.filter_obj<-function(obj,thresh=50,...){
  plot_filter_obj(obj=obj,thresh=thresh,...)
}

#' Summary method
#' @param obj of class filter_obj
#' @export
#' @method summary filter_obj
#' @details show filtered results
summary.filter_obj<-function(obj, thresh=50, .print=FALSE,...){

  tmp<-table(obj$percent$full<=thresh) %>%
    data.frame() %>%
    setNames(.,c('selected','value'))

  if(!FALSE %in% tmp$selected ){
    custom<-' no variables were removed.'

  } else {

    custom<-paste0(tmp$value[tmp$selected==TRUE],' of ',nrow(obj$percent),' variables were selected.')
    #TODO --should be coupled with a filter?
    vars<-obj$.names[!obj$percent$full<=thresh]
    ommited<-paste0('The following variables were removed: ',grammatical_paste(vars),'.')
    custom<-paste0(custom,' ',ommited)

  }

  #
  desc<-paste0('Based on the filter criteria, less than or equal to ',thresh,'% missing or zero, ',custom)

  tmp<-list(tmp,description=desc)

  if(.print) {
    print(tmp, row.names = FALSE, right = FALSE)
  } else {
    return(tmp)
  }

}

#' @title col_filt_obj
#' @param obj data_cube
#' @param id logical column filter
#' @return list of data, row_meta and col_meta
#' @export
#' @details update obj based on logical data columns filter
col_filt_obj<-function(obj,id){ # lots oF ASSUMPTIONS...MIGHT NEED JOIN
  obj$data<-obj$data[,id,drop=FALSE]
  obj$col_meta<-obj$col_meta[id,,drop=FALSE]
  class(obj)<-c('data_cube','list')
  return(obj)
  # # environment() %>% as.list %>% set_class(c("cer_obj",class(.)))
  # obj %>% set_class(c("cer_obj",class(.)))
}


#' @title message_plot
#' @param message text to show
#' @export
#' @import ggplot2
message_plot<-function(message='',size=10){
  ggplot(data.frame(x=1,y=1,label=message), aes(x=x,y=y,label=label)) +
    geom_text(size=size,color='gray') +
    theme_void()
}

test<-function(){

  library(dave.preproc)

  #load data
  data(dave_)
  data(dave_var_meta)

  #data and meta requiring join
  test_1<-function(){

    data<-dave_
    meta<-dave_var_meta
    var.id<-'ID'

    #row group
    row_meta<-c('label','class','age')

    obj<-dave_init_data(data,meta,row_meta,var.id)
    check(obj)
    summary(obj)
    plot(obj)

  }


  #filter based on missing
  group<-'class'
  data<-data.frame(obj$data,obj$row_meta %>% dplyr::select(one_of(group)))
  x<-filter_missing(data,group=group)

  thresh<-30
  plot(x,thresh=thresh)
  summary(x,thresh=thresh)

  group<-NULL
  data<-obj$data
  x<-filter_missing(data,group=group)
  thresh<-30
  plot(x,thresh=thresh)
  summary(x,thresh=thresh)

  #impute missing values
  x<-impute_missing(obj$data)
  xx<-filter_missing(x,group=group)
  plot(xx)

  x<-data.frame(a=c(1:5,NA),b=c(NA,rep(1,5)))
  xx<-impute_missing(x,'mean',scalar=.25)

  summary_impute_missing('value',scalar=.25)

  #-------------------
  old<-function(){
  # #create heatmap of NA or zero with conditional barplot
  # # library("ggExtra")
  # library(ggplot2)
  #
  # tresh<-50 # above which dropp variable
  #
  # tmp<-is.na(data) | data == 0
  # rows<-matrix(1:nrow(data),nrow(data),ncol(data))
  # .group<-matrix(as.character(data[,group]),nrow(data),ncol(data))
  # cols<-matrix(1:ncol(data),nrow(data),ncol(data),byrow = TRUE)
  # df<-data.frame(x=as.vector(rows),y=as.vector(cols),id=as.vector(tmp),group=as.vector(.group))
  #
  # #overall
  # heat_map<-ggplot(df, aes(x=x,y=y,fill=id)) +
  #   geom_tile() +
  #   scale_fill_manual(values = c("white",'gray'),name='Missing') +
  #   theme_classic()+
  #   xlab('samples') + ylab('variables')
  # # ggMarginal(hm, type = "density") # not useful want bar plot
  #
  # d2<-x$percent %>% data.frame(id=1:nrow(.),.) %>%
  #   reshape2::melt(.,id.vars='id') %>%
  #   mutate(dropped=value>thresh,y=1)
  # overview<-ggplot(d2,aes(y=y,x=id,fill=dropped)) +
  #    geom_bar(stat = "identity") +
  #    facet_grid(variable ~ .) +
  #    theme_classic() +
  #    scale_fill_manual(values = c("gray",'white'),name='dropped\nvariable') +
  #   ylab('')
  #
  #
  # #empty plot with top text?
  # message_plot<-function(message='',size=12){
  #   ggplot(data.frame(x=1,y=1,label=message), aes(x=x,y=y,label=label)) +
  #   geom_text(size=size) +
  #   theme_void()
  # }
  #
  #
  #
  # #comparison of synchronous and asynchronous filter
  # #for small data asynchronous is slower
  #
  # s1<-Sys.time()
  # x<-filter_missing(data,group=NULL,ignore=NULL)
  # Sys.time() - s1
  #
  # plan(multiprocess)
  # s1<-Sys.time()
  # x<-filter_missing2(data,group=NULL,ignore=NULL)
  # Sys.time() - s1
  #
  # #benchmark
  # #in fthis case sync is faster
  # library(microbenchmark)
  # mb<-microbenchmark(
  #   sync = filter_missing(data,group=NULL,ignore=NULL),
  #   async = filter_missing2(data,group=NULL,ignore=NULL),
  #   times=1000
  # )
  #
  # f1<-function(x,val=100000){
  #   lapply(1:x, function(i){
  #     # Sys.sleep(sleep)
  #     rnorm(val) %>% mean()
  #   })
  # }
  #
  # f2<-function(x,val=100000){
  #   v<-lapply(1:x, function(i){
  #     future({
  #       # Sys.sleep(sleep)
  #       rnorm(val) %>% mean()
  #     }) %plan% multiprocess
  #   })
  #   lapply(v,FUN=value)
  # }
  #
  # f3<-function(x,val=100000){
  #   lapply(1:x, function(i){
  #     future({
  #       # Sys.sleep(sleep)
  #       rnorm(val) %>% mean()
  #     }) %plan% multiprocess
  #   })
  # }
  #
  # val<-1e7
  # n<-5
  #
  # mb<-microbenchmark(
  #   sync = f1(n,val),
  #   async = f2(n,val),
  #   async2 = f3(n,val) %>% lapply(.,FUN=value),
  #   times=10
  # )
  }
}
