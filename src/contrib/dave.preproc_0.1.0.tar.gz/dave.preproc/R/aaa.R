#' dave
#' @name dave.preproc
#' @docType package
#' @import ggplot2 shiny dplyr
NULL

#' Sample data
#' @details Sample data based PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_
#' @usage data(dave_)
NULL

#' Sample variable meta data
#' @details variable meta data based on PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_var_meta
#' @usage data(dave_var_meta)
#' @format A data frame with  3286 rows and 10 columns
NULL
