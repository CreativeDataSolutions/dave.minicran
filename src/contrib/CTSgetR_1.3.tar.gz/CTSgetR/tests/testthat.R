library(testthat)
library(CTSgetR)

test_check("CTSgetR")
