

options(multivariate_ui =
  tagList(
    navbarMenu("Multivariate",icon=icon('codepen'),
               tabPanel("Principal Components (PCA)", uiOutput("pca"),icon=icon('arrows')),
               tabPanel("MDA", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE)),
               tabPanel("t-SNE", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE)),
               tabPanel("NNMFD", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE))
    )
  )
)
