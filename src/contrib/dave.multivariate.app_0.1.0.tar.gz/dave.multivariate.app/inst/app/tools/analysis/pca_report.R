pca_params<-reactive({
  pca_values
})

#report object
#fun for observer scoping
pca_report_obj<-function(){
  
  #need to prevent multiple calls
  
  .package<-'dave.multivariate'
  report_name<-'pca_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path=getOption("dave.report.rmd.path")
  html_save_path= getOption('dave.report.html.path')
  
  .report_obj<-get_report_obj(.package = .package,
                              report_name= report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)
  
  return(.report_obj)
}

name<-'pca'

#no way to stop double call
pca_report <-
  callModule(
    reportGenerator,
    name,
    report_params = pca_params,
    report_obj = pca_report_obj(),
    .available = pca_available
)
