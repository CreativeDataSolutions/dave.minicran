

# main fun pca
## list of function arguments
pca_args <- as.list(formals(init_data))

## list of function inputs selected by user
pca_inputs <- reactive({
  ## loop needed because reactive values don't allow single bracket indexing
  # pca_args$arg<-input$something
  # pca_args$

  for (i in r_drop(names(pca_args)))
    pca_args[[i]] <- input[[paste0("pca_",i)]]
  pca_args
})

# ## get global input dataset
# pca_datasetlist <- reactive({
#   input$dataset
# })

pca_values<-reactiveValues()

###############################
# Left menu
###############################
output$PCA_UI_side<-renderUI({
  tagList(
    conditionalPanel(condition = "input.tabs_pca == 'Calculate'", uiOutput("PCA_input")
    ),
    conditionalPanel(condition = "input.tabs_pca != 'Calculate'",uiOutput('PCA_plotting_UI')
    )
  )
})

#inputs
output$PCA_input <-renderUI({
  tagList(
    fluidRow(column(12,
      actionButton("pca_calculate", "Calculate", icon=icon('check'))
    )),
    br(),
    bs_accordion(id="pca_collapse_panel") %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("cogs") , "Method"),
                content =
                  tagList(
                    uiOutput("ui_PCs"),
                    checkboxInput("pca_center","Center",TRUE),
                    uiOutput("ui_pca_scaling"),
                    uiOutput("ui_pca_method"),
                    uiOutput("ui_pca_cv")
                  )
      ) %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                content =
                  fluidRow(column(12,
                                  uiOutput('ui_pca_save')
                  )
                  )
      )
  )
})

#plot
output$PCA_plotting_UI<-renderUI({
  tagList(
    bs_accordion(id="pca_plot_collapse_panel") %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("bar-chart") , "Plot"),
                content = 
                  fluidRow(column(12,
                      selectInput("pca_plots","Plot type",list("Screeplot"= "scree", 
                                                               "Cummulative screeplot"= "cumm", 
                                                               Scores = "scores", Diagnostic = "diagnostic", 
                                                               Loadings= "loadings",Biplot="biplot"), selected="cumm"),
                      # conditionalPanel(condition = "input.pca_plots != 'screeplot'",
                      bs_accordion(id="pca_plot_opts_collapse_panel") %>%
                        bs_append(title = tags$label(class='bsCollapsePanel', icon("user-circle-o") , "Groups"),
                                  content = 
                                    tagList(
                                      uiOutput("ui_data_set_var"),
                                      uiOutput("ui_data_set_groups"),
                                      selectInput("pca_group_bounds","Boundary:", 
                                                  list(none = "none", ellipse = "ellipse", polygon = "polygon"), selected="ellipse"),
                                      conditionalPanel(condition = "input.pca_group_bounds != 'none'",
                                        numericInput("pca_group_alpha", "Transparency:", value=.35, min=0, max=1, step=.1)
                                      )
                                    )
                        ) %>%
                        bs_append(title = tags$label(class='bsCollapsePanel', icon("exchange") , "Components"),
                                  content = 
                                    tagList(
                                      uiOutput("ui_pca_x_axis"),
                                      uiOutput("ui_pca_y_axis")
                                    )
                        ) %>%
                        bs_append(title = tags$label(class='bsCollapsePanel', icon("circle") , "Points"),
                                  content = 
                                    tagList(
                                      numericInput("pca_size", "Size:", value=10, min=1, step=1),
                                      numericInput("pca_point_alpha", "Transparency", value=.75, min=0, max=1, step=.1)
                                    )
                        ) %>%
                        bs_append(title = tags$label(class='bsCollapsePanel', icon("sort-alpha-asc") , "Labels"),
                                  content = 
                                    tagList(
                                      uiOutput("ui_data_set_sample"),
                                      checkboxInput("pca_show_labels","Show",TRUE),
                                      numericInput("pca_label_font_size", "Size:", value=5, min=0, step=1),
                                      textInput("pca_legend_label", "Legend title", value = NULL)
                                    )
                        )
                    )
                  )
      )
  )
})

#column of samples
output$ui_data_set_sample<-renderUI({
  # pca_values[['meta_vars']]<- .getdata_row_meta()
  vars<-NULL #pca_values[['meta_vars']] %>% colnames()
  selectInput(inputId = "data_set_sample", label = "Name", choices = vars, multiple = F)
})

#list of variables
output$ui_data_set_var <- renderUI({
  # pca_values[['meta_vars']]<-.getdata_row_meta()
  vars<-NULL#pca_values[['meta_vars']] %>% colnames()
  selectInput(inputId = "data_set_var", label = "Group", choices = vars,  multiple = TRUE)
})

#trigger init objects ebven if empty 
outputOptions(output, "ui_data_set_var", suspendWhenHidden = FALSE)
outputOptions(output, "ui_data_set_sample", suspendWhenHidden = FALSE)

#observe plot type
observeEvent(input$pca_plots,{
   # browser()
  #if(is.null(input$pca_plots)) return()
  
  #need to make sure this runs before getting plot args
  pca_values[['plot_type']]<-input$pca_plots
  
  if(input$pca_plots %in% c("scores",'diagnostic','biplot')){
    pca_values[['meta_vars']]<-.getdata_row_meta()
    vars<-pca_values[['meta_vars']] %>% colnames()
    updateSelectInput(session,'data_set_var',choices = vars)
    updateSelectInput(session,'data_set_sample',choices = vars)
  } 
  
  if(input$pca_plots %in% c("loadings")){
    pca_values[['meta_vars']]<- .getdata_col_meta() 
    vars<-pca_values[['meta_vars']] %>% colnames()
    updateSelectInput(session,'data_set_var',choices = vars)
  }
  
  if(input$pca_plots %in% c("scores",'diagnostic')){
    pca_values[['meta_vars']]<- .getdata_row_meta() 
    vars<-pca_values[['meta_vars']] %>% colnames()
    updateSelectInput(session,'data_set_sample',choices = vars)
  } 
  
  if(input$pca_plots %in% c("loadings")){
    pca_values[['meta_vars']]<- .getdata_col_meta()
    vars<-pca_values[['meta_vars']] %>% colnames()
    updateSelectInput(session,'data_set_sample',choices = vars) # does not update right away?
  }
  
  #need to map both...row an column
  if(input$pca_plots %in% c('biplot')){
    pca_values[['meta_vars']]<- .getdata_col_meta()
    vars<-pca_values[['meta_vars']] %>% colnames()
    pca_values[['meta_vars_row']]<- .getdata_row_meta()
    updateSelectInput(session,'data_set_sample',choices = vars) # does not update right away?
  } else {
    pca_values[['meta_vars_row']]<-NULL
  }
  
  if(input$pca_plots %in% c('scree','cumm')){
    pca_values[['meta_vars']]<-NULL 
    updateSelectInput(session,'data_set_sample',choices = NULL)
    updateSelectInput(session,'data_set_var',choices = NULL)
  }
  
})

#reactive to get values
get_pca_values<-reactive({
  return(pca_values)
})

#no of components
output$ui_PCs<-renderUI({
  obj<-.getdata_cube()$data %>% ncol()
  shiny::validate(need(!is.null(obj) == TRUE,''))
  # maxPCs<-ncol(get_numeric_data())
  numericInput("pca_pcs", "Number of Components", 2, min = 2, max = obj)
})

#pca_scaling
output$ui_pca_scaling <- renderUI({
  selectInput("pca_scaling", "Scale", list(none = "none", "unit variance" = "uv", pareto = "pareto"), selected="uv")
})

#pca_methods
output$ui_pca_method <- renderUI({
  # selectInput("pca_method", "Method", dvmPCA_methods())
  
  selectInput(
    "pca_method",
    "Method",
    c("svd", "nipals", "rnipals", "bpca", "ppca", "svdImpute", "robustPca", 
      "nlpca", "llsImpute", "llsImputeAll"),
    # ocpu_dvmPCA_methods(dave_multivariate_connection)$results # API call - slows down UI too much
    selected = state_single(
      "pca_method",
      c("svd", "nipals", "rnipals", "bpca", "ppca", "svdImpute", "robustPca", 
        "nlpca", "llsImpute", "llsImputeAll"),
      # ocpu_dvmPCA_methods(base_url = getOption('dave.multivariate_open_cpu_url'))$results,
      "svd"
    )
  )
})

#pca_cv
output$ui_pca_cv <- renderUI({
  selectInput("pca_cv", "cross-validation", list(none = "none", Q2 = "q2"), selected="q2")
})

#pca_x_axis
output$ui_pca_x_axis<-renderUI({
  numericInput("pca_x_axis", "x-axis", value=1, min=1, max = input$pca_pcs)
})

#pca_y_axis
output$ui_pca_y_axis<-renderUI({
  numericInput("pca_y_axis", "y-axis", value=2, min=1, max = input$pca_pcs)
})



#Store data
output$ui_pca_save<-renderUI({
  tags$table(
    tags$td(textInput("pca_dataset", "Save as:", input$dataset)),
    tags$td(actionButton("pca_save", "Save"), style="padding-top:30px;")
  )
})

###############################
# renderUI output
###############################
output$ui_pca <- renderUI({
  req(input$dataset)
  tagList(
      uiOutput("PCA_UI_side"),
      fluidRow(
        column(12,align="right",modalModuleUI(id="pca_help")))
      # help_modal('PCA - Principal Components Analysis','pca_help',inclMD(file.path(getOption("dave.path.multivariate"),"app/tools/help/demo.md")))
  )
})

#setup plot
pca_plot <- reactive({
  
  #make sure update happens first
  if(pca_values[['plot_type']] != input$pca_plots) return()
  # browser()
  
  # TODO make ganeric size controls
   plh <- 600
   plw <- 800

  # browser()
  # debug(plot.dvmPCA)
  .data<-get_pca_values() %>% .[['meta_vars']]
  plotInputs <- list()
  
  #control for biplot
  if(is.null(pca_values[['meta_vars_row']])){
    if(!is.null(.data) & !is.null(input$data_set_var)){
      #guard against entry before the UI has updated
      if(!input$data_set_var %in% colnames(.data)) return()
      plotInputs$color <- .data[,input$data_set_var,drop=FALSE]
    } else {
      plotInputs$color<-NULL
    }
  } else {
    ..data<-pca_values[['meta_vars_row']]
    if(!is.null(..data) & !is.null(input$data_set_var)){
      #guard against entry before the UI has updated
      if(!input$data_set_var %in% colnames(..data)) return()
      plotInputs$color <- ..data[,input$data_set_var,drop=FALSE]
    } else {
      plotInputs$color<-NULL
    }
    
  }

  
  plotInputs$group.bounds <- input$pca_group_bounds
  plotInputs$g.alpha <- input$pca_group_alpha
  plotInputs$xaxis <- input$pca_x_axis
  plotInputs$yaxis <- input$pca_y_axis
  plotInputs$size <- input$pca_size
  plotInputs$alpha <- input$pca_point_alpha
  
  if(!is.null(.data) & !is.null(input$data_set_sample)){
    #handle biplot..madness
    if(!input$data_set_sample %in% colnames(.data)) return()
    plotInputs$point.labels <- .data[,input$data_set_sample,drop=FALSE]
  } else {
    plotInputs$point.labels<-NULL
  }
  
  plotInputs$label <- input$pca_show_labels
  plotInputs$font.size <- input$pca_label_font_size
  plotInputs$color.legend.name <- input$pca_legend_label
  #plot type
  plotInputs$plot_type<-input$pca_plots
  
  #initializes after tab switch
  if(!is.null(input$pca_plots)) {
    if(input$pca_plots == 'scree') plotInputs$type<-'scree'
    if(input$pca_plots == 'cumm') plotInputs$type<-'cumm'
  }
  
  pca_values[['plot_args']]<-list(plot_width=plw, plot_height=plh, plot_args=plotInputs)
  return( pca_values[['plot_args']]) # else plot triggers recalculation
  
})

#still geting width errors?
pca_plot_width <- function(){
  #browser()
  obj<-tryCatch(pca_plot(),error=function(e){NULL})
  if(is.null(obj)){
    800
  } else {
    obj$plot_width
  }
}

pca_plot_height <- function(){
  obj<-tryCatch(pca_plot(),error=function(e){NULL})
  if(is.null(obj)){
    600
  } else {
    obj$plot_height
  }
}

#initialize data
pca_init<-reactive({
  req(input$dataset)
 
  pcaInputs <- list()
  
  data <- .getdata_cube()$data %>% check_dvmPCA(.) %>% .$data
  pcaInputs$pca.algorithm <- input$pca_method
  pcaInputs$pca.components <- input$pca_pcs
  pcaInputs$pca.center <- input$pca_center
  pcaInputs$pca.scaling <- input$pca_scaling
  pcaInputs$pca.cv <- input$pca_cv
  return(list(data=data, 
              pca.algorithm = input$pca_method,
              pca.components = input$pca_pcs,
              pca.center = input$pca_center,
              pca.scaling = input$pca_scaling,
              pca.cv = input$pca_cv
             )
         )
})

pca_available <- reactive({
  if(is.null(input$pca_calculate) || input$pca_calculate ==0) {
    return("Carry out dimensional reduction using Principal Components Analysis.")
  }
  if (is.na(input$pca_calculate))
    return("Select options and then calculate.")
  "available"
})


###############################
# main functions
###############################
.pca <-  reactive({
  
  res<-withProgress(message = "Calculating", value = 1, {
  
    # tryCatch(do.call('dvmPCA', pca_init()), error=function(e){NULL}) # 
    ocpu_dvmPCA(dave_multivariate_connection,body=pca_init())
    
  })
  
  
  validate(need(!is.null(res$results)==TRUE,res$error))
  return(res$results)
 
})

observeEvent(input$pca_calculate, {
 
    print('\n------- pca updating values------\n')
    pca_values[['pca']] <- .pca()
    return(pca_values[['pca']])
 
})

#gating for multiple calculations
.get_pca<-reactive({
  obj<-pca_values[['pca']]
  if(is.null(obj)) return()
  return(pca_values[['pca']])
})

.summary_pca <-reactive({
  if (pca_available() != "available") return(pca_available() %>% html_text_format(.))
  # obj<-.get_pca()
  # if(is.null(obj)) return(print('foo'))
  # browser()
  summary(.pca())$description  %>% html_paragraph_format(.)
})

output$summary_pca_ui<- renderUI({
  .summary_pca() %>% HTML()
})

#shared plot set up
.plot_pca_setup<-reactive({
  

  .call<-list(error=FALSE,message=NULL,results=NULL)
  
  if(is.null(input$pca_plots)){ .call$error<-TRUE;.call$message<-'Loading ...';return(.call)}
  if (pca_available() != "available"){ .call$error<-TRUE;.call$message<-pca_available();return(.call)}
  
  obj<-.pca()
  if(is.null(obj)) { .call$error<-TRUE;.call$message<-'Loading ...';return(.call)}
  args<-pca_plot()
  if(is.null(args)) { .call$error<-TRUE;.call$message<-'Loading ...';return(.call)}
  #save plot objects for the report
  if(input$pca_plots %in% c('loadings')){
    pca_values[['loadings']]<-list(plot_args=args$plot_args)
  }
  
  if(input$pca_plots %in% c('scores')){
    pca_values[['scores']]<-list(plot_args=args$plot_args)
  }
  
  .call$results<-list(obj=obj,plot_type = input$pca_plots, plot_args = args$plot_args)
  
  return(.call)
  
})

.plot_pca <- reactive({
  
  .call<-.plot_pca_setup()
  validate(need(!.call$error, .call$message))
  
  main<-.call$results
  plot(main$obj,plot_type = main$plot_type, plot_args=main$plot_args)

  #do.call('plot',list(.call$results))
})

#plotly
output$plotly_pca <- renderPlotly({
 
  
  .call<-.plot_pca_setup()
  validate(need(!.call$error, .call$message))
  
  # browser()
  main<-.call$results
  p<-plot(main$obj,plot_type = main$plot_type, plot_args=main$plot_args)
  if(is.null(p)) return() # works fine if called directly
  # browser()
  ggplotly(p)
  
})

###############################
# output is called from the main dave ui.R
###############################
output$pca <- renderUI({
  register_print_output("summary_pca", ".summary_pca" )
  register_plot_output("plot_pca", ".plot_pca",
                       height_fun = "pca_plot_height", width_fun = "pca_plot_width")

  # two separate tabs
  pca_output_panels <- tabsetPanel(
    id = "tabs_pca",
    tabPanel("Calculate", uiOutput('summary_pca_ui'),icon = icon("sliders")),#verbatimTextOutput("summary_pca")
    tabPanel("Explore",icon=icon('pencil-square-o'),plotlyOutput("plotly_pca", height = "100%")),
    tabPanel("Plot",icon = icon("bar-chart"),
             plot_downloader("pca", height = pca_plot_height()),
             plotOutput("plot_pca", height = "100%")),
    tabPanel("Report",icon=icon('file-text-o'), reportGeneratorUI('pca'))
  )
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('codepen'),as.character(" Multivariate")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('arrows'),as.character(" PCA")))),
                 tool_ui = "ui_pca",
                 output_panels = pca_output_panels)
})


#save
#add scores, diag to row meta
#add loadings to col meta
observeEvent(input$pca_save, {
  
  #browser()
  ## saving to a new dataset if specified
  dataset <- input$pca_dataset
  obj <- .pca()
  
  .names<-list(data=dataset,
               row=paste0(dataset,'_row_meta'),
               col=paste0(dataset,'_col_meta'))
  
  #merge results with meta
  .data<-.getdata()
  .row<-merge_df(.getdata_row_meta(),data.frame(obj$scores[,1:2],obj$diagnostics))
  .col<-merge_df(.getdata_col_meta(),data.frame(obj$loadings[,1:2]))
  
  #update data and col meta data
  #based on the filter results
  # if (is.null(r_data[[dataset]])) {
  r_data[[.names$data]] <- .data
  r_data[[.names$row]] <- .row
  r_data[[.names$col]] <- .col
  
  #update avialebale data objects
  #need to split update from create
  .names<-r_data[['datasetlist']] %>% c(unlist(.names),.) %>% unique()
  r_data[['datasetlist']] <-.names
})

