#' dave.multivariate
#'
#' @name dave.multivariate
#' @docType package
#' @import ggplot2 shiny dplyr
NULL


#' Sample data
#' @details Sample data set based on v13b4nf_WI38MD231_AQ.csv
#' @docType data
#' @keywords datasets
#' @name aq_data
#' @usage data(aq_data)
#' @format A data frame with 8 rows and 1951 columns
NULL

#' Sample variable meta data
#' @details variable meta data based on v13b4nf_MASTER_AQ.csv
#' @docType data
#' @keywords datasets
#' @name aq_var_meta
#' @usage data(aq_var_meta)
#' @format A data frame with  3286 rows and 10 columns
NULL
