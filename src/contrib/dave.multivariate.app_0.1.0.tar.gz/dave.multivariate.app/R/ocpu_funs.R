
#' @title .ocpu_dvmPCA_methods
#' @export
#' @import ocpuclient
.ocpu_dvmPCA_methods<-function(){
  
  dvmPCA_methods()  %>% 
    ocpuclient::ocpu_toJSON()
}

 
#' @title .ocpu_dvmPCA
#' @export
#' @import ocpuclient
.ocpu_dvmPCA <-
  function(data,
           pca.components = 2,
           pca.cv = c('none', 'q2'),
           pca.algorithm = 'svd',
           pca.center = TRUE,
           pca.scaling = c("none", "pareto", "vector", "uv"),
           seed = 123,
           return = "list",
           ...) {
    
    dvmPCA(
      data,
      pca.components = pca.components,
      pca.cv = pca.cv,
      pca.algorithm = pca.algorithm,
      pca.center = pca.center,
      pca.scaling = pca.scaling,
      seed = seed,
      return = return,
      ...
    ) %>%
      ocpuclient::ocpu_toJSON()
    
  }
