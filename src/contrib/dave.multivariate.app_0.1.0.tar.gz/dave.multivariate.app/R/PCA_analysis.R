###############################
# Export functions
###############################


#' Summary method
#' @param obj of class pca_list
#' @export
#' @details summarise data object
summary.dvmPCA<-function(pca, ...){
  
  tmp<-pca$method
  description<-c(
    paste0('Principal components analysis was conducted using the ',tmp$method,' method.'), 
    paste0(' The data set was ',ifelse(tmp$center,'centered','not centered'),' and ',ifelse(tmp$scaling =='none','not scaled',paste0('scaled using ',tmp$scaling)),'.'),
    paste0(' A total of ',tmp$ncomp,' components were calculated, explaining ',
           round(sum(pca$eigenvalues[,1]),3) *100 ,'% variance in the data set.'),
    ifelse(tmp$cv == 'none','',
           paste0(' The cross-validated variance explained was ',round(sum(pca$eigenvalues[,2]),3)*100,"%."))) %>%
    paste0(., collapse="")
  
  list(description=description)
  
}

#' Plot method
#' @param pca of class dvmPCA
#' @param plot_type one of 'diagnostic, 'scree','cumm', 'scores', 'loadings' and 'biplot'
#' @param plot_args list of arguments to plot methods
#' @importFrom purrr flatten
#' @method plot dvmPCA 
#' @export
#' @details plot results
plot.dvmPCA<-function(pca, plot_type="scores",plot_args=NULL,..){
  
  if(plot_type=="diagnostic"){
    args<-purrr::flatten(list(c(list(pca=pca),plot_args)))
    return(do.call('dvmPCA_diagnostic_plot',args))
  }
  
  if(plot_type %in% c('scores','loadings')){
    args<-purrr::flatten(list(c(list(pca=pca),plot_args,list(type=plot_type))))
    return(do.call('dvmPCA_scatter_plot',args))
  }
  
  
  if(plot_type=="biplot"){
    args<-purrr::flatten(list(c(list(pca=pca),plot_args)))
    return(do.call('dvmPCA_biplot_plot',args))
  }
  
  if(plot_type %in% c("scree",'cumm')){
    args<-purrr::flatten(list(c(list(pca=pca),plot_args)))
    return(do.call('dvmPCA_scree_plot',args))
  }
  
  
}


###############################
# PCA plot functions
###############################
#' @title dvmPCA_scree_plot
#' @import ggplot2 reshape2
#' @export
dvmPCA_scree_plot<-function(pca, type='scree',...){
  
  eigenvalues<-pca$eigenvalues
  .theme<- theme(
    axis.line = element_line(colour = 'gray', size = .75),
    panel.background = element_blank(),
    plot.background = element_blank()
  )
  
  
  #screeplot
  if(type == 'scree'){
    tmp<-data.frame(reshape2::melt(round(eigenvalues*100,1)),PCs=rep(1:nrow(eigenvalues)))#data.frame(reshape2::melt(eigenvalues$eigenvalue),PCs=rep(1:nrow(eigenvalues)))
    
    p<-ggplot(tmp, aes(y=value, x = as.factor(PCs),fill=variable))+geom_bar(stat="identity",position=position_dodge())+
      .theme + geom_hline(yintercept=1,linetype=2) + ylab("% variance explained") + xlab("") +
      scale_fill_brewer(palette = 'Set1')
  } 
  
  #cummulative
  if(type == 'cumm'){
    tmp2<-data.frame(reshape2::melt(round(eigenvalues*100,1)),PCs=rep(1:nrow(eigenvalues))) %>%
      group_by(variable) %>%
      mutate(tvar=(cumsum(value)))
    p<-ggplot(tmp2, aes(y=tvar, x = as.factor(PCs), fill=variable))+geom_bar( stat="identity",position=position_dodge())+
      .theme + geom_hline(yintercept=80,linetype=2) + xlab("Principal Component") + ylab("total % variance explained") +
      scale_fill_brewer(palette = 'Set1')
  }
  
  return(p)
   
}

#' @title dvmPCA_diagnostic_plot
#' @import ggplot2
#' @export
dvmPCA_diagnostic_plot<-function(pca, size=10,color=NULL,point.labels=NULL,font.size=5,theme=NULL,...){
  
  diagnostics<-pca$diagnostics
  if(is.null(theme)){
    .theme2<- theme(
      axis.line = element_line(colour = 'gray', size = .75),
      panel.background = element_blank(),
      plot.background = element_blank(),
      legend.background=element_rect(fill='white'),
      legend.key = element_blank()
    )
  } else {.theme2<-theme}
  
  if(is.null(point.labels)){
    diagnostics$point.labels<-rownames(diagnostics)
  } else {
    diagnostics$point.labels<-unlist(point.labels)
  }
  
  if(is.null(color)){
    .color<-NULL
  } else {
    diagnostics$color<-unlist(color)
    .color<-geom_point(aes(color=color),size=size) 
  }
  
  
  ggplot(diagnostics,aes(x=leverage,y=DmodX,label=point.labels)) +
    .color +
    geom_text(size=font.size) +
    .theme2
  
}

#' @title dvmPCA_scatter_plot
#' @import ggplot2 reshape2
#' @importFrom grid arrow
#' @importFrom grid unit
#' @export
dvmPCA_scatter_plot<-function(pca,xaxis=1,yaxis=2, type = c("scores","loadings"),
                      group.bounds="ellipse",size=3,color=NULL, label=TRUE, color.legend.name =  NULL,size.legend.name =  NULL,
                      font.size=5,alpha=.75,g.alpha=0.2,theme=NULL, point.labels=NULL,extra=NULL,...){
  
            if(type == 'scores') {
              obj<-pca$scores[,c(xaxis,yaxis)]
              tmp<-data.frame(obj,id = rownames(obj))
            }
  
            if(type == 'loadings') {
             obj<-pca$loadings[,c(xaxis,yaxis)]
              tmp<-data.frame(obj,id = rownames(obj))
            }
                
            #plot
            if(is.null(theme)){
              .theme2<- theme(
                axis.line = element_line(colour = 'gray', size = .75),
                panel.background = element_blank(),
                plot.background = element_blank(),
                legend.background=element_rect(fill='white'),
                legend.key = element_blank()
              )
            } else {.theme2<-theme}
            
            if(is.null(color)){
              tmp$color<-"gray"
            }else{
              tmp$color<-color[,] #as.factor(color[,])
              #if(is.null(color.legend.name)){color.legend.name<-colnames(color)}
            }
            
            points<-if(all(tmp$color=="gray")) {
              if(!is.data.frame(size)){
                geom_point(color="gray",size=size,alpha=alpha,show.legend = FALSE)
              } else {
                tmp$size<-size[,1]
                if(is.null(size.legend.name)){size.legend.name<-colnames(size)}
                geom_point(aes(size=size),color="gray",alpha=alpha)
              }
            } else {
              if(!is.data.frame(size)){
                geom_point(aes(color=color),size=size,alpha=alpha)
              } else {
                tmp$size<-size[,1]
                if(is.null(size.legend.name)){size.legend.name<-colnames(size)}
                geom_point(aes(color=color,size=size),alpha=alpha)
              }
            }
            #labels
            tmp$lab.offset<-tmp[,2]-abs(range(obj[,2])[1]-range(obj[,2])[2])/50
            if(label==TRUE){
              if(is.null(point.labels)){
                tmp$id<-unlist(tmp$id)
                labels<-geom_text(size=font.size,aes_string(x=colnames(tmp)[1], y="lab.offset",label="id"),color="black",show.legend = FALSE)
              } else {
                tmp$custom.label<-unlist(point.labels)
                labels<-geom_text(size=font.size,aes_string(x=colnames(tmp)[1], y="lab.offset",label="custom.label"),color="black",show.legend = FALSE)
              }
            } else { labels<-NULL }
            
            #grouping visualizations
            polygons<-NULL
            #Hoettellings T2 ellipse
            if(group.bounds=="ellipse"){
              ell<-get.coords(cbind(tmp[,1],tmp[,2]), group=tmp$color,type='ellipse')# group visualization via
              polygons<-if(is.null(color)){
                geom_polygon(data=data.frame(ell$coords),aes(x=x,y=y), fill="gray", color="gray",linetype=2,alpha=g.alpha, show.legend = FALSE)
              } else {
                geom_polygon(data=data.frame(ell$coords),aes(x=x,y=y, fill=group),linetype=2,alpha=g.alpha, show.legend = FALSE)
              }
            }
            #convex hull
            if(group.bounds=="polygon"){
              ell<-get.coords(cbind(tmp[,1],tmp[,2]), group=tmp$color,type='chull')# group visualization via
              polygons<-if(is.null(color)){
                geom_polygon(data=data.frame(ell$coords),aes(x=x,y=y), fill="gray", color="gray",linetype=2,alpha=g.alpha, show.legend = FALSE)
              } else {
                geom_polygon(data=data.frame(ell$coords),aes(x=x,y=y, fill=group),linetype=2,alpha=g.alpha, show.legend = FALSE)
              }
            }
            
            #making the actual plot
            p<-ggplot(data=tmp,aes_string(x=colnames(tmp)[1], y=colnames(tmp)[2])) +
              geom_vline(xintercept = 0,linetype=2, size=.5, alpha=.5) +
              geom_hline(yintercept = 0,linetype=2, size=.5, alpha=.5) +
              polygons +
              points +
              labels +
              .theme2 +
              scale_x_continuous(paste(colnames(tmp)[1],sprintf("(%s%%)", round(pca$eigenvalues[xaxis,1],digits=2)*100),sep=" "))+
              scale_y_continuous(paste(colnames(tmp)[2],sprintf("(%s%%)", round(pca$eigenvalues[yaxis,1],digits=2)*100),sep=" "))
            if(!is.null(color.legend.name)) {
              if(!is.numeric(unlist(color))) {
                p<-p+scale_colour_discrete(name = color.legend.name)
              } else {
                #blocking fill legend...
                p<-p+scale_color_continuous(name = color.legend.name)
              }
            }
            if(!is.null(size.legend.name)) {
              if(!is.numeric(unlist(size))) {
                p<-p+scale_size_discrete(name = size.legend.name)
              } else {
                p<-p+scale_size_continuous(name = size.legend.name)
              }
            }
            p<-p+extra
            
            return(p)

}


#' @title dvmPCA_biplot_plot
#' @export
dvmPCA_biplot_plot<-function(pca,xaxis=1,yaxis=2, 
                              group.bounds="ellipse",size=3,color=NULL, label=TRUE, color.legend.name =  NULL,size.legend.name =  NULL,
                              font.size=5,alpha=.75,g.alpha=0.2,theme=NULL, point.labels=NULL,extra=NULL,...){
    
    if(is.null(theme)){
      .theme2<- theme(
        axis.line = element_line(colour = 'gray', size = .75),
        panel.background = element_blank(),
        plot.background = element_blank()
      )
    } else {.theme2<-theme}
    
    #based on https://groups.google.com/forum/#!topic/ggplot2/X-o2VXjDkQ8
    scores<-pca$scores[,c(xaxis,yaxis)]
    loadings<-tmp.loadings<-pca$loadings[,c(xaxis,yaxis)]
    tmp.loadings[,1]<-rescale(loadings[,1], range(scores[,1]))
    tmp.loadings[,2]<-rescale(loadings[,2], range(scores[,2]))
      if(label){
      if(!is.null(point.labels)){
        .label<-unlist(point.labels)
      } else {
        .label<-rownames(loadings)
      }
      } else {
        .label<-""
      }
    tmp.loadings<-data.frame(tmp.loadings,label=.label)
    
    #Adding grouping visualizations
    tmp<-data.frame(scores[,1:2])
    if(is.null(color)){
      tmp$color<-"gray"
    }else{
      tmp$color<-as.factor(color[,])
      #if(is.null(legend.name)){legend.name<-colnames(color)}
    }
    #grouping visualizations
    polygons<-NULL
    
    #Hoettellings T2 ellipse
    if(group.bounds=="ellipse"){
      ell<-get.coords(cbind(tmp[,1],tmp[,2]), group=tmp$color,type='ellipse')# group visualization via
      polygons<-if(is.null(color)){
        geom_polygon(data=data.frame(ell$coords),aes(x=x,y=y), fill="gray", color="gray",linetype=2,alpha=g.alpha, show.legend = FALSE)
      } else {
        geom_polygon(data=data.frame(ell$coords),aes(x=x,y=y, fill=group),linetype=2,alpha=g.alpha, show.legend = FALSE)
      }
    }
    
    #convex hull
    if(group.bounds=="polygon"){
      ell<-get.coords(cbind(tmp[,1],tmp[,2]), group=tmp$color,type='chull')# group visualization via
      polygons<-if(is.null(color)){
        geom_polygon(data=data.frame(ell$coords),aes(x=x,y=y), fill="gray", color="gray",linetype=2,alpha=g.alpha, show.legend = FALSE)
      } else {
        geom_polygon(data=data.frame(ell$coords),aes(x=x,y=y, fill=group),linetype=2,alpha=g.alpha, show.legend = FALSE)
      }
    }
    
    
    points<-if(all(tmp$color=="gray")) {
      geom_point(data=tmp,aes_string(x=colnames(tmp)[1], y=colnames(tmp)[2]),color="gray",size=size,alpha=alpha,show.legend = FALSE)
    } else {
      if(!is.data.frame(size)){
        geom_point(data=tmp, aes_string(x=colnames(tmp)[1], y=colnames(tmp)[2],color="color"),size=size,alpha=alpha)
      } else {
        tmp$size<-size[,1]
        geom_point(data=tmp, aes_string(x=colnames(tmp)[1], y=colnames(tmp)[2],color="color",size="size"),alpha=alpha)
      }
    }
    
    p<-ggplot()+
      polygons+
      geom_segment(data=tmp.loadings, aes_string(x=0, y=0, xend=colnames(tmp.loadings)[1], yend=colnames(tmp.loadings)[2]), arrow=arrow(length=unit(0.05,"cm")), alpha=0.25)+
      geom_text(data=tmp.loadings, aes_string(x=colnames(tmp.loadings)[1], y=colnames(tmp.loadings)[2], label="label"), alpha=0.5, size=font.size)+
      points +
      scale_colour_discrete("Variety")+
      scale_x_continuous(paste(colnames(tmp)[1],sprintf("(%s%%)", round(pca$eigenvalues[xaxis,1],digits=2)*100),sep=" "))+
      scale_y_continuous(paste(colnames(tmp)[2],sprintf("(%s%%)", round(pca$eigenvalues[yaxis,1],digits=2)*100),sep=" ")) +
      .theme2
    #if(!is.null(legend.name)) {p<-p+scale_colour_discrete(name = legend.name)}
    p<-p+extra
    
    return(p)
}

#copied rom: https://github.com/ChristianGoueguel/HotellingEllipse/blob/master/R/ellipseCoord.R
ellipseCoord <- function(data, pcx = 1, pcy = 2, conf.limit = 0.95, pts = 200) {
  
  stopifnot(length(data) != 0)
  stopifnot(pcx != pcy)
  
  # if (is.data.frame(data) == FALSE & tibble::is_tibble(data) == FALSE) {
  #   stop("Data must be of class data.frame, tbl_df, or tbl")
  # }
  
  if (pcx == 0 | pcy == 0) {
    stop("No component is provided either in pcx or pcy, or both.")
  }
  
  if(conf.limit < 0 | conf.limit > 1) {
    stop("Confidence level should be between 0 and 1")
  }
  
  # matrix of data
  X <- as.matrix(data)
  
  # Sample size
  n <- nrow(X)
  
  # Confidence limit
  alpha <- as.numeric(conf.limit)
  
  # Number of points
  m <- as.numeric(pts)
  p <- seq(0, 2*pi, length = m)
  
  # # Hotelling’s T-square limit
  Tsq_limit <- (2*(n-1)/(n-2))*stats::qf(p = alpha, df1 = 2, df2 = (n-2))
  
  # Coordinate points
  rx <- sqrt(Tsq_limit*stats::var(X[, pcx]))
  ry <- sqrt(Tsq_limit*stats::var(X[, pcy]))
  
  res.coord <- tibble::tibble(
    x = rx*cos(p) + mean(X[, pcx], na.rm = TRUE),
    y = ry*sin(p) + mean(X[, pcy], na.rm = TRUE)
  )
  
  return(res.coord)
  
}

#' @title get.ellipse.coords
#' @export
#' @details required import loads plyr and interferes with dplyr if loaded after
get.coords<-function(obj,group=NULL,type='ellipse', dim1=1, dim2=2, ellipse.level=.95,pts=200){
  
  fct<-if(is.null(group)) as.factor(rep(1,nrow(obj))) else factor(unlist(group))
  .obj<-split(as.data.frame(obj),fct)
  names<-c(colnames(obj),"")
  
  if(type == 'ellipse'){
    coord.var<-lapply(1:length(.obj),function(i)
    {
      
      tmp <-
        cbind(as.data.frame(
          ellipseCoord(
            .obj[[i]],
            pcx = dim1,
            pcy = dim2,
            conf.limit = ellipse.level,
            pts = pts
          )
        ),rep(names(.obj)[i], pts))
      
      tmp
    })
  }
  
  if(type == 'chull'){
    coord.var<-lapply(1:length(.obj),function(i)
    {
      #returns rows to get from obj
      id<-chull(
        cbind(.obj[[i]][,dim1],.obj[[i]][,dim2]),
      )
      tmp <-
        cbind(data.frame(.obj[[i]][id,]),names(.obj)[i])
      
      tmp
    })
  }
  
  #format for ggplot 2
  tmp<-do.call("rbind",coord.var)
  #remove errors
  tmp<-tmp[!is.na(tmp[,1]),]
  
  
  #avoiding issues with x/y as factors
  obj<-data.frame(matrix(as.numeric(as.matrix(tmp[,1:2])),ncol=2),tmp[,3])
  colnames(obj)<-c("x","y","group")
  
  #may need to maintain ordered factor levels
  obj$group<-factor(obj$group,levels=levels(fct),ordered=is.ordered(fct))
 
  return(list(coords=data.frame(obj)))
}

#' #' @title get.polygon.coords
#' #' @export
#' #' @import ellipse splancs
#' #' @importFrom plyr ddply
#' get.polygon.coords<-function(obj,group){
#'   require(plyr) # avoid
#'   fct<-if(is.null(group)) data.frame(fct=as.factor(rep(1,nrow(obj)))) else factor(unlist(group))
#'   obj<-data.frame(obj,fct)
#'   .chull<-function(x){tryCatch(chull(x),error=function(e){NA})} #
#'   chull.bounds <- data.frame(plyr::ddply(obj, .(fct), function(x) data.frame(x[.chull(as.matrix(x)),])))
#'   
#'   browser()
#'   
#'   colnames(chull.bounds)<-c("x","y","group")
#'   #may need to maintain ordered factor levels
#'   chull.bounds$group<-factor(chull.bounds$group,levels=levels(fct),ordered=is.ordered(fct))
#'   return(chull.bounds)
#' }

#rescaling based on: http://cran.r-project.org/doc/contrib/Lemon-kickstart/rescale.R
rescale<-function(x,newrange) {
  if(nargs() > 1 && is.numeric(x) && is.numeric(newrange)) {
    # if newrange has max first, reverse it
    if(newrange[1] > newrange[2]) {
      newmin<-newrange[2]
      newrange[2]<-newrange[1]
      newrange[1]<-newmin
    }
    xrange<-range(x)
    if(xrange[1] == xrange[2]) stop("can't rescale a constant vector!")
    mfac<-(newrange[2]-newrange[1])/(xrange[2]-xrange[1])
    invisible(newrange[1]+(x-xrange[1])*mfac)
  }
  else {
    cat("Usage: rescale(x,newrange)\n")
    cat("\twhere x is a numeric object and newrange is the min and max of the new range\n")
  }
}

#join.columns
#replace with tidyr
join.columns<-function(obj=formatted$row.metadata[,4:6],char="|",quote.last=FALSE){
  
  if(class(obj)=="list"){obj<-as.matrix(obj[[1]])} else {obj<-as.matrix(obj)}
  #used to binf 2 columns try to generalize to more
  .local<-function(obj,char,quote.last)
  {
    
    if(length(obj)==0)
    {
      return(NULL)
    }else{
      if(ncol(as.matrix(obj))>=2)
      {
        n<-ncol(obj)
        out<-data.frame()
        sobj<-obj
        i<-1
        for(i in 1:(n-1))
        {
          if(quote.last==TRUE)
          {
            sobj[,i]<-paste(as.character(obj[,i]),paste("'",as.character(obj[,i+1]),"'",sep=""),sep=char)
          } else {
            sobj[,i]<-paste(as.character(obj[,i]),as.character(obj[,i+1]),sep=char)
          }
        }
        sobj[,-n]
      }else{
        obj
      }
    }
  }
  if (ncol(obj)>2)
  {
    tmp<-obj[,1:2]
    for(i in 1:(ncol(obj)-1)) {
      tmp2<-.local(tmp, char=char,quote.last=quote.last)
      if(i < (ncol(obj)-1)){
        tmp<-cbind(tmp2,obj[,(i+2),drop=FALSE])
      }
    }
    tmp2
    
  } else {
    .local(obj=obj,char=char,quote.last=quote.last)
  }
}

#' @title check_dvmPCA
#' @export
#' @details encode factor or character as numeric
check_dvmPCA<-function(data,convert=TRUE){
  .class<-sapply(data,class)
  valid<-TRUE

  id<-.class %in% c('character','factor')
  
  if(any(id)) {
    valid<-FALSE
  }
  
  if(convert & !valid){
    .fix<-function(x){as.numeric(as.factor(as.character(unlist(x))))} # hacky encoding to numeric
    .obj<-data[,id,drop=FALSE]
    .con<-lapply(1:ncol(.obj),function(i){
      .fix(.obj[,i])
    }) %>%
      do.call('cbind',.) %>%
      setNames(.,colnames(.obj))
    data[,id]<-.con
  } else {
    data<-data
  }
  return(list(valid=valid,data=data))
}

test<-function(){
  library(dave.multivariate) #for PCA
  
  
  data("dave_data")
  data<-dave_data
  
  #check
  data<-check_dvmPCA(data)$data
  

  
  .methods<-dvmPCA_methods()
  .pca<-dvmPCA(data,pca.components=2,pca.cv='q2',pca.algorithm=.methods[1],
                         pca.center=TRUE,pca.scaling= "uv", seed=123,return="list")
  
  
  dvmPCA_scatter_plot(
    .pca,
    xaxis = 1,
    yaxis = 2,
    type = "scores",
    group.bounds = "ellipse", #"polygon"
    size = 3,
    label = TRUE,
    color=color,
    color.legend.name =  'group',
    size.legend.name =  NULL,
    font.size = 5,
    alpha = .75,
    g.alpha = 0.2,
    theme = NULL,
    extra = NULL,
    plot = TRUE
  )
  
  summary(.pca)
  p<-plot(.pca)
  plotly::ggplotly(p)
  
  #generic plotting method
  #meta data for plotting
  data("dave_data_row_meta")
  color<-dave_data_row_meta %>% select(class)
  label<-dave_data_row_meta %>% select(label)
  
  plot_args<-list(size=5,labels=label,color=color)
  do.call('dvmPCA_diagnostic_plot',list(c(.pca,plot_args)))
  p<-plot(.pca,plot_type='diagnostic',plot_args)
  ggplotly(p)
 
  plot_args$group.bounds<-"polygon"
  plot(.pca,plot_type='scores',plot_args)
  plot(.pca,plot_type='diagnostic',plot_args)
  plot(.pca,plot_type='loadings')
  
  
  plot_args<-list(
    color=data.frame(group=sample(1:3,8,replace = TRUE)),#data.frame(group=aq_data$cellType),
    point.labels=1:length(colnames(data)),
    color.legend.name='foo',
    size=2
  )
  plot(.pca,plot_type='biplot',plot_args)
  
  plot_args<-list(type='q2')
  p<-plot(.pca,plot_type='scree',plot_args)
  
  #induvidual plots
  
  dvmPCA_scree_plot(.pca, type='q2')
  dvmPCA_scree_plot(.pca, type='eigen')
  dvmPCA_diagnostic_plot(.pca,size=10,labels=NULL)
  dvmPCA_diagnostic_plot(.pca,size=5,labels=aq_data$SampleID)
  #scores
  color<-data.frame(group=aq_data$cellType)
  label<-data.frame(label=aq_data$SampleID)
  dvmPCA_scatter_plot(.pca,xaxis=1,yaxis=2, type = "scores",
                      group.bounds="polygon",size=3,color=color, label=TRUE, 
                      color.legend.name =  'group',size.legend.name =  NULL,
                      font.size=5,alpha=.75,g.alpha=0.2,theme=NULL, 
                      point.labels=label,extra=NULL,plot=TRUE)
  #loadings
  dvmPCA_scatter_plot(.pca,xaxis=1,yaxis=2, type = "loadings",
                      group.bounds="ellipse",size=3,color=NULL, label=TRUE, 
                      color.legend.name =  NULL,size.legend.name =  NULL,
                      font.size=2,alpha=.75,g.alpha=0.2,theme=NULL, 
                      point.labels=NULL,extra=NULL,plot=TRUE)
  
  #biplot
  dvmPCA_biplot_plot(.pca,xaxis=1,yaxis=2, 
                     group.bounds="ellipse",size=3,color=NULL, label=TRUE, 
                     color.legend.name =  NULL,size.legend.name =  NULL,
                     font.size=1,alpha=.75,g.alpha=0.2,theme=NULL, 
                     point.labels=NULL,extra=NULL,plot=TRUE)
  
  #group ellipse and polygons
  #meta data for plotting
  data("dave_data_row_meta")
  color<-dave_data_row_meta %>% select(class)
  
  obj<-.pca$scores 
  group<-color
  type='ellipse'
  dim1=1
  dim2=2
  ellipse.level=.95
  pts=200
  
}
