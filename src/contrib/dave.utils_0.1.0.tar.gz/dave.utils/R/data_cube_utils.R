
#data cube manipulation functions


#get meta data object names
#' Title
#'
#' @param name
#'
#' @return
#' @export
#'
#' @examples
names_data_cube<-function(name){

  list(row=paste0(name,'_row_meta'),
       col=paste0(name,'_col_meta'))
}

#collect data_cube if possible
#' Title
#'
#' @param env
#' @param names
#'
#' @return
#' @export
#'
#' @examples
make_data_cube<-function(env,names){

  #collect names and compile a data_cube

}
