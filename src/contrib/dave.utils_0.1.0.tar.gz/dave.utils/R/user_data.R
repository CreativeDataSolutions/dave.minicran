#utility functions



#' @title check_user_folders
#' @param folders
#' @importFrom fs dir_create
#' @export
check_user_folders<-function(folders=NULL){

  fs::dir_create(folders, mode = "u=rwx,go=rx", recurse = TRUE)

}

#' @title check_s3_files
#' @export
#' @import dplyr
#' @details compare file creation time between local and s3 only checking names
check_s3_files<-function(path,s3_files){

  local_files<-dir(path,recursive = TRUE) %>%
    paste0(path,.) %>% file.info() %>% mutate(Key=rownames(.))
  check<-left_join(s3_files,local_files,by="Key") %>%
    mutate(update=TRUE)

  check$update[check$LastModified<check$mtime]<-FALSE
  check
}

#' @title sync_from_s3
#' @export
#' @import aws.s3
#' @details hack to deal nested bucket/file control
sync_from_s3<-function(path,bucket,prefix){
  files<-get_bucket_df(bucket=bucket,prefix=prefix)
  check<-check_s3_files(path,files)
  .files<-check$Key[check$update]

  lapply(.files,function(x) {
    aws.s3::save_object(object=x,bucket = bucket, file=x)
  })
}

#' @title sync_to_s3
#' @export
#' @importFrom aws.s3 s3sync
sync_to_s3<-function(path,bucket){
  files<-paste0(path,dir(path,recursive = TRUE))
  #can get // separators ?
  files<-gsub('//','/',files)
  aws.s3::s3sync(files=files, bucket=bucket, direction = "upload",verbose=TRUE)
}


test<-function(){

  # user<-Sys.getenv('SHINYPROXY_USERNAME')
  user<-'test'
  check_user_folders(user)

}
