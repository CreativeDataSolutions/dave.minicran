

#' @export
dave_filter_fun<-function(obj,level_var='type',value_var='value',level,value,qual){


  #only filter level in question

  out<-rep(TRUE,nrow(obj))

  check<-is.null(qual)

  if(check) return(list(filter=out,summary=NULL))

  if(qual == 'drop') out<-!out

  if(qual =='greater') {
    out<-obj[level_var] == level & obj[value_var] >= value

  }

  if(qual =='less') {
    out<-obj[level_var] == level & obj[value_var] <= value
  }


  desc_level<- paste0(level_var,' equal to ',level)

  desc_start<-'The following filter was applied: '

  if(qual == 'none') {
    desc_start<-desc_level<-desc_value<-NULL
  }

  if(qual == 'drop'){
    desc_value<-'were all removed'
  }

  if(!qual %in% c('none','drop')){
    .qual<-switch(qual,
                  'greater' = 'greater than or equal to ',
                  'less' = 'less than or equal to ')

    desc_value<-paste0('and ',value_var,' ',.qual,value)
  }

  desc<-paste(desc_start,desc_level,desc_value,collapse='\n')


  out[obj[level_var] != level]<-TRUE
  list(filter=out,summary=desc)

}

#' @export
dave_filter_fun_summary<-function(obj){

  #filter
  .filter<-lapply(obj,function(x){x$filter}) %>%
    do.call('cbind',.) %>%
    apply(.,1,all)

  #summary
  .summary<-lapply(obj,function(x){x$summary}) %>%
    unlist() %>% {.[!. == '']}
  if(length(.summary)>0) {
    .summary<-.summary %>%
      grammatical_paste(.) %>%
      paste0(.,'.')
  } else {
    .summary<-NULL
  }


  list(filter=.filter,summary=.summary)

}
