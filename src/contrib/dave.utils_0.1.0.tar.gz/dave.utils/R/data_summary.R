

  # # test<-function(){
  #
  # #module for data quality assesment
  # #high level summary of the data
  # #number of variables, samples
  # #missing values
  # #select from fast table or DT render
  #
  # #TODO make into a module
  # #profile if the data is a cube
  # #radio for summary or table views
  #
  # library(dplyr)
  # library(DT)
  # library(shiny)
  # library(shiny)
  # library(shinyjs)


  data_sum<-function(data){
    .sum<-dim(data) %>%
      as.list() %>%
      setNames(.,c('row','col'))

    .sum$na<-is.na(data) %>% sum

    .sum

  }

  dave_icon_text<-function(text='Text',icon='check',color='green',heading='h3',icon_size= "fa-2x"){

      tags$div(style = 'display:inline;',
             tags$div(style = paste0('color:',color,';display:inline;'), icon(icon,icon_size)),
             paste0('<',heading,' style="display:inline;">',text,'</',heading,'>') %>% HTML()
      )

  }

  data_icons<-function(obj){

    tagList(
      dave_icon_text(paste0(obj$row,' samples'),icon='check',color='green'),
      br(),
      dave_icon_text(paste0(obj$col,' variables'),icon='check',color='green'),
      br(),
      dave_icon_text(paste0(obj$na,' missing values'),icon=ifelse(obj$na>0,'times','check'),color=ifelse(obj$na>0,'red','green')),
      br(),
      dave_icon_text(' meta data created',icon=ifelse(!obj$data_cube,'times','check'),color=ifelse(!obj$data_cube,'red','green'))
    )

  }

  data_help_text<-function(obj){


      .help<-NULL


      if(!obj$data_cube){
        .help <-
          tagList(
            .help,
            tags$div(
              style = 'display:inline;',
              icon('exclamation-circle'),
              'Use <code>Preprocess >> Merge</code> to specify row and column meta data' %>%
                HTML()
            ) %>%
              helpText()
          )

      }

      if(obj$na>0) {
        .help <-
          tagList(
            .help,
            tags$div(
              style = 'display:inline;',
              icon('exclamation-circle'),
              'Use <code>Preprocess >> Missing</code> to remove or impute missing values' %>%
                HTML()
            ) %>%
                helpText()
          )
      }


      warn<-if(!is.null(.help)) h3(style="color:red;",'Warnings') else NULL

      tagList(warn,.help)
  }


  # module ------------------------------------------------------------------

  #' @title data_summary_visUI
  #' @export
  #' @import shiny
  data_summary_UI <- function(id) {

    ns <- NS(id)

    tagList(
      fluidRow(
        column(12,uiOutput(ns('main_ui')))
      )
    )
  }

  #' @title vis_canvas_visInput
  #' @export
  #' @import shiny skimr knitr kableExtra
  data_summary_Input <-
    function(input,
             output,
             session,
             module_data=NULL,
             data_cube=function(){NULL},
             data_name=''
    ) {


      check_data_cube<-reactive({

        obj<-data_cube()
        if(is.null(obj)) return(FALSE)

        sapply(obj,is.null) %>%
          any(.) %>% {!.}

      })

      get_data<-reactive({


        # browser()
        #wtf..empty app
        .data<-tryCatch(module_data(),error=function(e){})
        # if(is.null(.data)) return()
        # browser()
        validate(need(!is.null(.data),'Loading...'))

        .data

      })

      get_vars<-reactive({
          get_data() %>%
          colnames()
      })

      output$summary_fun_ui<-renderUI({
        # function(){

        data<-get_data()

        obj<-data_sum(data)

        obj$data_cube<-check_data_cube()

        # browser()

        fluidRow(
          column(4,data_icons(obj)),
          column(8,data_help_text(obj)),
          column(12,hr())
        )

      })

      output$type_ui<-renderUI({

        ns<-session$ns
        fluidRow(
          radioButtons(ns('type'),'',c('overview','table'),selected='overview',inline = TRUE),
          hr()
        )

      })

      get_table_data<-reactive({

        get_data() %>% select(one_of(input$table_vars))

      })

      output$table_controls<-renderUI({

        #every one of these needs to be type safe?
        ns<-session$ns

        wtf<-tryCatch(is.null(input$table_limit) || is.na(input$table_limit),error=function(e){TRUE})

        limit<-if(wtf) 10 else input$table_limit

        vars<-get_vars()

        #block full break when character or/
        check<-tryCatch(length(vars) > limit,error=function(e){FALSE})

        fluidRow(hr(),
                 column(
                   2,
                   numericInput(
                     ns('table_limit'),
                     'limit',
                     min = 1,
                     max = length(vars),
                     value = ifelse(check, limit, length(vars))
                   )
                 ),
                 column(
                   10,
                   selectizeInput(
                     ns('table_vars'),
                     'show variables',
                     choices = vars,
                     selected = na.omit(vars[1:limit]),
                     multiple = TRUE,
                     options = list(plugins = list('remove_button', 'drag_drop'))
                   )
                 ))

      })

      #overview
      output$skimr<-renderUI({
        if (is.null(get_table_data())) return()


        obj<-get_table_data()

        if(ncol(obj) == 0) return()

        Sys.setlocale("LC_CTYPE", "Chinese") #shiw histograms

        obj %>%
          skimr::skim() %>% # _to_wide()
          knitr::kable(.,format='html') %>%
          kableExtra::kable_styling('hover') %>%
          HTML()
      })

      output$skimr_ui<-renderUI({
        ns<-session$ns
        htmlOutput(ns('skimr'))
      })

      output$table_ui<- DT::renderDataTable(

        datatable(
          get_table_data(),rownames = FALSE, filter = 'top', options = list(
            pageLength = 10, autoWidth = TRUE,scrollX = TRUE,fontColor='black')
        )
      )

      output$main_ui<-renderUI({
        ns<-session$ns

        tagList(
          uiOutput(ns('type_ui')),
          conditionalPanel(condition = 'input.type == "overview"',ns=ns,
                           uiOutput(ns('summary_fun_ui')),
                           uiOutput(ns('skimr_ui'))),
          conditionalPanel(condition = 'input.type == "table"',ns=ns,
                           fluidRow(column(12,
                            DT::dataTableOutput(ns('table_ui'))
                           ))
          ),
          uiOutput(ns('table_controls'))
        )
      })

    }






tests<-function(){


  library(shiny)
  library(dave.utils)
  library(shinyjs)

  library(skimr)

# module test -------------------------------------------------------------


  ui <- shinyUI(fluidPage(
    useShinyjs(),
    uiOutput('main_ui')
  ))



  server <- shinyServer(function(input, output) {

    .data<-function(){
      data<-mtcars
      data[1:5,3]<-NA
      data
    }


    #test if object is a data_cube
    .getdata_cube<-function(obj){
      list(data=obj,
           row_meta=data.frame(rows=nrow(obj)),
           col_meta=data.frame(cols=ncol(obj))
      )
    }

    #creates input UI elements
    # callModule(data_summary_Input,'test',module_data=.data,data_cube=function(){.getdata_cube(.data())})
    callModule(data_summary_Input,'test',module_data=.data)

    output$main_ui<-renderUI({

      tagList(
        data_summary_UI('test')
      )
    })

  })

  # options(shiny.reactlog=FALSE)
  shinyApp(ui = ui, server = server)


  ## app -------------------------------------------------------------------------

  ui <- shinyUI(fluidPage(
    useShinyjs(),
    uiOutput('main_ui')
  ))


  server <- shinyServer(function(input, output) {


    summary_fun<-function(){

      obj<-data_sum(data)

      list(summary=data_icons(obj),
           br(),
           help=data_help_text(obj)
      )

    }

    output$type_ui<-renderUI({

      radioButtons('type','',c('overview','table'),selected='overview',inline = TRUE)

    })

    get_data<-reactive({
      data
    })

    output$table_ui<- DT::renderDataTable(


      datatable(
        get_data(),rownames = FALSE, filter = 'top', options = list(
          pageLength = 10, autoWidth = TRUE,scrollX = TRUE,fontColor='black')
      )
    )

    output$main_ui<-renderUI({


      tagList(
        uiOutput('type_ui'),
        conditionalPanel(condition = 'input.type == "overview"',
                         tagList(summary_fun())),
        conditionalPanel(condition = 'input.type == "table"',
                         DT::dataTableOutput(ns('table_ui')))
      )
    })

  })




}
