#plot height width module
#' @title vis_canvas_visUI
#' @export
#' @import shiny
vis_canvas_visUI <- function(id) {

  ns <- NS(id)
  tagList(
    fluidRow(
      column(12,uiOutput(ns('ui_vis_canvas')))
    )
  )
}

#' @title vis_canvas_visInput
#' @export
#' @import shiny rmarkdown
vis_canvas_visInput <-
  function(input,
           output,
           session
  ) {

    output$ui_vis_canvas<-renderUI({
      ns<-session$ns

      uiOutput(ns("vis_canvas_plot_dim"))

    })

    output$vis_canvas_plot_dim<-renderUI({

      ns<-session$ns

      fluidRow(
        column(12,
               tags$table(
                 tags$td(numericInput(ns("vis_canvas_plot_width_value"), "width", min=400,step=100,value=800)),
                 tags$td(numericInput(ns("vis_canvas_plot_height_value"), "height", min=400,step=100,value=600))
               )
        )
      )
    })


    #setup plot
    vis_canvas_plot <- reactive({

      plh <- input$vis_canvas_plot_height_value %>%
      { if (!is.null(.)) . else 600 }
      plw <- input$vis_canvas_plot_width_value %>%
      { if (!is.null(.)) . else 800 }

      list(width=plw, height=plh)
    })


    module_outputs<-reactive({


      list(width = vis_canvas_plot()$width,
           height = vis_canvas_plot()$height
      )
    })

    return(module_outputs)
  }
