#' @export
get_package_version<-function(package){

  info<-system.file('Meta/package.rds',package=package)
  out<-readRDS(gzcon(file(info,'rb')))
  names(out)<-tolower(names(out))
  names(out$description)<-tolower(names(out$description))

  return(out)
}


#' @title has_changed
#' @param obj list object to digest and compare against hash
#' @param  hash digested object
#' @return list changed:digested object and hash are not the same, hash digested object hash see digest::digest
#' @details use for explixit memoziation when cases of built in fail
#' @export
#' @import digest
has_changed<-function(obj,hash=''){

  obj_hash<-digest(obj)
  changed<-TRUE
  if(obj_hash == hash) changed<-FALSE

  list(changed=changed,hash=obj_hash)

}

