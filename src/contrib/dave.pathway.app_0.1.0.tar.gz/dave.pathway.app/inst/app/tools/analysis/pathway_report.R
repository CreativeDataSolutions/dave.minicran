pathway_params<-reactive({

  obj<-pathway_values[['images']]
  pathways <- input$report_pathway_selection

  m <- match(names(obj), pathways)
  id <- names(obj)[!is.na(m)][order(na.omit(m))]
  out<-obj[id]
  if(length(out)==0) out<-NULL

  vars=pathway_values[['top_vars']]

  top_n<-input$report_top_n_enrichment
  top_vars <- vars[1:top_n,,drop=FALSE]

  list(images=out,
       enrich=pathway_values[['enrich']],
       top_vars=top_vars,
       pathway_name=pathway_values[['pathway_name']]
  )


})


#base avialable off of both enrich or visualize
#todo block double wtf
pathway_report_available<-reactive({

  enrich<-path_enrich_available()
  view<- pathwaymap_available ()

  if('available' %in% c(enrich,view)) 'available' else 'Calculate enrichment or visualize pathway first.'

})

#report object
#fun for observer scoping
pathway_report_obj<-function(){
  .package<-'dave.pathway.app'
  report_name<-'pathway_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path=getOption("dave.report.rmd.path")
  html_save_path= getOption('dave.report.html.path')

  .report_obj<-get_report_obj(.package = .package,
                              report_name= report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)

  return(.report_obj)
}

name<-'pathway'

pathway_report<-callModule(reportGenerator, name,
                       report_params = pathway_params,
                       report_obj=pathway_report_obj(),
                       .available = pathway_report_available) #pathwaymap_available


