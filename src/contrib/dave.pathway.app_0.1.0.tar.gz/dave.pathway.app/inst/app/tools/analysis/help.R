
pathway_help_lookup <-
  list(
    url = 'https://creativedatasolutions.github.io/dave.docs/partial/pathway.html',
    pathway = list(
      Calculate = 'calculate',
      Plot = 'plot',
      Report = 'report'
    )
  )

pathway_help <-
  function(tab = input$tabs_path_enrich,
           id = 'pathway',
           lookup = pathway_help_lookup,
           url = pathway_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }



callModule(modalModule,id='pathway_help',content=pathway_help)

