r_url_list <- getOption("dave.url.list")

r_url_list[["pathwaymap"]] <-  list("tabs_pathwaymap" = list("Summary" = "pathwaymap/pathwaymap/", "Plot" = "pathwaymap/pathwaymap/plot/", "Map" = "pathwaymap/pathwaymap/map/"))
options(dave.url.list = r_url_list); rm(r_url_list)

options(pathway_ui =
  tagList(
    navbarMenu("Pathway",icon=icon('flask'),
               tabPanel('Enrichment', icon=icon('sort'),uiOutput('path_enrich_ui')),
               tabPanel("Disease", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE))
               # tabPanel("Visualize",icon=icon('eye'),
               #          uiOutput("pathwaymap"))
    )
  )
)
