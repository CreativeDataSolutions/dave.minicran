
#client fun
# ocpu_pathway_mapping


#' Summary method
#' @param obj of class pathway_map
#' @export
#' @details summarise data object
summary.pathway_map<-function(obj, ...){
  cat("PATHWAY mapping\n")
  print(str(obj))
  cat("\n")
}

#' Plot method
#' @param obj of class pathway_map
#' @export
#' @details plot
plot.pathway_map<-function(obj, shiny=FALSE, ...){
  #imgfile <- list.files(pattern=paste0(obj$inputs$ptw,".",obj$inputs$suffix,".multi.png"), full.names = TRUE) #.multi for more than one FC
  imgfile <- obj$inputs$image
  # if(length(imgfile)==0){
  #   imgfile <- paste0(obj$inputs$ptw,".",obj$inputs$suffix,".png")
  # }
  img_out <- list(src = imgfile, contentType = "image/png")
  return(img_out)
}

#' Plot method
#' @param obj of class pathway_map
#' @export
#' @details plot
include_graphics.pathway_map<-function(obj, shiny=FALSE, ...){
  # imgfile <- list.files(pattern=paste0(obj$inputs$ptw,".",obj$inputs$suffix,".multi.png"), full.names = TRUE) #.multi for more than one FC
  # if(length(imgfile)==0){
  #   imgfile <- paste0(obj$inputs$ptw,".",obj$inputs$suffix,".png")
  # }
  #knitr::include_graphics(imgfile)
  knitr::include_graphics(obj$inputs$image)
  #tags$img(src = imgfile, width = "800px", height = "800px")
}


#get kegg code and organism name
get.kegg.organism.info<-function(){
  # if(!exists("korg")) data(korg)
  req(kegg_org) #will be replaced
  data(kegg_org)
  #format list of organisms for select options
  orgls <- kegg_org[,"kegg.code"]
  names(orgls) <- kegg_org[,"scientific.name"]
  return(list(organisms=orgls, name=kegg_org[,"scientific.name"], code=kegg_org[,"kegg.code"]))
}


#NOT IMPLEMENTED - organism specific analysis
#cache REST calls to KEGG for
#organism specific analyses
#init DB
# dave.pathway.DB<-list()
# dave.pathway.DB[[id]]<-ptw
# save(dave.pathway.DB,file='inst/app/dave.pathway.DB')
# DB<-load(file='inst/app/dave.pathway.DB')


#' @title load_pathway_db
#' @param  save_path path to save DB for future update
#' @export
load_pathway_db<-function(file='app/dave.pathway.DB'){
  .file<-system.file(file,package='dave.pathway')
  load(.file)
  #assume basename
  invisible(get(basename(file)))
}


#get kegg pathway for organism
get.kegg.pathways<-function(id, DB='inst/app/dave.pathway.DB',save=TRUE){

  #save pathway querries
  if(is.null(DB)) {
    DB<-load_pathway_db()
  } else {
    load(DB)
    DB<-get(basename(DB))
  }

  #get from KEGG if no entry
  if(is.null(DB[[id]])){
    message('Query KEGG API')
    DB[[id]]<-keggList("pathway" ,id)
    if(save){
      save(DB,file=DB)
    }
  }

  ptw <- DB[[id]] #keggList("pathway" ,id) #get list of pathways
  #format list of pathways for select options
  ptwls <- gsub("path:","",names(ptw))
  names(ptwls) <- ptw
  return(list(pathways=ptwls, DB=DB))
}

#not based on organism
#' @title get_kegg_paths
#' @export
get_kegg_paths<-function(path_info,org=''){

  .tmp<-path_info %>% filter(!duplicated(map)) %>%
    dplyr::select(path,map) %>%
    na.omit() %>%
    droplevels() # get all paths no org check

  .path<-gsub('map',org,.tmp$map)
  names(.path)<-.tmp$path

  return(.path)
}


test<-function(){

  library(dplyr)
  library(dave.pathway)

  #small data object for testing
  x<-structure(list(data = structure(list(id = structure(c(2L, 1L), .Label = c("C00236",
                      "C00668"), class = "factor"), FC = c(-1, 1)), .Names = c("id","FC"),
                      row.names = c(NA, -2L), class = "data.frame"), kegg.col = "id",
                      cpd.FC = "FC", pathway.code = "hsa00030", organism.code = "hsa",
                      work.dir = "inst/app/tools/ptw/figures", suffix = "Map_aq_data_stat"),
                 .Names = c("data","kegg.col", "cpd.FC","pathway.code",
                            "organism.code", "work.dir", "suffix"))


  x<-structure(list(data = structure(list(id = structure(c(2L, 1L),
                  .Label = c("C01218","C00668"), class = "factor"), FC = c(-1, 1)), .Names = c("id","FC"),
                                     row.names = c(NA, -2L), class = "data.frame"), kegg.col = "id",
                    cpd.FC = "FC", pathway.code = "ko00030", organism.code = "ko",
                    work.dir = "inst/app/tools/ptw/figures", suffix = "Map_aq_data_stat"),
               .Names = c("data","kegg.col", "cpd.FC","pathway.code",
                          "organism.code", "work.dir", "suffix"))#add to env for interactive debug

  # #problems
  # .data<-data.frame(id=c('foo',NA),FC=c(NA,0))
  # x$data<-rbind(x$data,.data)


  for(i in 1:length(x)){
    assign(names(x)[i],x[[i]])
  }

  kegg.dir<- save.dir<-'inst/app/user/test/pathview/figures/'

  # debug(pathway.mapping)
  # save.dir<-'inst/app/test/pathview/'
  out<-suppressMessages(pathway.mapping(data, kegg.col, cpd.FC, pathway.code, organism.code, suffix=suffix,kegg.dir=kegg.dir))

  #added hack for saving png location
  #use full paths to avoid issue see comment in function
  kegg.dir <- paste0(getwd(),"/inst/app/user/test/pathview/figures")
  save.dir<- paste0(getwd(),"/inst/app/user/test/pathview/user")


  undebug(pathway.mapping)

  out<-suppressMessages(pathway.mapping(data, kegg.col, cpd.FC, pathway.code, organism.code, suffix,save.dir,kegg.dir))


  #created resource
  img<-out$inputs$image

  #need and enrichment function
  #build db for each analyte

  #build db for each pathway (number of analytes), total for each organism
  load('C:/Users/Dmitry/Dropbox/Software/TeslaHealth/analysis/KEGG/data/gene/9997')

  dave.pathway:::get.kegg.pathways(id='hsa')
}
