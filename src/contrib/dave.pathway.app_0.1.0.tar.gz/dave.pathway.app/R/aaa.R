#' dave.pathway
#'
#' @name dave.pathway
#' @docType package
#' @import ggplot2 shiny dplyr
NULL



#' Sample data
#' @details KEGG
#' @docType data
#' @keywords datasets
#' @name bods
#' @usage data(bods)
#' @format
NULL


#' Organism data
#' @details data set of KEGG organisms
#' @docType data
#' @keywords datasets
#' @name kegg_org
#' @usage data(kegg_org)
#' @format A data frame with 4493 rows and 4 columns
NULL

#' Stat data
#' @details Stat data set for dave_data
#' @docType data
#' @keywords datasets
#' @name dave_stat
#' @usage data(dave_stat)
#' @format A data frame with 188 rows and 15 columns
NULL

#' Stat data mimicking col_meta input
#' @details Stat data set col_meta for dave_data
#' @docType data
#' @keywords datasets
#' @name dave_stat_col_meta
#' @usage data(dave_stat_col_meta)
#' @format A data frame with 188 rows and 15 columns
NULL

#' pathway info
#' @details KEGG pathway info
#' @docType data
#' @keywords datasets
#' @name path_info
#' @usage data(path_info)
#' @format A data frame
NULL

#' pathway summary
#' @details KEGG pathway summary data
#' @docType data
#' @keywords datasets
#' @name path_summary
#' @usage data(path_summary)
#' @format A data frame
NULL
