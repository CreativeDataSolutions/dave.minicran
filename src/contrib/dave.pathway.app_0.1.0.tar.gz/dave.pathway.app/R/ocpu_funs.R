
#' @title ocpu_metabolic_network
#' @export
#' @import ocpuclient
.ocpu_pathway_mapping <-
  function(data,
           kegg.col,
           cpd.FC,
           pathway.code,
           organism.code,
           suffix,
           kegg.dir,
           save.dir) {

    pathway.mapping(data,
                    kegg.col,
                    cpd.FC,
                    pathway.code,
                    organism.code,
                    suffix,
                    kegg.dir) %>%
      ocpuclient::ocpu_toJSON()


  }


# #download created file
# file<-results$results$results$input$image
#
# file<-"/tmp/ocpu-temp/x08199b5ceed486/workspace/hsa00030.Map_aq_data_stat.png"
# tmp<-unlist(strsplit(file,'/'))
# key<-tmp[4]
# .file<-basename(file)
# paste0(getOption('open_cpu_url'),'/tmp/x08199b5ceed486/files/hsa00030.Map_aq_data_stat.png')
