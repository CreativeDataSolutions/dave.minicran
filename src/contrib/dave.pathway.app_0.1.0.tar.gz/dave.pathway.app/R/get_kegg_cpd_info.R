#get kegg metabolite info


#' @title get_cpd_paths
#' @import dplyr
#' @export
#' @details pathways for each compound
get_cpd_paths<-function(cpd,path_info){

  id<-path_info$cpd %in% cpd
  as.character(na.omit(path_info[id,]$map)) %>%
    table() %>%
    data.frame() %>%
    setNames(.,c('map','n_hits'))

}

#' @title cpd_paths_mat
#' @export
#' @import reshape2
cpd_paths_mat<-function(cpd,path_info,maps=NULL){
  id<-path_info$cpd %in% cpd
  main<-path_info[id,,drop=FALSE]

  .get<-c('cpd','map')
  melted<-melt(main %>% select(one_of(.get)),id.vars = .get)  %>%
    na.omit()
  mat<-dcast(melted,cpd ~ map )
  cpd<-mat[,1]
  .mat<-mat[,-1,drop=FALSE]
  .mat[!is.na(.mat)]<-TRUE
  .mat[is.na(.mat)]<-FALSE
  .mat<-sapply(mat, as.logical)
  out<-data.frame(cpd,.mat)

  if(!is.null(maps)){
    out<-out %>% dplyr::select(one_of('cpd',maps))
  }

  return(out)

}


#' @title get_path_data
#' @export
#' @details get info for paths
get_path_data<-function(paths,path_summary){
  tmp<-path_summary$path
  out<-left_join(paths,path_summary$path,by='map')
  out$map_total<-path_summary$summary$n_maps
  out$cpd_total<-path_summary$summary$n_cpd

  return(out)
}


#' @title test_path
#' @export
#' @details hypergeometric test for enrichment
pathway_enrichment<-function(path_data,cpd){

  test_fun<-function(n_hits,n_cpd,cpd_total,cpd,...){
    # #hypergeometric test for enrichment
    # n_hits = 51 # number of significantly changed pathway metabolites
    # n_cpd = 1455 # number of metabolites in pathway
    # cpd_total = 3358  # all possible metabolites in organism
    # cpd_total = 72  # number of significantly changed metabolites

    phyper(n_hits-1, n_cpd, cpd_total-n_cpd, cpd, lower.tail=F)

  }

  args<-as.list(path_data)
  args$cpd<-cpd
  p.val<-do.call('test_fun',args)
  fdr.p<-p.adjust(p.val,method = 'BH')
  res<-data.frame(p.value=signif(p.val,4),fdr.p.value=signif(fdr.p,4),path_data) %>%
    arrange(p.value) %>%
    mutate(prct=round((n_hits/n_cpd)*100,2))

  out<-list(path_enrich=res, methods=list(fdr='Benjamini and Hochberg',test="hypergeometric test"))

  class(out)<-'path_enrich'
  return(out)
}

# filter object based on p-values
#' @title filter_path_enrich
#' @export
filter_path_enrich<-function(obj,fdr=TRUE,limit=0.05){
  value<-if(fdr) 'fdr.p.value' else 'p.value'
  id<-obj$path_enrich[,value]<=limit
  obj$path_enrich<-obj$path_enrich[id,,drop=FALSE]
  obj$methods$fdr_filter<-fdr
  obj$methods$limit<-limit

  return(obj)
}

#' @export
#' @details summarise pathway_enrichment
summary.path_enrich<-function(obj){
  desc<-paste0('Pathway enrichment was conducted using the ', obj$methods$test,'. ')

  desc<-c(desc,
          paste0('Significantly enriched pathways were determined based on ',
                 ifelse(obj$methods$fdr_filter,
                        paste0(obj$methods$fdr,' FDR adjusted p-values'),'p-values'),
                 ' less than or equal to ',obj$methods$limit,". "))

  desc<-c(desc,paste0('A total of ',nrow(obj$path_enrich),' significantly enriched  (non-organism specific) pathways were identified.')) %>%
    paste0(.,collapse="")

  #get pathway names and map
  if(!exists('path_info')) data("path_info")
  paths<-get_kegg_paths(path_info,org='')
  .id<-obj$path_enrich$map %>%gsub('map','',.)
  tmp<- left_join(data.frame(id=.id,obj$path_enrich),
                 data.frame(id=paths,pathway=names(paths)),by='id')
  if(obj$methods$fdr_filter){
    res<-tmp %>% mutate('p_value'= signif(fdr.p.value,3) %>% format(., scientific=TRUE))
  } else {
    res<-tmp %>% mutate('p_value'=signif(p.value,3) %>% format(., scientific=TRUE))
  }

  res<-res %>% dplyr::select(pathway,map,p_value,n_hits,n_cpd,prct)

  list(description=desc,results=res)
}

#buils path_summary and path_info
build_data_sets<-function(){
  #tmp save location
  path<-'C:/Users/Dmitry/Dropbox/Software/TeslaHealth/analysis/KEGG/data/cpd/'

  #get KEGG gene info
  library(httr)
  library(dplyr)
  library(KEGGREST)

  url<-'http://rest.kegg.jp/list/compound'
  .all<-GET(url) %>% content()

  tmp<-strsplit(.all,'\n') %>%
    unlist() %>%
    strsplit(.,'\t') %>%
    do.call('rbind',.) %>%
    data.frame() %>%
    setNames(.,c('cpd','name'))

  tmp$cpd<-tmp$cpd %>% gsub('cpd:','',.)

  #head(tmp)

  #compounds
  .ids<-tmp$cpd %>% unlist()
  lapply(1:length(.ids),function(i){
    cat(i, '\r')
    id<-.ids[i]
    kegg_cpd <- tryCatch(keggGet(id), error =function(e){NULL})
    save(kegg_cpd,file=paste0(path,id))
  })


  #process files and extract mpathway information for each compound
  get_path_cpd_info<-function(obj,verbose=TRUE){

    options(warn = -1)
    lapply(1:length(obj),function(i){
      if(verbose) {message(i)}
      load(obj[i])
      .tmp<-kegg_cpd[[1]]$PATHWAY
      .cpd<-kegg_cpd[[1]]$ENTRY
      if(is.null(.cpd)) return()
      if(is.null(.tmp)){
        return(data.frame(cpd=.cpd,path=NA,map=NA))
      } else{
        data.frame(cpd=.cpd,path=.tmp,map=names(.tmp))
      }

    }) %>%
      do.call('rbind',.)

  }

  #get path summary path info
  get_path_summary<-function(path_info){

    f<-function(x){unique(x) %>% length()}
    .int_path<-path_info %>%
      group_by(map) %>%
      summarise(n_cpd=f(cpd))

    #total
    summary<-list(n_maps=f(path_info$map),n_cpd=f(path_info$cpd))

    list(path=.int_path,summary=summary)

  }


  #build data sets
  obj<-paste0(path,dir(path))
  path_info<-get_path_cpd_info(obj)

  path_summary<-get_path_summary(path_info)

  #save(path_info,file='data/path_info.rda')
  #save(path_summary,file='data/path_summary.rda')

}


test<-function(){

  library(dave.pathway)
  library(dave.stat)
  data("dave_stat_col_meta")

  tmp<-dave_stat_col_meta
  cpd<-tmp %>%
    filter(class_p.values<=0.05) %>%
    dplyr::select(KEGG) %>%
    unlist() %>%
    as.character()
  cpd<-cpd[cpd !=""]


  #get enrichment info for a set of metabolites
  # cpd<-sample(dir(path),20)
  paths<- get_cpd_paths(cpd,path_info)

  path_data<-get_path_data(paths,path_summary)

  #get matrix of pathways for each cpd
  cpd_paths_mat(cpd,path_info )

  obj<-pathway_enrichment(path_data,cpd=length(cpd)) %>%
    filter_path_enrich(.,fdr=FALSE)

  summary(obj)$description

  data("path_info")
  vars<-get_kegg_paths(path_info)
  id<-{vars} %in% {p.values$map %>% gsub('map','',.)}

  #get path info for col meta

  #get matrix of pathways for each cpd
  maps<-obj$path_enrich$map
  cpd_paths_mat(cpd,path_info,maps)

}
