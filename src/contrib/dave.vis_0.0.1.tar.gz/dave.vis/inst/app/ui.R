
tagList(
  useShinyjs(),
  do.call(navbarPage,
          c("dave.vis",
            getOption("dave.nav_ui"),
            getOption("dave_vis_ui"),
            getOption("dave.shared_ui")
          )
  )
)
