#' @param obj list object to digest and compare against hash
#' @param  hash digested object
#' @return list changed:digested object and hash are not the same, hash digested object hash see digest::digest
#' @details use for explixit memoziation when cases of built in fail
#' @export
#' @import digest
has_changed<-function(obj,hash=''){
  
  obj_hash<-digest(obj)
  changed<-TRUE
  if(obj_hash == hash) changed<-FALSE
  
  list(changed=changed,hash=obj_hash)
  
}



#want a UI to transfer data vars because theree can be so many
#e.g. limit to 10
dave_vis_module_values<-reactiveValues()
dave_vis_module_input<-reactiveValues() # values passed to the plotting module
dave_vis_module_output<-reactiveValues()
dave_vis_module_hash<-reactiveValues(hash='') # hack to control reactivity


#allow data to be selected from the sidebar
#do we want to toggle row or col meta plotting

output$dave_vis_module_data_select_type_ui<-renderUI({
  
  radioButtons('dave_vis_module_data_select_type','Dimension:',choices=c('samples','variables'),inline=TRUE,selected = 'samples')
  
})

output$dave_vis_module_data_select_ui<-renderUI({
  
  obj<-input$dave_vis_module_data_select_type
  req(obj)
  
  if(obj == 'samples'){
    
    .data<-.getdata_cube()$data
    .meta<-.getdata_cube()$row_meta
    
    if(!is.null(.meta)){
      .data<-cbind(.getdata_cube()$row_meta,.data)
    }
    
  }
  
  if(obj == 'variables'){
  
    .data<-.getdata_cube()$col_meta
    
  }  
  
  dave_vis_module_values$data<-.data
  
  pickerInput(
    inputId = "dave_vis_module_data_select",
    label = "Variables:",
    choices = colnames(.data),
    options = list(
      `actions-box` = TRUE,
      size = 10,
      `selected-text-format` = "count > 5",
      virtualScroll = 20
    ),
    multiple = TRUE
  )
  
})

output$dave_vis_module_data_select_full_ui<-renderUI({
  
  fluidRow(column(12,
                  uiOutput('dave_vis_module_data_select_type_ui'),
                  uiOutput('dave_vis_module_data_select_ui')
                  
                  ))
  
})


get_dave_vis_module_data<-reactive({
  
  if(is.null(dave_vis_module_values$data) | is.null(input$dave_vis_module_data_select)) return()
  
  dave_vis_module_values$data %>%
    select(one_of(input$dave_vis_module_data_select))
  
}) 



#old shiny version 1.5.0 


observe({
  
  #TODO: fix reactivity - entering too often
  # print('-----observing dave.vis-----')
  trigger<-input$dave_vis_module_data_select
  
  if(is.null(trigger)) return()
  
  isolate({
    
    if(is.null(input$tabs_dave_vis)) return()
    if(!input$tabs_dave_vis %in% c('Visualize')) return()
    


  .data<-get_dave_vis_module_data()
  if(is.null(.data)) return()
  
  
  
  #hack to control entry
  is_changed<-has_changed(.data,dave_vis_module_hash$hash)

  
  if(is_changed$changed){
    dave_vis_module_hash[['hash']]<-is_changed$hash
  } else {
    return()
  }
  
 
    # print('----recalculate dave vis ---')
    dave_vis_module_input$data<-.data
    dave_vis_module_input$name<-input$dataset
    
    dave_vis_module_output$module <- 
      callModule(module = dave.visServer,
                 id = "dave_vis",
                 data = dave_vis_module_input)
    
    
    
  })
  
})

get_dave_vis_module_output<-reactive({
  reactiveValuesToList(dave_vis_module_output$module)
})

# validate module output
dave_vis_available <- reactive({

  obj<-get_dave_vis_module_output()
  
  if(is.null(obj)) {
    return('Create visualization to see report.')
    
  }
  
  "available"
})





output$dave_vis_visualize_tab_ui<-renderUI({
  
  dave.visUI(
    id = "dave_vis", 
    choose_data = FALSE,
    header = FALSE
  )
  
})


#tab pabnel
output$ui_dave_vis <- renderUI({

  req(input$dataset)
  tagList(
    conditionalPanel(
      'input.tabs_dave_vis == "Visualize"',
      uiOutput('dave_vis_module_data_select_full_ui')
    ),
    conditionalPanel('input.tabs_dave_vis == "Report"'),
    fluidRow(column(
      12, align = "right", modalModuleUI(id = "dave_vis_help")
    ))
  )
})

output$dave_vis_ui <- renderUI({
  

  # #main panel
  dave_vis_output_panels <- tabsetPanel(
    id = "tabs_dave_vis",
    tabPanel("Visualize",icon=icon('eye'), uiOutput('dave_vis_visualize_tab_ui')), #call vis methods
    tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('dave_vis'))# 
  )
  
  
  
  #
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('braille'),as.character(" Plot")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('eye'),as.character(" Explore")))),
                 tool_ui = "ui_dave_vis",
                 output_panels = dave_vis_output_panels)
})





# save --------------------------------------------------------------------
#TODO add to object col meta

output$ui_dave_vis_save<-renderUI({
  actionButton("dave_vis_save", "Save")
})

observeEvent(input$dave_vis_save, {
  #default to calculate edges
  isolate({
    available <- dave_vis_available()
    validate(need(available == 'available', 'No objects available'))
    
    
    dataset <- input$dataset
    #saved obj names
    
    .name <- .makedata_cube_names(dataset)$col
    
    
    
    showNotification(paste("\u2713 Saving..."),
                     type = 'message',
                     duration = 2)
    
   
    # save_obj <- NULL 
    # 
    # r_data[[.name]] <- save_obj
  })
  
})