library(testthat)
library(dave.vis)

test_check("dave.vis")
