
> # dave.vis - interactive data mapping and visualization 

![](inst/app/tools/help/main.png)

## This is a modification of [esquisse](https://github.com/dreamRs/esquisse) R package to integrate with the [dave]() data analysis and visualization engine.

### See related:
* ### [dave](https://github.com/CreativeDataSolutions/dave)
* ### [dave.data](https://github.com/CreativeDataSolutions/dave.data)
* ### [get more ...](https://creative-data.science/)

<p style="text-align:center;"><img style="max-width: 10% !important;" src="https://github.com/CreativeDataSolutions/dave/blob/main/inst/app/www/imgs/cds.png?raw=true"></p>
