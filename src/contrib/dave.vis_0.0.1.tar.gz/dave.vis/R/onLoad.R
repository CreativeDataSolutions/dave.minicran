#' Adds the content of assets/ to dave.vis/
#'
#' @importFrom shiny addResourcePath registerInputHandler
#'
#' @noRd
.onLoad <- function(...) {
  shiny::addResourcePath("dave.vis", system.file("assets", package = "dave.vis"))
  shiny::registerInputHandler("davevis.dragula", function(data, ...) {
    if (is.null(data)) {
      NULL
    } else {
      data$source <- unlist(data$source)
      data$target <- lapply(data$target, unlist, recursive = FALSE)
      data
    }
  }, force = TRUE)
  davevis.palettes <- getOption("davevis.palettes")
  if (is.null(davevis.palettes)) {
    options("davevis.palettes" = default_pals)
  }
  davevis.themes <- getOption("davevis.themes")
  if (is.null(davevis.themes)) {
    options("davevis.themes" = default_themes)
  }
  davevis.default.theme <- getOption("davevis.default.theme")
  if (is.null(davevis.default.theme)) {
    options("davevis.default.theme" = "theme_minimal")
  }
  davevis.colors <- getOption("davevis.colors")
  if (is.null(davevis.colors)) {
    options("davevis.colors" = default_cols)
  }
}
