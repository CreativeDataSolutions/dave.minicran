

#' An add-in to easily create plots with ggplot2
#'
#' @param data a data.frame, you can pass a data.frame explicitly to the function, 
#' otherwise you'll have to choose one in global environment.
#' @param coerce_vars If \code{TRUE} allow to coerce variables to different type when selecting data.
#' @param disable_filters Logical. Disable the menu allowing to filter data used.
#' @param viewer Where to display the gadget: \code{"dialog"},
#'  \code{"pane"} or \code{"browser"} (see \code{\link[shiny]{viewer}}).
#'
#' @return code to reproduce chart.
#' @export dave.vis
#'
#' @importFrom shiny dialogViewer browserViewer runGadget paneViewer reactiveValues
#'
#' @examples
#' if (interactive()) {
#' # Launch with :
#' dave.vis(iris)
#' # If in RStudio it will be launched by default in dialog window
#' # If not, it will be launched in browser
#' 
#' # Launch dave.vis in browser :
#' dave.vis(iris, viewer = "browser")
#' 
#' # You can set this option in .Rprofile :
#' options("davevis.viewer" = "viewer")
#' # or
#' options("davevis.viewer" = "browser")
#' 
#' # dave.vis use shiny::runApp
#' # see ?shiny::runApp to see options 
#' # available, example to use custom port:
#' 
#' options("shiny.port" = 8080)
#' dave.vis(iris, viewer = "browser")
#' 
#' }
dave.vis <- function(data = NULL, 
                      coerce_vars = getOption(x = "davevis.coerceVars", default = TRUE),
                      disable_filters = getOption(x = "davevis.disable_filters", default = FALSE),
                      viewer = getOption(x = "davevis.viewer", default = "dialog")) {
  viewer <- match.arg(viewer, choices = c("dialog", "pane", "browser"))
  options("davevis.coerceVars" = coerce_vars)

  res_data <- get_data(data, name = deparse(substitute(data)))
  if (!is.null(res_data$dave.vis_data)) {
    res_data$dave.vis_data <- dropListColumns(res_data$dave.vis_data)
  }
  rv <- reactiveValues(
    data = res_data$dave.vis_data, 
    name = res_data$dave.vis_data_name
  )

  if (viewer == "browser") {
    inviewer <- browserViewer(browser = getOption("browser"))
  } else if (viewer == "pane") {
    inviewer <- paneViewer(minHeight = "maximize")
  } else {
    inviewer <- dialogViewer(
      "Hi there.",
      width = 1100, 
      height = 750
    )
  }

  runGadget(
    app = dave.visUI(
      id = "dave.vis",
      container = NULL, 
      # insert_code = FALSE,
      disable_filters = disable_filters
    ), 
    server = function(input, output, session) {
      callModule(
        module = dave.visServer, 
        id = "dave.vis", 
        data = rv
      )
    }, 
    viewer = inviewer
  )
}


