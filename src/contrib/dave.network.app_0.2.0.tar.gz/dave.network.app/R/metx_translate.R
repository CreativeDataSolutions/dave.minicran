
# translation module using CTSgetR

#' CTSgetR UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#' @export
#'
#' @importFrom shiny NS tagList
mod_CTSgetR_trigger_ui <- function(id) {
  ns <- NS(id)
  
  tagList(uiOutput(ns('sidebar_ui')))
  
}

#' CTSgetR UI module Server Function
#'
#' @noRd 
#' @export
#' @importFrom CTSgetR valid_from
#' @importFrom CTSgetR valid_to
#' @importFrom CTSgetR CTSgetR_summary
mod_CTSgetR_trigger_server <- function(id, data=NULL,trigger=NULL,connection=NULL) {
  
  moduleServer(
    id,
    function(input, output, session) {
      
      
      rv<-reactiveValues()
      
      .data<-reactive({data()}) # normaliZe name but useless
      
      #if data is NULL
      #use comma xseparated text input
      #else supply a data frame to choose inpout column from
      output$data_input <- renderUI({
        ns <- session$ns
        
        tagList(
          selectizeInput(ns('from_obj'), 'identifiers', choices = colnames(.data())),
          tippy_this(
            ns('from_obj'),
            'Select column containing values to translate from'
          )
        )
        
      })
      
      
      output$sidebar_ui <- renderUI({
        
        ns <- session$ns
        
        
        from_opts <- valid_from()
        to_opts <- valid_to()
        
        fluidRow(column(
          12,
          uiOutput(ns('data_input')),
          selectizeInput(ns('from_id'), 'from', choices = from_opts, selected = 'Chemical Name'),
          selectizeInput(ns('to_id'), 'to', choices = to_opts, selected='KEGG',multiple=TRUE)
        ))
        
      })
      
      
      #process input
      get_input<-reactive({
        
        
        shiny::validate(need(!is.null(input$from_obj),'Choose identifier options and then translate.'))
        
        .db_name<-Sys.getenv('ctsgetr_DB')
        if(.db_name ==''){
          .db_name<-'ctsgetr.sqlite'
        }
        
        tmp<-.data()
        if(is.null(tmp)){
          id <- input$from_obj %>%
            strsplit(.,',') %>%
            unlist() %>%
            trimws()
        } else {
          id<-tmp[,input$from_obj] %>%
            as.character()
        }
        
        
        
        from <- input$from_id
        to <- input$to_id
        
        #description
        
        
        list(id=id,from=from,to=to,db_name=.db_name,from_obj=input$from_obj)
        
      })
      
      get_summary<-reactive({
        args<-get_input()
        list(summary=CTSgetR_summary(args$from,args$to),input=args)
      })
      
      get_results <- reactive({
        trigger <- trigger()
        
        if (is.null(trigger) || trigger == 0) {
          return(NULL)
        }
        
        isolate({

          if(is.null(connection)){stop('No API connection found.')}
          
            body<-get_input()
           
            ocpu_post(
              connection,
              body = body,
              pkg_url = 'ocpu/library/CTSgetR/R/CTSgetR',
              encode = 'json',
              return_value = TRUE
            )$results
          
        })
        
      })
      
      
      # get_results
      
      return(list(results = get_results, summary = get_summary))
      
      
    }
  )
}


#' @noRd 
#' @export
CTSgetR_summary<-function(from=NULL,to=NULL,obj=NULL){
  
  f<-function(x){
    
    
    .len<-length(x)
    
    if(.len > 2){
      tmp<-paste0(x[1:(.len-1)],collapse=', ')
      tmp<-paste0(c(tmp,x[.len]),collapse=' and ')
    } else {
      tmp<-paste0(x,collapse=' and ')
    }
    
    tmp
  }
  
  .method<-NULL
  if(!is.null(to) & !is.null(from)){
    .method<-paste0('Metabolite ',from, 's were translated to ',f(to),' identifiers.')
  }
  
  
  #summarise missing translations
  if(!is.null(obj)){
    x<-obj %>% select(-id)
    missing<-apply(is.na(x) ,2,sum)
    
    if(any(missing)>0){
      
      id<-unlist(missing>0)
      info<-apply(matrix(c(colnames(x) ,paste0('(',unlist(missing),')')),nrow=ncol(x)),1,'paste', collapse=' ')
      
      obj<-paste0(' The following translations could not be completed: ',f(info[id]),'.')
    }
  }
  
  paste(c(.method,obj),collapse=' ')
  
}

