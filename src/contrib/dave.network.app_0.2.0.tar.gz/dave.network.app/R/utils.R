
#utility functions
#' @title CID_SDF_DB_stats
#' @export
CID_SDF_DB_stats<-function(DB=NULL){
  
  load(DB) #CID.SDF.DB
  DB<-CID.SDF.DB
  
  list( n = length(DB))
     
}

