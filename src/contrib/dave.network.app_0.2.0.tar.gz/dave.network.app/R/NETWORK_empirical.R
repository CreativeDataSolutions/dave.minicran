#empirical networks

#' @title get_cor_edges
#' @export
#' @details filter correlation matrix based on edge list
get_cor_edges<-function(cor_obj,edge_list=NULL,huge_NULL=FALSE,FDR='BH'){
  
  #break factors..TODO upstream
  fixln<-function(x){x %>% as.character() %>% as.numeric()}
  
  if(is.null(edge_list)){
    .cor<-adjacency_edgeList(cor_obj$cor)
    .pvals<-adjacency_edgeList(cor_obj$p.value)
    .fdrp<-p.adjust(fixln(.pvals$value),method=FDR) # fdr edges
    edge_list<-.cor %>% dplyr::select(source,target)
  } else {
    .cor<-sym.mat.to.edge.list(cor_obj$cor,edge_list)
    .pvals<-sym.mat.to.edge.list(cor_obj$p.value,edge_list)
    .fdrp<-p.adjust(.pvals[,1],method=FDR) # fdr edges
  }
  
  #translate edge index
  # browser()
  # 
  # if (!is.null(id))
  #   el <- convert_edge_index()
  
  el <- edge_list %>% dplyr::select(source, target)
  
  out <- data.frame(
    el,
    value = .cor$value %>% fixln,
    p.value = .pvals$value %>% fixln,
    fdr.p.value = .fdrp,
    type = "corr"
  )
  class(out) <- c('cer_el', class(out)) %>% unique()
  return(out)
}

#' @exportS3Method summary
summary.cor_obj<-function(args){
  
  desc<-paste0('Correlation analysis was conducted using the ',args$cor_method, ' method. ')
  if(!args$huge_method == 'none'){
    desc<-c(desc,'High-dimensional undirected graph estimation was used to select conditionally independent connections between variables.  The nonparanormal (npn) transformation was applied to help relax normality assumption and the graph structure was estimated by Meinshausen-Buhlmann method. ')
    if(!is.null(args$lambda)){
      if(args$huge_method == 'manual'){
        desc<-c(desc,paste0('The optimal lambda was manually selected at ',round(args$lambda,3),". "))
        if(args$huge_NULL) desc<-c(desc,paste0("No connections found after regularization, a previous edge list was used instead. "))
      } else {
        method<-switch(args$huge_method,
                       'ric' = 'rotation information criterion (ric)',
                       'stars' = 'stability approach for regularization selection (stars)'
        )
      #TODO return of lambda when args$huge_method not none or manual in dave.network::get_huge_edges
      # desc<-c(desc,paste0('The optimal lambda was selected based on the ',method, ' at ',round(args$lambda,3),". "))
        desc<-c(desc,paste0('The optimal lambda was selected based on the ',method, ". "))
      }
    }
  }
  
  pval<-if(args$cor_FDR) {
    'Benjamini and Hochberg false discovery adjusted'
  } else {
    NULL
  }
  c(desc,paste0('The selected connections were filtered based on ',pval,
                ' p-values less than or equal to ',args$cor_cutoff,'.')) %>%
    paste0(.,collapse="")
  
}

#' @exportS3Method summary
summary.cer_el<-function(cer_el){
  desc<-paste0('The network contains ',nrow(cer_el),' edges and ',c(cer_el[,1],cer_el[,2]) %>% unique() %>% length(),
         ' nodes.')
  
  lambda<-attr(cer_el,'lambda')
  if(!is.null(lambda)){
    desc<-c(desc,paste0(' Regularization lambda was set to ',signif(lambda,2),'.'))
  }

  desc %>% paste(.,collapse="")
}


test<-function(){
  
  #major types
  #corralation
  #regularization
  #partial correlation
  
  # library(dave.stat)
  library(dave.network)
  library(dave.network.app)
  
  data(dave_network)
  
  tmp_data<-dave_network
  
  # #testing with larger data
  # .data<-read.csv('C:/Users/Dmitry/Desktop/final_all_sex2.csv', header =TRUE)
  # .data<-.data[,-c(1:2),drop=FALSE]
  # #remove zero variance variables
  # .sd<-apply(.data,2,sd,na.rm=TRUE)
  # tmp_data<-.data %>% .[,!is.na(.sd) & .sd !=0] 
  
  #summary
  #--------
  args<-list(
    cor_method ='spearman',
    cor_FDR = TRUE,
    cor_cutoff = .05,
    lambda = NULL, 
    huge_method= 'manual'
  )
  
  
  #correlation obj
  cor_obj<-get_cor_mat(tmp_data,cor_method=args$cor_method)
  cor_el<-get_cor_edges(cor_obj$cor)
  
  
  #convert to generic object
  net<-format_net_obj(nodes=cor_obj$node,cor_el,net_index = 'id')
  summary(net)
  plot(net)
  
  
  #huge based regularization
  huge_obj<- get_huge_obj(tmp_data)
  plot(huge_obj)
  
  #auto 
  huge_el<-get_huge_edges(huge_obj, opt='stars') # opt='stars'
  summary(huge_el)
  net<-format_net_obj(nodes=data.frame(id=as.character(1:nrow(dave_data))),huge_el,net_index = 'id')
  colnames(net$edges)[3]<-'value'
  network.visnetwork(net,edge_cutoff=0)
  #manual
  args$lambda<-huge_obj$lambda[2]
  huge_el<-get_huge_edges(huge_obj, lambda=args$lambda) # opt='ric'
  summary(huge_el)
  
  #cor filter on reg selected edges
  #cut off here on p-value
  #easier to filter on p-value externaly before plotting
  el<-get_cor_edges(cor_obj$cor,edge_list=huge_el)
  var<-if(args$cor_FDR) {'fdr.p.value'} else {'p.value'}
  id<-el[[var]]<=args$cor_cutoff
  el<-el[id,,drop=FALSE] %>% remove_edge_dupes(.)
  
  #combine
  #nodes
  nodes<-data.frame(id=as.character(cor_obj$node$id), 
                    names=cor_obj$node$label,stringsAsFactors = FALSE)  #
  obj<-format_net_obj(nodes,el,net_index = 'names')
  class(obj)<-c(class(obj),'corr_obj')
  
  
  args<-list(
    cor_method ='spearman',
    cor_FDR = TRUE,
    cor_cutoff = .05,
    lambda = .005, 
    huge_method= 'manual'
  )
  
  summary.cor_obj(args)
  
  #cut off here on p-value
  #easier to filter on p-value externaly before plotting
  el<-cor_el
  obj<-format_net_obj(nodes,el,net_index = 'names')
  
  plot(obj)
  network.visnetwork(obj)
  
  #huge based regularization
  huge_obj<- get_huge_obj(tmp_data)
  huge_el<-get_huge_edges(huge_obj, opt='ric') # opt
  
  #try largest non-zero
  opt_el<-NULL
  .lambda<-huge_obj$lambda
  for(i in .lambda){
    out<-get_huge_edges(huge_obj, lambda=i)
    if(nrow(out)>0) {
      opt_el<-out
      break()
    }
  }
  
  #extract correlations
  opt_cor_edges<-get_cor_edges(cor_obj,edge_list=opt_el,FDR='BH')  %>%  remove_edge_dupes(.)
  
  #format
  nodes<-data.frame(id=cor_obj$node$id, names=cor_obj$node$label,stringsAsFactors = FALSE)  #id=1:ncol(tmp_data) %>% as.character(),
  
  #cut off here on p-value
  #easier to filter on p-value externaly before plotting
  el<-opt_cor_edges[opt_cor_edges$fdr.p.value<=1e-15,,drop=FALSE]
  obj<-format_net_obj(nodes,el,net_index = 'names')
  
  plot(obj)
  
  #summary
  #--------
  args<-list(
    cor_method ='spearman',
    cor_FDR = TRUE,
    cor_cutoff = .05,
    lambda = NULL, 
    huge_method= 'manual'
  )
  
  
  #correlation obj
  cor_obj<-get_cor_mat(tmp_data)
  cor_el<-get_cor_edges(cor_obj$cor)
  
  
 #need to work out cut off filter on p-value 
 network.ggplot(obj, edge_cutoff=0,repel=TRUE)
  

}