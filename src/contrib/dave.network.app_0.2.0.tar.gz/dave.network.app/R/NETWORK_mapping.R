#mapping columns to visual aesthetics


#' Title
#'
#' @param FC
#' @param transform string of function, defaults to 'log2
#'
#' @return data.frame based on 'transformed' FC as x, where FC_mag is the absolute value of x and FC_dir is the sign of x
#' @export
#'
#' @examples
#' \dontrun{
#' FC<-c(.5,2,1)
#' map_fold_change(FC,transform = 'log2')
#' }
map_fold_change <- function(FC, transform = 'log2') {
  tmp <- do.call(transform, list(FC))
  mag <- abs(tmp)
  
  dir <- sign(tmp)
  
  .names <- paste0(names(FC), c('_mag', '_dir'))
  
  res <- data.frame(mag, dir) %>%
    setNames(., .names)
  
  #bundle summary
  .sum <-
    paste0(
      'The variable ',
      names(FC),
      ' was transformed based on ',
      transform,
      ' and mapped to the absolute value and sign of the results.'
    )
  
  list(results = res, summary = .sum)
  
}

#' Title
#'
#' @param sig
#' @param threshold
#' @param inequality
#' @details return logical meeting 'sig' evaluating 'inequality' compared to 'threshold' e.g. sig >= threshold
#' @return data.frame where 'sig' equals a logical based on 'sig' evaluating 'inequality' compared to 'threshold' e.g. sig >= threshold
#' @export
#'
#' @examples
map_sig <- function(sig,
                    threshold = .05,
                    inequality = '<=') {
  #evaualte expression? -- better with do.call?
  expr <- paste('sig', inequality, threshold)
  .names <- paste0(names(sig), c('_sig'))
  res <- data.frame(eval(parse(text = expr))) %>%
    setNames(., .names)
  
  .sum <-
    paste0(
      'The variable ',
      .names,
      ' was transformed based on inequality',
      inequality,
      ' ',
      threshold,
      '.'
    )
  
  list(results = res, summary = .sum)
}

#' Title
#'
#' @param obj data.frame
#' @param cols column names to combine
#' @param sep separator to collapse on
#'
#' @return
#' @export
#'
#' @examples
map_unite <- function(obj, cols, sep = "_") {
  .names <- paste(cols, collapse = sep)
  tmp <- unite(
    obj %>% select(one_of(cols)),
    col = cols,
    # not working
    sep = sep,
    remove = TRUE,
    na.rm = FALSE
  )
  
  res <- tmp %>% setNames(., .names)
  
  .sum <-
    paste0('The variables ',
           grammatical_paste(cols),
           ' were combined.')
  
  list(results = res, summary = .sum)
}


#' Title
#'
#' @param obj data.frame to left join into
#' @param extra data.frame to join into obj
#' @param id shared column between obj and extra to join by
#' @param extra_columns column names to join in extra defaults to all
#'
#' @return data.frame based on left_join of extra in to obj by=id
#' @export
#'
#' @examples
map_left_join <- function(obj, extra, id, extra_columns = colnames(extra)) {
  left_join(obj, extra %>% select(one_of(c(id, extra_columns))), by = id)
}


# UI module ---------------------------------------------------------------
# select datasets
# select columns
# select transformation
#summary: describe transformations
# show table head of original and transformed values
# save transformed to datacube

#' Title
#'
#' @param id
#'
#' @return
#' @export
#'
#' @examples
mod_network_map_ui <- function(id) {
  ns <- NS(id)
  
  tagList(uiOutput(ns('sidebar_ui')))
  
}


#' Title
#'
#' @param id
#' @param obj list of inputs e.g transformation, datasets and options
#' @param trigger reactive to trigger calculations
#'
#' @return
#' @export
#'
#' @examples
mod_network_map_server <-
  function(id,
           obj = NULL,
           trigger = NULL,
           connection = NULL) {
    moduleServer(id,
                 function(input, output, session) {
                   ns <- NS(id)
                   
                   rv <- reactiveValues()
                   
                   .obj <- reactive({
                     obj()
                   })
                   
                   output$sidebar_ui <- renderUI({
                     ns <- session$ns
                     
                     tagList(
                       selectizeInput(
                         ns('transform'),
                         'transformation',
                         choices = c(
                           'map fold change' =   'fc' ,
                           'map p-value' = 'sig',
                           'combine columns' = 'combine'
                         )
                       ),
                       conditionalPanel(
                         'input.transform == "fc" | input.transform == "sig"' ,
                         ns = ns,
                         selectizeInput(ns('transform_column'),
                                        'to transform',
                                        choices = colnames(.obj())),
                         tippy_this(
                           ns('transform_column'),
                           'choose which column to transform'
                         )
                       ),
                       
                       tippy_this(ns('transform'),
                                  'choose transformation'),
                       conditionalPanel(
                         'input.transform == "sig"' ,
                         ns = ns,
                         tagList(
                           numericInput(ns('threshold'),
                                        'threshold',
                                        value = 0.05),
                           tippy_this(ns('threshold'),
                                      'value to compare to'),
                           textInput(ns('inequality'),
                                     'inequality',
                                     value = '<='),
                           tippy_this(
                             ns('inequality'),
                             'define the inequality for the comparison'
                           )
                         )
                       ),
                       conditionalPanel(
                         'input.transform == "combine"' ,
                         ns = ns,
                         selectizeInput(
                           ns('transform_combine_column'),
                           'column(s) to add',
                           choices = colnames(.obj()),
                           multiple = TRUE
                         ),
                         tippy_this(ns('transform_combine_column'),
                                    'columns to combine')
                       )
                     )
                   })
                   
                   
                   
                   #process input
                   get_input <- reactive({
                     list(
                       data = .obj(),
                       transform = input$transform,
                       transform_column = input$transform_column,
                       transform_comine_id = input$transform_comine_id,
                       transform_threshold = input$threshold,
                       transform_inequality = input$inequality,
                       transform_combine_column = input$transform_combine_column
                     )
                   })
                   
                   .calculate <- reactive({
                     trigger <- trigger() #reactive to trigger calculations
                     
                     if (is.null(trigger) || trigger == 0) {
                       return(NULL)
                     }
                     
                     isolate({
                       args <- get_input()
                       if (args$transform == 'fc') {
                         tmp <-
                           map_fold_change(args$data %>% select(one_of(args$transform_column)), transform = 'log2')
                       }
                       if (args$transform == 'sig') {
                         tmp <-
                           map_sig(
                             args$data %>% select(one_of(args$transform_column)),
                             threshold = args$transform_threshold,
                             inequality = args$transform_inequality
                           )
                       }
                       
                       if (args$transform == 'combine') {
                         tmp <-
                           map_unite(obj = args$data,
                                     cols = args$transform_combine_column)
                       }
                       
                       tmp
                     })
                     
                   })
                   
                   
                   get_results <- reactive({
                     .calculate()$results
                   })
                   
                   get_summary <- reactive({
                     .calculate()$summary
                   })
                   
                   return(list(results = get_results, summary = get_summary))
                   
                   
                 })
  }

test <- function() {
  # fold change -------------------------------------------------------------
  FC <- data.frame(FC = c(.5, 2, 1))
  obj <- FC %>% select(one_of('FC'))
  FC_out <- map_fold_change(FC, transform = 'log2')
  
  # convert significance or p-value to Boolean -------------------------------------------------
  sig <- data.frame(foo = c(1, .05, .01))
  sig_out <- map_sig(sig)
  
  #  map_combine_character ---------------------------------------------------
  obj <- data.frame(FC_out$results, sig_out$results)
  cols <- c('FC_dir', 'foo_sig')
  map_unite(obj, cols)
  
  
  #summary methods
  
  
  # module ------------------------------------------------------------------
  ui <- fluidPage(
    theme = shinytheme("lumen"),
    bs_accordion(id = "networkmap_collapse_mapping") %>%
      bs_append(
        title = tags$label(class = 'bsCollapsePanel', icon("map") , "Mapping options"),
        content =
          fluidRow(
            column(
              12,
              actionButton('test', 'calculate'),
              mod_network_map_ui('network_map'),
              verbatimTextOutput('show')
            )
          )
      )
  )
  
  server <- function(input, output) {
    .trigger <- reactive({
      input$test
    })
    .obj <- reactive({
      data.frame(FC, sig)
    })
    out <-
      mod_network_map_server('network_map', obj = .obj, trigger = .trigger)
    
    output$show <- renderPrint({
      list(out$results(), out$summary())
      
    })
  }
  
  # debug(mod_network_map_server)
  shinyApp(ui = ui, server = server)
}
