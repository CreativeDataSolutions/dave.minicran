###############################
# Export functions
###############################



#use network_vis methods
#' Plot ggplot method
#' @param obj of class network_biochem
#' @export
#' @exportS3Method plot
plot.network_biochem<-function(obj, ...){
  network_out <- network.ggplot(obj)
  return(network_out)
}

#' Export plotly method
#' @param obj of class network_viz
#' @export
#' @exportS3Method include_graphics
include_graphics.network_biochem<-function(obj, shiny=FALSE, ...){
  network_out <- network.ggplotly(obj)
  knitr::include_graphics(export(ggplotly(network_out)))
}

#' @exportS3Method summary
summary.kegg_obj<-function(type=c('KEGG','CID'),CID_cutoff=NULL){

  desc<-NULL
  if(any(type %in% 'KEGG')){
    desc<-c(desc,'Biochemical connections were determined based on KEGG identifiers. ')
  }
  if(any(type %in% 'CID')){
    if(is.null(CID_cutoff)){ 
      filter<-NULL
    } else {
      filter<-paste0('Connections were identified based on tanimoto smilarities greater or equal to ',CID_cutoff,'. ')
    }
    desc<-c(desc,paste0('Structural similarity based connections were calcuated between PubChem CID identiers. ',filter))
  }
  paste0(desc,collapse='')
}

test<-function(){

  library(dave.network)


  #debug compatibility with dave.preproc

  #data and meta requiring join
  test_1<-function(){

    library(dave.preproc)
    
    data(dave_)
    data(dave_var_meta)


    data<-dave_
    meta<-dave_var_meta
    var.id<-'ID'


    #row group
    row_meta<-c('label','class','age')

    obj<-dave_init_data(data,meta,row_meta,var.id)

    #initialize data

    input_nodes <-obj$col_meta
    kegg_col <- 'KEGG'
    net_index<-'ID'
    type<-'KEGG'
    node_mapping<-list(node_label='name') #check mapping inputs for not nulls inside

    #enforce unique net index?
    init<-list(data=input_nodes, idcolumn=kegg_col,net_index=net_index,type=type, node_mapping=node_mapping)

     res<-do.call('metabolic_network', init)

     p<-plot(res,repel=TRUE,curvature=0)
     ggplotly(p)

  }

  library(dave.network)
  library(dave.pathway)
  data("network_data")
  data("network_data_col_meta")


  #create package demo data
  make_data<-function(){

    
    dave_network<-read.csv('../../../../../Desktop/dave_.csv',header = T)
    dave_network_col_meta<-read.csv('../../../../../Desktop/dave__col_meta.csv',header = T)
    usethis::use_data(dave_network, overwrite = TRUE)
    usethis::use_data(dave_network_col_meta, overwrite = TRUE)
    # save(network_data,file='data/network_data.rda')
    # save(network_data_col_meta,file='data/network_data_col_meta.rda')
    
    library(dave.network)
    data(dave_network_col_meta)
    dave_network_col_meta
  }


  #merge columns and rows
  #melt then cast?
  library(reshape2)
  tmp<-network_data
  tmp<-data.frame(id=tmp[["Variables"]],tmp)
  tmp<-tmp[!duplicated(tmp$id),,drop=FALSE]
  #
  tmp1<-tmp[1:10,1:5]
  tmp2<-tmp[5:15,c(1,5:8)]
  m1<-melt(tmp1,id.vars='id')
  m2<-melt(tmp2,id.vars='id')
  m<-rbind(m1,m2)

  #make unique id
  id<-paste0(m$id,"_",m$variable)
  m<-m[!duplicated(id),,drop=FALSE]
  dm<-dcast(m,id ~ ...)

  join_nodes<-function(node1,node2,net_index='id'){
    m1<-melt(node1,id.vars=net_index)
    m2<-melt(node2,id.vars=net_index)
    m<-rbind(m1,m2)

    #make unique id
    id<-paste0(m$id,"_",m$variable)
    m<-m[!duplicated(id),,drop=FALSE]

    return(dcast(m,id ~ ...))
  }

  nodes<-join_nodes(tmp1,tmp2)

  .get_CID<-function(){
    library(CTSgetR)
    id<-aq_data_stat$KeggID
    id[id=='']<-NA

    from<-"KEGG"
    to<-"PubChem CID"
    cids<-CTSgetR(id,from,to)
    aq_data_stat$CID<-cids$value
  }

  data<-network_data
  keggcolumn<-'KeggID'
  net_index<-'ID'
  node_mapping<- vis_config <- NULL

  kegg_obj<-network.biochemical(data, keggcolumn, net_index, node_mapping, vis_config)

  summary.kegg_obj(CID_cutoff = .8)

  summary.kegg_obj<-function(type=c('KEGG','CID'),CID_cutoff=0.7){

    desc<-NULL
    if(any(type %in% 'KEGG')){
      desc<-c(desc,'Biochemical connections were determined based on KEGG identifiers. ')
    }
    if(any(type %in% 'CID')){
      desc<-c(desc,paste0('Structural similarity-based connections were calculated between PubChem CID identifiers. ',
      'Connections were identified based on tanimoto smilarities greater or equal to ',CID_cutoff,'. '))
    }
   paste0(desc,collapse='')
  }

  #plot
  nodes<-kegg_obj$nodes
  edges<-kegg_obj$edges
  obj<-kegg_obj

  plot(obj)

  # obj<-format.network(obj)
  network.ggplot(obj)

  p<-network.ggplotly(obj)
  ggplotly(p)

  network.visnetwork(obj)

  #using general network vis
  node_mapping<-list(node_label='Variables',node_size='WI38_MD231_FC')
  obj<-network.visualize(nodes, edges, node_mapping, vis_config=NULL)
  form<-format.network(obj)
  network.ggplot(obj)

  network.visnetwork(obj)
}
