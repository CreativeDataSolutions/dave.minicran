###############################
# Export functions
###############################

#' @title network.visualize
#' @param nodes
#' @return list
#' @export
#' @details format attributes to display network...legacy idiocy?
network.visualize<-function(nodes, edges, node_mapping=NULL, vis_config=NULL){
  out <- list(nodes=nodes, edges=edges, node_mapping=node_mapping, vis_config=vis_config)
  class(out)<-"network_viz"
  return(out)
}

#not clear how to mix network methods
generic_network_summary<-function(obj){
  
  paste0('The final network contains ',
         length(unique(c(obj$edges[,1],obj$edges[,2]))),' nodes (variables) and ',
         nrow(obj$edges),' edges (relationships).')
}

#' Summary method
#' @method summary network_viz
#' @param obj of class network_viz
#' @exportS3Method summary
summary.network_viz<-function(obj, ...){
  
  generic_network_summary(obj)
  
}

#' Plot ggplot method
#' @method plot network_viz
#' @param obj of class network_viz
#' @exportS3Method plot
plot.network_viz<-function(obj, edge_cutoff=0, shiny=FALSE, ...){
  network_out <- network.ggplot(obj, edge_cutoff,...)
  return(network_out)
}

#' Export plotly method
#' @param obj of class network_viz
#' @exportS3Method include_graphics
.network_viz<-function(obj, edge_cutoff=0, shiny=FALSE, ...){
  network_out <- network.ggplotly(obj, edge_cutoff)
  knitr::include_graphics(export(ggplotly(network_out)))
}


#format network for ggplot
#need to make edge filter more generic
format.network <- function(obj, edge_cutoff=0){
  nodes = obj$nodes
  edges = obj$edges

  edges = edges[edges$value > edge_cutoff,,drop=FALSE] #filter edges
  nodes = nodes[nodes$id %in% unique(c(edges$from %>% as.character(), edges$to %>% as.character())),,drop=FALSE] #exclude unused nodes

  if(!is.null(obj$node_mapping) && length(obj$node_mapping)>0){#mapping nodes to node attributes

    args_l<-list() # collect arguments for network vis

    #WTF..? depend on args accepted by
    
    #why does this match partial names?
    .size<-obj$node_mapping[['node_size']]
    .color<-obj$node_mapping$node_col
    .label<-obj$node_mapping$node_label
    .shape<-obj$node_mapping$node_shape

    if(!is.null(.size)){
      if(is.numeric(nodes[[.size]])){
        node.size = nodes[[.size]] + 20
      }else{
        node.size = 20
      }

      args_l<-c(args_l,list(list("node_size", node.size)))

    }

    if(!is.null(.color)){

      node.color = nodes[[.color]]
      if(is.numeric(node.color)){
        # if(length(unique(sign(node.color)))>1){
        #   node.color = as.character(factor(node.color < 0, labels = c("Up","Dn"))) #set color for fold change
        # }else{
          node.color <- as.character(as.factor(node.color)) #might not need
        # }
      } else {
        node.color <- as.character(node.color)
      }

      args_l<-c(args_l,list(list( "node_col", node.color)))
    }

    if(!is.null(.label)){

      node.name = nodes[[.label]]
      args_l<-c(args_l,list(list("node_label", node.name %>% as.character()))) # check outside!!!
    }

    #get edge lists
    n <- network(edges %>% dplyr::select(from,to), directed = FALSE)
    #set node and edge attributes
    f<-network::set.vertex.attribute# igraph interferes
    for(i in args_l){
      .args<-c(list(n),i)#purrr::flatten(c(list(n),i))
      do.call('f',.args)
    }

  }else{#use default node attributes
    #get edge lists
    n <- network(edges %>% dplyr::select(from,to), directed = FALSE)
  }
  #edge attributes
  edge.size = edges$value
  edge.color = as.character(edges$type)
  network::set.edge.attribute(n, "rel_type", edge.color)
  network::set.edge.attribute(n, "rel_score", edge.size)
  n<-tryCatch(ggnetwork(n , layout = "kamadakawai"),error =  function(e){})
  #add node attributes
  if(!is.null(nodes)){
    tmp<-left_join(data.frame(id=n$vertex.names), data.frame(nodes), by='id')
    n<-cbind(n, tmp)
  }

  return(n)
}



#separate node and edge plotting for ggnetworks?

#' create geom_nodes
#' @export
make_geom_nodes <-
  function(x = NULL,
           y = NULL,
           color = NULL,
           fill = NULL,
           size = NULL,
           size_range = NULL,
           shape = NULL,
           id = NULL,
           verbose = FALSE) {
    
  
  #create args
  #use built in?
  .char<-function(x,with="'"){
    if(!is.null(x)) paste(with,x,with,sep='')
  }
  .ac<-function(x,obj){if(!is.null(obj)) paste(c(x,obj),collapse =" = ")}
  .dc <-
    function(x, obj, default = NULL) {
      if (is.null(obj))
        paste(c(x, default), collapse = " = ")
    }
  

  points_aes <-
    list(
      .ac('x', x),
      .ac('y', y),
      .ac('size', .char(size)),
      .ac('fill', .char(fill)),
      .ac('color', .char(color)),
      .ac('shape', .char(shape)),
      .ac('group',.char(id))
      
    ) %>%
    unlist() %>%
    paste(.,collapse = ", ")
  
  #defaults
  default_size<-if(is.null(size_range)) 3 else max(size_range)
  
  points_default<-
    list(
      .dc('size',size, default_size),
      .dc('fill',fill, .char('gray')),
      .dc('color',fill, .char('black')),
      .dc('shape',shape, 21)
    ) %>%
    unlist() %>%
    paste(.,collapse = ", ")
  
  add_args<-function(x,add=',',first=TRUE){
    
    if(x!=''){if(first) c(add,x) else {c(x,add)}} %>% paste(.,collapse = '') else ''
    
  }
  
  plot_points<-paste0('geom_nodes(aes_string(',points_aes,')',add_args(points_default),')')
  
  if (verbose) print(plot_points)
  
  #create legends
  #if 2 levels choose points
  
  eval(parse(text = plot_points))
  
}

#ggplot
#TODO: control edge and node, size and color seperately
# native ggplot2 does not support this
#' @export
#' @import ggplot2 ggnetwork
network.ggplot <- function(obj, edge_cutoff=0, curvature = 0, repel=FALSE,...){
  n = format.network(obj, edge_cutoff)

  #node attributes ..????
  #label needs to contain ID for use with other networks
  #needs to pass through ggplot and then be used by
  .size<-obj$node_mapping[['node_size']]#$node_size ...fuzzy matches range
  .color<-obj$node_mapping$node_col
  .label<-obj$node_mapping$node_label
  .shape<-obj$node_mapping$node_shape
  
  .id<-obj$node_mapping$node_index
  if(!is.null(.id)) {
    #label + id
    if(is.null(.label)){
      n[['tmp_label']]<-paste0(n[[.id]], '||')
      .label<-'tmp_label'
    } else {
      n[[obj$node_mapping$node_label]]<-paste0(n[[.id]], '||',n[[.label]])
    }
    
  }
  
  .size_range<-obj$node_mapping[['node_size_range']]
  if(is.null(.size_range)) .size_range<-c(2,2) #...
  
  .text<-'text'
  if(is.null(n[[.text]])) {.text<-'id'} 
  
  #nodes w/o legend 
  
  nodes<- make_geom_nodes(fill=.color,size=.size,size_range=.size_range,shape=.shape,id=.text) 

  .scale_fill<-NULL

  if(!is.null(.color)){
    check<-n[[.color]]
    if(is.character(check) | is.factor(check) | is.logical(check)){
      .scale_fill<-scale_fill_brewer(palette = 'Set1')
    }
  }
  
  #edge colors...prevent node boarders
  
  .scale_color<-  scale_color_brewer(palette = 'Dark2')
  
  #repel needs its own data source else multiples?
  
  #labels
  if(repel){
    repel_data<-n[!duplicated(n$id),,drop=FALSE]
  }
  
  if(!is.null(.label)){
    if(repel){
      node_text<-geom_text_repel(data=repel_data, aes_string(label=.label), size=3, show.legend = FALSE,
                                 fontface = "bold", box.padding = unit(1, "lines"), label.padding=unit(.05, "lines"))
    } else {
      if(repel){
        node_text<-geom_text_repel(data=repel_data, aes_string(label=.label), size=3, show.legend = FALSE,
                                   fontface = "bold", box.padding = unit(1, "lines"), label.padding=unit(.05, "lines"))
      } else {
        node_text<-geom_nodetext(aes_string(label=.label), size=3, show.legend = FALSE,
                                 fontface = "bold")
      }
      
    }
  } else {
    if(repel){
      node_text<-geom_text_repel(data=repel_data,aes(label=id), size=3, show.legend = FALSE,
                                 fontface = "bold", box.padding = unit(1, "lines"), label.padding=unit(.05, "lines"))
    } else {
      node_text<-geom_nodetext(aes(label=id), size=3, show.legend = FALSE,
                               fontface = "bold")
    }
    
  }
  

  if(!is.null(.size)){  
    size_legend<-guides(size=guide_legend(title=.size))
    
    if(!is.null(.size_range)){
      if(any(class(n[[.size]]) %in% c('factor','character','logical'))){
        size_range<-scale_size_discrete(range=c(.size_range[1],.size_range[2]))
      } else{
        size_range<-scale_size(range=c(.size_range[1],.size_range[2]))
      }
    } else {
      if(any(class(n[[.size]]) %in% c('factor','character'))){
        size_range<-scale_size_discrete(range=c(1,5))
      } else {
        size_range<-scale_size(range=c(1,5))
      }
    }
  } else {
    
    size_range<-scale_size(range=c(1,5))
    size_legend<-NULL
    # guides(fill = guide_legend(override.aes = list(size = 4)))  
    
  }
  
  if(!is.null(.color)){
    color_legend<-guides(fill=guide_legend(title=.color))
  } else {
    color_legend<-NULL
  }
  
 
  #make this reverse compatible
  #Error: Columns `x`, `y`, `xend`, `yend` must be 1d atomic vectors or lists
  n$x <- tryCatch(n$x[,1],error=function(e){n$x})
  n$y <- tryCatch(n$y[,1],error=function(e){n$y})
  n$xend <- tryCatch(n$xend[,1],error=function(e){n$xend})
  n$yend <- tryCatch(n$yend[,1],error=function(e){n$yend})
  # n$y <- n$y[,1]
  # n$xend <- n$xend[,1]
  # n$yend <- n$yend[,1]

  
  # browser()
  
  network_plot<-ggplot(n, aes(x = x, y = y, xend = xend, yend = yend)) +
    # geom_edges(aes(linetype=rel_type, size=rel_score), curvature = curvature,color='gray') +
    geom_edges(aes(color=rel_type),size=1, curvature = curvature,arrow.fill=NULL) + # no arrows #see fan edge for curves
    nodes +
    # node_size_scale +
    .scale_fill +
    .scale_color +
    node_text +
    theme_blank() +
    #extra_theme + # remove plotly gridlines?
    size_range +
    theme(legend.position ='bottom') +
    size_legend +
    color_legend + #minimum legend color... should vary based on plot size?
    guides(color=guide_legend(title='relationship',override.aes = list(size = 2))) +
    guides(fill=guide_legend(title=obj$node_mapping[['node_col']],override.aes = list(size = 5))) 
  
  
  return(network_plot)
}


#TODO separate vis_conf from the plot to independent allow update
#visNetwork
#' @export
network.visnetwork <- function(obj, edge_cutoff=0,vis.height='900px',font.color='#00bc8c',font.size='16'){
  ggnw = network.ggplot(obj, edge_cutoff) #build ggplot network
  ggnw_info = ggplot_build(ggnw)
  nodes = obj$nodes
  edges = obj$edges

  #Tricky to set
  edges = edges[edges$value > edge_cutoff,] #filter edges should be centralized
  nodes = nodes[nodes$id %in% unique(c(edges$from, edges$to)),,drop=FALSE] #exclude unused nodes

  #nodes don't always match expected order after
  #ggplot network?
  #hack: use id added to label
  .tmp<-ggnw_info$data[[3]] %>% # label
  .$label %>% strsplit(.,"\\|\\|") %>%
    data.frame()
  .label<- .tmp %>% .[2,] %>% unlist()
  .id<-.tmp %>% .[1,] %>% unlist()
  
  #ids need to match type
  nodes<-left_join(data.frame(id=.id),nodes, by='id')

  #get node settings from ggplot
  #color
  nodes$color.background <- ggnw_info$data[[2]]$fill #get node colors from ggplot network
  nodes$color.border <- ggnw_info$data[[2]]$colour
  nodes$borderWidth <- 2
  nodes$color.highlight.background <- "yellow"
  nodes$title<-nodes$text
  # nodes$color.alpha <- ggnw_info$data[[2]]$alpha # need to add to hex or rgb
  #size
  nodes$size <- ggnw_info$data[[2]]$size
  if(is.null(nodes$size)) nodes$size<-3

  #shape
  nodes$shape <- ggnw_info$data[[2]]$shape
  if(length(unique(nodes$shape))>1) {
      nodes$shape<-NULL # to get label out of node
  }else{
     opts<-c("circle","square", "triangle",
             "box", "dot", "star", "ellipse", "database", "text", "diamond")
      nodes$shape<-opts[factor(nodes$shape)]
  }



  #label
  tmp<-obj$node_mapping$node_label
  if(!is.null(tmp)){
    nodes$label<-nodes[[tmp]]
  } else {
    nodes$label<- nodes[["id"]]
  }

  # browser()
  nodes$font.color<-font.color
  nodes$font.size<-font.size
  #need ID to be first column
  nodes<-data.frame(id=nodes$id,nodes)
  # nodes$title<-nodes$text
  nodes$value<-nodes$size
  if(length(unique(nodes$shape))==1) nodes$shape<-NULL # to get label out of node
  # nodes$font.size<-nodes$size*2
  # nodes$font.color<-'gray'


  # nodes$text<-

  # #cleanup
  vars<-c('id','value','shape','label','font.color','font.size',
          'title','color.background','color.border',
          'borderWidth','color.highlight.background')
  vars<-vars[vars%in% colnames(nodes)]
  nodes<-nodes %>% dplyr::select(one_of(vars))
  #
  #edges$value = edges$size
  if(is.null(edges$type)){edges$type<-'NA'}
  edges$color.color <- factor(edges$type, labels = unique(ggnw_info$data[[1]]$colour)) #get colors from ggplot network
  edges$color.highlight<-'red'
  edges$title<-round(edges$value,2)


  if(is.null(obj$vis_config)){
    network <- visNetwork(nodes, edges, width = "100%", vis.height=vis.height) %>%
      visPhysics(enabled = FALSE, stabilization = FALSE) #%>%

  }else{
    vis_conf <- obj$vis_config
    network <- visNetwork(nodes, edges, width = "100%", vis.height=vis.height) %>%
      visOptions(selectedBy = vis_conf$select_by, manipulation = vis_conf$vis_manip) %>%
      visConfigure(enabled = vis_conf$vis_config) %>%
      visInteraction(navigationButtons = vis_conf$vis_nav) %>%
      visPhysics(enabled = vis_conf$vis_physic) %>%
      visExport(type = "png", name = "export_network",float = "left", label = "Save image", style= "")
  }

 network<-network %>%
    visLayout(randomSeed = 12) %>%
    visEdges(shadow = TRUE, color = list( highlight = 'red')) %>%
    visOptions(nodesIdSelection = TRUE,
               highlightNearest = list(enabled = T, degree = 1, hover = T)) %>%
    visEdges(smooth = FALSE, shadow = TRUE) %>%
    visIgraphLayout()  %>%
    visInteraction(navigationButtons = TRUE)

  return(network)
}

# #DiagrammeR
# network.diagrammer <- function(obj){
#   nodes = obj$nodes
#   edges = obj$edges
#   colnames(nodes)[1] = "nodes" #diagrammeR use "nodes" instead of "id"
#   #mapping nodes
#   nc = obj$node_mapping$node_col
#   node.color = colorRampPalette(brewer.pal(length(nodes[[nc]]), "RdYlBu"))(length(nodes[[nc]]))[rank(nodes[[nc]])]
#   nodes$color = node.color
#   shape = c("square", "triangle", "box", "circle", "dot", "star",
#             "ellipse", "database", "text", "diamond")
#   ns = obj$node_mapping$node_shape
#   node.shape = factor(nodes[[ns]], labels= shape[1:length(unique(nodes[[ns]]))])
#   nodes$shape = node.shape
# 
#   graph <- create_graph(nodes_df = nodes, edges_df = edges)
#   return(graph)
# }

#' @title hover_text
#' @export
hover_text<-function(obj,use=c('node_size','node_col','node_label')){

  .names<-obj$node_mapping[names(obj$node_mapping) %in% use]
  if(length(.names)==0) return(NULL)
  #ignores duplicate mapping
  .tmp<-obj$nodes %>% dplyr::select(one_of(as.character(unlist(.names))))
  .tmp<-lapply(1:ncol(.tmp),function(i){
    .obj<-.tmp[,i,drop=FALSE]
    check<-all(!is.na(as.numeric(.obj[,])))
    if(check){
      .obj[,1]<-round(as.numeric(.obj[,]),2)
    }
    paste(colnames(.obj),.obj[,],sep=': ')
  }) %>%
    do.call('cbind',.) %>%
    apply(.,1,paste,collapse="<br>")

  factor(.tmp,levels=unique(.tmp),ordered=TRUE)

}


test<-function(){
  
  library(dave.network)
  
  #data objects
  .data<-mtcars
  
  data_obj <-
    list(
      data = .data,
      
      col_meta = data.frame(
       # ID = 1:ncol(.data) %>% as.character(),
        id = 1:ncol(.data) %>% as.character() ,
        names = colnames(.data) %>% as.character(),
        stringsAsFactors = FALSE
      ),
      row_meta = data.frame(AM = as.factor(.data$am))
    )
  
  data_obj$names <- list(
    row = function(data_obj) {
      rownames(data_obj$data)
    },
    col = function(data_obj) {
      data_obj$col_meta$names %>% unlist()
    }
  )
  
  #..
  data_obj$col_meta$bar_color<- rep(c("A",'B'),nrow(data_obj$col_meta))[1:nrow(data_obj$col_meta)]
  data_obj$col_meta$size<- rep(1:3,nrow(data_obj$col_meta))[1:nrow(data_obj$col_meta)]
  
  #network objects
  #should scope a network object
  
  f<-function(x){
    matrix(c('c','d'),nrow=length(x),ncol = 1)
  }
  
  network_obj<-list(nodes=data_obj$col_meta,
                    edges=expand.grid(1:5 %>% as.character(),3:6%>% as.character()) %>% data.frame() %>% setNames(.,c('to','from')) %>%
                      data.frame() %>% mutate(value=1))
  network_obj$edges$type<-f(network_obj$edges$value) 
  
  
  
  #add mapping
  network_obj$node_mapping<-list(
    node_index='id',
                    node_col='bar_color',
                    node_size='size',
                     node_size_range=c(5,10)
  )
  
  x<-do.call('network.visualize', network_obj)
  
  # undebug(network.ggplot)
  # undebug(format.network)
  
  plot(x)
  plot(x,repel=TRUE)
  network.visnetwork(x)
  
  #load debug data
  nodes<-read.csv('../../../../../Desktop/net4_nodes.csv',header = TRUE)
  edges<-read.csv('../../../../../Desktop/net4_edges.csv',header = TRUE)
  
  node_mapping<-list(
    node_index='id',
    node_col='kruskal_selected',
    node_size='FC_non.diabetic.._diabetic..',
    node_size_range=c(5,10)
  )
  
  network_obj<-list(nodes=nodes,edge=edges,
                    node_mapping=node_mapping)
  
  x<-do.call('network.visualize', network_obj)
  plot(x)
  # plot(x,repel=TRUE)
  # network.visnetwork(x)
  
  #-----------------------
  library(dave.network)
  data("dave_network")

  data<-dave_network

  #chemical similarity
  idcolumn<-'CID'
  type<-"CID"
  net_index <- "ID"
  DB<-'CID.SDF.DB'

  cid_el<-metabolic_network(data, idcolumn, type=type, net_index = net_index,
                            node_mapping=NULL, vis_config=NULL, DB)

  #static
  plot(obj=cid_el,edge_cutoff=.7,curvature=FALSE)
  
  do.call('plot',list(obj=cid_el,edge_cutoff=.7,curvature=FALSE))  

  p<- plot(obj=cid_el,edge_cutoff=.7,curvature=FALSE)
  
  
  ggplotly(p)

  #add parameters
  obj<-cid_el

  #plot options
  obj$nodes$color<-rep(letters[1:3],length.out=nrow(obj$nodes))#obj$nodes$WI38_MD231_p.value<0.05
  # node_mapping<-NULL
  node_mapping<-list(node_size='color',
                     node_col = 'color',
                     node_label = 'ID',
                     # node_index = 'ID',
                     node_size_range=c(5,10)
  )
  obj$node_mapping<-node_mapping

  plot(obj,edge_cutoff=.9)

  #interactive
  obj$nodes$text<-dave.network:::hover_text(obj)
  dave.network:::network.visnetwork(obj,edge_cutoff=.7)

  obj$node_mapping$node_index<-NULL
  plot(obj,edge_cutoff=.7)



  #KEGG biochemical relationships
  idcolumn<-"KeggID"
  type<-"KEGG"

  kegg_el<-metabolic_network(data, idcolumn, type=type, net_index = net_index, node_mapping=NULL, vis_config=NULL)
  plot(kegg_el,edge_cutoff=.7)

  #combine the two networks
  net_obj<-list(cid_el,kegg_el)
  #combine two networks
  #combine edges
  full_obj<-join_networks(net_obj)
  plot(full_obj,edge_cutoff=.7)

    #testing node and edge mapping
    data$color<-data$WI38_MD231_p.value<0.05
    node_mapping<-NULL
    node_mapping<-list(node_size='WI38_MD231_FC',
                       node_col = 'color',
                       node_label = 'KeggID',
                       node_size_range=c(5,10)
                       )
    cid_el<-metabolic_network(data, idcolumn, type=type,
                              net_index = net_index, node_mapping=node_mapping,
                              vis_config=NULL, DB='CID.SDF.DB')
    tmp<-list(nodes=cid_el$nodes, edges=cid_el$edges, node_mapping=node_mapping, vis_config=NULL)
    obj<-do.call('network.visualize',tmp)
  plot(obj,edge_cutoff=.7)

  network.visnetwork(obj,edge_cutoff=.7)


# ggplot tests for dynamic aes switching ----------------------------------

  
  points<-data.frame(x=1:3,y=3:1,color=c('red','white','blue'),size=1:3,shape=letters[1:3])
  

  plot_fun_old<-function(data,x, y,color=NULL, fill=NULL,size=NULL,shape=NULL){
    
    #having problems in main fun to combine NULL aes
    # eval(parse(text = code))?.... yes...?
    
    # ggplot(data = data,
    #        aes_string(
    #          x = x,
    #          y = y,
    #          fill = fill,
    #          color = color,
    #          size = size,
    #          shape = shape
    #        )
    # ) +
    #   geom_point()
    # 
    # #check in data
    # .check<-function(data=NULL,name=NULL){
    #   
    #   logic<-name %in% colnames(data)
    #   
    #   if(length(logic) > 0 && logic) name else NULL
    # }
    # 
    # #aes_string
    # .color<-.check(data,color)
    # .size<-.check(data,size)
    # .shape<-.check(data,shape)
    # .x<-.check(data,x)
    # .y<-.check(data,y)
    # 
    # 
    # shape_default <- function(x=NULL) {
    #   if (is.null(x)) 
    #     21
    #   else NULL
    # }
    # size_default <- function(x=NULL) {
    #   if (is.null(x)) 
    #     2
    #   else max(x)
    # }
    # 
    # browser()
    # 
    # ggplot(data = data,aes_string( 
    #   x=.x,
    #   y=.y,
    #   {if (!is.null(.color)) {
    #     fill = .color
    #   } else {fill=NULL}},
    #   {if (!is.null(.size)) {
    #     size = .size
    #   } else {size=NULL}},
    #   {if (!is.null(.shape)) {
    #     shape = .shape
    #   } else { shape=NULL}}
    # ), {if (is.null(.shape)) {
    #   shape = shape_default(.shape)
    # }}, 
    # {if (is.null(.size)) {
    #   size = size_default(.size)
    # }}) + 
    #   geom_point()
    
    # ggplot(data = data) + 
    #   geom_point(aes_string( 
    #     x=x,
    #     y=y,
    #     size=size,
    #     fill=fill,
    #     color=color,
    #     shape=shape),shape=21,color='black',fill='gray') +
    #   theme_minimal()
    
    
    #create args
    .ac<-function(x,obj){if(!is.null(obj)) paste(c(x,obj),collapse =" = ")}
    .dc<-function(x,obj){if(is.null(obj)) paste(c(x,obj),collapse =" = ")}
    
    points_aes <-
      list(
        .ac('x', x),
        .ac('y', y),
        .ac('size', size),
        .ac('fill', fill),
        .ac('color', color),
        .ac('shape', shape)
      ) %>%
      unlist() %>%
      paste(.,collapse = ", ")
    
    points_default<-
      list(
        .dc('size', 21),
        .dc('fill', 'gray'),
        .dc('color', 'black'),
        .dc('shape', 21)
      ) %>%
      unlist() %>%
      paste(.,collapse = ", ")

    
    plot_points<-paste0('geom_point(aes_string(',points_aes,")",points_default,')')
    
    ggplot(data = data) +
    eval(parse(text = plot_points))
    
  }
  
  plot_fun<-function(data,x, y,color=NULL, fill=NULL,size=NULL,shape=NULL,id=NULL){
    
    #create args
    .ac<-function(x,obj){if(!is.null(obj)) paste(c(x,obj),collapse =" = ")}
    .dc <-
      function(x, obj, default = NULL) {
        if (is.null(obj))
          paste(c(x, default), collapse = " = ")
      }
    #for quotes
    .char<-function(x,with="'"){
      paste(with,x,with,sep='')
    }
    
    points_aes <-
      list(
        .ac('x', x),
        .ac('y', y),
        .ac('size', size),
        .ac('group',id),
        .ac('fill', fill),
        .ac('color', color),
        .ac('shape', shape)
      ) %>%
      unlist() %>%
      paste(.,collapse = ", ")
    
    points_default<-
      list(
        .dc('size',size, 2),
        .dc('fill',fill, .char('gray')),
        .dc('color',color, .char('black')),
        .dc('shape',shape, 21)
      ) %>%
      unlist() %>%
      paste(.,collapse = ", ")
    
   add_args<-function(x,add=',',first=TRUE){
     
     if(x!=''){if(first) c(add,x) else {c(x,add)}} %>% paste(.,collapse = '') else ''
     
   }
    
    plot_points<-paste0('geom_point(aes_string(',points_aes,')',add_args(points_default),')')
    
   
    ggplot(data = data) +
      eval(parse(text = plot_points))
    
  }
  
  make_nodes<-function(x=NULL,y=NULL,color=NULL, fill=NULL,size=NULL,size_range=NULL,shape=NULL,id=NULL){
    
 
    #create args
    #use built in?
    .char<-function(x,with="'"){
      if(!is.null(x)) paste(with,x,with,sep='')
    }
    .ac<-function(x,obj){if(!is.null(obj)) paste(c(x,obj),collapse =" = ")}
    .dc <-
      function(x, obj, default = NULL) {
        if (is.null(obj))
          paste(c(x, default), collapse = " = ")
      }
   
    points_aes <-
      list(
        .ac('x', x),
        .ac('y', y),
        .ac('size', .char(size)),
        .ac('fill', .char(fill)),
        .ac('color', .char(color)),
        .ac('shape', .char(shape)),
        .ac('group',.char(id))
        
      ) %>%
      unlist() %>%
      paste(.,collapse = ", ")
    
    #defaults
    default_size<-if(is.null(size_range)) 3 else max(size_range)
    
    points_default<-
      list(
        .dc('size',size, default_size),
        .dc('fill',fill, .char('gray')),
        .dc('color',color, .char('black')),
        .dc('shape',shape, 21)
      ) %>%
      unlist() %>%
      paste(.,collapse = ", ")
    
    add_args<-function(x,add=',',first=TRUE){
      
      if(x!=''){if(first) c(add,x) else {c(x,add)}} %>% paste(.,collapse = '') else ''
      
    }
    
    plot_points<-paste0('geom_nodes(aes_string(',points_aes,')',add_args(points_default),')')
    
    print(plot_points)

    eval(parse(text = plot_points))
    
  }
  
  
  
  # Write dynamic aes_string with NULL 
  #predefined defaults block aes 
  #defaults need to be pre defined
  
  plot_fun(data=points,x='x',y='y')
  
  plot_fun(
    data = points,
    x = 'x',
    y = 'y',
    fill = 'fill',
    color = NULL,
    size = 'size',
    shape = 'shape'
  )
  
  #TODO block legends
  
  plot_fun(data=points,x='x',y='y',fill='fill',color='shape',size='size',shape='shape')
  plot_fun(data=points,x='x',y='y',fill='fill',shape='shape')
  
  #ggplot test with fill and color
  library(ggplot2)
  line<-data.frame(a=1:2,b=2:3,color=c('red','white'),size=1:2)
  points<-data.frame(x=1:3,y=3:1,color=c('red','white','blue'),size=1:3)


  ggplot() +
    geom_segment(data=line,aes(x=a,xend=b,y=b,yend=a,size=size,linetype=color)) +
    geom_point(data=points,aes(x=x,y=y,fill = as.character(size),size=size,color=color),shape=21) +
    scale_fill_manual("points", values =points$size ,
                      guide = guide_legend(override.aes =
                                             list(colour = "gray",
                                                  size = sort(unique(points$size)) ))) +
    theme_classic() +
    scale_size(range=c(1,5)) +
    guides(colour = guide_legend(override.aes = list(size=10)))

  ggplotly(p)

  #----------
  #Create discrete levels for point sizes (because points will be mapped to fill)
  d1$z.bin <- findInterval(d1$z, c(0,2,4,6,8,10), all.inside= TRUE)  #Create bins

  #Scale the points to the same size as the lines (points * 100).
  #Map points to a dummy aesthetic (fill)
  #Hack the fill properties.
  set.seed(123)
  d1=data.frame(x=runif(10),y=runif(10),z=runif(10,1,10),color=as.character(1:0))
  d2=data.frame(x=runif(10),y=runif(10),z=runif(10,100,1000),color=c(1:4,1:4,1:2))
  #Create discrete levels for point sizes (because points will be mapped to fill)
  d1$z.bin <- findInterval(d1$z, c(0,2,4,6,8,10), all.inside= TRUE)  #Create bins

  ggplot()+  geom_line(aes(x,y,size=z),data=d2) +
    geom_point(aes(x,y, size=z * 100, fill = as.character(z.bin),color=color),data=d1) +
    scale_size("line", range = c(0,1)) +
    scale_fill_manual("points", values = rep(1, 10) ,
                      guide = guide_legend(override.aes =
                                             list(colour = "black",
                                                  size = sort(unique(d1$z.bin)) )))

}




# deprecated --------------------------------------------------------------

#' #separate node and edge plotting for ggnetworks?
#' 
#' #ggplot
#' #TODO: control edge and node, size and color seperately
#' # native ggplot2 does not support this
#' #' @export
#' #' @import ggplot2 ggnetwork
#' network.ggplot <- function(obj, edge_cutoff=0, curvature = 0, repel=FALSE,...){
#'   n = format.network(obj, edge_cutoff)
#' # 
#' #   #plotting override for theme
#' #   extra_theme<-theme(panel.grid.minor = element_blank(),
#' #                      panel.grid.major = element_blank())
#'   
#'   #label needs to contain ID for use with other networks
#'   #needs to pass through ggplot and then be used by
#'   #other methods
#'   #text used for hover becomes unnecessary here
#'   #need to create seperate mappign method?
#' 
#'   #node attributes
#'   .size<-obj$node_mapping[['node_size']]#$node_size ...fuzzy matches range
#'   .color<-obj$node_mapping$node_col
#'   .label<-obj$node_mapping$node_label
#'   .id<-obj$node_mapping$node_index
#'   if(!is.null(.id)) {
#'     #label + id
#'     if(is.null(.label)){
#'       n[['tmp_label']]<-paste0(n[[.id]], '||')
#'       .label<-'tmp_label'
#'     } else {
#'       n[[obj$node_mapping$node_label]]<-paste0(n[[.id]], '||',n[[.label]])
#'     }
#' 
#'   }
#' 
#'   .size_range<-obj$node_mapping[['node_size_range']]
#'   .text<-'text'
#'   if(is.null(n[[.text]])) {.text<-'ID'} # NULL w/ aes_string breaks grop_by_df ..
#'   #TODO add shape mapping
#'   # node_size_scale<-NULL
#'   if(!is.null(.size) & !is.null(.color) ){
#' 
#'     #need to account for size type
#'     # if(!is.numeric(n[[.size]])){
#'     #   # n[[.size]][is.na( n[[.size]])]<-0
#'     #   if()
#'       # n[[.size]]<-as.numeric(n[[.size]])
#'     # }
#'     # n[['fill_size']]<-as.character(n[[.size]])
#'       nodes<- geom_nodes(aes_string(size=.size, fill=.color,group=.text),shape=21)
#'       # nodes<-geom_point(aes_string(size=.size, color=.color,fill='fill_size'))
#'       # node_size_scale<- scale_fill_manual("points", values =rep(1,nrow(n)) ,
#'       #                     guide = guide_legend(override.aes =
#'       #                                            list(colour = "gray",
#'       #                                                 size = as.numeric(sort(unique(n[['fill_size']]))))))
#' 
#'   }
#'   if(!is.null(.size) & is.null(.color) ){
#'     # if(!is.numeric(n[[.size]])){
#'     #   n[[.size]]<-as.numeric(n[[.size]])
#'     # }
#'     #group can't be null for update..
#'     #how to better manage cases?
#'     #can whole expression be added ?
#'     
#'       # if(is.null(.text)){
#'       #   nodes<- geom_nodes(aes_string(size=.size))
#'       # } else {
#'         nodes<- geom_nodes(aes_string(size=.size,group=.text))
#'       # }
#'       
#'       # nodes<- geom_point(aes_string(size=.size))
#'   }
#'   if(is.null(.size) & !is.null(.color) ){
#'     nodes<- geom_nodes(aes_string( fill=.color,group=.text),shape=21)
#'     # nodes<- geom_point(aes_string( fill=.color),shape=21)
#'   }
#' 
#'   if(is.null(.size) & is.null(.color) ){
#'     nodes<-geom_nodes(aes_string(group=.text),size=min(.size_range))
#'   }
#' 
#'   #color and fill scaling
#'   .scale_fill<-NULL
#'   #todo make border and fills seperate
#'   if(!is.null(.color)){
#'     check<-n[[.color]]
#'     if(is.character(check) | is.factor(check)){
#'       .scale_fill<-scale_fill_brewer(palette = 'Set1')
#'     }
#'   }
#' 
#'   #edge colors...prevent node boarders
#' 
#'   .scale_color<-  scale_color_brewer(palette = 'Dark2')
#' 
#'   #repel needs its own data source else multiples?
#'   
#'   #labels
#'   if(repel){
#'     repel_data<-n[!duplicated(n$id),,drop=FALSE]
#'   }
#'   
#'   if(!is.null(.label)){
#'     if(repel){
#'       node_text<-geom_text_repel(data=repel_data, aes_string(label=.label), size=3, show.legend = FALSE,
#'                                  fontface = "bold", box.padding = unit(1, "lines"), label.padding=unit(.05, "lines"))
#'     } else {
#'       if(repel){
#'         node_text<-geom_text_repel(data=repel_data, aes_string(label=.label), size=3, show.legend = FALSE,
#'                                    fontface = "bold", box.padding = unit(1, "lines"), label.padding=unit(.05, "lines"))
#'       } else {
#'         node_text<-geom_nodetext(aes_string(label=.label), size=3, show.legend = FALSE,
#'                                  fontface = "bold")
#'       }
#' 
#'     }
#'   } else {
#'     if(repel){
#'       node_text<-geom_text_repel(data=repel_data,aes(label=id), size=3, show.legend = FALSE,
#'                                  fontface = "bold", box.padding = unit(1, "lines"), label.padding=unit(.05, "lines"))
#'     } else {
#'       node_text<-geom_nodetext(aes(label=id), size=3, show.legend = FALSE,
#'                                fontface = "bold")
#'     }
#' 
#'   }
#' 
#'   #LEGENDS
#'   # if(!is.null(.size)){
#'   #   size_legend<-guides(size=guide_legend(title=.size))
#'   # 
#'   #   if(!is.null(.size_range)){
#'   #     if(any(class(n[[.size]]) %in% c('factor','character'))){
#'   #       size_range<-scale_size_discrete(range=c(.size_range[1],.size_range[2]))
#'   #     } else{
#'   #       size_range<-scale_size(range=c(.size_range[1],.size_range[2]))
#'   #     }
#'   #   } else {
#'   #     if(any(class(n[[.size]]) %in% c('factor','character'))){
#'   #       size_range<-scale_size_discrete(range=c(1,5))
#'   #     } else {
#'   #       size_range<-scale_size(range=c(1,5))
#'   #     }
#'   #   }
#'   # } else {
#'   if(!is.null(.size)){  
#'     size_legend<-guides(size=guide_legend(title=.size))
#'     
#'     if(!is.null(.size_range)){
#'       if(any(class(n[[.size]]) %in% c('factor','character','logical'))){
#'         size_range<-scale_size_discrete(range=c(.size_range[1],.size_range[2]))
#'       } else{
#'         size_range<-scale_size(range=c(.size_range[1],.size_range[2]))
#'       }
#'     } else {
#'       if(any(class(n[[.size]]) %in% c('factor','character'))){
#'         size_range<-scale_size_discrete(range=c(1,5))
#'       } else {
#'         size_range<-scale_size(range=c(1,5))
#'       }
#'     }
#'   } else {
#'     
#'     size_range<-size_legend<-NULL
#'     
#'   }
#'   
#'   
#'   if(!is.null(.color)){
#'     color_legend<-guides(fill=guide_legend(title=.color))
#'   } else {
#'     color_legend<-NULL
#'   }
#' 
#'   # if(!is.null(.size)){  
#'   #   if(!is.null(.size_range)){
#'   #     if(any(class(n[[.size]]) %in% c('factor','character','logical'))){
#'   #       size_range<-scale_size_discrete(range=c(.size_range[1],.size_range[2]))
#'   #     } else{
#'   #       size_range<-scale_size(range=c(.size_range[1],.size_range[2]))
#'   #     }
#'   #   } else {
#'   #     if(any(class(n[[.size]]) %in% c('factor','character'))){
#'   #       size_range<-scale_size_discrete(range=c(1,5))
#'   #     } else {
#'   #       size_range<-scale_size(range=c(1,5))
#'   #     }
#'   #   }
#'   # }
#' 
#'   #fix for 
#'   #Error: Columns `x`, `y`, `xend`, `yend` must be 1d atomic vectors or lists
#'   n$x <- n$x[,1]
#'   n$y <- n$y[,1]
#'   n$xend <- n$xend[,1]
#'   n$yend <- n$yend[,1]
#'   
#'   network_plot<-ggplot(n, aes(x = x, y = y, xend = xend, yend = yend)) +
#'     # geom_edges(aes(linetype=rel_type, size=rel_score), curvature = curvature,color='gray') +
#'     geom_edges(aes(color=rel_type),size=1, curvature = curvature,arrow.fill=NULL) + # no arrows
#'     nodes +
#'     # node_size_scale +
#'     .scale_fill +
#'     .scale_color +
#'     node_text +
#'     theme_blank() +
#'     #extra_theme + # remove plotly gridlines?
#'     size_range +
#'     theme(legend.position ='bottom') +
#'     guides(color=guide_legend(title='relationship')) +
#'     size_legend +
#'     color_legend
#' 
#'   return(network_plot)
#' }
