#' dave.network
#'
#' @name dave.network
#' @docType package
NULL


#' bio and structural network data
#' @details data based PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_network
#' @usage data(dave_network)
'dave_network'

#' bio and structural network col meta data
#' @details data based PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_network_col_meta
#' @usage data(dave_network_col_meta)
'dave_network_col_meta'

