#issues with namespace for dplyr
# https://github.com/rubenarslan/formr/blob/master/R/amigoingmad.R
#use to view conflicts...

#' @export
select<-dplyr::select


#' @title join_nodes
#' @export
#' @import reshape2
#' @details join two dataframes on rows and columns using network row index
join_nodes<-function(node1,node2,net_index='id'){


  #check
  if(is.null(node1) || nrow(node1) ==0) return(node2)
  if(is.null(node2) || nrow(node2) ==0) return(node1)

  #need to preserve types of node1 or if absent node2
  .classes<-sapply(node1,'class')
  #id and ID need character
  #one from data merge (ID) other used in network plotting...
  #need to merge into 1
    
  m1<-melt(node1,id.vars=net_index)
  m2<-melt(node2,id.vars=net_index)
  m<-rbind(m1,m2)

  #make unique id
  id<-paste0(m$id,"_",m$variable)
  m<-m[!duplicated(id),,drop=FALSE]

  out<-dcast(m,id ~ ...)
  #add back types
  #not clear how to avoid for
  #order changes ...
  .classes<-.classes[colnames(out)]
  for(i in 1:ncol(out)){  
    .type<-paste0('as.',.classes[i])
    out[,i]<-do.call(.type,list(out[,i]))
  }

  return(out)
}


#' @title update_nodes
#' @export
#' @details update node index based on meta data and index. If child then meta overwrites, else meta only adds columns.
update_nodes<-function(nodes,meta,net_index='id',child=TRUE){
  
  #TODO need to merge user <ID> and network id?
  #force index types to match...
  #want str? 
  # browser() #fixed?
  nodes[net_index]<-as.character(nodes[[net_index]])
  meta[net_index]<-as.character(meta[[net_index]])
  
  #child controls if y or x is chosen
 
  .nodes<-left_join(nodes,meta,by=net_index)
  
  if(child){
    id<-grepl('.x',colnames(.nodes))
    .nodes<-.nodes[,!id]
    .names<-gsub('.y','',colnames(.nodes))
    
  } else {
    id<-grepl('.y',colnames(.nodes))
    .nodes<-.nodes[,!id]
    .names<-gsub('.x','',colnames(.nodes))
    
  }
  
  .nodes %>% setNames(.,.names)
  
}



#combine two networks
#' @details generic  biochem or structural networks
#' @title join_networks
#' @export
#' @import dplyr
join_networks<-function(net_obj){
  nodes<-edges<-NULL
  
  #get numeric, others will we coerced to character for the join
  #all should be the same, use the first
  #TODO remove 'value' duplication
  
  #edges
  is_numeric_edges<-lapply(net_obj[[1]]$edges, is.numeric) %>% unlist()
  is_numeric_nodes<-lapply(net_obj[[1]]$nodes, is.numeric) %>% unlist() 

  
  for(i in 1:length(net_obj)){ 
    #need same types for common names
    new<-net_obj[[i]]$edges %>%
      mutate_all(as.character)
      
    edges<-bind_rows(edges,new)
    # nodes<-bind_cols(nodes,net_obj[[i]]$nodes) # does not use a row index
    nodes<-join_nodes(nodes,net_obj[[i]]$nodes)
  }

  #revert original edge types which were converted to ensure a proper join
  for(i in 1:length(is_numeric_edges)){
    if(is_numeric_edges[i]){
      .name<-names(is_numeric_edges[i])
      edges[,.name]<-as.numeric(edges[,.name])
    }
  }
  
  
  #fix node types
  for(i in 1:length(is_numeric_nodes)){
    if(is_numeric_nodes[i]){
      .name<-names(is_numeric_nodes[i])
      nodes[,.name]<-as.numeric(nodes[,.name])
    }
  }
  
  #ignore graphical parameters merge
  network.visualize(edges=edges,nodes=nodes)

}


#extract values from a square symmetric matrix based on an edge list
#' @export
#' @import reshape2
sym.mat.to.edge.list<-function(mat,edge.list){
  # extract position of objects from a
  # square symmetric matrix based on its dimnames -- if rownames are absent assume ordered already
  # according to an edge list

  #initialize objects
  idn<-rownames(mat) # -- this does nothing?
  if(is.null(idn)) idn <-1:nrow(mat)
  
  ids<-seq(along=idn)#

  #common network edges names
  edge.names<-edge.list
  edge.ids<-do.call("rbind",lapply(1:nrow(edge.names),function(i)
  {
    data.frame(columns=ids[idn%in%edge.names[i,1]],
               rows=ids[idn%in%edge.names[i,2]])
  }))

  #Extract value from mat based on index
  edge.val<-do.call("rbind",lapply(1:nrow(edge.ids),function(i)
  {
    tmp<-data.frame(value=mat[edge.ids[i,1],edge.ids[i,2]])
    rownames(tmp)<-paste(edge.names[i,1],edge.names[i,2],sep="~")
    tmp
  }))
  return(edge.val)
}


#' @title format_net_obj
#' @export
format_net_obj<-function(nodes, edges,idcolumn='id', net_index=NULL, node_mapping=NULL, vis_config=NULL){
  
  
  if (is.null(net_index)) {
    el <- edges
  } else {
    el <-
      edges %>% convert_edge_index(.,
                                   start = idcolumn,
                                   end = net_index,
                                   db = nodes) #%>%
    #data.frame(.,edges[,-(1:2)]) #..assumptions, might keep
    #strange lost the rest
    
  }
  colnames(el)[1:2] <- c('from', 'to') #...
  #need id internally but this 
  #can conflict with the name in data
  nodes$id <- nodes[[net_index]]
  
  
  #need ato add attributes
  #todo make fun for all attr
  attr(el, 'lambda') <- attr(edges, 'lambda')
  
  #prepare for plotting
  network.visualize(
    nodes = nodes,
    edges = el,
    node_mapping = node_mapping,
    vis_config = vis_config
  )
  
}


#use igraph to simplify network (remove duplicates and loops)
#' @title  remove_edge_dupes
#' @export
#' @importFrom igraph graph_from_edgelist simplify get.edgelist
#' @details remove duplicates and loops
remove_edge_dupes<-function(el){
  #extract edge list
  #need to remove any empty edges
  .el<-el[,1:2] %>% na.omit() %>%  as.matrix()
  g<-igraph::graph_from_edgelist(.el,directed=FALSE)

  id1<-igraph::which_loop(g)
  id2<-igraph::which_multiple(g)
  id<-!id1 & !id2
  el[id,,drop=FALSE ]
}


#' #also in metabomapr --- different
#' #------------------
#' @title convert_edge_index
#' @param edge_list matrix or data frame columns > 2 ignored
#' @param start column name of index matching edge list
#' @param end column name of index matching db
#' @param db data.frame containing mapping between start and end
#' @return edge list converted from start to end
#' @import dplyr
#' @export
convert_edge_index<-function(edge_list,start,end,db){


  if(start == end) return(edge_list)
  
  #convert source/target to character for join # TODO fix naming ,source='source',target='target'
  edge_list$source<-as.character(edge_list[,1])#as.character(edge_list$source)
  edge_list$target<-as.character(edge_list[,2])#as.character(edge_list$target)

  #remove items not in db
  ns<-edge_list$source %in% db[[start]]
  nt<-edge_list$target %in% db[[start]]

  #the data base needs to be unique with regards to start
  #this should be forced outside!!
  db[[start]]<-make.unique(db[[start]] %>% as.character())

  #deal with case when no translation should be done
  s<-left_join(edge_list[ns,'source',drop=FALSE],db,by=c('source' = start),keep=TRUE) %>%
    select(end) %>%
    setNames('source')
  
  t<-left_join(edge_list[nt,'target',drop=FALSE],db,by=c('target' = start)) %>%
    select(end) %>%
    setNames('target')
  

  data.frame(s,t,edge_list[,-(1:2),drop=FALSE])
}


#' @title CID_tanimoto
#' @param mat adjacency matrix
#' @param symmetric TRUE if undirected keep lower.tri
#' @param diagonal TRUE to keep self-connections
#' @param mat adjacency matrix
#' @import reshape2
#' @details convert adjacency matrix into an edge list
#' @export
adjacency_edgeList<-function(mat,symmetric=TRUE,diagonal=FALSE){
  # bit of a hack around handling NA
  mat<-as.matrix(mat)
  id<-is.na(mat) # used to allow missing
  mat[id]<-"nna"
  if(symmetric){mat[lower.tri(mat)]<-"na"} # use to allow missing values
  if(!diagonal){diag(mat)<-"na"}
  obj<-melt(mat)
  colnames(obj)<-c("source","target","value")
  obj<-obj[!obj$value=="na",]
  obj$value[obj$value=="nna"]<-NA
  return(obj)
}

#' @title check_network
#' @export
check_network<-function(nodes,edges, coerce='as.character'){
  
  #make sure types between node$id and edges$from/to can be joined
  #value is numeric
  
  nodes$id<-do.call(coerce,list(nodes$id))
  edges$from<-do.call(coerce,list(edges$from))
  edges$to<-do.call(coerce,list(edges$to))
  edges$value<-as.numeric(edges$value)
  
  #will need to other edge list specific validations later
  
  list(nodes=nodes,edges=edges) 
}


test<-function(){
  #el<-data.frame(source=c('A','B','D','C','A'), target=c('B','A','A','A','c'), type=c('way_1','1_way','3_way','2_way','way_2'),stringsAsFactors=FALSE)

  library(dave.network)
  
  #update nodes
  n<-20
  nodes<-data.frame(id=1:n,foo=1:n)
  meta<-data.frame(id=1:n,foo='sucka',bar=c('A','B'))
  
  update_nodes(nodes,meta)
  update_nodes(nodes,meta,child=FALSE)
  

  # join_networks -----------------------------------------------------------
  nodes1<-data.frame(id=c(1:3),name=letters[1:3])
  nodes2<-data.frame(id=c(4:6),name=letters[4:6])
  edges1<-data.frame(source=c(1,1,2),target=c(2,3,1),type='edge1',value=1,foo=1)
  edges2<-data.frame(source=c(4,4,5),target=c(5,6,6),type='edge2',value=2)
  net_obj<-list(list(edges=edges1,nodes=nodes1),list(edges=edges2,nodes=nodes2))
  
  join_networks(net_obj)
  
  #convert edge index
  edge_list<-data.frame(source=c('A','B','D','C','A'), target=c('B','A','A','A','C'), type=c('way_1','1_way','3_way','2_way','way_2'),stringsAsFactors=FALSE)
  db<-data.frame(id=1:4,name=c('A','B','C','D'))
  db<-data.frame(id=paste('var',4:1),name=c('A','B','C','D'))
  
  library(dave.preproc)
  #test format index
  format_net_index(db,id='id',fix_NA = TRUE)
  
  convert_edge_index(edge_list,start='name',end='id',db)
  convert_edge_index(edge_list,start='name',end='name',db)
  
  #debug data
  el<-function(){
    structure(list(source = c(2L, 1L, 2L, 4L, 2L, 4L, 5L, 4L, 5L, 
                              6L, 1L, 2L, 4L, 5L, 7L, 1L, 4L, 5L, 7L, 8L, 2L, 4L, 5L, 6L, 7L, 
                              8L, 9L, 1L, 3L, 5L, 7L, 9L, 1L, 2L, 4L, 5L, 6L, 7L, 8L, 9L, 10L, 
                              11L, 1L, 5L, 7L, 8L, 9L, 10L, 14L, 14L, 1L, 3L, 5L, 7L, 8L, 9L, 
                              10L, 14L, 15L, 1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L, 9L, 10L, 11L, 
                              14L, 15L, 17L, 1L, 5L, 11L, 14L, 15L, 17L, 18L, 1L, 2L, 4L, 5L, 
                              6L, 7L, 8L, 9L, 10L, 11L, 14L, 15L, 17L, 18L, 1L, 2L, 4L, 5L, 
                              6L, 7L), target = c(4L, 5L, 5L, 5L, 6L, 6L, 6L, 7L, 7L, 7L, 8L, 
                                                  8L, 8L, 8L, 8L, 9L, 9L, 9L, 9L, 9L, 10L, 10L, 10L, 10L, 10L, 
                                                  10L, 10L, 11L, 11L, 11L, 11L, 11L, 14L, 14L, 14L, 14L, 14L, 14L, 
                                                  14L, 14L, 14L, 14L, 15L, 15L, 15L, 15L, 15L, 15L, 15L, 16L, 17L, 
                                                  17L, 17L, 17L, 17L, 17L, 17L, 17L, 17L, 18L, 18L, 18L, 18L, 18L, 
                                                  18L, 18L, 18L, 18L, 18L, 18L, 18L, 18L, 18L, 19L, 19L, 19L, 19L, 
                                                  19L, 19L, 19L, 21L, 21L, 21L, 21L, 21L, 21L, 21L, 21L, 21L, 21L, 
                                                  21L, 21L, 21L, 21L, 22L, 22L, 22L, 22L, 22L, 22L), value = c(0.299609505995154, 
                                                                                                               0.292599919566745, 0.459942835992995, 0.549520352605652, 0.540174492207966, 
                                                                                                               0.440757065076484, 0.51925071298937, 0.394218304381644, 0.369652579725175, 
                                                                                                               0.47407311381903, 0.342776575763635, 0.301981685381016, 0.50239823697174, 
                                                                                                               0.522945294270158, 0.453331604874255, 0.286603355357169, 0.483860513352346, 
                                                                                                               0.408154005703915, 0.629828882551206, 0.738397718434016, 0.399371022633454, 
                                                                                                               0.325576873217527, 0.400440757065076, 0.484573502722323, 0.50829660357791, 
                                                                                                               0.462276380606689, 0.606818771065595, 0.310784095359029, 0.384261360760626, 
                                                                                                               0.477443609022556, 0.312483795696137, 0.29731656728027, 0.392629093354601, 
                                                                                                               0.284076605358963, 0.407441016333938, 0.59573502722323, 0.50213896810993, 
                                                                                                               0.574799066632097, 0.443803474202748, 0.497472128597355, 0.405431682654913, 
                                                                                                               0.29491833030853, 0.315905485332613, 0.291418200674099, 0.331151153746435, 
                                                                                                               0.411913404200156, 0.451322271195229, 0.331086336530983, 0.53850142597874, 
                                                                                                               -0.37226939859114, 0.31515996653899, 0.294354055198044, 0.367189525537983, 
                                                                                                               0.391625615763547, 0.463896810993, 0.387542131190044, 0.292584910552243, 
                                                                                                               0.621726730619653, 0.687127301011149, 0.312566857691606, 0.363463375765271, 
                                                                                                               0.314902444429002, 0.320715582058595, 0.638449572206378, 0.41632097485092, 
                                                                                                               0.627560280010371, 0.626328752916775, 0.568511796733212, 0.443868291418201, 
                                                                                                               0.394023852735287, 0.717267306196526, 0.592170080373347, 0.697886958776251, 
                                                                                                               0.345481668558909, 0.321078924996911, 0.316345734058952, 0.619075439392268, 
                                                                                                               0.55747911896677, 0.581469264816701, 0.494715710364789, 0.340702088685727, 
                                                                                                               0.308805763066372, 0.407635467980296, 0.492934923515686, 0.389681099299974, 
                                                                                                               0.624449053668654, 0.7713896810993, 0.829465906144672, 0.709229971480425, 
                                                                                                               0.282473424941664, 0.564298677728805, 0.592364532019704, 0.515945035001296, 
                                                                                                               0.699507389162562, 0.358205573405573, 0.486751712614036, 0.583030852994555, 
                                                                                                               0.544788695877625, 0.619393310863365, 0.414376458387348), p.value = c(0.0235632633569618, 
                                                                                                                                                                                     0.0271937697219038, 0.000318792108375598, 0.0000095529964263541, 
                                                                                                                                                                                     0.0000144489527849068, 0.00060045078093518, 0.0000349378453132765, 
                                                                                                                                                                                     0.0024112865344148, 0.00465516194729254, 0.00019517217982612, 
                                                                                                                                                                                     0.00904973373170392, 0.0224312037547121, 0.0000682833417542383, 
                                                                                                                                                                                     0.000030020415849874, 0.000398185115765948, 0.0306616373021875, 
                                                                                                                                                                                     0.000137184645748301, 0.00162316011170138, 0.000000152972329026113, 
                                                                                                                                                                                     0.0000000000555382406730587, 0.0020871098657953, 0.0134609694133212, 
                                                                                                                                                                                     0.00202489885847568, 0.000133650398132623, 0.0000542245230397143, 
                                                                                                                                                                                     0.000294408159116966, 0.000000562184085506345, 0.0186236800636645, 
                                                                                                                                                                                     0.00316698995922882, 0.000173065350909773, 0.0179556683864184, 
                                                                                                                                                                                     0.0247029512450285, 0.00251993451052135, 0.0322296408066651, 
                                                                                                                                                                                     0.00165704546635892, 0.00000101520050033166, 0.0000689721190907377, 
                                                                                                                                                                                     0.00000292415396385692, 0.000544358626972663, 0.0000825153274468526, 
                                                                                                                                                                                     0.00175597073458689, 0.0259443002120157, 0.016672598808545, 0.027849822069048, 
                                                                                                                                                                                     0.011863392464567, 0.00145453592572053, 0.000425650234950226, 
                                                                                                                                                                                     0.0118809851522261, 0.000015539691581079, 0.00435030478447906, 
                                                                                                                                                                                     0.0169452760709201, 0.0262438740622997, 0.00495912758699157, 
                                                                                                                                                                                     0.0025907602475721, 0.000278488358747442, 0.00289756832754939, 
                                                                                                                                                                                     0.0272020202069392, 0.000000244824322370718, 0.00000000357910812098794, 
                                                                                                                                                                                     0.017923553504601, 0.0054521492632249, 0.0170403461152526, 0.0150017674324396, 
                                                                                                                                                                                     0.0000000913583173556276, 0.00127694949573409, 0.000000174739380298661, 
                                                                                                                                                                                     0.000000187742324353479, 0.00000396153220583173, 0.000543218537384593, 
                                                                                                                                                                                     0.00242435267631125, 0.000000000345193207351713, 0.00000122201815466738, 
                                                                                                                                                                                     0.0000000016049281903463, 0.00848512360974274, 0.0148816005634469, 
                                                                                                                                                                                     0.0165133416169292, 0.00000028473159474629, 0.00000664965627317216, 
                                                                                                                                                                                     0.00000210418806800838, 0.000091621123287311, 0.009504549522239, 
                                                                                                                                                                                     0.0194277122832736, 0.00164774181532357, 0.0000979850878426447, 
                                                                                                                                                                                     0.00273305924652689, 0.000000209352965185872, 0.00000000000219402274126423, 
                                                                                                                                                                                     0.00000000000000155431223447522, 0.000000000662809807039366, 
                                                                                                                                                                                     0.0332587337284396, 0.00000483856491428902, 0.00000120979071027705, 
                                                                                                                                                                                     0.0000399573140796861, 0.000000001418001716047, 0.00622083352858049, 
                                                                                                                                                                                     0.000123363257311659, 0.00000194610760706482, 0.000011797479518183, 
                                                                                                                                                                                     0.00000027964366378086, 0.00135274630071969), fdr.p.value = c(0.0368609610529572, 
                                                                                                                                                                                                                                                   0.0418612610769374, 0.000872307638464083, 0.0000447652866430542, 
                                                                                                                                                                                                                                                   0.0000634338875897439, 0.00150453562489348, 0.000131933765322528, 
                                                                                                                                                                                                                                                   0.00503217389869872, 0.00895001482779849, 0.000570939570656271, 
                                                                                                                                                                                                                                                   0.0159164359088175, 0.0352824142391826, 0.000232804405814509, 
                                                                                                                                                                                                                                                   0.00011619369048673, 0.00106153086453441, 0.0465748444314896, 
                                                                                                                                                                                                                                                   0.000421056698210084, 0.00356504984533685, 0.00000136828561800754, 
                                                                                                                                                                                                                                                   0.00000000163424833324108, 0.00443878295401536, 0.0226374684916873, 
                                                                                                                                                                                                                                                   0.00431527192198086, 0.000412082742872107, 0.000191294382540351, 
                                                                                                                                                                                                                                                   0.000813147541281902, 0.0000040781444786794, 0.0299544992867013, 
                                                                                                                                                                                                                                                   0.0063941549563881, 0.000514000509068467, 0.0290450094076175, 
                                                                                                                                                                                                                                                   0.0384082195485635, 0.00523416623398064, 0.0486347610647322, 
                                                                                                                                                                                                                                                   0.00362836362753959, 0.00000673046848169043, 0.00023487360198377, 
                                                                                                                                                                                                                                                   0.0000163695565313278, 0.0013836233893994, 0.000273683785485572, 
                                                                                                                                                                                                                                                   0.00381802200646441, 0.0401587252809674, 0.0272246363014887, 
                                                                                                                                                                                                                                                   0.0427278820941704, 0.0201814841273897, 0.00323807066606572, 
                                                                                                                                                                                                                                                   0.00111958792030456, 0.0202084164231431, 0.0000671436372682465, 
                                                                                                                                                                                                                                                   0.00843170033890926, 0.0276188024698024, 0.0405731777905094, 
                                                                                                                                                                                                                                                   0.00945993154725985, 0.00536090238029885, 0.000776843073647459, 
                                                                                                                                                                                                                                                   0.00590840336299872, 0.0418683454794574, 0.00000203152850580359, 
                                                                                                                                                                                                                                                   0.0000000580139050797424, 0.0290072909348189, 0.0102639214148243, 
                                                                                                                                                                                                                                                   0.0277461708312484, 0.0248176853185349, 0.000000895327113555237, 
                                                                                                                                                                                                                                                   0.0028909592450275, 0.00000153099468968047, 0.00000163098479506474, 
                                                                                                                                                                                                                                                   0.0000212740026177468, 0.0013813374551353, 0.00505715081715776, 
                                                                                                                                                                                                                                                   0.00000000801910374001672, 0.00000787416077650918, 0.000000029996996600023, 
                                                                                                                                                                                                                                                   0.0150757032363039, 0.0246508729887582, 0.0269761008392711, 0.00000231087679017569, 
                                                                                                                                                                                                                                                   0.0000329141250261345, 0.0000124600940497751, 0.000299386107871635, 
                                                                                                                                                                                                                                                   0.0166271662068925, 0.0310691786737525, 0.00361074757927311, 
                                                                                                                                                                                                                                                   0.000317111355917143, 0.00561941897402113, 0.00000178361887785677, 
                                                                                                                                                                                                                                                   0.0000000000979712255982424, 0.000000000000205026289687789, 0.0000000141646282040666, 
                                                                                                                                                                                                                                                   0.0499642922198682, 0.0000250914464330686, 0.00000780852541683882, 
                                                                                                                                                                                                                                                   0.000147443773755138, 0.0000000271216461555923, 0.0115015765384227, 
                                                                                                                                                                                                                                                   0.000384601124941211, 0.000011674611029104, 0.0000534438821302059, 
                                                                                                                                                                                                                                                   0.00000227279793594132, 0.00303977218466011), type = c("corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr", "corr", "corr", "corr", "corr", "corr", 
                                                                                                                                                                                                                                                                                                          "corr", "corr", "corr")), row.names = c(458L, 609L, 610L, 612L, 
                                                                                                                                                                                                                                                                                                                                                  762L, 764L, 765L, 916L, 917L, 918L, 1065L, 1066L, 1068L, 1069L, 
                                                                                                                                                                                                                                                                                                                                                  1071L, 1217L, 1220L, 1221L, 1223L, 1224L, 1370L, 1372L, 1373L, 
                                                                                                                                                                                                                                                                                                                                                  1374L, 1375L, 1376L, 1377L, 1521L, 1523L, 1525L, 1527L, 1529L, 
                                                                                                                                                                                                                                                                                                                                                  1977L, 1978L, 1980L, 1981L, 1982L, 1983L, 1984L, 1985L, 1986L, 
                                                                                                                                                                                                                                                                                                                                                  1987L, 2129L, 2133L, 2135L, 2136L, 2137L, 2138L, 2142L, 2294L, 
                                                                                                                                                                                                                                                                                                                                                  2433L, 2435L, 2437L, 2439L, 2440L, 2441L, 2442L, 2446L, 2447L, 
                                                                                                                                                                                                                                                                                                                                                  2585L, 2586L, 2587L, 2588L, 2589L, 2590L, 2591L, 2592L, 2593L, 
                                                                                                                                                                                                                                                                                                                                                  2594L, 2595L, 2598L, 2599L, 2601L, 2737L, 2741L, 2747L, 2750L, 
                                                                                                                                                                                                                                                                                                                                                  2751L, 2753L, 2754L, 3041L, 3042L, 3044L, 3045L, 3046L, 3047L, 
                                                                                                                                                                                                                                                                                                                                                  3048L, 3049L, 3050L, 3051L, 3054L, 3055L, 3057L, 3058L, 3193L, 
                                                                                                                                                                                                                                                                                                                                                  3194L, 3196L, 3197L, 3198L, 3199L), class = c("cer_el", "data.frame"
                                                                                                                                                                                                                                                                                                                                                  ))
  }
  nodes<-function(){
    structure(list(id = c("1", "2", "3", "4", "5", "6", "7", "8", 
                          "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", 
                          "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", 
                          "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", 
                          "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", 
                          "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", 
                          "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", 
                          "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", 
                          "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", 
                          "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", 
                          "107", "108", "109", "110", "111", "112", "113", "114", "115", 
                          "116", "117", "118", "119", "120", "121", "122", "123", "124", 
                          "125", "126", "127", "128", "129", "130", "131", "132", "133", 
                          "134", "135", "136", "137", "138", "139", "140", "141", "142", 
                          "143", "144", "145", "146", "147", "148", "149", "150", "151", 
                          "152"), Name = c("1,2-Propanediol", "Unknown 358 U ", "meso 2,3-Butanediol ", 
                                           "Pyruvic acid ", "Lactic acid", "2-Hydroxyisobutyric acid ", 
                                           "Glycolic acid", "Alanine ", "Glycine ", "Oxalic acid", "Carbonic acid ", 
                                           "Valero-1,5-lactam", "p-Cresol ", "3-Hydroxybutyric acid ", "2-Aminobutyric acid ", 
                                           "Allylthioacetic acid", "3-Aminoisobutyric acid ", "Valine ", 
                                           "2-Ethyl-3-hydroxypropionic acid ", "Benzoic acid", "Serine", 
                                           "Ethanolamine ", "Leucine", "Glycerol ", "Isoleucine ", "Proline ", 
                                           "Succinic acid ", "Glyceric acid", "Uracil ", "4-Deoxythreonic acid", 
                                           "5-Hydroxyhexanoic acid ", "4-Deoxyerythronic acid", "Unknown 794 U ", 
                                           "U 807", "Threonine ", "Acid 823", "2,4-Dihydroxybutyric acid ", 
                                           "Unknown 835 U ", "3,4-Dihydroxybutyric acid", "3-Methylglutaconic acid ", 
                                           "Ornithine 1,5-lactam ", "Unknown 906 U", "Aminomalonic acid ", 
                                           "Malic acid ", "Adipic acid", "Threitol", "U D", "Erythritol", 
                                           "U 972", "Pyroglutamic acid", "4-Hydroxyproline ", "U 987", "Creatinine", 
                                           "Phenylalanine", "1-Deoxypentitol", "Erythronic acid", "Cysteine ", 
                                           "Threonic acid", "2-Ketoglutaric acid ", "A160001 ", "3-Hydroxy-3-methylglutaric acid ", 
                                           "Glutamic acid  ", "Unknown 1089 U ", "3-Deoxypentitol", "4-Hydroxyphenylacetic acid ", 
                                           "345-Trihydroxypentanoic acid ", "Xylose", "3-Deoxy-245-trihydroxypentonic acid", 
                                           "Asparagine", "Taurine ", "Lyxose", "Ribose", "1,6-Anhydroglucose", 
                                           "2-Aminoadipic acid ", "Xylitol", "Quinolinic acid ", "Arabitol", 
                                           "Ribitol", "Fucose", "Indenone", "cis-Aconitic acid", "Homovanillic acid ", 
                                           "Glycerol-3-P", "Glutamine ", "Lyxonic acid", "Phosphoethanolamine ", 
                                           "Ribonic acid", "Hypoxanthine", "Hippuric acid", "1-Methylhistidine ", 
                                           "3-Phosphoglycerate", "Ornithine ", "Citric acid", "3-(3-Hydroxyphenyl)-3-hydroxypropanoic", 
                                           "Glucoheptonic acid 14-lactone", "3-Methylhistidine", "Sugar 1369", 
                                           "Quinic acid", "A201005 ", "Sugar 1382", "Fructose", "Hydantoin 5-propionate", 
                                           "Allantoin ", "Gluconic-d-lactone ", "Mannose", "Indole-3-acetic acid", 
                                           "Galactose", "Glucose", "Lysine ", "Histidine ", "Tyrosine ", 
                                           "Mannitol", "Sorbitol", "Galactitol", "Unknown 1457 U ", "Galacturonic acid", 
                                           "Glycyl-proline", "Pantothenic acid ", "3-Hydroxy-3-(4-hydroxy-3-methoxyphenyl)propionic acid", 
                                           "Galactonic acid", "Gluconic acid ", "Palmitic acid ", "Glucaric acid", 
                                           "7-Methylxanthine ", "Inositol-like ", "2,3,3-Trihydroxyacrilic acid", 
                                           "Kynurenic acid ", "N-Acetylglucosamine ", "Inositol", "Uric acid", 
                                           "Sugar 1602", "N-Acetylgalactosamine", "4-Hydroxyhippuric deriv. ", 
                                           "Sugar 1624", "Monosacch E", "Sugar 1646", "2-Amino-6-hydroxy-7-methylpurine", 
                                           "Tryptophan", "5-Hydroxyindole-3-acetic acid", "U C  ", "Glycine, N-(4-hydroxybenzoyl)-, bis(trimethylsilyl) deriv.", 
                                           "Cystine ", "A231002", "Pseudouridine", "Monosacch 1886", "U A ", 
                                           "Pentadecan-1-ol ", "Hydroxyproline dipeptide", "N-Acetylneuraminic acid", 
                                           "Xylobiose ", "Sucrose", "Disaccharide"), HMDB = c("HMDB01881", 
                                                                                              NA, "HMDB03156", "HMDB00243", "HMDB00190", "HMDB00729", "HMDB00115", 
                                                                                              "HMDB00161", "HMDB00123", "HMDB02329", "HMDB0001967", "HMDB0061932", 
                                                                                              "HMDB01858", "HMDB00357", "HMDB00452", NA, "HMDB0003911", "HMDB00883", 
                                                                                              "HMDB0000396", "HMDB01870", "HMDB00187", "HMDB00149", "HMDB00687", 
                                                                                              "HMDB00131", "HMDB00172", "HMDB00162", "HMDB00254", "HMDB00139", 
                                                                                              "HMDB00300", "HMDB02453", "HMDB00525", "HMDB00498", NA, NA, "HMDB00167", 
                                                                                              NA, "HMDB00360", NA, "HMDB0000337", "HMDB0000522", "HMDB0000323", 
                                                                                              NA, "HMDB01147", "HMDB00156", "HMDB00448", "HMDB04136", NA, "HMDB02994", 
                                                                                              NA, "HMDB00267", "HMDB00725", NA, "HMDB00562", "HMDB00159", NA, 
                                                                                              "HMDB00613", "HMDB00574", "HMDB00943", "HMDB00208", NA, "HMDB00355", 
                                                                                              "HMDB00148", NA, NA, "HMDB00020", "HMDB59753", "HMDB00098", NA, 
                                                                                              "HMDB00168", "HMDB00251", NA, "HMDB00283", "HMDB00640", NA, "HMDB02917", 
                                                                                              "HMDB00232", "HMDB00568", "HMDB00508", "HMDB00174", NA, "HMDB00072", 
                                                                                              "HMDB00118", "HMDB00126", "HMDB00641", "HMDB0060255", "HMDB0000224", 
                                                                                              "HMDB00867", "HMDB00157", "HMDB0000714", "HMDB0000001", "HMDB0000807", 
                                                                                              "HMDB00214", "HMDB00094", "HMDB02643", NA, "HMDB00479", NA, "HMDB03072", 
                                                                                              NA, NA, "HMDB00660", "HMDB01212", "HMDB0000462", NA, "HMDB00169", 
                                                                                              "HMDB00197", "HMDB00143", "HMDB00122", "HMDB0000182", "HMDB00177", 
                                                                                              "HMDB00158", "HMDB00765", "HMDB00247", "HMDB00107", NA, "HMDB02545", 
                                                                                              "HMDB0000721", "HMDB00210", NA, "HMDB00565", "HMDB00625", "HMDB00220", 
                                                                                              "HMDB00663", "HMDB0001991", NA, NA, "HMDB00715", "HMDB00215", 
                                                                                              "HMDB00211", "HMDB00289", NA, "HMDB0000212", NA, NA, NA, NA, 
                                                                                              "HMDB00897", "HMDB00929", "HMDB00763", NA, "HMDB13678", "HMDB00192", 
                                                                                              NA, "HMDB00767", NA, NA, "HMDB0013299", "HMDB28864", "HMDB00230", 
                                                                                              "HMDB29894", "HMDB00258", NA), KEGG = c("C00583", NA, "C20657", 
                                                                                                                                      "C00022", "C00186", NA, "C00160", "C00041", "C00037", "C00209", 
                                                                                                                                      "C01353", NA, "C01468", "C01089", "C02261", NA, "C05145", "C00183", 
                                                                                                                                      NA, "C00180", "C00065", "C00189", "C00123", "C00116", "C00407", 
                                                                                                                                      "C00148", "C00042", "C00258", "C00106", NA, NA, NA, NA, NA, "C00188", 
                                                                                                                                      NA, NA, NA, NA, NA, NA, NA, "C00872", "C00149", "C06104", "C16884", 
                                                                                                                                      NA, "C00503", NA, "C01879", "C01157", NA, "C00791", "C00079", 
                                                                                                                                      NA, NA, "C00097", "C01620", "C00026", NA, "C03761", "C00025", 
                                                                                                                                      NA, NA, "C00642", NA, "C00181", NA, "C00152", "C00245", "C00476", 
                                                                                                                                      "C00121", NA, "C00956", "C00379", "C03722", "C01904", "C00474", 
                                                                                                                                      "C01019", NA, "C00417", "C05582", "C00093", "C00064", "C05412", 
                                                                                                                                      "C00346", "C01685", "C00262", "C01586", NA, "C00597", "C00077", 
                                                                                                                                      "C00158", NA, NA, "C01152", NA, "C00296", NA, NA, "C02336", "C05565", 
                                                                                                                                      "C01551", "C00198", "C00159", "C00954", "C00124", "C00031", "C00047", 
                                                                                                                                      "C00135", "C00082", "C00392", "C00794", "C01697", NA, "C08348", 
                                                                                                                                      "C01632", "C00864", NA, "C00880", "C00257", "C00249", "C00818", 
                                                                                                                                      "C16353", NA, NA, "C01717", "C00140", "C00137", "C00366", NA, 
                                                                                                                                      "C01074", NA, NA, NA, NA, NA, "C00078", "C05635", NA, NA, "C00491", 
                                                                                                                                      NA, "C02067", NA, NA, NA, NA, "C19910", "C01630", "C00089", NA
                                                                                              ), known = c(1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
                                                                                                           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 
                                                                                                           0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 
                                                                                                           1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
                                                                                                           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 
                                                                                                           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 
                                                                                                           1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 
                                                                                                           0, 1, 0, 0, 1, 1, 1, 1, 1, 0), CID = c(1030, NA, 262, 1060, 107689, 
                                                                                                                                                  11671, 3698251, 5950, 5257127, 18676629, NA, NA, 2879, 441, 6971252, 
                                                                                                                                                  NA, NA, 6287, NA, 20144841, 5951, 700, 6106, 753, 6306, 145742, 
                                                                                                                                                  1110, 439194, 1174, 10964471, 170748, 13120901, NA, NA, 6288, 
                                                                                                                                                  NA, 192742, NA, NA, NA, NA, NA, 100714, 222656, 196, 169019, 
                                                                                                                                                  NA, 222285, NA, 7405, 5810, NA, 588, 6140, NA, 2781043, 5862, 
                                                                                                                                                  151152, 51, NA, 1662, 33032, NA, NA, 127, NA, 135191, NA, 6267, 
                                                                                                                                                  1123, NA, 5779, 2724705, NA, 6912, 1066, 827, NA, 17106, NA, 
                                                                                                                                                  643757, 1738, 439162, 5961, NA, NA, 5460677, 790, NA, NA, NA, 
                                                                                                                                                  6262, 19782904, 102959, NA, 64969, NA, NA, NA, NA, 439709, 782, 
                                                                                                                                                  NA, NA, 18950, 802, 439357, 5793, NA, 6274, 6057, 6251, 5780, 
                                                                                                                                                  11850, NA, 84740, NA, 988, NA, 128869, 10690, 985, 33037, NA, 
                                                                                                                                                  NA, NA, 3845, 11861101, NA, 1175, NA, NA, NA, NA, NA, NA, 11361, 
                                                                                                                                                  6305, 1826, NA, NA, 67678, NA, 15047, NA, NA, NA, NA, 445063, 
                                                                                                                                                  NA, 5988, NA), id.1 = c("var1", "var2", "var3", "var4", "var5", 
                                                                                                                                                                          "var6", "var7", "var8", "var9", "var10", "var11", "var12", "var13", 
                                                                                                                                                                          "var14", "var15", "var16", "var17", "var18", "var19", "var20", 
                                                                                                                                                                          "var21", "var22", "var23", "var24", "var25", "var26", "var27", 
                                                                                                                                                                          "var28", "var29", "var30", "var31", "var32", "var33", "var34", 
                                                                                                                                                                          "var35", "var36", "var37", "var38", "var39", "var40", "var41", 
                                                                                                                                                                          "var42", "var43", "var44", "var45", "var46", "var47", "var48", 
                                                                                                                                                                          "var49", "var50", "var51", "var52", "var53", "var54", "var55", 
                                                                                                                                                                          "var56", "var57", "var58", "var59", "var60", "var61", "var62", 
                                                                                                                                                                          "var63", "var64", "var65", "var66", "var67", "var68", "var69", 
                                                                                                                                                                          "var70", "var71", "var72", "var73", "var74", "var75", "var76", 
                                                                                                                                                                          "var77", "var78", "var79", "var80", "var81", "var82", "var83", 
                                                                                                                                                                          "var84", "var85", "var86", "var87", "var88", "var89", "var90", 
                                                                                                                                                                          "var91", "var92", "var93", "var94", "var95", "var96", "var97", 
                                                                                                                                                                          "var98", "var99", "var100", "var101", "var102", "var103", "var104", 
                                                                                                                                                                          "var106", "var107", "var108", "var109", "var110", "var111", "var112", 
                                                                                                                                                                          "var113", "var114", "var115", "var116", "var117", "var119", "var120", 
                                                                                                                                                                          "var121", "var122", "var123", "var124", "var125", "var126", "var127", 
                                                                                                                                                                          "var128", "var129", "var130", "var131", "var132", "var133", "var134", 
                                                                                                                                                                          "var135", "var136", "var137", "var138", "var139", "var140", "var141", 
                                                                                                                                                                          "var142", "var143", "var144", "var145", "var146", "var147", "var148", 
                                                                                                                                                                          "var149", "var150", "var151", "var152", "var153", "var154")), row.names = c(1L, 
                                                                                                                                                                                                                                                      2L, 3L, 4L, 5L, 6L, 7L, 8L, 9L, 10L, 11L, 12L, 13L, 14L, 15L, 
                                                                                                                                                                                                                                                      16L, 17L, 18L, 19L, 20L, 21L, 22L, 23L, 24L, 25L, 26L, 27L, 28L, 
                                                                                                                                                                                                                                                      29L, 30L, 31L, 32L, 33L, 34L, 35L, 36L, 37L, 38L, 39L, 40L, 41L, 
                                                                                                                                                                                                                                                      42L, 43L, 44L, 45L, 46L, 47L, 48L, 49L, 50L, 51L, 52L, 53L, 54L, 
                                                                                                                                                                                                                                                      55L, 56L, 57L, 58L, 59L, 60L, 61L, 62L, 63L, 64L, 65L, 66L, 67L, 
                                                                                                                                                                                                                                                      68L, 69L, 70L, 71L, 72L, 73L, 74L, 75L, 76L, 77L, 78L, 79L, 80L, 
                                                                                                                                                                                                                                                      81L, 82L, 83L, 84L, 85L, 86L, 87L, 88L, 89L, 90L, 91L, 92L, 93L, 
                                                                                                                                                                                                                                                      94L, 95L, 96L, 97L, 98L, 99L, 100L, 101L, 102L, 103L, 104L, 106L, 
                                                                                                                                                                                                                                                      107L, 108L, 109L, 110L, 111L, 112L, 113L, 114L, 115L, 116L, 117L, 
                                                                                                                                                                                                                                                      119L, 120L, 121L, 122L, 123L, 124L, 125L, 126L, 127L, 128L, 129L, 
                                                                                                                                                                                                                                                      130L, 131L, 132L, 133L, 134L, 135L, 136L, 137L, 138L, 139L, 140L, 
                                                                                                                                                                                                                                                      141L, 142L, 143L, 144L, 145L, 146L, 147L, 148L, 149L, 150L, 151L, 
                                                                                                                                                                                                                                                      152L, 153L, 154L), class = "data.frame")
  }
  
  edge_list<-el()
  cb<-nodes()
  
  convert_edge_index(edge_list,start='id',end='id',db)
  
  obj <-
    format_net_obj(
      nodes = db,
      edges = edge_list,
      idcolumn = 'id',
      net_index = NULL,
      node_mapping = NULL,
      vis_config = NULL
    )
  
}

