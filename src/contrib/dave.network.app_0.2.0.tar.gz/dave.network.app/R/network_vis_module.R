



# module ------------------------------------------------------------------



#' @title network_visUI
#' @export
#' @import shiny
network_visUI <- function(id) {

  ns <- NS(id)
  tagList(
    fluidRow(
      column(12,uiOutput(ns('ui_networkmap_module')))
    )
  )
}

#' @title network_visInput
#' @export
#' @import shiny rmarkdown
network_visInput <-
  function(input,
           output,
           session,
           data_obj,
           plot_controls
           ) {

    
    #need to sanitize inputs here?
    get_data_obj<-reactive({
      
      check<-tryCatch(data_obj(),error=function(e){}) # wtf! in app .pubchemmap breaks
      validate(need(!is.null(check),'Data is not compatible with method'))
      
      data_obj()
    })
    
    
    get_vars<-reactive({
      obj<-tryCatch(map_vars,error=function(e){NULL}) # cache in observer if un initiated
      
      c('none',obj)
    })
    

    #nodes
    output$ui_select_node_label<-renderUI({

      
      ns<-session$ns
      obj<-tryCatch(map_vars,error=function(e){NULL}) # cache in observer if un initiated

      vars<-c('none',obj)


      fluidRow(
        column(12,
               selectInput(inputId = ns("select_node_label"), label = "Label",
                           choices = vars, selected = state_single("select_node_label",vars), multiple = F),
               checkboxInput(ns('repel_node_label'),'repel labels',value = FALSE)
        )
      )

    })

    output$ui_select_node_color<-renderUI({
      ns<-session$ns
      vars <- get_vars()
      
      selectInput(inputId = ns("select_node_color"), label = "Color",
                  choices = vars, selected = state_single(ns("select_node_color"),vars), multiple = F)
    })

    output$ui_select_node_size<-renderUI({

      ns<-session$ns
      vars <- get_vars()
      fluidRow(column(12,
                      selectInput(inputId = ns("select_node_size"), label = "Size",
                                  choices = vars, selected = state_single(ns("select_node_size"),vars), multiple = F),
                      sliderInput(ns('select_node_size_limits'),'limits',min=0,max=20,value=c(1,5),step=.25)
      )
      )

    })

    output$ui_select_node_shape<-renderUI({

      ns<-session$ns
      vars <- get_vars()
      
      selectInput(inputId = ns("select_node_shape"), label = "Shape", choices = vars,
                  selected = state_single(ns("select_node_shape"),vars), multiple = F)
    })

    #TODO add networkmap_init()$nodes

    #update node inputs based on the node data
    observe({

      #should respond to the data
      
      #wtf
      .data_obj<-get_data_obj()#(),error=function(e){}) # wtf! ^2 #tryCatch(data_obj(),error=function(e){}) # wtf! in app .pubchemmap breaks
      
      ns<-session$ns

      vals<-reactiveValues()
      vars<-.data_obj$names$col#(data_obj)#networkmap_init()$nodes#networkmap_values[['networkmap_init']]$nodes
    
      #need to store for uninitiaded Ui
      # does not work vals[['vars']]<
      map_vars<<-vars
      
      
      if(is.null(vars)) return()
      vars <- c("none",vars)
      ids<-c("select_node_label","select_node_color","select_node_size","select_node_shape")
      for(i in 1:length(ids)){
        local({
          updateSelectInput(session=session,inputId = ids[i],choices=vars)
        })
      }

    })

    #edge properties
    output$ui_edge_attr<-renderUI({

      ns<-session$ns
      fluidRow(
        column(12,
               numericInput(ns('edge_curvature'),'curve',min=0,max=1,value=0)
        )
      )
    })

    #TODO how does this work w/ ns
    outputOptions(output, "ui_edge_attr", suspendWhenHidden = FALSE)


    # react to the network update
    output$network_plot_calculate_ui<-renderUI({

      ns<-session$ns

      fluidRow(
        column(4,#TODO get align to work
               div(actionButton(ns('network_plot_calculate'),'Plot',icon=icon('check')))),
        column(12,hr())
      )
    })
    

    # edge filter -------------------------------------------------------------
    obj_stats<-reactive({
    
      .data_obj<-get_data_obj()
      
      .data_obj$edges %>% 
        group_by(type) %>%
        summarise_at('value',funs(min=min(.),max=max(.)))
      
    })
    
    output$filter_object<-renderUI({
      
      ns<-session$ns
      
      obj<-obj_stats()
      

      # tagList(
        out<-lapply(1:nrow(obj), function(i){
          # local({
              fluidRow(
                column(12,hr()),
                column(12,
                       radioButtons(
                         ns(paste0('filter_edges_', i)),
                         label = obj[i, ]$type,
                         choices = c(
                           all = 'none',
                          'greater than' =  'greater',
                          'less than' = 'less',
                          none = 'drop'
                         ),
                         selected = 'none',
                         inline = TRUE
                       ),
                       numericInput(
                         ns(paste0('filter_edges_value_', i)),
                         label = 'value',
                         min = obj[i, ]$min,
                         max = obj[i, ]$max,
                         value = mean(c(obj[i, ]$min, obj[i, ]$max)) %>% signif(.,3)
                       ),
                       hr()
                )
              )
          # })
        })

        tagList(out)
      # )
      
    })
    
    output$filter_obj_ui<-renderUI({
      
      ns<-session$ns
      
      bs_accordion(id = "networkmap_filter_object_collapse_panel") %>%
        bs_append(
          title = tags$label(class = 'bsCollapsePanel', icon("filter") , "Filter"),
          content =
            fluidRow(
              column(
                12,
               uiOutput(ns('filter_object'))
              )
            )
        )
    })
    
    #TODO move this to dave.utils or dave.help
    filter_fun<-function(obj,level_var='type',value_var='value',level,value,qual){
      
      
      #only filter level in question
      
      out<-rep(TRUE,nrow(obj))
      
      check<-is.null(qual)
      
      if(check) return(list(filter=out,summary=NULL))
      
      if(qual == 'drop') out<-!out
      
      if(qual =='greater') {
        out<-obj[level_var] == level & obj[value_var] >= value 
        
      }
      
      if(qual =='less') {
        out<-obj[level_var] == level & obj[value_var] <= value 
      }
      
      
      desc_level<- paste0(level_var,' equal to ',level)
      
      desc_start<-'The following filter was applied: '
      
      if(qual == 'none') {
        desc_start<-desc_level<-desc_value<-NULL
      } 
      
      if(qual == 'drop'){
        desc_value<-'were all removed'
      }
      
      if(!qual %in% c('none','drop')){
        .qual<-switch(qual,
                      'greater' = 'greater than or equal to ',
                      'less' = 'less than or equal to ')
        
        desc_value<-paste0('and ',value_var,' ',.qual,value)
      }
      
      desc<-paste(desc_start,desc_level,desc_value,collapse='\n')

      
      out[obj[level_var] != level]<-TRUE
      list(filter=out,summary=desc)
      
    }
    
    filter_edges_obj<-reactive({
      
      .data_obj<-get_data_obj()
      
       # browser()
      
      obj<-.data_obj$edges
      obj_stats<-obj_stats()
      
      # browser()
      #block when calling when ui is not enabled
      #from dave.utils
      out<-lapply(1:nrow(obj_stats),function(i){
        
        dave_filter_fun(obj,
                   level = obj_stats$type[i],
                   value = input[[paste0('filter_edges_value_', i)]],
                   qual = input[[paste0('filter_edges_', i)]])
        
      }) 
      
      
      dave_filter_fun_summary(out)

      
    })

    ###############################
    # renderUI output
    ###############################
    output$ui_networkmap_module <- renderUI({

      ns<-session$ns

      tagList(
        fluidRow(
          column(12,align="right",
                 
                 div( uiOutput(ns('network_plot_calculate_ui'))) # style='align:"right" !important;',
          )
        ),
        tagList(
          bs_accordion(id = "networkmap_plot_collapse_panel") %>%
            bs_append(
              title = tags$label(class = 'bsCollapsePanel', icon("circle") , "Nodes"),
              content =
                fluidRow(column(
                  12,
                  uiOutput(ns("ui_select_node_label")),
                  uiOutput(ns("ui_select_node_color")),
                  uiOutput(ns("ui_select_node_size")),
                  uiOutput(ns("ui_select_node_shape"))
                ))
            ) %>%
            bs_append(
              title = tags$label(class = 'bsCollapsePanel', icon("arrows-h") , "Edges"),
              content =
                fluidRow(column(12,
                                uiOutput(
                                  ns('filter_obj_ui')
                                ),
                                uiOutput(ns(
                                  'ui_edge_attr'
                                ))))
            ) %>%
            bs_append(
              title = tags$label(class = 'bsCollapsePanel', icon("square") , "Canvas"),
              content =
                fluidRow(column(12,
                                uiOutput(
                                  ns('networkmap_plot_global_ui')
                                )))
            ),
        conditionalPanel(
          condition = "input.networkmap_explore_plot_type == 'dynamic'",
          ns = ns,
          bs_accordion(id = "networkmap_plot_collapse_panel") %>%
            bs_append(
              title = tags$label(class = 'bsCollapsePanel', icon("cogs") , "Options"),
              content =
                fluidRow(
                  column(
                    12,
                    uiOutput(ns("ui_select_nodes")),
                    hr(),
                    h4("Options"),
                    checkboxInput(ns("vis_physic"), "Disable stabilization", value = FALSE),
                    checkboxInput(ns("vis_config"), "Show configuration", value = FALSE),
                    checkboxInput(ns("vis_manip"), "Show manipulation", value = FALSE),
                    checkboxInput(ns("vis_nav"), "Show navigation", value = FALSE)
                  )
                )
            )
        )
      )
      )
    })

    #add zoom controls?
    #+ an - step down
    #or zoom% accepting fractions
    observeEvent(input$networkmap_plot_zoom_value,{
     
      isolate({
        if(is.null(input$networkmap_plot_zoom_value)) return()
        
        ns<-session$ns
        
        width<-tryCatch(input$networkmap_plot_width_value * input$networkmap_plot_zoom_value,error=function(e){})
        height<-tryCatch(input$networkmap_plot_height_value * input$networkmap_plot_zoom_value,error=function(e){})
        
        width<-if(is.null(width)) 800 else width
        height<-if(is.null(height)) 600 else height
        
        updateNumericInput(session,"networkmap_plot_width_value",value=width)
        updateNumericInput(session,"networkmap_plot_height_value",value=height)
      })
      
    })
    
    output$zoom_plot_ui<-renderUI({
      
      ns<-session$ns
      numericInput(ns("networkmap_plot_zoom_value"),"zoom", min=0.01,max=5, step=.1,value=1)
      
    })
 
    
    output$networkmap_plot_global_ui<-renderUI({

      ns<-session$ns
      
      .width<-800#if(is.null(dims$width)) 800 else dims$width
      .height<-600#if(is.null(dims$height)) 600 else dims$height
      
      fluidRow(
        column(6,uiOutput(ns('zoom_plot_ui'))), # true step would be log for <1?
        column(12,
                tags$table(
                 tags$td(numericInput(ns("networkmap_plot_width_value"), "width", min=400,step=100,value=.width)),
                 tags$td(numericInput(ns("networkmap_plot_height_value"), "height", min=400,step=100,value=.height))
               )
        )
      )
    }) 


    #setup plot
    networkmap_plot <- reactive({

      plh <- input$networkmap_plot_height_value
      plw <- input$networkmap_plot_width_value

      list(plot_width=plw, plot_height=plh)
    })

    networkmap_plot_width <- function()
      networkmap_plot() %>% { if (is.list(.)) .$plot_width else 800 }

    networkmap_plot_height <- function()
      networkmap_plot() %>% { if (is.list(.)) .$plot_height else 600 }


    #collect all inputs

    networkmap_init<-reactive({

      #should respond to the data
      .data_obj<-get_data_obj()
      
      #filter edges
      id<- filter_edges_obj()$filter
      validate(need(any(id),'Nothing selected'))
      
      .data_obj$edges<-.data_obj$edges[id,,drop=FALSE]
      # browser()
      mapping_opt = list(node_label=input$select_node_label,
                         node_col=input$select_node_color,
                         node_size=input$select_node_size,
                         node_size_range=input$select_node_size_limits,
                         node_shape=input$select_node_shape)


      visnetwork_opt = list(
        select_by = input$select_nodes,
        vis_physic = input$vis_physic,
        vis_config = input$vis_config,
        vis_manip = input$vis_manip,
        vis_nav = input$vis_nav
      )

      #sanitize inputs
      is_none<-function(x){ is.null(x) || x =='none' || x == '' }
      id<-sapply(mapping_opt,is_none)
      mapping_opt[id]<-NULL

      id<-sapply(visnetwork_opt,is_none)
      visnetwork_opt[id]<-NULL


      #add nodes and edges for convenience
      out<-list(nodes=.data_obj$nodes, edges=.data_obj$edges, node_mapping=mapping_opt, vis_config=visnetwork_opt)

      do.call('network.visualize',out)

    })

    networkmap_available <- reactive({


      if(is.null(input$network_plot_calculate) || input$network_plot_calculate ==0) {
        return("Select options, then plot to visualize.")
      }

      "available"
    })

    #need to collect input to share with other
    #module calculate click or link calculate


    #collect all needed outputs
    module_outputs<-reactive({

      # if(networkmap_available() != 'available') return()

      # isolate({
        list(
          init=networkmap_init(),
          available=networkmap_available, # TODO?
          plot_args=list( #updates will trigger replot of UI.. if mod name scope from input
                         width=networkmap_plot_width(),
                         height=networkmap_plot_height()
            ),
          summary=filter_edges_obj()$summary #summary of what was done in the module
        )
      # })

    })

    return(module_outputs)

}


#' @title network_vis_plotUI
#' @export
#' @import shiny
network_vis_plotUI<- function(id) {

  ns <- NS(id)
  tagList(
    fluidRow(
      column(12,uiOutput(ns('networkmap_ui')))
    )
  )
}

#' @title network_vis_plotInput
#' @export
#' @import shiny
network_vis_plotInput<-function(input,
                                output,
                                session,
                                data_obj) {
  
  
  #static
  networkmap_available<-
    eventReactive(input$network_plot_calculate,{
    
    tmp<-data_obj()
    if(is.null(tmp$available)){
      'Calculate objects to plot'
    } else {
      tmp$available()
    }

  })

  networkmap_init<-reactive({

    data_obj()$init

  })

  plot_args<-eventReactive(input$network_plot_calculate,{
    # reactive({
    data_obj()$plot_args
  })

  networkmap_plot_width <- 

    reactive({
      #breaks show/hide?
      out<-plot_args()$width
      

      if(is.null(out)) 800 else out
      
    })
  
  networkmap_plot_height <- 
    reactive({
      out<-plot_args()$height
      
      if(is.null(out)) 600 else out
      
  })


  
  ###############################
  # plotting functions
  ###############################
  .networkmap<- 
    # reactive({
    eventReactive(input$network_plot_calculate,{

    
    if (networkmap_available() != "available") return()
    
    isolate({
      do.call(network.visualize, networkmap_init())
    })

  })

  

  .plot_networkmap <- eventReactive(input$network_plot_calculate,{
    # reactive({



    if (networkmap_available() != "available") {
      #block character render
      msg<-networkmap_available()
      validate(need(!is.character(msg),msg))
    }

    
    isolate({
      
      withProgress(message = "Setting up network", value = 1, {
  
       
        if(get_plot_type() == 'ggplot'){
  
          plot(.networkmap(), repel=input$repel_node_label,curvature=input$edge_curvature)
  
        } else {
  
          plot(.networkmap(),curvature=0)
        }
  
      })
    })

  })

  
  #return for report
  module_outputs<-reactive({
    
   
    list(obj=.networkmap(), repel=input$repel_node_label,curvature=input$edge_curvature)
    
  })
  
  output$plot_networkmap<-renderPlot({


    if(networkmap_available() != 'available') return()
    if(get_plot_type() != 'ggplot') return()

    .plot_networkmap()

  })

  #plotly
  output$plotly_networkmap <- renderPlotly({

    if(tryCatch(networkmap_available(),error=function(e){'not ready'}) != 'available') return()
    if(get_plot_type() != 'plotly') return()
  
    
    isolate({
      plot_g<-.plot_networkmap()
      withProgress(message = "Rendering network", value = 1, {
        ggplotly(plot_g,height=networkmap_plot_height(), width = networkmap_plot_width()) 
      })
    })

  })



  #visNetwork why naming?
  output$visnetwork_networkmap <- renderVisNetwork({

    if(networkmap_available() != 'available') return()
    if(get_plot_type() != 'visnetwork') return()

    obj<-.networkmap()
    isolate({
      
      .text<-hover_text(obj)
      obj$nodes$text<-.text
   
      obj$node_mapping$node_index<-'id' # hack to get ggplot obj to match up with nodes
      
        
      withProgress(message = "Rendering network", value = 1, {
        network.visnetwork(obj)
      })
    })
  })

  output$plot_type_controls<-renderUI({

    ns<-session$ns

    fluidRow(
      column(12,radioButtons(ns("networkmap_explore_plot_type"),'',
                             c("static" = "static", "interactive" = "interactive","dynamic" = "dynamic"), selected = 'static', inline=T))
    )

  })

  output$plot_type_interactive<-renderUI({

    ns<-session$ns 
    
    height<-paste0(networkmap_plot_height(),'px')
    width <- paste0(networkmap_plot_width(),'px')
    
    
    tagList(
      fluidRow(
        column(12,
               {if(get_plot_type() == 'ggplot') plotOutput(ns("plot_networkmap"), height=height, width = width) else NULL},
               {if(get_plot_type() == 'plotly') plotlyOutput(ns("plotly_networkmap")) else NULL },
               {if(get_plot_type() == 'visnetwork') visNetworkOutput(ns("visnetwork_networkmap"),height=height, width = width) else NULL } # TODO size network
        )
      )
    )

  })

  #gate plot types
  get_plot_type<-eventReactive(input$network_plot_calculate,{
    # reactive({
    
    if(input$networkmap_explore_plot_type =='static') return('ggplot')
    if(input$networkmap_explore_plot_type =='dynamic') return('visnetwork')
    if(input$networkmap_explore_plot_type =='interactive') return('plotly')
      
  })


  
  output$networkmap_ui<-renderUI({

    ns<-session$ns
    
    fluidRow(column(12,
         uiOutput(ns('plot_type_controls')),
         uiOutput(ns('plot_type_interactive'))

    ))

  })


  return(module_outputs)

}



test<-function(){
  

  # #place holder main panel output
  output_UI<-function(id){

    ns <- NS(id)
    tagList(
      fluidRow(
        column(12,uiOutput(ns('ui_output')))
      )
    )

  }

  output_Input<- function(input,
                          output,
                          session,
                          Inputs
  ){

    output$text<-renderPrint({
        input$network_plot_calculate
        # browser()
        Inputs()
    })

    output$ui_output<-renderUI({
      ns<-session$ns
      verbatimTextOutput(ns('text'))
    })

  }

  
  #need to change sidepanel UI based on tab
  
  
  library(shiny)
  library(dplyr)
  library(bsplus)
  library(dave.help)
  library(dave.network)
  library(shinyjs)
  
  #TODO fix globals
  state_single<-function(id,vars){
    
    vars[1]
    
  }
  
  #data objects
  .data<-mtcars
  
  data_obj <-
    list(
      data = .data,
      col_meta = data.frame(
        neID = 1:ncol(.data) %>% as.character(),
        id = 1:ncol(.data) %>% as.character() ,
        names = colnames(.data) %>% as.character(),
        stringsAsFactors = FALSE
      ),
      row_meta = data.frame(AM = as.factor(.data$am))
    )
  
  data_obj$col_meta<-data_obj$col_meta %>% mutate(group=rep(c('A','B'),length.out=nrow(data_obj$col_meta)),
                                                  size=rep(c(1:3),length.out=nrow(data_obj$col_meta)))
  
  
  data_obj$names <- list(
    row = function(data_obj) {
      rownames(data_obj$data)
    },
    col = function(data_obj) {
      colnames(data_obj$col_meta)
    }
  )
  
  
  #network objects
  #should scope a network object
  
  network_obj<-list(nodes=data_obj$col_meta,
                    edges=expand.grid(1:5 %>% as.character(),3:6 %>% as.character()) %>% data.frame() %>% setNames(.,c('to','from')) %>%
                      data.frame() %>% mutate(value=1,type='foo'))
  
  f<-function(x){sample(1:x,x)}
  network_obj$edges<-rbind(network_obj$edges,expand.grid(1:5 %>% as.character(),3:6 %>% as.character()) %>% data.frame() %>% setNames(.,c('to','from')) %>%
                             data.frame() %>% mutate(value=f(nrow(.)),type='bar'))
  
  network_obj$names$row<-NULL
  network_obj$names$col<-colnames(network_obj$nodes)
  
  data_out<-function(){
    network_obj
  }
  
  
  ## app -------------------------------------------------------------------------
  
  ui <- shinyUI(fluidPage(
    useShinyjs(),
    uiOutput('main_UI')
  ))
  
  
  server <- shinyServer(function(input, output) {
  
  
    #tabs
    #main
    output$output_panels <- renderUI({
      tabsetPanel(id = "tabs_output",
                  tabPanel("Calculate", icon = icon('pencil-square-o'), output_UI('test')),
                  tabPanel("Visualize", icon = icon('pencil-square-o'), network_vis_plotUI('test'))) #output_UI('test')
    })
  
  
  
    #creates input UI elements
    plot_controls<-callModule(network_visInput,'test',data_obj=data_out) # block calculate untill triggered
    callModule(output_Input,'test',Inputs=plot_controls)
  
    #network plot
    callModule(network_vis_plotInput,'test',data_obj=plot_controls)
  
      output$main_UI<-renderUI({
        sidebarLayout(
          sidebarPanel(
            wellPanel(
              HTML(paste("<label><strong>Menu:", 'menu', "</strong></label><br>")),
              HTML(paste("<label><strong>Tool:", 'tool', "</strong></label><br>")),
              if (!is.null(data))
                HTML(paste("<label><strong>Data:", 'data', "</strong></label>"))
            ),
            conditionalPanel('input.tabs_output == "Visualize"',
              network_visUI('test') # need to also prevent calculation unless on tab
            )# renders inputs
          ),
          mainPanel(
            uiOutput('output_panels')
          )
        )
    })
  
  
  })
  
  # options(shiny.reactlog=FALSE)
  shinyApp(ui = ui, server = server)
  
  
  
  tests2<-function(){
  
    #follow this example
    # https://github.com/stephlocke/shinymodulesdesignpatterns/blob/master/input_to_multiplemodules/04_allinputsmodule.R
  
    #simple example of
    #1) collecting inputs
    #2) calculating something
    #3) plotting the results
  
    library(shiny)
    library(dplyr)
    library(ggplot2)
  
    data(mtcars)
    data(diamonds)
  
    #simulate responding to other UI changes
    #test using these changes in conditional panels
    modsUI<-function(id){
      ns<-NS(id)
      uiOutput(ns('modsUI'))
    }
  
    modsInput<-function(input,output,session){
  
      output$modsUI<-renderUI({
        ns<-session$ns
        selectInput(ns('mods'),'tab',choices=c('Calculate','Report','Plot','Explore'))
      })
  
      get_output<-reactive({
  
        input$mods
  
      })
  
      return(get_output)
  
    }
  
    network_visInput<-function(input,output,session,mod_input){
  
      output$data<-renderUI({
        ns<-session$ns
        selectInput(ns('data'),'data',choices=c('mtcars','diamonds'),selected='mtcars')
      })
  
      output$col_varsUI<-renderUI({
        ns<-session$ns
        selectInput(ns('col_vars'),'variable',choices=NULL)
      })
  
      observeEvent(input$data,{
        ns<-session$ns
        vars<- get_data() %>% colnames()
        updateSelectInput(session,'col_vars',choices=vars)
  
      })
  
      output$test1<-renderUI({
        ns<-session$ns
        obj<-mod_input()
        if(is.null(obj)) obj<-'foo'
        #conditional panel seems to not work?
        bs_accordion(id=ns("test_collapse_panel")) %>%
          bs_append(title = tags$label(class='bsCollapsePanel', icon("share-alt") , obj),
                    content =
                      fluidRow(column(12,
                                        hr(),
                                        switch(obj,
                                               'Calculate'= HTML('Its Calculate time!'),
                                               'Plot' = HTML('Plooooooooooooooooooooot!'))
  
                      ))
          ) %>%
          {
            if(obj == 'Plot'){
              bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Plot options"),
                        content=
                          fluidRow(column(12,
                                          HTML('sup brokaski?')
                          ))
              )
            }
          }
  
  
      })
  
      #react to another module
      output$selected<-renderUI({
        HTML(mod_input())
      })
  
      output$data_input<-renderUI({
        ns<-session$ns
        tagList(
          uiOutput(ns('data')),
          uiOutput(ns('col_varsUI')),
          uiOutput(ns('test1')),
          uiOutput(ns('selected'))
        )
      })
  
      get_data<-reactive({
  
        if(is.null(input$data)) return()
  
        switch(input$data,
               'mtcars' = mtcars,
               'diamonds' = diamonds)
  
      })
  
      get_col_vars<-reactive({
        if(is.null(input$col_vars)) return()
  
        get_data() %>% select(one_of(input$col_vars))
  
      })
  
  
      out<-reactive({
        list(col_vars=get_col_vars(),data=get_data())
      })
  
      return(out)
  
    }
  
    network_visUI<-function(id){
  
      ns<-NS(id)
      tagList(uiOutput(ns('data_input')))
    }
  
    testInput<-function(input, output, session, data){
  
      output$selection<-renderPrint({
        lapply(data(),head)
      })
    }
  
    testUI<-function(id){
      ns<-NS(id)
      verbatimTextOutput(ns('selection'))
    }
  
    #debug
    debugInput<-function(input, output, session, obj='Calculate'){
  
      output$debug_ui<-renderUI({
  
        ns<-session$ns
  
        obj<-obj()#'Plot'
        bs_accordion(id=ns("test_collapse_panel")) %>%
          bs_append(title = tags$label(class='bsCollapsePanel', icon("share-alt") , obj),
                    content =
                      fluidRow(column(12,
                                      hr(),
                                      switch(obj,
                                             'Calculate'= HTML('Its Calculate time!'),
                                             'Plot' = HTML('Plooooooooooooooooooooot!'))
  
                      ))
          )
      })
    }
    debugUI<-function(id){
      ns<-NS(id)
      tagList(uiOutput(ns('debug_ui')))
    }
  
    ## app -------------------------------------------------------------------------
    ui <- shinyUI(fluidPage(
      titlePanel("testing"),
      useShinyjs(),
      sidebarLayout(sidebarPanel(
        tagList(
          modsUI('foo'),
          network_visUI('foo'),
          network_visUI('foo2'),
          modsUI('foo2'),
          uiOutput('debug')
        )
      ),
      mainPanel(
        tagList(
          debugUI('foo'),
          hr(),
          testUI('bar'),
          testUI('bar2')
        )
      ))
    ))
  
  
  
    server <- shinyServer(function(input, output) {
  
      #1
      mod_input<-callModule(modsInput,'foo')
      data <- callModule(network_visInput,"foo",mod_input=mod_input)
      callModule(debugInput,"foo",obj=mod_input)
      callModule(testInput, "bar", data)
      #2
      mod_input2<-callModule(modsInput,'foo2')
      data2 <- callModule(network_visInput,"foo2",mod_input=mod_input2)
      callModule(testInput, "bar2", data2)
  
  
    })
  
    shinyApp(ui = ui, server = server)
  
  
  }
}
