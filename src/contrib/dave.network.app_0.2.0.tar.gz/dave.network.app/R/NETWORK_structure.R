###############################
# Export functions
###############################



#' Summary method
#' @param obj of class network_structure
#' @exportS3Method summary
summary.network_structure<-function(obj, edge_cutoff, ...){
  cat("Structural similarity network\n")
  if (is_not(edge_cutoff)) edge_cutoff <- 0
  edges = obj$edges[obj$edges$value > edge_cutoff,] #filter edges
  nodes = obj$nodes[obj$nodes$id %in% unique(c(edges$from, edges$to)),] #exclude unused nodes
  out <- list(nodes=nodes, edges=edges, node_mapping=obj$node_mapping, vis_config=obj$vis_config, edge_cutoff=edge_cutoff)
  print(str(out))
  cat("\n")
}

#' Plot ggplot method
#' @param obj of class network_structure
#' @exportS3Method plot
plot.network_structure<-function(obj, edge_cutoff=0,...){
  network_out <- network.ggplot(obj, edge_cutoff)
  return(network_out)
}

#' Export plotly method
#' @param obj of class network_viz
#' @exportS3Method include_graphics
include_graphics.network_structure<-function(obj, edge_cutoff, shiny=FALSE, ...){
  network_out <- network.ggplotly(obj, edge_cutoff)
  knitr::include_graphics(export(ggplotly(network_out)))
}


test<-function(){
  library(dave.network)
  library(dave.pathway)
  data("network_data")

  data<-network_data

  #generic
  idcolumn<-'CID'
  type<-"CID"

  el<-metabolic_network(data, idcolumn, type=type, net_index = net_index, node_mapping=NULL, vis_config=NULL)
  plot(el,edge_cutoff=.7)

  cidcolumn<-'CID'
  id<-data[[cidcolumn]]
  data[id=="",]<-NA
  net_index<-'Variables'

  cid_el<-network.structure(data, cidcolumn, net_index, node_mapping=NULL, vis_config=NULL)

  plot(cid_el,edge_cutoff=0)

}
