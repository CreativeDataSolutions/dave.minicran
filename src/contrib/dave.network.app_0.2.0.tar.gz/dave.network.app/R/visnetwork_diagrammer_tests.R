#testing getting vis network node positions
# and exchange with diagrammer

test<-function(){
  
  #from : https://github.com/rich-iannone/DiagrammeR/issues/171
  
  library(visNetwork)
  library(DiagrammeR)
  library(DiagrammeRsvg)
  library(xml2)
  library(htmltools)
  library(magrittr)
  
  nodes <-
    create_nodes(nodes = c("a", "b", "c", "d", "e", "f"),
                 label = TRUE,
                 fillcolor = c("lightgrey", "red", "orange", "pink",
                               "aqua", "yellow"),
                 shape = "circle",
                 value = c(2, 1, 0.5, 1, 1.8, 1),
                 type = c("1", "1", "1", "2", "2", "2"),
                 x = c(1, 2, 3, 4, 5, 6),
                 y = c(-2, -1, 0, 6, 4, 1))
  
  # Create an edge data frame
  edges <-
    create_edges(from = c("a", "b", "c", "d", "f", "e"),
                 to = c("d", "c", "a", "c", "a", "d"),
                 color = c("green", "green", "grey", "grey",
                           "blue", "blue"),
                 rel = "leading_to")
  
  # Create a graph object
  graph <- create_graph(nodes_df = nodes,
                        edges_df = edges,
                        # change layout here
                        graph_attrs = "layout = twopi")
  
  #view
  render_graph(graph)
  
  # Render the graph using Graphviz
  svg <- export_svg(render_graph(graph))
  # look at it to give us a visual check
  browsable(HTML(svg))
  # use html to bypass namespace problems
  svgh <- read_html(paste0(strsplit(svg,"\\n")[[1]][-(1:6)],collapse="\\n"))
  
  # Get positions
  node_xy <- xml_find_all(svgh,"//g[contains(@class,'node')]") %>%
  {
    data.frame(
      id = xml_text(xml_find_all(.,".//title")),
      x = xml_attr(xml_find_all(.,".//*[2]"), "cx"),
      y = xml_attr(xml_find_all(.,".//*[2]"), "cy"),
      stringsAsFactors = FALSE
    )
  }
  
  #  assuming same order
  #   easy enough to do join with dplyr, etc.
  graph$nodes_df$x <- as.numeric(node_xy$x)[order(node_xy$id)]
  graph$nodes_df$y <- -as.numeric(node_xy$y)[order(node_xy$id)]
  
 render_graph(graph, "visNetwork") %>%
    visInteraction(dragNodes = TRUE)
}

#get visnetwork coordinates:


test<-function(){
  
  #get visnet layout
  #http://stackoverflow.com/questions/39560194/mindmap-like-layout-using-visnetwork-r-package-network-visualization-using-vis
  
  nodes <- data.frame(id = 1:9, level = c(1,1,2,3,3, 4, 4, 4, 4))
  edges <- data.frame(from = c(3, 3, 3, 3, 4, 4, 5, 5), 
                      to = c(1, 2, 4, 5, 6, 7, 8, 9))
  
  
  # visNetwork(nodes, edges) %>%
  #   visHierarchicalLayout(direction = "LR")
  
  mynetwork <- visNetwork(nodes, edges) %>%
    visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
    visLayout(randomSeed = 1) %>%
    visPhysics(enabled = FALSE) # disable physics to move nodes
  
  require(shiny)
  server <- function(input, output) {
    output$network <- renderVisNetwork({
      mynetwork
    })
    
    vals <- reactiveValues(coords=NULL)
    
    output$view <- renderPrint({
      write.table(vals$coords, file = "save_coordinates.csv", sep = ";")
      vals$coords
    })
    
    observe({
      input$getcoord
      visNetworkProxy("network") %>% visGetPositions()
      vals$coords <- if (!is.null(input$network_positions)) 
        do.call(rbind, input$network_positions)
    })
  }
  
  ui <- fluidPage(
    visNetworkOutput("network", height = "800px"),
    actionButton("getcoord", "View & Save Coordinates"),
    verbatimTextOutput("view")
  )
  
  shinyApp(ui = ui, server = server)
  
}
