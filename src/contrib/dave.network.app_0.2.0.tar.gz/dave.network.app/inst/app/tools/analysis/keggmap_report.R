
# keggmap_report_params<-reactive({
#   
#   list(obj=.keggmap(),
#        summary=.summary_keggmap()$description
#   )
#   
# })

#not clear how to use the same report for multiple objects
keggmap_report_obj<-function(){
  .package<-'dave.network.app'
  report_name<-'keggmap_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path=getOption("dave.report.rmd.path")
  html_save_path= getOption('dave.report.html.path')
  
  .report_obj<-get_report_obj(.package = .package,
                              report_name= report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)
  
  
  return(.report_obj)
}


# is_available<-keggmap_available # available is reserved
name<-'kegg'

kegg_report<-callModule(reportGenerator, name,
                           report_params = keggmap_report_params,
                           report_obj= keggmap_report_obj(),
                           .available = keggmap_available)