

# calculate ---------------------------------------------------------------


## get global input dataset
pubchemmap_datasetlist <- reactive({
  input$dataset
})


output$ui_struc_cal <- renderUI({
  vars <- .getdata_col_meta() %>% colnames()
  
  selectInput(inputId = "cid_col",
              label = "Select CID column:",
              choices = vars,
              selected = state_single("cid_col",vars), #TODO
              multiple = FALSE)
})

# output$ui_struct_net_index <- renderUI({
#   vars <- .getdata_col_meta() %>% colnames()
#   selectInput(inputId = "struct_net_index",
#               label = "Network index:",
#               choices = vars,
#               selected = state_single("struct_net_index",vars),
#               multiple = FALSE)
# })

#compute network
output$ui_pubchemmap_calculate <- renderUI({
  fluidRow(
    column(4,
           div(actionButton("pubchemmap_calculate", "Calculate",icon=icon('check')))),
    column(12,hr())
  )
})


output$pubchemmap_calculate_tab_ui <- renderUI({
  req(input$dataset)
  tagList(
    uiOutput("ui_pubchemmap_calculate"),
    bs_accordion(id="pubchemmap_collapse_panel") %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("cogs") , "Methods"),
                content = 
                  fluidRow(column(12,
                    # helpText("PubChem CID based chemical similarity"),
                    uiOutput("ui_struc_cal")#,
                   # uiOutput('ui_struct_net_index')#,
                    # numericInput("pubchemmap_edge_cutoff", 
                    #              label = "Edge Cut off:", min = 0, max = 1, 
                    #              value = state_init("pubchemmap_edge_cutoff",.7), step = .01)
                  ))
      ) %>%
    bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
              content =
                fluidRow(column(12,
                  uiOutput("ui_pubchemmap_save")
                ))
      )
  )
})


#initialize data
pubchemmap_init<-
  reactive({
  # eventReactive(input$pubchemmap_calculate,{
  # isolate({
  #   if(pubchemmap_available() != 'available') return()
  #   
  #   cat('-----\nentered inner pubchemmap_init ---------\n')
    input_nodes <- .getdata_col_meta() #.getdata_cube()$col_meta 
    cid_col <- input$cid_col
    net_index<-'id'#input$struct_net_index
    type<-'CID'
    DB<-getOption('dave.network.app.CID.DB')
    
    #check
    is_empty<-c(input_nodes,cid_col,net_index) %>%
      sapply(.,is.null) %>%
      any()
    
    validate(need(!is_empty,'Select inputs to proceed'))
    
    return(list(data=input_nodes, idcolumn=cid_col,net_index=net_index,type=type,DB=DB))
  # })
})

pubchemmap_available <- reactive({
  if(is.null(input$pubchemmap_calculate) || input$pubchemmap_calculate ==0) {
    return("Calculate structural similarities between metabolites.")
  }
  
  "available"
})


.pubchemmap <- eventReactive(input$pubchemmap_calculate,{
  
  #TODO add ID validation: https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/172232379/SDF
  message('Calculating structural similarity relationships.')
  
  withProgress(message = 'Calculating structural similarity relationships.', value = 0.75, {
    # tryCatch(do.call(metabolic_network,pubchemmap_init()),error=function(e){})
    out<-ocpu_metabolic_network(dave_network_connection,body=pubchemmap_init())
    # do.call(metabolic_network,keggmap_init())
  })
  
  validate(need(out$meta$status == 201, out$path))
  
  out$results

  
  # })
})


pubchemmap_network_object<-reactive({
  
  obj<-.pubchemmap()
  
  validate(need(!is.null(obj),'Could not calculate. Make sure all inputs are valid Pubchem Compound ID numbers (CID)'))
  
  #filter in the plot module
  #need to export criteria to summary
  #obj$edges<-obj$edges#[obj$edges$value >= input$pubchemmap_edge_cutoff,]
  
  list(
    nodes = obj$nodes,
    edges = obj$edges,
    names = list(row = NULL, col = colnames(obj$nodes))
  )
  
})

# summary -----------------------------------------------------------------


.summary_pubchemmap <-reactive({
  
  if (pubchemmap_available() != "available") return(pubchemmap_available() %>% html_text_format(.) %>% list(description=.))

  #nothing or set in the plot

  #collect module summary
  #filter summary
  # network summary
  filter_summary<-NULL
  network_summary<-pubchemmap_network_object()
  
  #then filtered edges if present
  available<-pubchemmap_plot_controls()$available() # source reactive from module
  
  if(!is.null(available) && available == 'available') {
    filter_summary<-pubchemmap_plot_controls()$summary # no source?
    network_summary<-pubchemmap_plot_controls()$init
  }
  
  
  c(
    summary.kegg_obj(
      type = 'CID',
      CID_cutoff = NULL
    ),
    filter_summary,
    generic_network_summary(network_summary)
  ) %>%
    html_paragraph_format(.) %>%
    list(description = .)

})

output$.summary_pubchemmap_ui<-renderUI({

     HTML(.summary_pubchemmap()$description)

})

# report ------------------------------------------------------------------


#collect report object
pubchemmap_report_params<-reactive({
  
  list(
    plot_obj = tryCatch(pubchemmap_plot_obj(),error=function(e){NULL}),
    summary_obj =  .summary_pubchemmap()$description 
  )
  
})

# save --------------------------------------------------------------------


#Store data
output$ui_pubchemmap_save<-renderUI({
  tags$table(
    tags$td(textInput("pubchemmap_dataset", "Save result in:", paste0("similarity_network"))),
    tags$td(actionButton("pubchemmap_save", "Save"), style="padding-top:30px;")
  )
})

observeEvent(input$pubchemmap_save, {
  
  
  #default to calculate edges 
  available<-pubchemmap_available()
  validate(need(available == 'available','No objects available'))
  init<-pubchemmap_network_object()
  
  #then filtered edges if present
  available<-pubchemmap_plot_controls()$available() # source reactive from module
  if(!is.null(available) && available == 'available') init<-pubchemmap_plot_controls()$init # no source?
  
  #filtering is handled in the module
  
  
  ## saving to a new dataset if specified
  withProgress(message = "Saving", value = 1, {
    dataset <- input$pubchemmap_dataset
    el_name<-paste0(dataset,'_edges')
    node_name<-paste0(dataset,'_nodes')
    el <- init$edges
    node<- init$nodes
    r_data[[el_name]] <- el
    r_data[[node_name]] <- node
    obj<-c(el_name,node_name)
    
    r_data[['datasetlist']] %<>% c(obj,.) %>% unique()

  })
})



# module ------------------------------------------------------------------

pubchemmap_plot_controls<-callModule(network_visInput,'pubchemmap',data_obj=pubchemmap_network_object)

#network plot
pubchemmap_plot_obj<-callModule(network_vis_plotInput,'pubchemmap',data_obj=pubchemmap_plot_controls)


#tab pabnel
output$ui_pubchemmap <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel('input.tabs_pubchemmap == "Calculate"',
                     uiOutput('pubchemmap_calculate_tab_ui') 
    ),
    conditionalPanel('input.tabs_pubchemmap == "Visualize"',
                     network_visUI('pubchemmap') 
    ),
    conditionalPanel('input.tabs_pubchemmap == "Report"'),
    fluidRow(
      column(12,align="right",modalModuleUI(id="pubchemmap_help"))
    )
  )
})

output$pubchemmap <- renderUI({
  
  # #main panel
  pubchemmap_output_panels <- tabsetPanel(
    id = "tabs_pubchemmap",
    tabPanel("Calculate", icon = icon("sliders"),uiOutput('.summary_pubchemmap_ui')),
    tabPanel("Visualize",icon=icon('eye'),network_vis_plotUI('pubchemmap')),
    tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('pubchem'))
  )
  
  
  
  #
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('flask'),as.character(" Structural")))),
                 tool_ui = "ui_pubchemmap",
                 output_panels = pubchemmap_output_panels)
})

