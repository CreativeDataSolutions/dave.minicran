
## get global input dataset
networkmap_datasetlist <- reactive({
  input$dataset
})

networkmap_values<-reactiveValues()

# save --------------------------------------------------------------------

output$ui_networkmap_save<-renderUI({
  tags$table(
    tags$td(textInput("networkmap_dataset", "Network name", paste0("network"))),
    tags$td(actionButton("networkmap_save", "Save"), style="padding-top:30px;")
  )
})

observeEvent(input$networkmap_calculate,{
  
  name<-paste0(input$dataset,"_network")
  updateTextInput(session,'networkmap_dataset', value = name)
  
})


observeEvent(input$networkmap_save, {
 
  #default to calculate edges 
  available<-networkmap_available()
  validate(need(available == 'available','No objects available'))
  init<-.combine_nets()
  
  #then filtered edges if present
  available<-networkmap_plot_controls()$available() # source reactive from module
  if(!is.null(available) && available == 'available') init<-networkmap_plot_controls()$init # no source?
  
  withProgress(message = "Saving", value = 1, {
    dataset <- input$networkmap_dataset
    el_name<-paste0(dataset,'_edges')
    node_name<-paste0(dataset,'_nodes')
    el <- init$edges
    node<- init$nodes
    r_data[[el_name]] <- el
    r_data[[node_name]] <- node
    obj<-c(el_name,node_name)
    
    r_data[['datasetlist']] %<>% c(obj,.) %>% unique()
  })
  
  
})

# calculate ---------------------------------------------------------------

#Edge lists
output$ui_edge_list <- renderUI({
  #get all data set names
  vars <- r_data$datasetlist[grepl("_edges",r_data$datasetlist)]
  
  fluidRow(column(12,selectInput(inputId = "edge_list",
              label = "Select networks:",
              choices = vars, selectize = TRUE,
              multiple = TRUE),
           checkboxInput('edge_list_dupes','single edges',value=TRUE)
  ))
})

#show network
output$ui_networkmap_calculate <- renderUI({
  fluidRow(column(12,
                  actionButton("networkmap_calculate", "Calculate",icon=icon('check'))
  ))
  
})

#calculate UI
output$networkmap_calculate_tab_ui<-renderUI({
  tagList(
    fluidRow(column(12,
                    uiOutput(
                      "ui_networkmap_calculate"
                    ))),
    br(),
    bs_accordion(id = "networkmap_collapse_panel") %>%
      bs_append(
        title = tags$label(class = 'bsCollapsePanel', icon("mouse-pointer") , "Select"),
        content =
          fluidRow(column(12,
                          uiOutput("ui_edge_list")))
      ) %>%
      bs_append(
        title = tags$label(class = 'bsCollapsePanel', icon("adjust") , "Update"),
        content =
          fluidRow(column(12,
                          uiOutput(
                            "update_nodes_ui"
                          )))
      ) %>%
      bs_append(
        title = tags$label(class = 'bsCollapsePanel', icon("save") , "Save"),
        content =
          fluidRow(column(12,
                          uiOutput(
                            "ui_networkmap_save"
                          )))
      )
  )
})


#initialize data
networkmap_init<-eventReactive(input$networkmap_calculate,{
  
  check<-networkmap_available()
  validate(need(check == 'available',check))
  
  
  #TODO make this only run on calculate  not plot
  #create net obj list
  net_obj<-lapply(input$edge_list, function(x){
    list(nodes=r_data[[.get_net_nodes(x)]],
         edges= r_data[[x]])
  })
  
  #join networks
  full_obj<-join_networks(net_obj)
  if(input$edge_list_dupes) {
    edge_l<-full_obj$edges %>%
      remove_edge_dupes() #optionally remove duplicates based on rbind order for types
  } else{
    edge_l<-full_obj$edges
  }  
  
  nodes_l<-full_obj$nodes
  
  #update nodes based on var meta
  #need data
  
  if(!is.null(input$update_nodes_select) && input$update_nodes_select){
    
    #check<-!sapply(list(input$update_nodes_meta_id,input$update_nodes_meta), is.null) %>% any()
  
    #if(check){
    
      meta<-r_data[[input$update_nodes_meta]]
      # net_index=input$update_nodes_meta_id
      #need to make sure id types match
       .nodes_l<-tryCatch(update_nodes(nodes_l,meta,net_index='id',child=input$update_nodes_child),
                          error=function(e){NULL})
  
       
       if(!is.null(.nodes_l)) nodes_l<-.nodes_l
  
    #}

  }
  
  list(nodes=nodes_l, edges=edge_l,names=list(row=NULL,col=colnames(nodes_l)))

})

#TODO need to update
#node attributes
#if checked box then try to add
#col attributes to the network?
#mostly left join on index to get new columns?
#problems need to specify index and meta data
#set index as an atribute?

compatible_nodes<-reactive({
  
  obj<-r_data$datasetlist
  id<-grepl("_nodes",obj)
  id<-id | grepl("_col_meta",obj)
  
  #verify that there is a shared index
  
  r_data$datasetlist[id]
  
})

#check if index shared between nodes and meta 
compatible_index<-reactive({
  

  check<-!is.null(input$edge_list)
  if(!check) return()
  # validate(need(check,'Select networks to update.'))
  
  if(is.null(input$update_nodes_select)) return()
  if(is.null(input$update_nodes_meta)) return()
  
  if(input$update_nodes_select){

    #meta data
    meta<-r_data[[input$update_nodes_meta]] %>% colnames()
    
    #get nodes
    nodes<-lapply(.get_net_nodes(input$edge_list),function(x){r_data[[x]] %>% colnames()}) %>%
      Reduce(intersect,.)
    
    nodes[nodes %in% meta]
    
  }
  
})


output$update_nodes_meta_ui<-renderUI({
  
  check<-!is.null(input$edge_list)
  validate(need(check,'Select networks to update.'))
  
  #allow compatible data
  meta_vars<-compatible_nodes()
  
  fluidRow(column(12,
                  checkboxInput('update_nodes_child','overwrite current',value = TRUE),
                  selectizeInput('update_nodes_meta','update with',choices=meta_vars)#,
                  #uiOutput('update_nodes_meta_id_ui')
  ))
  
})

#index retriggers meta
# output$update_nodes_meta_id_ui<-renderUI({
#   
#   index_vars<-compatible_index()
#   
#   selectizeInput('update_nodes_meta_id','on index',choices=index_vars)
#   
# })

output$update_nodes_ui<-renderUI({

  
  fluidRow(column(12,
                  checkboxInput('update_nodes_select','update node attributes',value = FALSE),
                  conditionalPanel(condition = "input.update_nodes_select",
                    uiOutput('update_nodes_meta_ui')
                  )
                ))
  
})

#configure network object
networkmap_network_object<-reactive({
  
 networkmap_init()
  
 
})


networkmap_available <- reactive({

  
  if(is.null(input$networkmap_calculate) || input$networkmap_calculate ==0) {
    return("To combine compatible networks, select edge lists and calculate.")
  }
  # if (is.na(input$networkmap_calculate))
  #   return("Please choose a comparison value")
  
  if (is.null(input$edge_list))
    return("Please choose an edge list or calculate one.") #nothing selected
  
  
  "available"
})


#change to a network merge only
.combine_nets <- reactive({
  withProgress(message = "Calculating", value = 1, {
    out<-networkmap_network_object()
    class(out)<-c(class(networkmap_network_object()),'network_viz') %>% unique()
    out
    # do.call(network.visualize, networkmap_init())
  })
})


# summary -----------------------------------------------------------------


.summary_networkmap <-reactive({
  if (networkmap_available() != "available") return(networkmap_available() %>% html_text_format(.) %>% list(description=.))
  
  #filter summary
  filter_summary<-NULL
  network_summary<-networkmap_network_object()
  
  #then filtered edges if present
  available<-networkmap_plot_controls()$available() # source reactive from module
  
  if(!is.null(available) && available == 'available') {
    filter_summary<-networkmap_plot_controls()$summary # no source?
    network_summary<-networkmap_plot_controls()$init
  }
  

  tmp<-if(length(input$edge_list)>1){
    ' were combined.'
  } else {
    ' was selected.'
  }
  paste0('The ',c(input$edge_list %>% gsub('_edges','',.) %>% grammatical_paste()),tmp) %>% 
    c(.,
      filter_summary,
      generic_network_summary(network_summary)
      ) %>% 
    html_paragraph_format(.) %>%
    list(description=.)
})

output$.summary_networkmap_ui<-renderUI({

   HTML(.summary_networkmap()$description)

})



# module ------------------------------------------------------------------
 
networkmap_plot_controls<-callModule(network_visInput,'networkmap',data_obj=networkmap_network_object)

#network plot
networkmap_plot_obj<-callModule(network_vis_plotInput,'networkmap',data_obj=networkmap_plot_controls)

#collect report object
networkmap_report_params<-reactive({

  # browser()
  
  list(
    plot_obj = tryCatch(networkmap_plot_obj(),error=function(e){NULL}),
    summary_obj =  .summary_networkmap()$description 
  )
  
})


# UI ----------------------------------------------------------------------


#sidebar UI
output$ui_networkmap <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel('input.tabs_networkmap == "Calculate"',
                     uiOutput('networkmap_calculate_tab_ui') 
    ),
    conditionalPanel('input.tabs_networkmap == "Visualize"',
                     network_visUI('networkmap') 
    ),
    conditionalPanel('input.tabs_networkmap == "Report"'),
    fluidRow(column(
      12, align = "right", modalModuleUI(id = "vismap_help")
    ))
  )
})

output$networkmap <- renderUI({

  # #main panel
  networkmap_output_panels <- tabsetPanel(
    id = "tabs_networkmap",
    tabPanel("Calculate", icon = icon("sliders"),uiOutput('.summary_networkmap_ui')),
    tabPanel("Visualize",icon=icon('eye'),network_vis_plotUI('networkmap')),
    tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('network'))
  )
  
 
  
  #
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('plus'),as.character(" Enrich")))),
                 tool_ui = "ui_networkmap",
                 output_panels = networkmap_output_panels)
})