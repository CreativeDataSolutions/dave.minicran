
# network common funs
#used in app
#get linked edges and nodes

.get_net_nodes<-function(el){
  gsub('_edges','_nodes',el)
}

