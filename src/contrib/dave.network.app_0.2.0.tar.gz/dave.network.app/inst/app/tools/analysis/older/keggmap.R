# # main fun keggmap
# ## list of function arguments
# keggmap_args <- as.list(formals(init_data))
# 
# ## list of function inputs selected by user
# keggmap_inputs <- reactive({
#   ## loop needed because reactive values don't allow single bracket indexing
#   # keggmap_args$arg<-input$something
#   # keggmap_args$
#   
#   for (i in r_drop(names(keggmap_args)))
#     keggmap_args[[i]] <- input[[paste0("keggmap_",i)]]
#   keggmap_args
# })
# 
# ## get global input dataset
# keggmap_datasetlist <- reactive({
#   input$dataset
# })
# 
# ###############################
# # Left menu
# ###############################
# #KEGG calculation
# output$ui_kegg_cal <- renderUI({
#   vars <- .getdata_col_meta() %>% colnames()#colnames(r_data[[keggmap_datasetlist()]])
#   fluidRow(column(12,
#   helpText('Calculate KEGG based biochemical connections'),
#   selectInput(inputId = "kegg_col",
#               label = "KEGG id:",
#               choices = vars,
#               selected = state_single("kegg_col",vars),
#               multiple = FALSE)
#   ))
# })
# 
# #network index
# output$ui_kegg_net_index <- renderUI({
#   vars <- .getdata_col_meta() %>% colnames()#colnames(r_data[[keggmap_datasetlist()]])
#   selectInput(inputId = "kegg_net_index",
#               label = "Network index:",
#               choices = vars,
#               selected = state_single("kegg_net_index",vars),
#               multiple = FALSE)
# })
# 
# #basic plotting controls 
# output$ui_keggmap_select_node_label<-renderUI({
#   
#   vars <- .getdata_col_meta() %>% colnames() %>%
#     c('none',.)
#   fluidRow(
#     column(12,
#            selectInput(inputId = "keggmap_select_node_label", label = "Label", 
#                        choices = vars, selected = state_single("keggmap_select_node_label",vars), multiple = F),
#            checkboxInput('keggmap_repel_node_label','repel labels',value = FALSE)
#     )
#   )
#   
# })
# 
# outputOptions(output, "ui_keggmap_select_node_label", suspendWhenHidden = FALSE)
# 
# 
# 
# #compute network
# output$ui_keggmap_calculate <- renderUI({
#   actionButton("keggmap_calculate", "Calculate")
# })
# #Store data
# output$ui_keggmap_save<-renderUI({
#   tags$table(
#     tags$td(textInput("keggmap_dataset", "Save result in:", paste0("biochem_network"))),
#     tags$td(actionButton("keggmap_save", "Save"), style="padding-top:30px;")
#   )
# })
# 
# ###############################
# # renderUI output
# ###############################
# output$ui_keggmap <- renderUI({
#   req(input$dataset)
#   tagList(
#     bs_accordion(id="keggmap_collapse_panel") %>%
#       bs_append(title = tags$label(class='bsCollapsePanel', icon("cogs") , "Biochemical"),
#                 content = 
#                   fluidRow(column(12,
#                     uiOutput("ui_kegg_cal"),
#                     uiOutput('ui_kegg_net_index'),
#                     uiOutput("ui_keggmap_calculate"),
#                     uiOutput("ui_keggmap_select_node_label"))
#                   )
#       ) %>%
#       bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
#                 content =
#                   fluidRow(column(12,uiOutput("ui_keggmap_save")))
#       ),
#     fluidRow(
#       column(12,align="right",modalModuleUI(id="keggmap_help")))
#     )
# })
# 
# #setup plot
# keggmap_plot <- reactive({
#   plh <- 600
#   plw <- 800
#   list(plot_width=plw, plot_height=plh)
# })
# 
# keggmap_plot_width <- function()
#   keggmap_plot() %>% { if (is.list(.)) .$plot_width else 800 }
# 
# keggmap_plot_height <- function()
#   keggmap_plot() %>% { if (is.list(.)) .$plot_height else 600 }
# 
# #initialize data
# keggmap_init<-reactive({
#   input_nodes <-.getdata_col_meta()  
#   kegg_col <- input$kegg_col
#   net_index<-input$kegg_net_index
#   type<-'KEGG'
# 
#   #mapping parameters
#   #TODO make module
#   node_mapping<-list(node_label=input$keggmap_select_node_label)#, 
#                      #node_col=input$select_node_color, 
#                      #node_size=input$select_node_size,
#                      #node_size_range=input$select_node_size_limits, 
#                      #node_shape=input$select_node_shape)
#   
#   #enforce unique net index?
#   return(list(data=input_nodes, idcolumn=kegg_col,net_index=net_index,type=type,node_mapping=node_mapping))
# 
# })
# 
# keggmap_available <- reactive({
#   if(is.null(input$keggmap_calculate) || input$keggmap_calculate ==0) {
#     return("This analysis is used to link compatible sample and variable meta data. Select accordingly and then calculate.")
#   }
#   if (is.na(input$keggmap_calculate))
#     return("Please choose a comparison value")
#   "available"
# })
# 
# ###############################
# # main functions
# ###############################
# .keggmap <- reactive({
# 
#   isolate({
#     withProgress(message = "Calculating", value = 1, {
#       # browser()
#       do.call(metabolic_network,keggmap_init())
#       # do.call(network.biochemical, keggmap_init())
#     })
#   })
# })
# 
# .summary_keggmap <-reactive({
#   if (keggmap_available() != "available") return(keggmap_available() %>% html_text_format(.) %>% list(description=.))
#   # summary(.keggmap())
#   summary.kegg_obj(type='KEGG')  %>% 
#     html_paragraph_format(.) %>%
#     list(description=.)
# })
# 
# output$.summary_keggmap_ui<-renderUI({
#   
#   # fluidRow(
#   #   column(12,
#            HTML(.summary_keggmap()$description)
#   #   )
#   # )
#   
# })
# 
# .plot_keggmap <- reactive({
#   if (keggmap_available() != "available") {
#     #block character render
#     msg<-keggmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   withProgress(message = "Plotting", value = 1, {
#     plot(.keggmap(), repel=input$keggmap_repel_node_label, shiny = TRUE)
#   })
# })
# 
# #plotly
# output$plotly_keggmap <- renderPlotly({
#   if (keggmap_available() != "available") {
#     #block character render
#     msg<-keggmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   # browser()
#   withProgress(message = "Plotting", value = 1, {
#     plot_g <- plot(.keggmap(),curvature=0)
#     ggplotly(plot_g)
#   })
# })
# 
# #visNetwork
# output$network_keggmap <- renderVisNetwork({
#   if (keggmap_available() != "available") {
#     #block character render
#     msg<-keggmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   withProgress(message = "Plotting", value = 1, {
#     network.visnetwork(.keggmap())
#   })
# })
# 
# #create controls for multiple explore
# output$keggmap_explore_ui<-renderUI({
#   
#   fluidRow(
#     column(12,radioButtons("keggmap_explore_plot_type",'', 
#                            c("static" = "static", "dynamic" = "dynamic"), selected = 'static', inline=T)),
#     column(12,
#            conditionalPanel(condition = "input.keggmap_explore_plot_type == 'dynamic'", visNetworkOutput("network_keggmap")),
#            conditionalPanel(condition = "input.keggmap_explore_plot_type == 'static'", plotlyOutput("plotly_keggmap"))
#     )
#   )
#   
# })
# 
# ###############################
# # output is called from the main dave ui.R
# ###############################
# output$keggmap <- renderUI({
#   register_print_output("summary_keggmap", ".summary_keggmap" )
#   register_plot_output("plot_keggmap", ".plot_keggmap",
#                        height_fun = "keggmap_plot_height", width_fun = "keggmap_plot_width")
#   
#   # two separate tabs
#   keggmap_output_panels <- tabsetPanel(
#     id = "tabs_keggmap",
#     tabPanel("Calculate", icon = icon("sliders"),uiOutput('.summary_keggmap_ui')),
#     tabPanel("Explore",icon=icon('pencil-square-o'),uiOutput('keggmap_explore_ui')),
#     tabPanel("Plot",icon = icon("bar-chart"),
#              plotOutput("plot_keggmap", height = "100%")),
#     tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('kegg'))#uiOutput('keggmap_report_ui'))
#   )
#   stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
#                  tool = tags$span(class='cer_menue',HTML(paste0(icon('flask'),as.character(" Biochemical")))),
#                  tool_ui = "ui_keggmap",
#                  output_panels = keggmap_output_panels)
# })
# 
# ###############################
# # observeEvent for actionButton
# ###############################
# #report
# observeEvent(input$keggmap_report, {
#   figs <- FALSE
#   outputs <- c("summary")
#   inp_out <- list(list(show = input$keggmap_show))
#   if (length(input$keggmap_plots) >= 0) {
#     outputs <- c("summary","plot")
#     inp_out[[2]] <- list(plot.setup = keggmap_plot(), plot.type="ggplot")
#     #inp_out[[3]] <- list(path = "")
#     figs <- TRUE
#   }
#   update_report(inp_main = clean_args(keggmap_inputs(), keggmap_args),
#                 fun_name = ".keggmap",
#                 inp_out = inp_out, outputs = outputs, figs = figs,
#                 fig.width = keggmap_plot_width(),
#                 fig.height = keggmap_plot_height())
# })
# 
# #save
# observeEvent(input$keggmap_save, {
#   ## saving to a new dataset if specified
#   #save edges and associated node attributes
#   # browser()
#   
#   withProgress(message = "Saving", value = 1, {
#     dataset <- input$keggmap_dataset
#     el_name<-paste0(dataset,'_edges')
#     node_name<-paste0(dataset,'_nodes')
#     el <- .keggmap()$edges
#     node<- .keggmap()$nodes
#     r_data[[el_name]] <- el
#     r_data[[node_name]] <- node
#     obj<-c(el_name,node_name)
#     #need this
#     # for(i in obj){
#     #   r_data[[paste0(el_name,"_descr")]] <- r_data[[paste0(el_name,"_descr")]]
#     #   r_data[[paste0(node_name,"_descr")]] <- r_data[[paste0(node_name,"_descr")]]
#     # }
#     r_data[['datasetlist']] %<>% c(obj,.) %>% unique()
#   })
# })