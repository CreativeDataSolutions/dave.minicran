# # main fun networkmap
# ## list of function arguments
# networkmap_args <- as.list(formals(init_data))
# 
# ## list of function inputs selected by user
# networkmap_inputs <- reactive({
#   ## loop needed because reactive values don't allow single bracket indexing
#   # networkmap_args$arg<-input$something
#   # networkmap_args$
# 
#   for (i in r_drop(names(networkmap_args)))
#     networkmap_args[[i]] <- input[[paste0("networkmap_",i)]]
#   networkmap_args
# })
# 
# ## get global input dataset
# networkmap_datasetlist <- reactive({
#   input$dataset
# })
# 
# networkmap_values<-reactiveValues()
# 
# ###############################
# # Left menu
# ###############################
# #Edge lists
# output$ui_edge_list <- renderUI({
#   #get all data set names
#   vars <- r_data$datasetlist[grepl("_edges",r_data$datasetlist)]
#   selectInput(inputId = "edge_list",
#               label = "Select networks:",
#               choices = vars, selectize = TRUE, 
#               multiple = TRUE)
# })
# 
# #nodes
# output$ui_select_node_label<-renderUI({
#   
#   vars<-'none'
#   fluidRow(
#     column(12,
#       selectInput(inputId = "select_node_label", label = "Label", 
#               choices = vars, selected = state_single("select_node_label",vars), multiple = F),
#       checkboxInput('repel_node_label','repel labels',value = FALSE)
#       )
#   )
#  
# })
# 
# output$ui_select_node_color<-renderUI({
#   vars <- 'none'
#   selectInput(inputId = "select_node_color", label = "Color", choices = vars, selected = state_single("select_node_color",vars), multiple = F)
# })
# 
# output$ui_select_node_size<-renderUI({
#   vars <- 'none'
#   fluidRow(column(12,
#           selectInput(inputId = "select_node_size", label = "Size", 
#                       choices = vars, selected = state_single("select_node_size",vars), multiple = F),
#           sliderInput('select_node_size_limits','limits',min=0,max=20,value=c(1,5),step=.25)
#           )
#   )
#   
# })
# 
# output$ui_select_node_shape<-renderUI({
#   
#   vars <- 'none'
#   selectInput(inputId = "select_node_shape", label = "Shape", choices = vars, selected = state_single("select_node_shape",vars), multiple = F)
# })
# 
# #update node inputs based on the node data
# observe({
#  
#   
#   if(is.null(input$networkmap_calculate) || input$networkmap_calculate==0) return()
#   # vars<-networkmap_values[['networkmap_init']]$nodes
#   isolate({
#     vars<-networkmap_init()$nodes#networkmap_values[['networkmap_init']]$nodes
#     if(is.null(vars)) return()
#     vars <- c("none",colnames(vars))
#     ids<-c("select_node_label","select_node_color","select_node_size","select_node_shape")
#     for(i in 1:length(ids)){
#       local({
#         updateSelectInput(session=session,inputId = ids[i],choices=vars)
#       })
#     }
#   })
#   
# })
# 
# #edge properties
# output$ui_edge_attr<-renderUI({
#   fluidRow(
#     column(12,
#            numericInput('edge_curvature','curve',min=0,max=1,value=.1)
#     )
#   )
# })
# 
# outputOptions(output, "ui_edge_attr", suspendWhenHidden = FALSE)
# 
# #Store data
# output$ui_networkmap_save<-renderUI({
#   tags$table(
#     tags$td(textInput("networkmap_dataset", "Network name", paste0("network"))),
#     tags$td(actionButton("networkmap_save", "Save"), style="padding-top:30px;")
#   )
# })
# 
# observeEvent(input$networkmap_calculate,{
#   
#   name<-paste0(input$dataset,"_network")
#   updateTextInput(session,'networkmap_dataset', value = name)
#   
# })
# 
# 
# #show network
# output$ui_networkmap_calculate <- renderUI({
#   fluidRow(column(12,
#                   actionButton("networkmap_calculate", "Select",icon=icon('check'))
#                 ))
# 
# })
# 
# # react to the network update
# output$network_plot_calculate_ui<-renderUI({
#   fluidRow(
#     column(12,
#       actionButton('network_plot_calculate','Plot',icon=icon('share-alt'))
#     )
#   )
# })
# 
# ###############################
# # renderUI output
# ###############################
# output$ui_networkmap <- renderUI({
#   req(input$dataset)
#   tagList(
#     conditionalPanel(condition = "input.tabs_networkmap == 'Calculate'",
#      tagList(
#        fluidRow(column(12,
#                        uiOutput("ui_networkmap_calculate")
#        )),
#        br(),
#         bs_accordion(id="networkmap_collapse_panel") %>%
#           bs_append(title = tags$label(class='bsCollapsePanel', icon("share-alt") , "Networks"),
#                     content = 
#                       fluidRow(column(12,            
#                         uiOutput("ui_edge_list")
#                       ))
#         ) %>%
#           bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
#                     content=
#                       fluidRow(column(12,
#                                 # uiOutput("ui_coord_save")#,
#                                 # # br(),
#                                 # # actionButton("coord_save", "Save"),
#                                 uiOutput("ui_networkmap_save")
#                       ))
#         )
#       )
#     ),
#     conditionalPanel(condition = "input.tabs_networkmap != 'Calculate'",
#       tagList(
#         conditionalPanel(condition = "input.tabs_networkmap != 'Report'",
#         fluidRow(column(12,
#                         uiOutput('network_plot_calculate_ui')
#         ))),
#          br(),
#          bs_accordion(id="networkmap_plot_collapse_panel") %>%
#          bs_append(title = tags$label(class='bsCollapsePanel', icon("circle") , "Nodes"),
#                    content = 
#                      fluidRow(column(12, 
#                           uiOutput("ui_select_node_label"),
#                           uiOutput("ui_select_node_color"),
#                           uiOutput("ui_select_node_size"),
#                           uiOutput("ui_select_node_shape")
#                      ))
#          ) %>%
#          bs_append(title = tags$label(class='bsCollapsePanel', icon("arrows-h") , "Edges"),
#                    content = 
#                      fluidRow(column(12,
#                         uiOutput('ui_edge_attr')
#                      ))
#         ) %>%
#         bs_append(title = tags$label(class='bsCollapsePanel', icon("square") , "Canvas"),
#                   content = 
#                     fluidRow(column(12,
#                                     uiOutput('networkmap_plot_global_ui')
#                     ))
#         )
#       )
#     ),
#     conditionalPanel(condition = "input.tabs_networkmap == 'Visnetwork'",
#        bs_accordion(id="networkmap_plot_collapse_panel") %>%
#          bs_append(title = tags$label(class='bsCollapsePanel', icon("cogs") , "Options"),
#                    content = 
#                      fluidRow(column(12, 
#                         uiOutput("ui_select_nodes"),
#                         hr(),
#                         h4("Options"),
#                         checkboxInput("vis_physic", "Disable stabilization", value = FALSE),
#                         checkboxInput("vis_config", "Show configuration", value = FALSE),
#                         checkboxInput("vis_manip", "Show manipulation", value = FALSE),
#                         checkboxInput("vis_nav", "Show navigation", value = FALSE)
#                      ))
#       )
#     ),
#     fluidRow(
#       column(12,align="right",modalModuleUI(id="vismap_help")))
#   )
# })
# 
# #initialize
# outputOptions(output, "ui_select_node_label", suspendWhenHidden = FALSE)
# outputOptions(output, "ui_select_node_color", suspendWhenHidden = FALSE)
# outputOptions(output, "ui_select_node_size", suspendWhenHidden = FALSE)
# outputOptions(output, "ui_select_node_shape", suspendWhenHidden = FALSE)
# 
# #plot global controls
# output$networkmap_plot_global_ui<-renderUI({
#   fluidRow(
#     column(12,
#            tags$table(
#              tags$td(numericInput("networkmap_plot_width_value", "width", min=400,step=100,value=1250)),
#              tags$td(numericInput("networkmap_plot_height_value", "height", min=400,step=100,value=600))
#            )
#     )
#   )
# })
# 
# 
# #setup plot
# networkmap_plot <- reactive({
#   plh <- input$networkmap_plot_height_value
#   plw <- input$networkmap_plot_width_value
#   
#   list(plot_width=plw, plot_height=plh)
# })
# 
# networkmap_plot_width <- function()
#   networkmap_plot() %>% { if (is.list(.)) .$plot_width else 800 }
# 
# networkmap_plot_height <- function()
#   networkmap_plot() %>% { if (is.list(.)) .$plot_height else 600 }
# 
# #initialize node data
# 
# #initialize data
# networkmap_init<-reactive({
#   validate(need(!is.null(input$edge_list) == TRUE,'Select networks to view'))
#   
#   #TODO make this only run on calculate  not plot
#   #create net obj list
#   net_obj<-lapply(input$edge_list, function(x){
#     list(nodes=r_data[[.get_net_nodes(x)]],
#          edges= r_data[[x]])
#   })
#   
#   #join networks
#   full_obj<-join_networks(net_obj)
#   edge_l<-full_obj$edges %>%
#     remove_edge_dupes() #remove duplicates based on rbind order for types
#   node_l<-full_obj$nodes
#   # browser()
#   #combine nodes
#   #TODO:plotting might have to be added later
#   is_none<-function(x){ is.null(x) || x =='none' | x == '' }
#   
#   mapping_opt = list(node_label=input$select_node_label, 
#                      node_col=input$select_node_color, 
#                      node_size=input$select_node_size,
#                      node_size_range=input$select_node_size_limits, 
#                      node_shape=input$select_node_shape)
#   visnetwork_opt = list(select_by=input$select_nodes, vis_physic=input$vis_physic, vis_config=input$vis_config, vis_manip=input$vis_manip, vis_nav=input$vis_nav)
#   
#   #change none to NULL
#   #TODO control reactivity
#   id<-sapply(mapping_opt,is_none)
#   mapping_opt[id]<-NULL
# 
#   id<-sapply(visnetwork_opt,is_none)
#   visnetwork_opt[id]<-NULL
#     
#   networkmap_values[['networkmap_init']]<-list(nodes=node_l, edges=edge_l, node_mapping=mapping_opt, vis_config=visnetwork_opt)
# 
#   return(networkmap_values[['networkmap_init']])
#   #return(list(nodes=r_data[[input$node_attr]], edges=edge_l))
# })
# 
# networkmap_available <- reactive({
# 
#   
#   if(is.null(input$networkmap_calculate) || input$networkmap_calculate ==0) {
#     return("This analysis is used to link compatible sample and variable meta data. Select accordingly and then calculate.")
#   }
#   if (is.na(input$networkmap_calculate))
#     return("Please choose a comparison value")
#   
#   if (is.null(input$edge_list))
#     return("Please choose a network or calculate one.") #nothing selected
#   
#   
#   "available"
# })
# 
# ###############################
# # main functions
# ###############################
# .networkmap <- reactive({
#   withProgress(message = "Calculating", value = 1, {
#   
#     do.call(network.visualize, networkmap_init())
#   })
# })
# 
# .summary_networkmap <-reactive({
#   if (networkmap_available() != "available") return(networkmap_available() %>% html_text_format(.) %>% list(description=.))
#   
#   paste0('Networks ',c(input$edge_list %>% gsub('_edges','',.) %>% grammatical_paste()),' were combined.') %>% 
#     c(.,summary(.networkmap())) %>% 
#     html_paragraph_format(.) %>%
#     list(description=.)
# })
# 
# output$.summary_networkmap_ui<-renderUI({
#   
#   # fluidRow(
#   #   column(12,
#            HTML(.summary_networkmap()$description)
#   #   )
#   # )
#   
# })
# 
# .plot_networkmap <- eventReactive(input$network_plot_calculate,{
#   
#   if (networkmap_available() != "available") {
#     #block character render
#     msg<-networkmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   
#   if(!input$tabs_networkmap %in% c('Plot','Explore')) return()
#   networkmap_values[['networkmap']]<-.networkmap()
#   # browser() # debug(dave.network:::network.ggplotly)
#   withProgress(message = "Plotting", value = 1, {
#     if(input$tabs_networkmap  == 'Plot'){
#       plot(.networkmap(), repel=input$repel_node_label,curvature=input$edge_curvature) 
#     } else {
#       return(plot(.networkmap(),curvature=0))
#     }
# 
#   })
# })
# 
# #plotly
# output$plotly_networkmap <- renderPlotly({
#   
#   plot_g<-.plot_networkmap()
#   ggplotly(plot_g) %>% layout(height = networkmap_plot_height(), width = networkmap_plot_width())
#   
#   # validate(need(networkmap_available() == "available",'Calculate to view results'))
# 
#   # if (networkmap_available() != "available") {
#   #  #block character render
#   #    msg<-networkmap_available()
#   #    validate(need(!is.character(msg),msg))
#   # }
#   # 
#   # withProgress(message = "Plotting", value = 1, {
#   #   plot_g <- plot(.networkmap(),curvature=0) #network.ggplotly(.networkmap())
#   #   ggplotly(plot_g) %>% layout(height = networkmap_plot_height(), width = networkmap_plot_width())
#   # })
# })
# 
# #visNetwork why naming?
# output$network_networkmap <- renderVisNetwork({
#   
#   if (networkmap_available() != "available") {
#     #block character render
#     msg<-networkmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   
#   obj<-.networkmap()
#   # browser()
#   .text<-hover_text(obj)
#   obj$nodes$text<-.text
#   obj$node_mapping$node_index<-'id' # hack to get ggplot obj to match up with nodes
#   
#   withProgress(message = "Plotting", value = 1, {
#     network.visnetwork(obj)
#   })
# })
# 
# # #coordinates
# # output$view <- renderPrint({
# #   as.data.frame(vals$coords, optional = T)
# # })
# 
# output$networkmap_explore_ui<-renderUI({
#   
#   fluidRow(
#     column(12,radioButtons("networkmap_explore_plot_type",'', 
#                            c("static" = "static", "dynamic" = "dynamic"), selected = 'static', inline=T)),
#     column(12,
#            conditionalPanel(condition = "input.networkmap_explore_plot_type == 'dynamic'", visNetworkOutput("network_networkmap")),
#            conditionalPanel(condition = "input.networkmap_explore_plot_type == 'static'", plotlyOutput("plotly_networkmap"))
#     )
#   )
#   
# })
# 
# ###############################
# # output is called from the main dave ui.R
# ###############################
# output$networkmap <- renderUI({
#   register_print_output("summary_networkmap", ".summary_networkmap" )
#   register_plot_output("plot_networkmap", ".plot_networkmap",
#                        height_fun = "networkmap_plot_height", width_fun = "networkmap_plot_width")
# 
#   # two separate tabs
#   networkmap_output_panels <- tabsetPanel(
#     id = "tabs_networkmap",
#     tabPanel("Calculate", icon = icon("sliders"),uiOutput('.summary_networkmap_ui')),
#     tabPanel("Explore",icon=icon('pencil-square-o'),uiOutput('networkmap_explore_ui')),
#     tabPanel("Plot",icon = icon("bar-chart"),
#              plotOutput("plot_networkmap", height = "100%")),
#     tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('network'))#uiOutput('networkmap_report_ui'))
#   )
#   stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
#                  tool = tags$span(class='cer_menue',HTML(paste0(icon('eye'),as.character(" Visualize")))),
#                  tool_ui = "ui_networkmap",
#                  output_panels = networkmap_output_panels)
# })
# 
# ###############################
# # observeEvent for actionButton
# ###############################
# #report
# observeEvent(input$networkmap_report, {
#   figs <- FALSE
#   outputs <- c("summary")
#   inp_out <- list(list(show = input$networkmap_show))
#   if (length(input$networkmap_plots) >= 0) {
#     outputs <- c("summary","plot")
#     inp_out[[2]] <- list(plot.setup = networkmap_plot(), plot.type="ggplot")
#     #inp_out[[3]] <- list(path = "")
#     figs <- TRUE
#   }
#   update_report(inp_main = clean_args(networkmap_inputs(), networkmap_args),
#                 fun_name = ".networkmap",
#                 inp_out = inp_out, outputs = outputs, figs = figs,
#                 fig.width = networkmap_plot_width(),
#                 fig.height = networkmap_plot_height())
# })
# 
# #save
# #TODO add binding variables
# #allow export of network to 
# #various formats e.g cytoscape
# #add slot to data cube for edges?
# observeEvent(input$networkmap_save, {
#   ## saving to a new dataset if specified
#   dataset <- input$networkmap_dataset
#   networkmapdf <- .networkmap()$edges
#   r_data[[dataset]] <- networkmapdf
#   # r_data[[paste0(dataset,"_descr")]] <- r_data[[paste0(input$dataset,"_descr")]]
#   r_data[['datasetlist']] %<>% c(dataset,.) %>% unique
# })
# 
# # #save coordinate
# # vals <- reactiveValues(coords=NULL)
# # observeEvent(input$coord_save, {
# #   ## saving to a new dataset if specified
# #   visNetworkProxy("network") %>% visGetPositions()
# #   if (!is.null(input$network_positions)){
# #     vals$coords <- do.call(rbind, input$network_positions)
# #   }
# #   dataset <- input$coord_data
# #   networkmapdf <- as.data.frame(vals$coords, optional = T)
# #   r_data[[dataset]] <- networkmapdf
# #   r_data[[paste0(dataset,"_descr")]] <- r_data[[paste0(input$dataset,"_descr")]]
# #   r_data[['datasetlist']] %<>% c(dataset,.) %>% unique
# # })