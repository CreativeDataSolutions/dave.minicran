
options(network_ui =
  tagList(
    navbarMenu("Network", icon=icon('share-alt'),
               shinyjs::useShinyjs(),
               tabPanel("Translate", uiOutput("metxtrans"),icon=icon('arrows-alt-h')),
               tabPanel("Mapping", uiOutput("network_mapping"),icon=icon('map')),
               tabPanel("Correlation", uiOutput("corrmap"),icon=icon('superscript')),
               tabPanel("Biochemical", uiOutput("keggmap"),icon=icon('flask')),
               tabPanel("Structural", uiOutput("pubchemmap"),icon=icon('flask')),
               tabPanel("Enrich", uiOutput("networkmap"),icon=icon('plus'))
    )
  )
)
