
> # dave.data.app - data management module

![](https://creativedatasolutions.github.io/dave.docs/img/dave.preproc/data_overview.png)

## This is a modification of [radiant.data](https://github.com/radiant-rstats/radiant.data) R package to integrate with the [dave](https://github.com/CreativeDataSolutions/dave) data analysis and visualization engine.

### See related:
* ### [dave](https://github.com/CreativeDataSolutions/dave)
* ### [dave.vis](https://github.com/CreativeDataSolutions/dave.vis)
* ### [get more ...](https://creative-data.science/)

<p style="text-align:center;"><img style="max-width: 10% !important;" src="https://github.com/CreativeDataSolutions/dave/blob/main/inst/app/www/imgs/cds.png?raw=true"></p>
