# utils
#utility merge list and df functions for saving objects
#TODO move to utils?
#' @title merge_df
#' @export
merge_df<-function(start,end){


  start_names<-colnames(start)
  end_names<-colnames(end)
  merge_names<-start_names[start_names %in% end_names]
  new_names<-end_names[!end_names %in% merge_names]

  #update
  start[,merge_names]<-end[,merge_names]

  #create
  data.frame(start,end[,new_names,drop=FALSE])

}

#' @title merge_list
#' @export
merge_list<-function(start,end){
  #look up list item by name and
  #update colnames or create
  start_names<-names(start)
  end_names<-names(end)
  merge_names<-start_names[start_names %in% end_names]
  new_names<-end_names[!end_names %in% merge_names]


  #loop over list
  #vector list replace
  #how to vector all?

  for(i in 1:length(merge_names)){
    .start<-start[[merge_names[i]]]
    .end<-end[[merge_names[i]]]
    start[[merge_names[i]]]<-merge_df(.start,.end)
  }

  new<-end[!names(end) %in% merge_names]
  c(start,new)

}

#' @title col_filt_obj
#' @param obj data_cube
#' @param id logical column filter
#' @return list of data, row_meta and col_meta
#' @export
#' @details update obj based on logical data columns filter
col_filt_obj<-function(obj,id){ # lots oF ASSUMPTIONS...MIGHT NEED JOIN
  obj$data<-obj$data[,id,drop=FALSE]
  obj$col_meta<-obj$col_meta[id,,drop=FALSE]
  class(obj)<-c('data_cube','list')
  return(obj)
}

#' @export
#' @title  normalize_path
#' @details adding forwardslash to the end of normalizePath
normalize_path<-function(x,folder=TRUE){
  ifelse(folder,paste0(normalizePath(x),'/'),normalizePath(x))
}
