#' Deprecated function(s) in the dave.data.app package
#'
#' These functions are provided for compatibility with previous versions of
#' dave. They will eventually be  removed.
#' @rdname dave.data.app-deprecated
#' @name dave.data.data-deprecated
#' @param ... Parameters to be passed to the updated functions
#' @docType package
#' @export  dfprint nrprint
#' @aliases dfprint nrprint
#' @section Details:
#' \tabular{rl}{
#'   \code{dfprint} is now a synonym for \code{\link{formatdf}}\cr
#'   \code{nrprint} is now a synonym for \code{\link{formatnr}}\cr
#' }
#'
dfprint <- function(...) {
  .Deprecated("formatdf", package = "dave.data")
  formatdf(...)
}
nrprint <- function(...) {
  .Deprecated("formatnr", package = "dave.data")
  formatnr(...)
}
NULL
