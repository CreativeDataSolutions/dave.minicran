

# #options(shiny.trace=TRUE)
# #TODO fix namespace overwritting, using importFrom
# # hack for now
# select<-dplyr::select
#
#
# #coming from DAVe
# #---------------
# # #TODO fix:
# # library(dave.help)
#
# #should these be dynamic
# user<-'user' # main storage location
# shared_folder<-'user' # not relevant for single user
#
# #saved environment; saved w/ in dave.data.app
# options(dave.user.session = normalizePath(paste(user,'session',sep='/')))
#
#
# #---
#
#
# # #USER specific controls
# # #---------------------
# if(Sys.getenv('USERNAME') =='') {
#   user<-'.'
# } else {
#   user<-normalizePath(paste(user_folder,Sys.getenv('SHINYPROXY_USERNAME'),sep="/"))
# }


#set user artifact paths
#--------------


#basepath of user stored sessions
#options(dave.user.session = normalizePath('session')) # .. scoping can be the base path from where the app is called


## based on https://github.com/rstudio/shiny/issues/1237
suppressWarnings(
  try(
    rm("registerShinyDebugHook", envir = as.environment("tools:rstudio")),
    silent = TRUE
  )
)

## function to load/import required packages and functions
import_fs <- function(ns, libs = c(), incl = c(), excl = c()) {
  tmp <- sapply(libs, library, character.only = TRUE); rm(tmp)
  if (length(incl) != 0 || length(excl) != 0) {
    import_list <- getNamespaceImports(ns)
    if (length(incl) == 0)
      import_list[names(import_list) %in% c("base", "methods", "stats", "utils", libs, excl)] <- NULL
    else
      import_list <- import_list[names(import_list) %in% incl]
    import_names <- names(import_list)

    for (i in seq_len(length(import_list))) {
      fun <- import_list[[i]]
      lib <- import_names[[i]]
      ## replace with character.only option when new version of import is posted to CRAN
      ## https://github.com/smbache/import/issues/11
      eval(parse(text = paste0("import::from(",lib,", '",paste0(fun,collapse="', '"),"')")))
    }
  }
  invisible()
}

init_data <- function() {


  r_data <- reactiveValues()

  df_name <- getOption("dave.init.data", default = "mt_cars")
  if (file.exists(df_name)) {
    df <- load(df_name) %>% get
    df_name <- basename(df_name) %>% {gsub(paste0(".",tools::file_ext(.)),"",., fixed = TRUE)}
  } else {
    df <- data(list = df_name, package = "dave.data.app", envir = environment()) %>% get
  }

  r_data[[df_name]] <- df
  r_data[[paste0(df_name, "_descr")]] <- attr(df, "description")
  r_data$datasetlist <- df_name
  r_data$url <- NULL
  r_data
}

## import required functions and packages
if (!"package:dave.data.app" %in% search())
  import_fs("dave.data.app", libs = c("magrittr","dplyr"))
  # import_fs("dave.data.app", libs = c("magrittr","ggplot2","tidyr","dplyr","tibble"))

## running local or on a server
if (Sys.getenv('SHINY_PORT') == "") {
  options(dave.local = TRUE)
  ## no limit to filesize locally
  options(shiny.maxRequestSize = -1)
} else {
  options(dave.local = FALSE)
  ## limit upload filesize on server (500MB)
  options(shiny.maxRequestSize = 5000 * 1024^2)# 10MB 100 * 1024^2)
}

## encoding
options(dave.encoding = "UTF-8")

## path to use for local or server use
ifelse (grepl("dave.data.app", getwd()) && file.exists("../../inst") , "..", system.file(package = "dave.data.app")) %>%
  options(dave.path.data = .)

## print options
options(width  = 250, scipen = 100)

# ## list of function arguments
# list("n" = "length", "n_missing" = "n_missing", "n_distinct" = "n_distinct",
#      "mean" = "mean_rm", "median" = "median_rm", "sum" = "sum_rm",
#      "var" = "var_rm", "sd" = "sd_rm", "se" = "se", "cv" = "cv", "varp" = "varp_rm",
#      "sdp" = "sdp_rm", "min" = "min_rm", "max" = "max_rm", "5%" = "p05",
#      "10%" = "p10", "25%" = "p25", "75%" = "p75", "90%" = "p90", "95%" = "p95",
#      "skew" = "skew","kurtosis" = "kurtosi") %>%
# options(dave.functions = .)

## for report and code in menu R
knitr::opts_knit$set(progress = TRUE )
knitr::opts_chunk$set(echo = FALSE, comment = NA, cache = FALSE,
  message = FALSE, warning = FALSE, error = TRUE,
  # screenshot.force = FALSE,
  fig.path = normalizePath(tempdir(), winslash = "/"))


# setting DATA UI
#-----------------
options(dave.nav_ui =
  list(windowTitle = "DAVe", id = "nav_dave", inverse = TRUE,
       collapsible = TRUE, tabPanel("Data", withMathJax(), uiOutput("ui_data"),icon=icon('database'))))



## environment to hold session information
r_sessions <- new.env(parent = emptyenv())

## create directory to hold session files
#locations of user sessions
# file.path(normalizePath("~"),"dave.sessions") %>% {if (!file.exists(.)) dir.create(.)}
file.path(normalizePath(getOption('dave.user.session'))) %>% {if (!file.exists(.)) dir.create(.)}

## adding the figures path to avoid making a copy of all figures in www/figures
# addResourcePath("figures", file.path(getOption("dave.data.path.app"), "app/tools/help/figures/"))
addResourcePath("imgs", file.path(getOption("dave.data.path.app"), "app/www/imgs/"))
addResourcePath("js", file.path(getOption("dave.data.path.app"), "app/www/js/"))

options(dave.mathjax.path = "https://cdn.mathjax.org/mathjax/latest")


# make_url_patterns <- function(url_list = getOption("dave.url.list"),
#                               url_patterns = list()) {
#   for (i in names(url_list)) {
#     res <- url_list[[i]]
#     if (!is.list(res)) {
#       url_patterns[[res]] <- list("nav_dave" = i)
#     } else {
#       tabs <- names(res)
#       for (j in names(res[[tabs]])) {
#         url <- res[[tabs]][[j]]
#         url_patterns[[url]] <- setNames(list(i,j), c("nav_dave",tabs))
#       }
#     }
#   }
#   url_patterns
# }
#
# ## generate url patterns
# options(dave.url.patterns = make_url_patterns())

## installed packages versions
tmp <- grep("dave.", installed.packages()[,"Package"], value = TRUE)
if ("dave" %in% installed.packages()) tmp <- c("dave" = "dave", tmp)

dave.versions <- "Unknown"
if (length(tmp) > 0)
  dave.versions <- sapply(names(tmp), function(x) paste(x, paste(packageVersion(x), sep = ".")))

options(dave.versions = paste(dave.versions, collapse = ", "))
rm(tmp, dave.versions)


