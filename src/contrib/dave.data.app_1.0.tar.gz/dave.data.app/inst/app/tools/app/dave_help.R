# # #need to assign to unique to save
# rad_data_get_help_section<-reactive({#function(){#
#
#   mods<-c(
#     main='data',
#     'dave.data'=input$tabs_data
#   )
#
#   help_section(mods)
# })
#
#
# callModule(modalModule,id='data_help',content=rad_data_get_help_section)

data_help_lookup <-
  list(url = 'https://creativedatasolutions.github.io/dave.docs/partial/data.html',
       data = list(Calculate = 'formatting'))


map_data_help <-
  function(tab = 'Calculate',
           id = 'data',
           lookup = data_help_lookup,
           url = data_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }


callModule(modalModule,id='data_help',content=map_data_help)
