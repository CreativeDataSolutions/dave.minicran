
#this could come as a modal and be created from dave?

dave_version<- getOption('dave_version') #'0.2.0'
dave_date<- getOption('dave_date') #'2018-8-01'

#images
addResourcePath('dave_about',system.file('app/www/imgs',package='dave.app'))
dave_icon<-'dave_about/icon.png'


#create about card
c_style<-' box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
max-width: 200px;
margin: auto;
text-align: left;'

t_style<-'color: #00112b;
font-size: 18px;'

#basic nav style

about_card<-paste0('<div style="',c_style,' background-color:#009871;">
                   <img src="',dave_icon,'" alt="DAVe" style="width:100%;">
                   <p class="title" style="',t_style,'">Version: ',dave_version,'</p>
                   <p class="title" style="',t_style,'">Released: ',dave_date,'</p>
                   </div>')



output$ui_about_version<-renderUI({
  HTML(about_card)
})

output$ui_about_info<-renderUI({
  html<-system.file('app/tools/help/002-quickstart.html',package='dave.data.app')
  HTML(paste(readLines(html),collapse="\n"))
})
