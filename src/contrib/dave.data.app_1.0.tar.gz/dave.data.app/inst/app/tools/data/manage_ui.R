#######################################
# Manage datasets in/out of dave
#######################################

output$ui_fileUpload <- renderUI({
  if(is.null(input$dataType)) return()
  # req(input$dataType)
  if (input$dataType == "csv") {
    fileInput('uploadfile', '', multiple = TRUE,
      accept = c('text/csv','text/comma-separated-values',
                 'text/tab-separated-values', 'text/plain','.csv','.tsv'))
  } else if (input$dataType %in% c("rda","rds")) {
    fileInput('uploadfile', '', multiple = TRUE,
      accept = c(".rda",".rds",".rdata"))
  } else if (input$dataType == "url_rda") {
    with(tags, table(
      tr(
        td(textInput("url_rda", NULL, "")),
        td(actionButton("url_rda_load", "Load", icon = icon("upload")), style = "padding-top:5px;")
      )
    ))
  } else if (input$dataType == "url_csv") {
    with(tags, table(
      tr(
        td(textInput("url_csv", NULL, "")),
        td(actionButton("url_csv_load", "Load", icon = icon("upload")), style = "padding-top:5px;")
      )
    ))
  }
})



#main data UI
output$ui_Manage <- renderUI({
  # data_types_in <- c("rda" = "rda", "rds" = "rds", "state" = "state", "csv" = "csv",
  #                    "clipboard" = "clipboard", "from global workspace" = "from_global",
  #                    "examples" = "examples", "rda (url)" = "url_rda",
  #                    "csv (url)" = "url_csv")
  # data_types_out <- c("rda" = "rda", "rds" = "rds", "project" = "state", "csv" = "csv",
  #                     "clipboard" = "clipboard", "to global workspace" = "to_global")
  data_types_in <- c("examples" = "examples",
                     "csv" = "csv",
                     "project" = "state")
  data_types_out <- c("csv" = "csv","project" = "state")
  #
  # if (!isTRUE(getOption("dave.local"))) {
  #   data_types_in <- data_types_in[-which(data_types_in == "from_global")]
  #   data_types_out <- data_types_out[-which(data_types_out == "to_global")]
  # }

  tagList(
    bs_accordion(id="data_manage_collapse_panel") %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("cloud-download") , "Load"),
                content =
                  tagList(
                    selectInput("dataType", label = "Data Type:", data_types_in, selected = "examples"),
                    conditionalPanel(condition = "input.dataType != 'examples'",
                                     conditionalPanel("input.dataType == 'csv'",
                                                      with(tags, table(td(checkboxInput('man_header', 'Header', TRUE)),
                                                                       td(HTML("&nbsp;&nbsp;")),
                                                                       td(checkboxInput("man_str_as_factor", "Str. as Factor", TRUE)))),
                                                      checkboxInput("man_read.csv", "use read.csv", TRUE),
                                                      radioButtons("man_sep", "Separator:", c(Comma=",", Semicolon=";", Tab="\t"),
                                                                   ",", inline = TRUE),
                                                      radioButtons("man_dec", "Decimal:", c(Period=".", Comma=","),
                                                                   ".", inline = TRUE)
                                     ),
                                     uiOutput("ui_fileUpload")
                    ),
                    conditionalPanel(condition = "input.dataType == 'examples'",
                                     actionButton("loadExampleData", "Load", icon = icon("upload"))
                    ),
                    conditionalPanel(condition = "input.dataType == 'state'",
                                     fileInput("uploadState", "Load analysis project:",  accept = ".rda"),
                                     uiOutput("refreshOnUpload")
                    )
                  )
      ) %>%
    bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
              content =
                tagList(
                    selectInput("saveAs", label = "Save data to type:", data_types_out, selected = "csv"),
                    conditionalPanel(condition = "input.saveAs == 'state'",
                                     HTML("<label>Save analysis project:</label><br/>"),
                                     downloadButton("saveState", "Save")
                    ),
                    conditionalPanel(condition = "
                                     input.saveAs != 'state'",
                                     downloadButton("downloadData", "Save")
                    )
                  )
              ) %>%
    bs_append(title = tags$label(class='bsCollapsePanel', icon("close") , "Delete"),
              content =
                tagList(
                  # checkboxInput("man_show_remove", "Delete data", FALSE),
                  # conditionalPanel(condition = "input.man_show_remove == true",
                                   uiOutput("uiRemoveDataset"),
                                   actionButton("removeDataButton", "Delete")
                  # )
                )
              )
  )
})


# removing datasets
output$uiRemoveDataset <- renderUI({
  selectInput(inputId = "removeDataset", label = NULL,
    choices = r_data$datasetlist, selected = NULL, multiple = TRUE,
    size = length(r_data$datasetlist), selectize = FALSE
  )
})

observeEvent(input$removeDataButton, {
  # removing datasets
  # only remove datasets if 1 or more were selected - without this line
  # all files would be removed when the removeDataButton is pressed
  if (is.null(input$removeDataset)) return()
  datasets <- r_data[["datasetlist"]]
  if (length(datasets) > 1) {  # have to leave at least one dataset
    removeDataset <- input$removeDataset
    if (length(datasets) == length(removeDataset))
      removeDataset <- removeDataset[-1]

    # Must use single string to index into reactivevalues so loop is necessary
    for (rem in removeDataset) {
      r_data[[rem]] <- NULL
      r_data[[paste0(rem,"_descr")]] <- NULL
    }
    r_data[["datasetlist"]] <- datasets[-which(datasets %in% removeDataset)]
  }
})



output$downloadData <- downloadHandler(
  filename = function() { paste0(input$dataset,'.',input$saveAs) },
  content = function(file) {

    ext <- input$saveAs

    if (ext == 'csv') {
      readr::write_csv(.getdata_transform(), file)
    } else {

      robj <- input$dataset
      tmp <- new.env(parent = emptyenv())
      tmp[[robj]] <- .getdata_transform()
      if (!is.null(input$man_data_descr) && input$man_data_descr != "")
        attr(tmp[[robj]],"description") <- r_data[[paste0(robj,"_descr")]]

      if (ext == 'rda') {
        save(list = robj, file = file, envir = tmp)
      } else {
        saveRDS(tmp[[robj]], file = file)
      }
    }
  }
)

observeEvent(input$uploadfile, {
  ## loading files from disk
  inFile <- input$uploadfile
  ## iterating through the files to upload
  for (i in 1:(dim(inFile)[1]))

    loadUserData(inFile[i,'name'], inFile[i,'datapath'], input$dataType,
                 .csv = input$man_read.csv,
                 header = input$man_header,
                 man_str_as_factor = input$man_str_as_factor,
                 sep = input$man_sep, dec = input$man_dec)

  updateSelectInput(session, "dataset", label = "Datasets:",
                    choices = r_data$datasetlist,
                    selected = r_data$datasetlist[1])
})



## loading all examples files (linked to help files)
observeEvent(input$loadExampleData, {
  ## data.frame of example datasets
  exdat <- data(package = getOption("dave.example.data"))$results[, c("Package","Item")]
  # exdat <- data(package = r_example_data)$results[, c("Package","Item")]

  #guard against only one example
  if(is.null(exdat)) return() # TODO add message
  if(is.null(nrow(exdat))) {
    exdat<-matrix(exdat,1,2) %>%
      data.frame() %>%
      setNames(.,c('Package','Item'))
  }


  for (i in 1:nrow(exdat)) {
    #is this an error?
    # pack <-
    item <- exdat[i,"Item"]
    r_data[[item]] <- data(list = item, package = exdat[i,"Package"], envir = environment()) %>% get
    r_data[[paste0(item,"_descr")]] <- attr(r_data[[item]], "description")
    r_data[['datasetlist']] <<- c(item, r_data[['datasetlist']]) %>% unique
  }


  ## sorting files alphabetically
  r_data[['datasetlist']] <- sort(r_data[['datasetlist']])

  updateSelectInput(session, "dataset", label = "Datasets:",
                    choices = r_data$datasetlist,
                    selected = r_data$datasetlist[1])
})


#######################################
# Load previous state
#######################################
observeEvent(input$uploadState, {
  inFile <- input$uploadState
  tmpEnv <- new.env(parent = emptyenv())
  load(inFile$datapath, envir = tmpEnv)

  ## remove characters that may cause problems in shinyAce
  if (!is.null(tmpEnv$r_state$rmd_report))
    tmpEnv$r_state$rmd_report %<>% gsub("[\x80-\xFF]", "", .) %>% gsub("\r","\n",.)

  #browser()

  r_sessions[[r_ssuid]] <- list(
    r_data = tmpEnv$r_data,
    r_state = tmpEnv$r_state,
    timestamp = Sys.time()
  )

  ## saving session information to file
  fn <- paste0(normalizePath(getOption('dave.user.session')),"/r_", r_ssuid, ".rds")
  saveRDS(r_sessions[[r_ssuid]], file = fn)

  # suppressWarnings(rm(r_data, r_state, envir = .GlobalEnv))
  # r_data  <- do.call(reactiveValues, r_sessions[[r_ssuid]]$r_data)
  # r_state <- r_sessions[[r_ssuid]]$r_state

  #loadProject(r_sessions,r_ssuid)

  rm(tmpEnv)
})

output$refreshOnUpload <- renderUI({
  inFile <- input$uploadState
  if (!is.null(inFile)) {
    ## Joe Cheng: https://groups.google.com/forum/#!topic/shiny-discuss/Olr8m0JwMTo
    tags$script("window.location.reload();")
  }
})

#######################################
# Save state
#######################################
saveState <- function(filename) {
  isolate({
    LiveInputs <- toList(input)
    r_state[names(LiveInputs)] <- LiveInputs
    r_data <- toList(r_data)
    save(r_state, r_data , file = filename)
  })
}

output$saveState <- downloadHandler(
  filename = function() { paste0("dave-state-",Sys.Date(),".rda") },
  content = function(file) {
    saveState(file)
  }
)

#######################################
# Loading data into memory
#######################################
# observeEvent({pressed(input$renameButton) || !is_empty(input$data_rename)}, {
observeEvent(input$renameButton, {
  .data_rename()
})



# .data_rename <- reactive({
.data_rename <- function() {
  isolate({
    if (is_empty(input$data_rename)) return()
    ## use pryr::object_size to see that the size of the list doesn't change
    ## when you assign a list element another name
    r_data[[input$data_rename]] <- r_data[[input$dataset]]
    r_data[[input$dataset]] <- NULL
    r_data[[paste0(input$data_rename,"_descr")]] <- r_data[[paste0(input$dataset,"_descr")]]
    r_data[[paste0(input$dataset,"_descr")]] <- NULL

    ind <- which(input$dataset == r_data[["datasetlist"]])
    r_data[["datasetlist"]][ind] <- input$data_rename
    r_data[["datasetlist"]] %<>% unique

    updateSelectInput(session, "dataset", label = "Datasets:", choices = r_data$datasetlist,
                      selected = input$data_rename)

  })
}

output$ui_datasets <- renderUI({
  ## Drop-down selection of active dataset
  bs_accordion(id="data_dataset_collapse_panel") %>%
    bs_append(title = tags$label(class='bsCollapsePanel', icon("folder-open") , "Data"),
          content =
            tagList(
              selectInput(inputId = "dataset", label = "Datasets:", choices = r_data$datasetlist,
                selected = state_init("dataset"), multiple = FALSE),
              conditionalPanel(condition = "input.tabs_data == 'Manage'",
                checkboxInput("man_add_descr","Add/edit data description", FALSE),
                conditionalPanel(condition = "input.man_add_descr == true",
                  actionButton('updateDescr', 'Update description')
                ),
                checkboxInput("man_rename_data","Rename data", FALSE),
                conditionalPanel(condition = "input.man_rename_data == true",
                  uiOutput("uiRename")
                )
              )
            )
    )
})

outputOptions(output,'ui_datasets',suspendWhenHidden=FALSE)

output$uiRename <- renderUI({
  tags$table(
    tags$td(textInput("data_rename", NULL, input$dataset)),
    tags$td(actionButton('renameButton', 'Rename'), style="padding-top:5px;")
  )
})

output$htmlDataExample <- renderText({

  if (is.null(.getdata())) return()

  ## Show only the first 10 (or 20) rows
  #TODO: limit columns
  r_data[[paste0(input$dataset,"_descr")]] %>%
    { is_empty(.) %>% ifelse (., 20, 10) } %>%
    show_data_snippet(nshow = .)
})
