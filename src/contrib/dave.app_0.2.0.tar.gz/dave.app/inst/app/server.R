

# shinyServer(function(input, output, session) {
#
#   source('src/slow_global.R',local = TRUE)
#   source('src/dave_server.R',local = TRUE)
#   hide("loading_content")
#
# })

shinyServer(function(input, output, session) {


  source(system.file(package='dave.app','app/src/local/server.R'),local = TRUE)


})
