
#options(shiny.trace=TRUE)
#options(shiny.reactlog=TRUE)

#server loads

#see global.R for part 1 of 2

# if(getOption('USE_DAVE') != '' && as.logical(getOption('USE_DAVE'))) library(dave.app)

DAVE_PKGS<-getOption('DAVE_PKGS')

#load libraries - can be slow so doing after UI intialization
load_DAVE_library(DAVE_PKGS)

#about info scoping from package DESCRIPTION
#used in About which is a tab made in dave.app
info<-dave.utils::get_package_version('dave.app')$description
options('dave_version'= as.character(info['version']))
options('dave_date'= as.character(info['date']))


#turn off R and report menus
options('dave.shared_ui' = NULL) # not working?

