#init API client endpoints

library(dave.ocpu.client)

#need connection for each endpoint
set_headers( 'Content-Type' = 'application/json')

# #required APIs - local tests
# dave_ml_connection <- HttpClient$new(url = 'http://localhost:8085/',opts = list(timeout = 10000))
# ctsgetr_connection <- HttpClient$new(url = 'http://localhost:8084/',opts = list(timeout = 10000))
# dave_network_connection <- HttpClient$new(url = 'http://localhost:8081/',opts = list(timeout = 10000))
# dave_path_connection <- HttpClient$new(url = 'http://localhost:8082/',opts = list(timeout = 10000))
# dave_multivariate_connection <- HttpClient$new(url = 'http://localhost:8083/',opts = list(timeout = 10000))

#required APIs - server
base_API<-'http://ec2-52-22-43-130.compute-1.amazonaws.com'
ctsgetr_connection <- HttpClient$new(url = paste0(base_API,'/ctsgetr/'),opts = list(timeout = 10000))
dave_network_connection <- HttpClient$new(url = paste0(base_API,'/network/'),opts = list(timeout = 10000))
dave_multivariate_connection <- HttpClient$new(url = paste0(base_API,'/multivariate/'),opts = list(timeout = 10000))
dave_path_connection <- HttpClient$new(url = paste0(base_API,'/path/'),opts = list(timeout = 10000))
dave_ml_connection <- HttpClient$new(url = paste0(base_API,'/ml/'),opts = list(timeout = 10000))

#dave.network not used anymore
options('dave.network.app.CID.DB' = '/open_cpu/CID.SDF.DB')



