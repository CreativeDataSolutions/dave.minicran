#global options
DAVE_PKGS<-getOption('DAVE_PKGS')



# init data and previous session ------------------------------------------
options(dave.data.path.app = system.file(package = "dave.data.app")) #sourced earlier than other libs as global dependency
source(file.path(getOption("dave.data.path.app"),"app/init.R"), encoding = getOption("dave.encoding"), local = TRUE)

remove_session_files()

#check current session
isolate({
  prevSSUID <- parseQueryString(session$clientData$url_search)[["SSUID"]]
})

## set the session id
r_ssuid <-
  if (getOption("dave.local")) {
    if (is.null(prevSSUID)) {
      mrsf <- most_recent_session_file()
      paste0("local-",shiny:::createUniqueId(3))
    } else {
      mrsf <- "0000"
      prevSSUID
    }
  } else {
    ifelse (is.null(prevSSUID), shiny:::createUniqueId(5), prevSSUID)
  }

## (re)start the session and push the id into the url
session$sendCustomMessage("session_start", r_ssuid)

## load for previous state if available but look in global memory first
if (exists("r_data")) {
  r_data  <- do.call(reactiveValues, r_data)
  r_state <- if (exists("r_state")) r_state else list()
  suppressWarnings(rm(r_data, r_state, envir = .GlobalEnv))
} else if (!is.null(r_sessions[[r_ssuid]]$r_data)) {
  r_data  <- do.call(reactiveValues, r_sessions[[r_ssuid]]$r_data)
  r_state <- r_sessions[[r_ssuid]]$r_state
} else if (file.exists(paste0(normalizePath(getOption('dave.user.session')),"r_", r_ssuid, ".rds"))) {
  ## read from file if not in global
  fn <- paste0(normalizePath(getOption('dave.user.session')),"/r_", r_ssuid, ".rds")

  rs <- try(readRDS(fn), silent = TRUE)
  if (is(rs, 'try-error')) {
    r_data  <- init_data()
    r_state <- list()
  } else {
    if (length(rs$r_data) == 0)
      r_data  <- init_data()
    else
      r_data  <- do.call(reactiveValues, rs$r_data)

    if (length(rs$r_state) == 0)
      r_state <- list()
    else
      r_state <- rs$r_state
  }

  unlink(fn, force = TRUE)
  rm(rs)
} else if (isTRUE(getOption("dave.local")) && file.exists(paste0(normalizePath(getOption('dave.user.session')),"/r_", mrsf, ".rds"))) {

  ## restore from local folder but assign new ssuid
  fn <- paste0(normalizePath(getOption('dave.user.session')),"/r_", mrsf, ".rds")
  rs <- try(readRDS(fn), silent = TRUE)
  if (is(rs, 'try-error')) {
    r_data  <- init_data()
    r_state <- list()
  } else {
    r_data  <- if (length(rs$r_data) == 0) init_data() else do.call(reactiveValues, rs$r_data)
    r_state <- if (length(rs$r_state) == 0) list() else rs$r_state
  }

  ## don't navigate to same tab in case the app locks again
  r_state$nav_dave <- NULL

  unlink(fn, force = TRUE)
  rm(rs)
} else {
  r_data  <- init_data()
  r_state <- list()
}

## identify the shiny environment
r_environment <- environment()

## parse the url and use updateTabsetPanel to navigate to the desired tab
observeEvent(session$clientData$url_search, {
  url_query <- parseQueryString(session$clientData$url_search)
  if ("url" %in% names(url_query)) {
    r_data$url <- url_query$url
  } else if (is_empty(r_data$url)) {
    return()
  }

  ## create an observer and suspend when done
  url_observe <- observe({
    if (is.null(input$dataset)) return()
    url <- getOption("dave.url.patterns")[[r_data$url]]
    if (is.null(url)) {
      ## if pattern not found suspend observer
      url_observe$suspend()
      return()
    }
    ## move through the url
    for (u in names(url)) {
      if (is.null(input[[u]])) return()
      if (input[[u]] != url[[u]])
        updateTabsetPanel(session, u, selected = url[[u]])
      if (names(tail(url,1)) == u) url_observe$suspend()
    }
  })
})

## keeping track of the main tab we are on
observeEvent(input$nav_dave, {
  if (!input$nav_dave %in% c("Refresh", "Stop"))
    r_data$nav_dave <- input$nav_dave
})

## Jump to the page you were on
## only goes two layers deep at this point
if (!is.null(r_state$nav_dave)) {

  ## don't return-to-the-spot if that was quit or stop
  if (r_state$nav_dave %in% c("Refresh","Stop")) return()

  ## naming the observer so we can suspend it when done
  nav_observe <- observe({
    ## needed to avoid errors when no data is available yet
    if (is.null(input$dataset)) return()
    updateTabsetPanel(session, "nav_dave", selected = r_state$nav_dave)

    ## check if shiny set the main tab to the desired value
    if (is.null(input$nav_dave)) return()
    if (input$nav_dave != r_state$nav_dave) return()
    nav_dave_tab <- getOption("dave.url.list")[[r_state$nav_dave]] %>% names

    if (!is.null(nav_dave_tab) && !is.null(r_state[[nav_dave_tab]]))
      updateTabsetPanel(session, nav_dave_tab, selected = r_state[[nav_dave_tab]])

    ## once you arrive at the desired tab suspend the observer
    nav_observe$suspend()
  })
}

isolate({
  if (is.null(r_data$plot_height)) r_data$plot_height <- 600
  if (is.null(r_data$plot_width)) r_data$plot_width <- 600
})


# dave shared funs --------------------------------------------------------
source(file.path(getOption("dave.data.path.app"),"app/dave.R"), encoding = getOption("dave.encoding"), local = TRUE)

source(file.path(getOption("dave.path.report"),"app/init.R"), encoding = getOption("dave.encoding"), local = TRUE)
source(list.files(file.path(getOption("dave.path.report"),"app/tools/analysis"),full.names = TRUE),encoding = getOption("dave.encoding"), local = TRUE)


## source data & app tools from dave.data
for (file in list.files(c(
  file.path(getOption("dave.data.path.app"), "app/tools/app"),
  file.path(getOption("dave.data.path.app"), "app/tools/data")
),
pattern = "\\.(r|R)$",
full.names = TRUE)) {
  source(file,
         encoding = getOption("dave.encoding"),
         local = TRUE)
}

## list of dave menus to include
rmenus<-getOption('DAVE_PKGS')



## packages to use for example data
# options(dave.example.data = c("dave.preproc","dave.stat","dave.network.app"))
set_DAVE_example_DATA()



#This was built pre modules
## "sourcing" dave"s package functions in the server.R environment
for (i in rmenus[-1]) {
  eval(parse(text = paste0("dave.data.app::copy_all(", i, ")")))
  #control path naming pre last '.' - should generalize scheme
  tmp<-strsplit(i, "\\.")[[1]]
  ipath <-
    paste0(c(tmp[-length(tmp)],'path',tmp[length(tmp)]), collapse = ".")
  for (file in list.files(
    file.path(getOption(ipath), "app/tools/analysis"),
    pattern = "\\.(r|R)$",
    full.names = TRUE
  )) {
    source(file,
           encoding = getOption("dave.encoding"),
           local = TRUE)
  }
}

#tons of dep overwritting namespace problems...
select<-dplyr::select
validate<-shiny::validate

## save state on refresh or browser close
saveStateOnRefresh(session)

