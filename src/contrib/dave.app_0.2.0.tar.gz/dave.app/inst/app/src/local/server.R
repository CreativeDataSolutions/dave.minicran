

message('Loading app server')

source(system.file(package='dave.app','app/src/slow_global.R'),local = TRUE)
source(system.file(package='dave.app','app/src/local/local_server.R'),local = TRUE)
hide("loading_content")



