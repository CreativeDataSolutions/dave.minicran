

# debug -------------------------------------------------------------------

## options to set for debugging
# options(shiny.trace = TRUE)
# options(shiny.reactlog = TRUE)
# options(shiny.error = recover)
# options(warn = 2)
# options(warn = 0)
## turn off warnings globally
# options(warn=-1)

## set autoreload on if found TRUE in .Rprofile
# options("autoreload")[[1]] %>%
#   {options(shiny.autoreload = ifelse (!is.null(.) && ., TRUE, FALSE))}

#control file upload size if not
# Sys.getenv('SHINY_PORT')

#this loads the bare miniumum
#----------------------------
#see slow_global.R for the rest

# name<-getOption('APP_NAME')

#these are also part of dave #should instead be added to each app
# library(shinythemes)
# library(shinyjs)

message('Loading app global')

#sync folders with s3 or create
source(system.file(package='dave.app','app/src/startup.R'),local = TRUE)
options("dave.app.encoding" = "UTF-8") # might need to set enecoding
options(encoding=  "UTF-8")
options(dave.data.path.app = system.file(package = "dave.data.app"))
source(file.path(getOption("dave.data.path.app"), "app/global.R"), encoding = getOption("dave.encoding", default = "UTF-8"), local = TRUE)


#need for UI
# library(shinythemes)
# library(shinyjs)
options(dave.path.css=system.file('app/www/css/styles.css',package='dave.app')) # seems loaded in UI before global?
addResourcePath('dave_img',system.file('app/www/imgs',package='dave.app'))
options('google_analytics_js' = system.file('app/www/js/google-analytics.js',package='dave.app'))
addResourcePath('dave_js',system.file('app/www/js',package='dave.app'))


options(dave.path.report = system.file(package = "dave.report"))

source(file.path("init.R"), encoding = getOption("dave.encoding"), local = TRUE)
source(file.path(getOption("dave.path.report"), "app/init.R"), encoding = getOption("dave.encoding", default = "UTF-8"), local = TRUE)
