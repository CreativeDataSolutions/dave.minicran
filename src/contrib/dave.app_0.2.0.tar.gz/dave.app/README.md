<br>

![](https://creativedatasolutions.github.io/dave.docs/img/dave.main/data.png)

### This package is a modification of [Radiant](https://github.com/vnijs/radiant) to combine modules for metabolomic data analysis. [Read more ...](https://creativedatasolutions.github.io/dave.docs/)

### See related:
* ### [dave.data]()
* ### [dave.vis]()
* ### [find out how to get more](https://creative-data.science/)

<p style="text-align:center;"><img style="max-width: 10% !important;" src="inst/app/www/imgs/cds.png"></p>
