#load each package individually
#install packages


#' Title
#'
#' @param DAVE_PKGS
#'
#' @return
#' @export
#' @details define dave packages to include
#' @examples
load_DAVE_library<-function(DAVE_PKGS= getOption('DAVE_PKGS')){

  for(i in DAVE_PKGS) {
    library(i,character.only = TRUE)
  }
}



#' Title
#'
#' @param DAVE_PKGS
#'
#' @return
#' @export
#' @details set package paths to UI resources
#' @examples
set_DAVE_path<-function(DAVE_PKGS = getOption('DAVE_PKGS')){

  for(i in DAVE_PKGS) {
    obj<-strsplit(i,"\\.") %>%
      unlist()

    #path
    len<-length(obj)
    path<-paste0(c(obj[1:(len-1)],'path',obj[len]),collapse = '.')

    .opt<-setNames(list(system.file(package = i)), path)
    options(.opt)
  }

}

#' Title
#'
#' @param pkgs
#'
#' @return
#' @export
#' @details load example data
#'
#' @examples
set_DAVE_example_DATA<-function(pkgs=c("dave.preproc","dave.stat","dave.network.app")){
  options(dave.example.data = pkgs)
}


#' Title
#'
#' @param DAVE_PKGS
#'
#' @return
#' @export
#' @details load dave package shiny UI elements
#' @examples
load_DAVE_UI<-function(DAVE_PKGS = getOption('DAVE_PKGS')){

  for(i in DAVE_PKGS) {

    tryCatch(
      source(
        system.file("app/init.R", package = i),
        encoding = getOption("dave.encoding"),
        local = FALSE
      ),
      error = function(e) {
      }
    )
  }

}


#' Title
#'
#' @param DAVE_UI
#'
#' @return
#' @export
#'
#' @examples
render_DAVE_UI<-function(DAVE_UI = c(getOption("dave.nav_ui"),
                                          getOption('dave_vis_ui'),
                                          getOption("report_ui"),
                                          getOption("preproc_ui"),
                                          getOption("stat_ui"),
                                          getOption("cluster_ui"),
                                          getOption('multivariate_ui'),
                                          getOption('pathway_ui'),
                                          getOption('ml_ui'),
                                          getOption('network_ui'))){

  return(DAVE_UI)

}
#' Title
#'
#' @param opts
#'
#' @return
#' @export
#'
#' @examples
set_dave_options <- function(opts) {

  opts$USER_PATH<-getwd()

  #set defaults if absent
  if (is.null(opts$DAVE_PKGS_DEFAULT)) {
    opts$DAVE_PKGS_DEFAULT <- c("dave.data.app",
                                "dave.help",
                                "dave.report",
                                "dave.vis",
                                "dave.utils")
  }

  if(is.null(opts$USERNAME)){
    opts$USERNAME<-'dave_user'
  }

  if(is.null(opts$USER_DATA)){
    opts$USER_DATA<-'user'
  }

  opts$DAVE_PKGS <- unique(c(opts$DAVE_PKGS_DEFAULT, opts$DAVE_APP))

  out <- lapply(1:length(opts), function(i) {
    options(opts[i])
  })

}

#' Title
#'
#' @param opts
#' @param app
#'
#' @return
#' @export
#'
#' @examples
run_dave_app<-function(opts,app='dave.app'){


  set_dave_options(opts)
  #shiny app root
  .app<-system.file('app',package=app)
  shiny::runApp(.app,launch.browser = TRUE)
}

#' Title
#'
#' @return
#' @export
#'
#' @examples
run_daveApp<-function(USERNAME = 'dave_user',USER_DATA = 'user'){

  opts <- list(
    #supporting dave packages
    DAVE_PKGS_DEFAULT = c(
      "dave.data.app",
      "dave.help",
      "dave.report",
      "dave.vis",
      "dave.utils"
    ),
    USERNAME = USERNAME,
    USER_DATA = USER_DATA,
    # analysis dave packages
    DAVE_APP = c(
      "dave.preproc",
      "dave.stat",
      "dave.multivariate.app",
      "dave.pathway.app",
      "dave.ml.app",
      "dave.network.app",
      "dave.cluster"
    )
  )

  dave.app::run_dave_app(opts)
}
