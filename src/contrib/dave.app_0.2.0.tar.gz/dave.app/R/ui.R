#' Title
#'
#' @return
#' @export
#'
#' @examples
make_dave_ui<-function(dave_icon = 'dave_img/icon.png'){
  tagList(
    useShinyjs(),
    div(
      id = "loading_content",
      tags$img(src = 'dave_img/loading.gif', style = "left: 50%;position: absolute; top: 50%;")
    ),
    includeCSS(getOption('dave.path.css')),
    tags$head(
      tags$title('DAVe'),
      tags$link(rel = "shortcut icon", href = "imgs/ico.png"),
      includeScript(getOption('google_analytics_js'))
    ),
    do.call(
      navbarPage,
      c(
        list(title = shiny::HTML(
          paste0(
            '<div><img style="display: inline;"
                  src="',
            dave_icon,
            '" width=75px/><h4 style="color: black;display: inline;"></h4></div>'
          )
        )),
        theme = shinythemes::shinytheme("darkly"),
        render_DAVE_UI()
      )
    )
  )

}
