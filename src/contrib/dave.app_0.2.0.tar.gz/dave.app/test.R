

#options(shiny.trace = TRUE)
# options(shiny.fullstacktrace = TRUE)

dave.app::run_daveApp(USERNAME = 'dave_user')


#
install.packages('devtools')
library(devtools)
install_github("dgrapov/CTSgetR")




r <- getOption("repos")
r["CDS"] = "https://creativedatasolutions.github.io/dave.minicran/"
options(repos = r)

pkgs <-
  c(
    'dave.app',
    'dave.vis',
    'dave.preproc',
    'dave.stat',
    'dave.cluster',
    'dave.pathway.app',
    "dave.ml.app",
    "dave.multivariate.app",
    "dave.network.app"
  )

install.packages(pkgs)
