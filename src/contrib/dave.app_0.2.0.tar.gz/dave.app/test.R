
#TODO fix dave_data ... add correct net index!
#options(shiny.trace = TRUE)
# options(shiny.fullstacktrace = TRUE)

dave.app::run_daveApp(USERNAME = 'dave_user')



