---
bibliography: 'C:/Users/think/Documents/R/win-library/3.6/dave.report/references/dave_refs.bib'
---





<hr/>
<h3>Predictive modeling</h3>
<hr/>
<h4>Machine learning based predictive modelling was used to predict class. A single model was fit and optimized based on predictive performance on the test data.</h4><br/>
<h4>Model performance</h4>
<table class="table table-striped table-hover table-condensed table-responsive" style="margin-left: auto; margin-right: auto;">
 <thead>
  <tr>
   <th style="text-align:left;"> model </th>
   <th style="text-align:left;"> metric </th>
   <th style="text-align:right;"> train </th>
   <th style="text-align:right;"> test </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> rfbest </td>
   <td style="text-align:left;"> Accuracy </td>
   <td style="text-align:right;"> 0.86 </td>
   <td style="text-align:right;"> 0.9 </td>
  </tr>
</tbody>
</table>

<br/>
<img src="C:/Users/think/Dropbox/Software/dave/dave_apps/dave.ml.app/user/dave_user/report/partial/model_report_files/figure-html/unnamed-chunk-2-1.png" width="2100" style="display: block; margin: auto;" /><br/>
<h4>A random forest model was developed on  55 samples and 188 predictors to predict  2 classes: diabetic.., non.diabetic.. with no pre-processing. Cross validation was done by resampling: cross-validated (7 fold, repeated 3 times) . Tuning parameter 'mtry' was held constant at a value of 62.</h4><br/>
<h4>Model classification performance</h4>
<img src="C:/Users/think/Dropbox/Software/dave/dave_apps/dave.ml.app/user/dave_user/report/partial/model_report_files/figure-html/unnamed-chunk-2-2.png" width="2100" style="display: block; margin: auto;" /><h4>Model classification curve</h4>
<img src="C:/Users/think/Dropbox/Software/dave/dave_apps/dave.ml.app/user/dave_user/report/partial/model_report_files/figure-html/unnamed-chunk-2-3.png" width="2100" style="display: block; margin: auto;" /><br/>
<h4>Overview of each variable's contribution to the models predictive performance.</h4><br/>
<table class="table table-striped table-hover table-condensed table-responsive" style="margin-left: auto; margin-right: auto;">
 <thead>
  <tr>
   <th style="text-align:left;"> variable </th>
   <th style="text-align:right;"> importance </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> var188 </td>
   <td style="text-align:right;"> 2.9 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> var115 </td>
   <td style="text-align:right;"> 1.8 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> var173 </td>
   <td style="text-align:right;"> 1.7 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> var119 </td>
   <td style="text-align:right;"> 1.3 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> var51 </td>
   <td style="text-align:right;"> 1.2 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> var142 </td>
   <td style="text-align:right;"> 1.2 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> var73 </td>
   <td style="text-align:right;"> 1.0 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> var125 </td>
   <td style="text-align:right;"> 0.8 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> var90 </td>
   <td style="text-align:right;"> 0.8 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> var134 </td>
   <td style="text-align:right;"> 0.7 </td>
  </tr>
</tbody>
</table>

<br/>
<h4>The concordance between the composite variables rank across all models (y-axis) and the importance in the top performing model (x-axis) is shown below.</h4><img src="C:/Users/think/Dropbox/Software/dave/dave_apps/dave.ml.app/user/dave_user/report/partial/model_report_files/figure-html/unnamed-chunk-2-4.png" width="2100" style="display: block; margin: auto;" />




##### Method references include: caret: Classification and Regression Training R package [@caret].

### References
*****
