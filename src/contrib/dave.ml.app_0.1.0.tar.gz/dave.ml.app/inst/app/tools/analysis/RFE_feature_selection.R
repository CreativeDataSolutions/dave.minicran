#not using module because only two UIs sharing
#limited divs

dave_rfe_values<-reactiveValues()



#module
#create model data based on combining x and y
.get_model_data_rfe<-reactive({
  if (is.null(input$dataset)) return()
  if (is.null(input$rfe_dependent_var)) return()
  if (is.null(input$rfe_dependent_var_type)) return()

  #browser()

  .data<-r_data[[input$dataset]]

  .y<-get_model_data_by_type_rfe()$y_data %>% dplyr::select(one_of(input$rfe_dependent_var))


  #should synchronize train/test split with model settings

  return(list(data=data.frame(.data),y=data.frame(.y),full=data.frame(.y,.data)))

})

#copying rf verison of switching
#between regression and and classification
get_model_data_by_type_rfe<-reactive({
  if(is.null(input$rfe_dependent_var_type)) return(NULL)
  limit_numeric<-FALSE
  if(input$rfe_dependent_var_type == 'regression'){
    data<-cbind( .getdata_row_meta(),r_data[[input$dataset]])
    limit_numeric<-TRUE
  } else {
    data<- .getdata_row_meta()
  }

  validate(need(!is.null(data),'Data is not compatible'))

  vars<- data %>% colnames()
  .class<-sapply(data,class)
  names(vars) <- paste0(vars," (",.class,")")

  if(limit_numeric){
    keep<-.class %in% c("numeric","integer")
    data<-data[,keep,drop=FALSE]
    vars<-vars[keep]
  }

  # browser()

  list(names=vars,y_data=data)
})

#variable names for importance
output$ui_rfe_variable_names<-renderUI({

  #browser()
  if(is.null(input$rfe_plot_type) || !input$rfe_plot_type == 'importance') return()
  vars<-.getdata_col_meta() %>% colnames()
  if(is.null(vars)) return()

  selectInput('rfe_variable_names','Variable names',choices=vars)

})

outputOptions(output, 'ui_rfe_variable_names', suspendWhenHidden = FALSE) # used in report

output$ui_top_nvars_rfe<-renderUI({
  if(!input$rfe_plot_type == 'importance') return()
  numericInput('top_nvars_rfe','top number',min=1,value=10)
})

#separating update linkage hell
output$rfe_dependent_var_type_ui<-renderUI({
  radioButtons('rfe_dependent_var_type','Select variable to predict',choices = c('classification','regression'),inline = TRUE)
})

#Choose dependent varaible
output$ui_rfe_dependent_var <- renderUI({
  if (is.null(input$dataset)) return()
  # dat <- r_data[[input$rf_measured_data]]
  # vars<- as.list(colnames(dat))
  # vars<- .getdata_row_meta() %>% colnames()
  # names(vars) <- paste0(vars," (",sapply(.getdata_row_meta(),class),")")
  vars<- get_model_data_by_type_rfe()$names
  selectInput(inputId = "rfe_dependent_var",
              label = "",
              choices = vars,
              selected = state_single("rfe_dependent_var",vars),
              multiple = FALSE)
})

#allow classification or regression
observeEvent(input$rfe_dependent_var_type,ignoreNULL = TRUE,{

  vars<-get_model_data_by_type_rfe()$names

  if(is.null(vars)) return()

  updateSelectInput(session= session,'rfe_dependent_var',choices=vars,selected=NULL)

})

#Choose independent varaibles #sel`ect all by default
output$ui_rfe_independent_var <- renderUI({
  if (is.null(input$dataset)) return()

  dat <- .getdata_cube()$data#.get_model_data_rfe()$data
  #Add a validate condition to avoid error message due to late loading
  validate(
    need(nrow(dat)!= 0, "Please select a data set"),
    need(input$rfe_dependent_var != "", "Loading X variables..")
  )
  selected <- input$rfe_dependent_var
  dat <- dat %>% dplyr::select(-one_of(selected))
  vars<- as.list(colnames(dat))
  names(vars) <- paste0(colnames(dat)," (",sapply(dat,class),")")

  selectInput(inputId = "rfe_independent_vars",
              label = "Select X variables ",
              choices = vars,
              selected = vars,
              selectize = FALSE,
              multiple = TRUE,size = 5)
})

#get training data information
get_rfe_train_data<-reactive({

  .train_data<-dave_ml_values[['data']][[input$dataset]]

  if(is.null(.train_data)) {shinyjs::hide('rfe_progress_gif')}
  shiny::validate(need(!is.null(.train_data),'Need to create a model first to specify training data'))



  body<-list(obj=.train_data,
             name='train.data')

  train_data<-get_ocpu_list_item(dave_ml_connection, body)

  #get dimensions

  train_data_dims<-ocpu_post(dave_ml_connection,
                             body = list(x=ocpu_session(train_data)),
                             pkg_url = 'ocpu/library/base/R/dim',
                             encode = NULL,
                             return_value = TRUE)$results


  return(list(data = train_data, dims=train_data_dims))

})

#Subset size for RFE
output$ui_rfe_subset_size <- renderUI({
  if(is.null(input$dataset)) return()
  .dims<-get_rfe_train_data()$dims

  sliderInput(inputId = "rfe_subset_size",
              label = "Pick the initial subset size",
              min = 2,max = .dims[2],value = c(2,.dims[2]),step = 1,dragRange = T
  )
})

output$ui_rfe_subset_step_size <- renderUI({
  if(is.null(input$dataset)) return()
  #should source dim from the train data
  .dims<-get_rfe_train_data()$dims
  sliderInput(inputId = "rfe_subset_step_size",
              label = "Step size",
              min = 2,max = .dims[2],value = 2,step = 5,dragRange = F
  )
})
#RFE functions
#TODO add more Funcs
output$ui_rfe_functions <- renderUI({
  if(is.null(input$dataset)) return()
  selectInput(inputId = "rfe_functions",
              label = "Pick RFE function",
              choices = list('random forest' = "rfFuncs",
                             'linear model' = "lmFuncs",
                             'naive bayes' = "nbFuncs"),
              selected = "rfFuncs"
  )
})

#RFE select best subset
output$ui_rfe_best_subset <- renderUI({
  if(is.null(input$dataset)) return()
  selectInput(inputId = "rfe_best_subset",
              label = "Best subset function",
              choices = c("PickSizeBest","PickSizeTolerance"),
              selected = "PickSizeBest"
  )
})

#Model metric
output$ui_rfe_model_metric <- renderUI({
  if (is.null(input$dataset)) return()
  dependent.var <- .get_model_data_rfe()$y #
  # browser()
  if(is.null(dependent.var) || length(dependent.var)==0) return()
  if(class(dependent.var[,1]) %in% c("numeric","integer")){ #TODO eventually deal with multiple Y
    options = c("RMSE","Rsquared")
  }else{
    options = list('Accuracy' = 'Accuracy','Kappa' = 'Kappa',
                   'ROC' = 'ROC','Sensitivity'='Sens','Specificity'='Spec')
  }
  selectInput(inputId = "rfe_model_metric",
              label = "Optimize",
              choices = options,multiple=F)
})

output$ui_rfe_plot_metric <- renderUI({
  if (is.null(input$dataset)) return()
  # browser()

  dependent.var <- .get_model_data_rfe()$y #
  if(is.null(dependent.var) || length(dependent.var)==0) return()
  if(class(dependent.var[,1]) %in% c("numeric","integer")){ #TODO eventually deal with multiple Y
    options = c("RMSE","Rsquared")
  }else{
    options = list('Accuracy' = 'Accuracy','Kappa' = 'Kappa',
                   'ROC' = 'ROC','Sensitivity'='Sens','Specificity'='Spec')
  }

  selectInput(inputId = "rfe_plot_metric",
              label = "Optimize",
              choices = options,multiple=F)
})

#RFE pick best size tolerance
output$ui_rfe_best_size_tolerance <- renderUI({
  if(is.null(input$dataset)) return()
  numericInput(inputId = "rfe_best_size_tolerance",
               label = "percent tolerance",value = .5,
               min = 0,step = .5

  )
})

output$ui_rfe_train_controls<-renderUI({
  fluidRow(
    column(12,
           selectInput(inputId = "rfe_resampling_method",
                       label = "resampling method",
                       choices = c("repeatedcv" = "repeatedcv",
                                   "cv" = "cv",
                                   "adaptive_cv" = "adaptive_cv",
                                   "none" = "none"
                       ),
                       selected = "repeatedcv"
           ),
           numericInput(inputId = "rfe_resampling_iterations",
                        label = "number of folds",
                        value = 3),
           numericInput(inputId = "rfe_cv_repeats",
                        label = "number of repeats",
                        value = 2,min=2),
           numericInput(inputId = "rfe_tune_length",
                        label = "tune length",
                        value = 1)

    )
  )
})

# rfe_resampling_method rfe_resampling_iterations rfe_cv_repeats rfe_tune_length

#selection tune UI
#for optimization
output$ui_rfe_select_tune<-renderUI({

  fluidRow(
    column(12,
      uiOutput("ui_rfe_subset_size"),
      uiOutput("ui_rfe_subset_step_size"),
      uiOutput("ui_rfe_functions"),
      uiOutput("ui_rfe_model_metric")
    )
  )
})

#for plottting
output$ui_rfe_plot_tune<-renderUI({

  fluidRow(
    column(12,
           uiOutput('rfe_plot_type_ui'),
           uiOutput("ui_rfe_plot_metric"),
           uiOutput("ui_rfe_best_subset"),
           conditionalPanel(
             condition = "input.rfe_best_subset == 'PickSizeTolerance'",
             uiOutput("ui_rfe_best_size_tolerance")
           )
    )
  )
})

#init even if not opened
#seems like this needs to be done for each div... should try shinyJS instead?
outputOptions(output, "ui_rfe_select_tune", suspendWhenHidden = FALSE)
outputOptions(output, "ui_rfe_train_controls", suspendWhenHidden = FALSE)
outputOptions(output, 'ui_rfe_functions', suspendWhenHidden = FALSE) # needs its own?
outputOptions(output, 'ui_rfe_subset_size', suspendWhenHidden = FALSE)
outputOptions(output, "ui_rfe_subset_step_size", suspendWhenHidden = FALSE)
outputOptions(output, "ui_rfe_functions", suspendWhenHidden = FALSE)
outputOptions(output, "ui_rfe_model_metric", suspendWhenHidden = FALSE)
outputOptions(output, "ui_rfe_best_subset", suspendWhenHidden = FALSE)
outputOptions(output, "ui_rfe_best_size_tolerance", suspendWhenHidden = FALSE)
outputOptions(output, 'ui_rfe_plot_tune', suspendWhenHidden = FALSE)
outputOptions(output, "ui_rfe_plot_metric", suspendWhenHidden = FALSE)

#module
#setup plot
rfe_plot <- reactive({
  lx <- ifelse (not_available(input$list_of_var) || isTRUE(input$viz_combx), 1, length(input$list_of_var))
  nr <- lx * 2
  if (lx > 1){
    plh <- (600/2) * ceiling(nr / 2)
    plw <- 1200
  }else{
    plh <- 400
    plw <- 600
  }
  list(plot_width = plw, plot_height = plh)
})

#module
rfe_plot_width <- function()
  rfe_plot() %>% { if (is.list(.)) .$plot_width else 600 }

#module
rfe_plot_height <- function()
  rfe_plot() %>% { if (is.list(.)) .$plot_height else 400 }


rfe_available <- reactive({
  if(is.null(input$rfe_calc) || input$rfe_calc ==0) {
    return("Calculate to view results")
  }
  if (is.na(input$rfe_calc))# not
    return("Please choose a dependent variable")
  "available"
})

#collect rfe vars
#not using
rfe_init<-reactive({
  list(
    func = input$rfe_functions,
    ctrl = create_rfe_control(func), # TODO: add cv ad tune controls
    data = .get_model_data_rfe()$full,
    subsize = input$rfe_subset_size,
    y = input$rfe_dependent_var,
    best_subset = input$rfe_best_subset,
    # metric = input$rfe_model_metric,
    metric = output$rfe_plot_metric,
    tolerance = input$rfe_best_size_tolerance
  )

})

rfe_subset<-reactive({
  #create subset
  body <-
    list(
      from = input$rfe_subset_size[1],
      to = input$rfe_subset_size[2],
      by = input$rfe_subset_step_size
    )

  pkg_url <-  'ocpu/library/base/R/seq'
  return_value <- FALSE


  ocpu_post(
    dave_ml_connection,
    body = body,
    pkg_url = pkg_url,
    encode = 'json',
    return_value = return_value
  )

})

#main function
runRFE <- eventReactive(input$rfe_calc,{

  #algorithm/validation tune
  func <- input$rfe_functions
  method <- input$rfe_resampling_method
  repeats <- input$rfe_resampling_iterations
  number <- input$rfe_cv_repeats
  tuneLength <-input$rfe_tune_length


  body <- list(
    func = func,
    method = method,
    repeats = repeats,
    number = number
  )

  shinyjs::show('rfe_progress_gif')

  ctrl <- ocpu_create_rfe_control(dave_ml_connection,body=body)


  train_data<-get_rfe_train_data()$data



  rfe_subset<-rfe_subset()

  .y <- input$rfe_dependent_var


  #could make this reactive to memoize?
  body <- list(
    data =  train_data,
    y = .y,
    subset = rfe_subset,
    ctrl = ctrl,
    tuneLength = tuneLength,
    seed = input$ml_set_seed
  )



  withProgress(message = "Ranking variables...", value = 1, {
    rfe_mod<-ocpu_create_rfe(dave_ml_connection ,body = body)
  })

  res<-rfe_mod # get_ocpu_obj(ocpu_session(rfe_mod))

  shinyjs::hide('rfe_progress_gif')


  #set values for summary
  dave_rfe_values[['rfe_calc_vars']]<-list( func = input$rfe_functions,
                                               method = input$rfe_resampling_method,
                                               repeats = input$rfe_resampling_iterations,
                                               number = input$rfe_cv_repeats,
                                               tuneLength =input$rfe_tune_length)
  return(res)

})

#progress
progress_gif<-system.file('app/www/imgs/loading.gif',package='dave.app')

output$rfe_progress_gif<-renderImage({
  list(
    src = progress_gif
  )
},deleteFile=FALSE)

outputOptions(output, 'rfe_progress_gif', suspendWhenHidden=FALSE)

#select best from calculated
.rfe <- reactive({

  rfRFE <- runRFE()

  best_subset <- input$rfe_best_subset
  metric <- input$rfe_plot_metric
  tolerance <- input$rfe_best_size_tolerance

  body<-list( rfRFE = rfRFE,
              best = best_subset,
              metric = metric,
              tolerance = tolerance)


  withProgress(message = "Selecting best variables...", value = 1, {
    out<-ocpu_rebuild_rfe(dave_ml_connection ,body = body)
  })



  # out<-rebuild_rfe(
  #                  rfRFE = rfRFE,
  #                  best = best_subset,
  #                  metric = metric,
  #                  tolerance = tolerance)

  dave_rfe_values[['rfe']]<-out
  dave_rfe_values[['rfe_select_args']]<-list(best_subset = input$rfe_best_subset,
                                                metric = input$rfe_plot_metric,
                                                tolerance = input$rfe_best_size_tolerance,
                                                func = input$rfe_function)



  return(out)


})


#outputs
.summary_rfe <- reactive({
  if (rfe_available() != "available")
    return(rfe_available() %>% html_text_format(.))
  #summary(.rfe())

  tmp <- .rfe()

  obj <- c(tmp$results,
           dave_rfe_values[['rfe_select_args']],
           dave_rfe_values[['rfe_calc_vars']],
           dave_rfe_values[['args']])
  class(obj) <- 'model_rfe'

  if (is.null(obj$rfe))
    return('The model is NULL, try different variables or options' %>% html_text_format(.))
  #browser()
  # summary(obj) %>% html_paragraph_format(.)
  do.call('summary', list(obj = obj)) %>% html_paragraph_format(.) # react to plotting updates..
})

output$.summary_rfe_ui<-renderUI({
  fluidRow(
    column(12,
      # textOutput("rfe_busy_mssg"), # dynamic out put of console messages
      HTML(.summary_rfe())
    )
  )
})


output$rfe_plot_type_ui<-renderUI({
  fluidRow(
    column(12,
      selectInput('rfe_plot_type','Type:',choices = c('overall','importance'),selected='overall'),
      uiOutput('ui_rfe_variable_names'),
      uiOutput('ui_top_nvars_rfe')
    )
  )
})

get_variable_names_rfe<-reactive({
  if(!is.null(input$rfe_variable_names)){

    id<-.get_model_data_rfe()$data %>% colnames()
    names<-.getdata_col_meta()[,input$rfe_variable_names]
    var_names<-data.frame(id,names)
  } else {
    var_names<-NULL
  }
  var_names
})


#prepare plots
.prepare_rfe_plots<-reactive({
  validate(
    need(rfe_available() == "available" && !is.null(input$rfe_plot_type), "Nothing to plot yet")
  )


  if(input$rfe_plot_type == 'importance'){
    var_names<-get_variable_names_rfe()
    nvar<-if(is.null(input$top_nvars_rfe)) 10 else input$top_nvars_rfe
    dave_rfe_values[['args']]<-list(nvar=nvar,var_names=var_names)  #else overwritten unless don't suspend
  }

  # cache for report # could set report defaults?
  return(dave_rfe_values[['args']])

})

.plot_rfe <- reactive({


  args<-.prepare_rfe_plots()

  do.call('plot',c(list(.rfe()$results,metric=input$rfe_plot_metric,
                        type=input$rfe_plot_type,func=input$rfe_function, print=FALSE),args))

})

#plotly
#TODO collect plot
#args in one place
output$plotly_rfe <- renderPlotly({


  args<-.prepare_rfe_plots()

  p<-do.call('plot',c(list(.rfe()$results,metric=input$rfe_plot_metric,
                        type=input$rfe_plot_type,
                        func=input$rfe_functions, print=FALSE),args))

  # p<-plot(.rfe(),metric=input$rfe_plot_metric,
  #         type=input$rfe_plot_type,
  #         func=input$rfe_functions, print=FALSE,var_names=var_names,nvar=nvar)
  ggplotly(p)
})

output$ui_rfe <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel(condition = "input.tabs_rfe == 'Calculate'",
                     tagList(
                       fluidRow(
                         column(12,
                                actionButton("rfe_calc", "Calculate",icon=icon('check'))
                         )
                       ),
                       br(),
                       bs_accordion(id="rfe_collapse_panel") %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("folder-open") , "Data"),
                                   content=
                                       fluidRow(
                                         column(12,
                                          uiOutput('rfe_dependent_var_type_ui'),
                                          uiOutput("ui_rfe_dependent_var"),
                                          uiOutput("ui_rfe_independent_var")
                                         )
                                       )
                         ) %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("balance-scale") , "Optimize"),
                                   content=
                                     uiOutput('ui_rfe_select_tune')
                         ) %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("sort") , "Validate"),
                                   content=
                                      uiOutput('ui_rfe_train_controls')
                         ) %>%
                        bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                                 content=
                                   uiOutput("ui_rfe_save")
                     )
                   )
    ),
    conditionalPanel(condition = "input.tabs_rfe  == 'Plot'| input.tabs_rfe  == 'Explore'",
                    tagList(
                      bs_accordion(id="rfe_collapse_panel") %>%
                        bs_append(title = tags$label(class='bsCollapsePanel', icon("crosshairs") , "Select"),
                                  content=
                                    uiOutput('ui_rfe_plot_tune')#TODO separate plot and select menues
                        )
                    )
    ),
    fluidRow(
      column(12,align="right",modalModuleUI(id="rfe_help")))

  )
})



###############################
# output is called from the main dave ui.R
###############################
output$rfe <- renderUI({
  register_print_output("summary_rfe", ".summary_rfe" )

  register_plot_output("plot_rfe", ".plot_rfe",
                       height_fun = "rfe_plot_height", width_fun = "rfe_plot_width")


  # two separate tabs
  rfe_output_panels <- tabsetPanel(
    id = "tabs_rfe",
    tabPanel(
      "Calculate",
      icon = icon("sliders"),
      uiOutput('.summary_rfe_ui'),
      shiny::tags$div(hidden(
        imageOutput('rfe_progress_gif', height = "100")
      ), style = "text-align: center;")
    ),
    tabPanel(
      "Explore",
      icon = icon('pencil-square-o'),
      plotlyOutput("plotly_rfe", height = "100%")
    ),
    tabPanel(
      "Plot",
      icon = icon("bar-chart"),
      plot_downloader("rfe", height = rfe_plot_height()),
      plotOutput("plot_rfe", height = "100%")
    ),
    tabPanel("Report", icon = icon('file-text-o'),
             reportGeneratorUI('rfe'))
  )
  stat_tab_panel(
    menu = tags$span(class = 'cer_menue', HTML(paste0(
      icon('university'), as.character(" Model")
    ))),
    tool = tags$span(class = 'cer_menue', HTML(paste0(
      icon('filter'), as.character(" Feature selection")
    ))),
    tool_ui = "ui_rfe",
    output_panels = rfe_output_panels
  )
})


# ###############################
# # observeEvent for actionButton
# ###############################
# #report
# observeEvent(input$rfe_report, {
#   figs <- FALSE
#   outputs <- c("summary")
#   inp_out <- list(list(dependent.var = input$rfe_dependent_var,
#                        train.percent = input$rfe_train_percent,
#                        set_seed_val = input$rfe_set_seed,
#                        tuneLength = input$rfe_tune_length
#   ))
#   #if (length(input$plot_type) > 0) {
#   outputs <- c("summary","plot")
#   inp_out[[2]] <- list(NULL) # not used
#   figs <- TRUE
#   #}
#   update_report(inp_main = clean_args(rfe_inputs(), rfe_args),
#                 fun_name = ".rfe",
#                 inp_out = inp_out,
#                 fig.width = rfe_plot_width(),
#                 fig.height = rfe_plot_height())
# })

#save ui
#Store data
output$ui_rfe_save<-renderUI({
  rfe_dataset <- input$dataset

  fluidRow(column(12,
                  h3("Save results"),
                  checkboxInput('filter_rfe_data','keep selected',value=FALSE),
                  tags$table(
                    tags$td(textInput("rfe_dataset", "Save as:", rfe_dataset)),
                    tags$td(actionButton("rfe_save", "Save"), style="padding-top:30px;")
                  )
  ))
})

#save
observeEvent(input$rfe_save, {


  # dataset <- input$dataset

  #main objects
  rfe<-dave_rfe_values[['rfe']]$results

  if(is.null(rfe)) return()

  #save and update data cube
  obj<-.getdata_cube()
  .names<-c(list(data=input$rfe_dataset),.makedata_cube_names(input$rfe_dataset))


  if(!is.null(rfe$rfe$optVariables)){
    obj$col_meta$rfe_selected<-colnames(obj$data) %in% rfe$rfe$optVariables

    #only keep selected
    id<-obj$col_meta$rfe_selected
    if(input$filter_rfe_data){
      obj$data<- obj$data[,id,drop=FALSE]
      obj$col_meta<- obj$col_meta[id,,drop=FALSE]
    }
  }

  #update data and col meta data
  #based on the filter results
  # if (is.null(r_data[[dataset]])) {
  r_data[[.names$data]] <- obj$data
  r_data[[.names$row]] <- obj$row_meta
  r_data[[.names$col]] <- obj$col_meta
  #inherit description, for now not used
  # r_data[[paste0(dataset,"_descr")]] <- r_data[[paste0(input$dataset,"_descr")]]
  r_data[['datasetlist']] %<>% c(unlist(.names),.) %>% unique

})

