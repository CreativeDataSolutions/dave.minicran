ml_params<-reactive({

  obj<-dave_ml_values[['model']][[input$dataset]]
  id<-names(obj) %in% input$report_model
  out<-obj[id]

  if(length(out)==0) out<-NULL


  list(params=out,args=get_ml_plot_args())

})


ml_report_obj<-function(){
  .package<-'dave.ml.app'
  report_name='model_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path=getOption("dave.report.rmd.path")
  html_save_path= getOption('dave.report.html.path')

  .report_obj<-get_report_obj(.package = .package,
                              report_name= report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)
  return(.report_obj)
}


name<-'ml'

ml_report<-callModule(reportGenerator, name,
                        report_params = ml_params,
                        report_obj = ml_report_obj(),
                        .available = ml_available)
