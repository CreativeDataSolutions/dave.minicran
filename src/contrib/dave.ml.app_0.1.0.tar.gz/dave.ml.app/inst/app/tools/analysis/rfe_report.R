rfe_params<-reactive({

  tmp<-.rfe()


  obj <- c(tmp$results,
           dave_rfe_values[['rfe_select_args']],
           dave_rfe_values[['rfe_calc_vars']],
           dave_rfe_values[['args']])
  class(obj) <- 'model_rfe'


 list(params=obj,args=dave_rfe_values[['args']]) # plotting arguments and total nvar to show)
  #return(obj)

})




rfe_report_obj<-function(){
  .package<-'dave.ml.app'
  report_name<-'rfe_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path = getOption("dave.report.rmd.path")
  html_save_path = getOption('dave.report.html.path')

  .report_obj<-get_report_obj(.package = .package,
                              report_name = report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)
  return(.report_obj)
}


name<-'rfe'

rfe_report<-callModule(reportGenerator, name,
                      report_params = rfe_params,
                      report_obj = rfe_report_obj(),
                      .available = rfe_available)

