
#model help
output$model_help_ui<-renderUI({
  fun<-input$model_type[1]
  if(is.null(fun)) return(HTML('Select modeling method to view info'))

  #use library
  # browser()
  lib<-getModelInfo(fun,regex=FALSE)[[1]]$library
  #make sure it is loaded
  body<-list(fun = fun,lib=lib)
  res<-ocpu_get_help_html(dave_ml_connection,body)
  require(lib,character.only = TRUE)
  #library help can be NULL
  #then try the function
  res<-tryCatch(get_help_html(fun,package=lib),error=function(e){NULL})

  if(is.null(res)){

    res<-tryCatch(get_help_html(lib),error=function(e){NULL})
  }

  if(is.null(res)){
    res<-'Description not found.'
  }

  return(res)
})

model_help_modal<-function() {

  modalDialog(
    fluidRow(
      column(12,
            uiOutput('model_help_ui')
      )
    ),
    footer = tagList(
      modalButton("Close")
    ),
    size = "s",
    easyClose = TRUE
  )
}

observeEvent(input$help_model_btn, {
  showModal(model_help_modal())
})
