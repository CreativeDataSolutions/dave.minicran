# progress_gif<-system.file('app/www/imgs/loading.gif',package='dave.app')
#
#
# output$ml_calculating_ui<-renderUI({
#   hidden(imageOutput('ml_progress_gif', height ="100"))
# })
#
# output$ml_progress_gif<-renderImage({
#   list(
#     src = progress_gif
#   )
# },deleteFile=FALSE)
#
# # outputOptions(output, 'ml_progress_gif', suspendWhenHidden=FALSE)
#
# test<-function(){
#
#   library(shiny)
#
#   ui <- pageWithSidebar(
#
#     headerPanel("renderImage example"),
#     sidebarPanel(
#       useShinyjs(),
#       actionButton('foo','bar'),
#       imageOutput('ml_progress_gif', height ="100")
#     ),
#     mainPanel(
#       # Use imageOutput to place the image on the page
#       uiOutput('ml_calculating_ui')
#     )
#   )
#
#   server <- function(input, output, session) {
#
#     observe({
#       input$foo
#       shinyjs::toggle('ml_progress_gif')
#       shinyjs::toggle('ml_calculating_ui')
#     })
#
#     output$ml_calculating_ui<-renderUI({
#       hidden(imageOutput('ml_progress_gif', height ="100"))
#     })
#
#
#     output$ml_progress_gif<-renderImage({
#       list(
#         src = progress_gif
#       )
#     },deleteFile=FALSE)
#
#   }
#
#   shinyApp(ui, server)
#
# }
