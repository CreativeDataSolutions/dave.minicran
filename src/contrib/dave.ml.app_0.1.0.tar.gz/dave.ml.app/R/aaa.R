#' dave.rf
#'
#' @name dave.ml.app
#' @docType package
#' @import ggplot2 shiny dplyr
NULL


#' filtered caret models information
#' @details models tested to work
#' @docType data
#' @keywords datasets
#' @name models
#' @usage data(models)
#' @format list of available models
NULL


#' filtered caret models passing simple classiffication and regression tests
#' @details models tested to work
#' @docType data
#' @keywords datasets
#' @name passing_models
#' @usage data(passing_models)
#' @format list of available models for classification and regression passing small data tests (multiple groups classification)
NULL
