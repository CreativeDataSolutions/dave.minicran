
#' @title check_model_deps
#' @export
#' @details load model depenancies or if absent try to install
check_model_deps<-function(model){
  x<- getModelInfo()
  deps<-x[[model]]$library
  check<-sapply(deps,require,character.only = TRUE)
  need<-deps[!check]
  #print(need)
  if(length(need) == 0) return()
  os_install(need)
}

#' @title getModelInfo
#' @export
#' @details get model information
getModelInfo<-function(model = NULL, regex = TRUE, ...){
    data(models,package = 'dave.ml.app') # fails to load?
    # models<-system.file('data/models.rda',package = 'dave.rf')

    if (!is.null(model)) {
      keepers <- if (regex)
        grepl(model, names(models), ...)
      else which(model == names(models))[1]
      models <- models[keepers]
      if (length(models) == 0) stop("That model is not in caret's built-in library")
    }

    models
}


#' @title fix_factor
#' @export
#' @details make sure factor levels (numeric, or logical) won't error caret
fix_factor<-function(x,name){
  check<- make.names(x) %>%
    grepl('^X',.) %>%
    any() | is.logical(x)

  if(check){
    x<-paste(name,x,sep='.') %>% make.names() %>% factor()
  }
  return(x)
}

#' @title get_models_by_y_type
#' @export
get_models_by_y_type<- function(type="Classification",passing=TRUE){
  a<-unlist(sapply(getModelInfo(),function(y) if(type %in% y$type) y[[1]]))

  b<-a[!is.null(a)]

  if(passing){
   data("passing_models")
    b<-b[names(b)%in%passing_models[[tolower(type)]]]
  }

  c<- names(b)
  names(c)<- paste0(b," (",c,")")
  return(c)
}

#' Summary method
#'
#' @param obj of class model_list
#' @export summary.model_list
#' @details summarise model results
summary.model_list<-function(mod){


  #description; hacky af
  args<-tolower(capture.output(print.train(mod$model)))

  #extract tunning
  single_tune<-FALSE
  st<-grep('resampling results',args)+2
  en<-grep('select the optimal model',args)-1 # if more than one tune var

  if(length(en)==0) { en<-grep('tuning parameter',args)-1; single_tune<-TRUE}

  empty<-length(st)==0 | length(en) ==0
  if(empty) {
    res<-mod_res<-NULL
  } else {
    #remove tune table
    tune<-args[st:en]

    x<-args[-c(st:en)]

    #mode desc
    res<-c(paste0('A ',
                  x[1],
                  'model was developed on ',
                  x[3], ' and ',
                  x[4], ' to predict',
                  x[5], 'with ',
                  x[7],'. ') %>% gsub("'",'',.),
           #cv desc
           paste0('Cross validation was done by ',
                  x[8],
                  '. '),
           if(single_tune){
             paste0(gsub("^(([[:alpha:]]))", "\\U\\1", x[12], perl=TRUE),".")
           } else {
             paste0(gsub("^(([[:alpha:]]))", "\\U\\1", x[12], perl=TRUE),
                    " ", # x[13],
                    gsub("^(([[:alpha:]]))", "\\U\\1", x[13], perl=TRUE)
             )
           }
         ) %>% paste(.,collapse='')


    #get optimal model statistics
    mat<-mod$model$results
    max<-mod$model$maximize
    metric<-mod$model$metric
    best<-mod$model$bestTune[1] #TODO fix for multiple,
    #out
    tmp<-mat %>% dplyr::select(dplyr::one_of(metric))
    id<- tmp %>% {
      if(max){
        which.max(.[,1])
      } else {
        which.min(.[,1])
      }
    }

    mod_res<-list(top=tmp[id,,drop=FALSE],
                  full=mat[id,,drop=FALSE]) #add SD to final

  }

  #get test data summary
  #control for classif or reg
  if(!is.null(mod$data$classification) && !empty){
    if(mod$data$classification){
      test<-list(top=mod$test_conf_mat$overall[[metric]],full=mod$test_conf_mat$overall)
    } else {
      test<-list(top=mod$test_res[[metric]],full=mod$test_res)
    }
  } else {
    test<-NULL
  }


  list(description=res,
        results=mod_res,
        conf_matrix = mod$test_conf_mat,
        test= test)

}

#' @title get_model_perf
#' @param multi_mod list of model_list class objects
#' @export
#' @details compare multiple model results and extract top model
#' based on training
get_model_perf<-function(multi_mod,select_best='test',...){

  #control for single model
  if(!'multi_model_list' %in% class(multi_mod)){
    #should skip but keeping formating?
    multi_mod<-list(multi_mod) %>%
      setNames(.,multi_mod$method)
  }


  out<-lapply(1:length(multi_mod),function(i){
    summary.model_list(multi_mod[[i]])
  }) %>%
    setNames(.,names(multi_mod))

  #combine all model results
  mat<-lapply(1:length(out),function(i){

    top<-out[[i]]$results$top
    if(is.null(top)) {
      .top<-NA
      .test<-NA
      desc<-multi_mod[[i]]$model #
      if(is.null(desc)) desc<-as.character(multi_mod[[i]])
      metric<-NA
      maximize<-NA
      time_min<-NA
    } else {
      .top<-top[[1]]
      .test<-out[[i]]$test$top
      desc<-out[[i]]$description
      metric<-names(top)
      maximize<-multi_mod[[i]]$model$maximize
      time_min<-multi_mod[[i]]$time
    }
    time_min<-multi_mod[[i]]$time
    data.frame(train=.top,test=.test,metric=metric,maximize=maximize,time_min=time_min,description=desc)
  }) %>%
    do.call('rbind',.)
  mat<-data.frame(model=names(multi_mod),mat)

  #select best model
  #need to know metric max/min
  best<-mat %>% na.omit() #
  if(nrow(best) ==0){
    best<-NULL
  } else {
    if(nrow(best)>1){

      #control selection based on
      #train or test performance
      #could be problem if no test?
      #could select on others? need min max
      if(select_best == 'test'){
        id<-if(best$maximize[1]) which.max(best$test) else which.min(best$test)
      } else {
        id<-if(best$maximize[1]) which.max(best$train) else which.min(best$train)
      }

      best<-best[id,,drop=FALSE]
    }
  }


  #create summary of all models
  y<-multi_mod[[1]]$y
  gen_desc<-paste0('Machine learning based predictive modelling was used to predict ',y,'.')
  if(length(multi_mod)== 1){
   desc<-paste0('A single model was fit and optimized based on predictive performance on the ',select_best,' data.')

  } else {
    desc<-paste0('A total of ', length(multi_mod) ,' models were fit and the best model was selected based optimal predictive performance on the ',select_best,' data.')
  }
  gen_desc<-paste(gen_desc,desc,collapse = ' ')

  list(description= gen_desc,best=best,results=mat,full=out)

}

#' @export
grammatical_paste<-function(obj,collapse=", "){
  len<-length(obj)
  if(len==1) obj else paste0(paste(obj[-len],collapse=collapse)," and ",obj[len],collapse="")
}

#' Summary method
#'
#' @param obj of class model_rfe
#' @param var_names to change variable names
#' @param nvar number of variables to list in summary
#' @export summary.model_rfe
#' @details summarise RFE results
#' @import dplyr
summary.model_rfe<-function(obj,var_names=NULL,nvar=5,...){
  desc<-'Recursive feature elimination (RFE) was used to identify top predictive variables. '
  desc<-c(desc,
          paste0('Backward and forward variable selection was done to optimize model ',
                 obj$metric,' using ',obj$func, ', validated with ',
                 obj$method," for ",obj$repeats,' folds repeated ',obj$number,' times while conducting ',
                 obj$tuneLength,' round(s) of model parameter tuning. ')
  )

  desc<-c(desc,
          paste0('The final model was selected based on the ',
                 {if(obj$best_subset == "PickSizeBest"){
                   'best subset'
                 } else {
                   paste0('best subset within a ',obj$tolerance,'% tolerance')
                 }
                 },
                 ' method. '
          )
  )

  #extract from rfe object
  #when there is a selection scoping changes?
  .best<-obj$rfe$bestSubset
  .res<-obj$rfe$results %>%
    filter(Variables == .best) %>%
    dplyr::select(dplyr::contains(obj$metric)) %>%
    unlist() %>%
    signif(.,3) %>%
    paste(.,collapse=' +/- ')
  desc<-c(desc,
          paste0('The selected model contains ',.best,' variable(s) and has ',
                 obj$metric, ' equal to ',.res,'.')
  )

  if(nvar>length(obj$selected)) nvar<-length(obj$selected)

  if(is.null(var_names)){

    desc<-c(desc,
            paste0(' The top ', nvar,' variables include: ',grammatical_paste(obj$selected %>% .[1:nvar] %>% na.omit()),'.'))
  } else {
    #get variable names

    .names<-left_join(data.frame(id=obj$selected),var_names,by='id')$names

    desc<-c(desc,
            paste0(' The top ', nvar,' variables include: ',grammatical_paste(.names %>% .[1:nvar] %>% na.omit()),'.'))
  }

  paste(desc, collapse = "")
}


#' Plot method
#' @param obj of class model_list
#' @export plot.model_list
#' @details plot a single or list of model properties
plot.model_list<-function(obj,type=c('performance', 'model','importance','confusion','classification'), ...){

  #only allow multiple model performance plot
  #model plot is tune variables specific so only facet multi
  if(type %in% c('confusion')){
    if('multi_model_list' %in% class(obj)) {
      obj<-obj[[1]]
    }
  }

  switch(type,
         performance = plot_performance(obj,...),
         importance = plot_importance(obj,...),
         model = plot_model(obj,...),
         confusion = plot_confusion_matrix(obj,...),
         classification = plot_classification_curve(obj,...))
}

#' Plot method
#' @param obj of class model_rfe
#' @param type one of overall or importance
#' @export plot.model_rfe
#' @details plot
plot.model_rfe <-function(obj,metric = 'Accuracy',type='overall',print=TRUE,func=NULL,...){ # selection should be external to capture in report


  if(type == 'overall'){
    x<-obj$rfe
    x$results$Selected <- ""
    x$results$Selected[x$results$Variables == x$bestSubset] <- "*"

    results <- x$results[, colnames(x$results) %in% c("Variables", "Selected", metric)]
    metric <- metric[which(metric %in% colnames(results))]
    results$size<-results$Selected %>% as.factor()  %>% as.numeric()

    resampText <- caret:::resampName(x, FALSE)
    resampText <- paste(metric, resampText)

    p<-ggplot(results,aes_string(y=metric,x='Variables')) +
      geom_line() +
      geom_point(aes_string(color='Selected',size='size'),show.legend = FALSE) +
      scale_color_manual(values=c('black','red')) +
      scale_size_continuous(range = c(2,5)) +
      ylab(resampText) +
      theme_bw()

    if(print) {print(p)} else {return(p)}
  }

  if(type == 'importance'){

    if(is.null(func)) func<-'default'
    selected<-obj$selected
    #make sure selected is colored right if there are no/all selected

    imp<-obj$rfe$variables
    obj<- imp %>%
      group_by(var) %>%
      summarise_at(.,'Overall',.funs=c(importance=median)) %>%
      arrange(desc(importance)) %>%
      mutate(variable=var,median=1:nrow(.),mad=0,model=func, ID=func,selected=variable %in% selected) %>%
      mutate(selected= factor(selected, levels = c(TRUE,FALSE)))
    #can have all selected/not... how to keep consistent? colors for plot

    plot_importance(obj,print=print,is_rfe=TRUE,...)
  }

}

#' Plot confusion matrix
#' @param
#' @export
#' @import ggplot2 reshape2
#' @details
plot_confusion_matrix<-function(conf_mat,percent=TRUE,print=TRUE,for_plotly=FALSE,test=TRUE,...){

  #toggle between train and test
  if(test){
     tmp<-conf_mat$test_conf_mat$table
     .title<-'test data'
  } else {
     tmp<-conf_mat$train_conf_mat$table
     .title<-'train data'
  }

  #normalize percents to group
  #ugly switch
  if(percent){
    total<-apply(tmp,2, sum)
    tmp<-round(tmp/total*100,0)
    confusion<-melt(tmp)
    colnames(confusion)<-c("Predicted","Actual","Percent")
    data<-confusion

    tile <- ggplot(data) +
      geom_tile(aes(x=Actual, y=Predicted,fill=Percent), color="black",size=0.1) +
      labs(x="Actual",y="Predicted") +
      scale_fill_gradient(low="white",high="#87c1fb")
    #text
    .text<-  geom_text(data=data,aes(x=Actual,y=Predicted, label=sprintf("%.1f", Percent)), size=3, colour="black")

  } else {
    confusion<-melt(tmp)
    colnames(confusion)<-c("Predicted","Actual","Number")
    data<-confusion
    tile <- ggplot(data) +
      geom_tile(aes(x=Actual, y=Predicted,fill=Number), color="black",size=0.1) +
      labs(x="Actual",y="Predicted") +
      scale_fill_gradient(low="white",high="#87c1fb")
    .text<- geom_text(data=data,aes(x=Actual,y=Predicted, label=Number), size=3, colour="black")
  }

  # lastly we draw diagonal tiles. We use alpha = 0 so as not to hide previous layers but use size=0.3 to highlight border
  .plot<-tile + .text + theme_minimal()

  #avoid plotly errors
  #use with ggplotly
  if(for_plotly){

    return(.plot)
  } else {
    .data<-subset(data, as.character(Actual)==as.character(Predicted))
    .plot<- .plot + # this breaks for plotly
      geom_tile(data=.data,
                aes(x=Actual,y=Predicted), color="black",size=0.3, fill="black", alpha=0)
  }

  #show train/test
  .plot<-.plot + ggtitle(.title)


  if(print){
    print(.plot)
  } else {
    return(.plot)
  }

}

#' @export
#' @param select_best use train or test performance to select best model
#' @param weight base model and importance contribution to each variable based on 'rank' or 'difference' from the top
#' @details calculate importance across multiple models, overall rank is based on variable importance * model rank
#' @return top model importance and median overall rank
get_importance<-function(obj,select_best='test',weight='difference',...){

  #model weight
  #use test rank
  res<-get_model_perf(obj,select_best=select_best)

  #rank all models use order and difference?
  if(weight == 'rank'){
    mod_rank<-res$results %>%
      {if(any(.$maximize)) {
        mutate(.,modrank=rank(.[,select_best]))
      } else {
        mutate(.,modrank=rank(1/.[,select_best]))
      }
      }
  }


  if(weight == 'difference'){
    mod_rank<-res$results %>%
    {if(any(.$maximize)) {
      mutate(.,modrank=.[,select_best])
    } else {
      mutate(.,modrank={1/.[,select_best]})
    }
    }
  }


  #handle multiple models
  normalize_importance<-function(obj){
    .imp <- obj$importance
    if(is.null(.imp)){return(NULL)}

    # .imp$importance<-na.omit(.imp$importance[1:nvar,,drop=FALSE]) # done in the plot

    #need to switch between classification
    #and regression importance
    ov<-.imp$importance$Overall

    multi<-FALSE
    if(is.null(ov)) {
      tmp<-.imp$importance
      if(ncol(tmp)==2){
        .imp<-data.frame(variable=rownames(.imp$importance), importance=tmp[,1]) # two class all are equal
      } else {
        multi<-TRUE
        .imp<-data.frame(variable=rownames(.imp$importance), tmp)
        .imp<-melt(.imp,id.vars='variable') # could fix numeric
        .imp<-setNames(.imp,c('variable','group','importance'))
      }
    } else {
      .imp<-data.frame(variable=rownames(.imp$importance), importance=ov)

    }

    return(.imp)# more official to return
  }

  #multiple models
  if('multi_model_list' %in% class(obj)) {
    res<-lapply(1:length(obj), function(i){
      normalize_importance(obj[[i]]) %>%
        data.frame(model=names(obj)[i],.)
    }) %>%
      do.call('rbind',.)
  } else {
    res<- normalize_importance(obj) %>%
      data.frame(model=obj$method,.)
  }



  #split ID could include group
  res$ID<-res %>%
    select(-one_of('importance','variable')) %>%
    apply(.,1,paste,collapse='_')


  #induvidual rank
  in_model_rank<-res %>%
    split(.,.$ID)

    tmp<-lapply(1:length(in_model_rank), function(i){
      x<-in_model_rank[[i]]
      if(weight == 'difference'){ # will get zeros
        x$irank<-scale(x$importance,center = TRUE) %>%
        {. - min(.)} %>% as.numeric()
      }

      if(weight == 'rank'){
        x$irank<-rank(x$importance)
      }
     #rank(1/x$importance) # bigger better, order does not work?
      x$mrank<-mod_rank %>%
        filter(model == names(in_model_rank)[i]) %>%
        .$modrank
      x %>% mutate(frank=irank*mrank) #final rank, multiply?
    }) %>%
      do.call('rbind',.) %>%
      group_by(variable) %>%
      summarise_at(.,'frank',.funs=list(median=median,mad=mad))



  #show winning model distance
  id<-mod_rank %>%
      .$modrank %>%
      which.max() %>%
      mod_rank$model[.]

  #overall rank and top model distance
  #reverse rank for plotting

  left_join(tmp,in_model_rank[[names(in_model_rank)[names(in_model_rank) %in% id]]],by='variable') %>%
    mutate(median=rank(1/median))

}

#' @title plot_importance
#' @param var_names two column data drame containing model data column names and new names
#' @param noplot hack to get selected variables for a table output
#' @export
#' @import ggplot2 reshape2 RColorBrewer
plot_importance<-function(obj, nvar=10,print=TRUE,is_rfe=FALSE,var_names=NULL,noplot=FALSE,figs=2, ...){



  #not tested for multiclass
  #for rfe
  if(is_rfe) {

    if(is.null(var_names)){
      .imp<-obj %>%
        arrange(median) %>%
        .[1:nvar,] %>%
        na.omit(.)
    } else {

      .imp <- obj
      .names<-left_join(.imp,var_names,by=c('variable'='id'))
      .imp$variable<-.names$names

      .imp<-.imp %>%
        arrange(median) %>%
        .[1:nvar,] %>%
        na.omit(.)

    }


    #force consistent colors when factor levels are absent
    .col <- brewer.pal(3,"Set1")[1:2] #[.imp$selected]
    .size<-c(4,1.5)

    if(all(as.logical(.imp$selected))) {
      .col <- .col[1] #[.imp$selected]
      .size<-.size[1] #[.imp$selected])
    }

    if(all(!as.logical(.imp$selected))) {
      .col <- .col[2] #[.imp$selected]
      .size<-.size[2] #[.imp$selected])
    }

    size<-scale_size_manual(values=.size)
    extra <- list(scale_colour_manual(name = "selected",values = .col), size)

    points<- geom_point(aes(color=selected,size=selected)) #can't add untill ggplot exists

  } else {
    #add variable names
    #need to join original colnames with varinfo

    if(is.null(var_names)){
      .imp <- get_importance(obj,...) %>%
        arrange(median) %>%
        .[1:nvar,] %>%
        na.omit(.)
    } else {

      .imp <- get_importance(obj,...)
      .names<-left_join(.imp,var_names,by=c('variable'='id'))
      .imp$variable<-.names$names

      .imp<-.imp %>%
        arrange(median) %>%
        .[1:nvar,] %>%
        na.omit(.)

    }
    points<-geom_point(size=2.5,color='gray')
    extra<-NULL
  }

  #detect group based on ID?
  if(all(grepl('_',.imp$ID))) multi<-TRUE else multi<-FALSE
  if(!multi){
    .imp<-.imp[order(.imp$median,decreasing = TRUE),]
    .imp$variable<-factor(.imp$variable,labels=.imp$variable,levels=.imp$variable,ordered=TRUE)
    facet<-NULL
  } else {
    facet<-facet_wrap(~group)
  }


  #plot
  .plot <- ggplot(.imp, aes(x=variable,y=importance)) +
    geom_linerange(aes(ymin = 0, ymax = importance)) +
    coord_flip() +
    points +
    extra +
    # geom_point(aes(size=mad,alpha=1/mad),show.legend = FALSE) +
    # scale_size(range=c(2,6)) +
    geom_hline(yintercept=0,size=1,color='gray',linetype=2) +
    facet +
    theme_bw(base_size=20) +
    xlab('overall rank') +
    ylab(paste0(unique(.imp$model),' importance'))


  if(noplot) return(.imp)

  if(print){
    print(.plot)
  } else {
    return(.plot)
  }
}


#' @title plot_model
#' @param model caret model
#' @import ggplot2
#' @export
plot_model<-function(model,print=TRUE,...){

  #
  format_model<-function(model){
    tmp<-model$model$results
    tmp[tmp=='NaN']<-NA

    #get metrics and error vars
    sd_vars<-tmp %>% dplyr::select(dplyr::contains('SD')) %>% colnames()
    vars<-gsub('SD','',sd_vars)
    tune_vars<-colnames(tmp)[!colnames(tmp) %in% c(vars,sd_vars)]
    lapply(seq_along(vars), function(i){
      data.frame(tmp %>% dplyr::select(one_of(tune_vars)),metric=vars[i],
                 id=1:nrow(tmp),
                 value=tmp %>% dplyr::select(one_of(vars[i])) %>% unlist(),
                 variance=tmp %>% dplyr::select(one_of(sd_vars[i])) %>% unlist()) %>%
        mutate(low=value - variance,
               high=value + variance)
    }) %>%
      do.call('rbind',.)
  }

  #multiple models
  if('multi_model_list' %in% class(model)) {
    res<-lapply(1:length(model), function(i){
      format_model(model[[i]])
    }) %>%
      setNames(.,names(model))
  } else {
    res<- format_model(model) %>%
      list(.) %>%
      setNames(.,model$method)
  }

  #fix params and melt as tune
  melt_tune<-function(obj,exclude=c("metric", "id", "value", "variance", "low", "high")){

    name_vals<-function(x){
      paste0(names(x),'[',x[,],']')
    }

    lapply(1:length(obj), function(i){

      main<-obj[[i]]

      x<-main %>%
      select(-one_of(exclude))

      tune<-lapply(1:ncol(x), function(i){
        name_vals(x[,i,drop=FALSE])
      }) %>%
        unlist() %>%
      data.frame(tune=.)

      other<-main %>%
        select(one_of(exclude))

      data.frame(model=names(obj)[i],tune,other)

    }) %>%
      do.call('rbind',.)


  }

  tmp<-melt_tune(res)


  #model as color
  #tune var as x; bind name and value
  #value as y


  .plot<-ggplot(tmp,aes(y=value,x = tune,group=metric,color=model)) +
    geom_point() +
    geom_errorbar(aes(ymax =high ,ymin = low), position='dodge', width=0.25) +
    facet_grid(.~ metric ) +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))

  if(print){
    print(.plot)
  } else {
    return(.plot)
  }
}

#' @title t_mins
#' @param x of class POSIX.lt
#' @details conversion of diff time to minutes (ignores day)
t_mins<-function(x){
  #assume model time < 1 day
  hrs<-if(attr(x,'units')=='hrs'){
    x[[1]]/60
  } else { 0 }
  mins<-if(attr(x,'units')=='mins'){
    x[[1]]
  } else { 0 }
  secs<-if(attr(x,'units')=='secs'){
    x[[1]]/60
  } else { 0 }
  hrs+mins+secs
}

#' Plot method
#' @param obj results from get_model_perf
#' @param print return plot or plot object
#' @export
#' @import ggplot2 dplyr ggrepel
#' @importFrom reshape2 melt
#' @importFrom plotly ggplotly
#' @importFrom ggrepel geom_text_repel
plot_performance<-function(obj,print=TRUE,labels=TRUE,...){

  res<-get_model_perf(obj)

  obj1<-res$results %>%
    data.frame() %>%
    melt(.,id.vars=colnames(.)[!colnames(.) %in% c('test','train')])

  #create ggplot labels
  if(labels){
    labs<-geom_text_repel(aes(label=model))
  } else {
    labels<-NULL
  }

  p<-ggplot(obj1,aes(x=time_min,y=value,color=variable,text=model)) +
    geom_point(size=1.5, alpha=.75) +
    labs +
    labs(color='model') +
    ylab(obj1$metric %>% na.omit() %>% .[1]) +
    xlab('time (min)') +
    scale_color_brewer(palette = 'Set1') +
    theme_classic() +
    guides(colour = guide_legend(override.aes = list(size=3,alpha=1)))

  if(print) {print(p) } else { return(p) }
}

#' @title ml_model_perf_table
#' @export
#' @import formattable
ml_model_perf_table<-function(tab,best,round=2,for_pdf=FALSE){
  #hacking text highlighting
  id<-tab$model %in% best$model
  tab$model[id]<-paste0(tab$model[id],'best')

  tab<-tab %>%
    mutate_if(is.numeric,funs(round(.,2)))


  if (for_pdf) {
    kbl(tab) %>%
      kable_styling(
        bootstrap_options = c("striped", "hover", "condensed", "responsive"),
        latex_options = "scale_down"
      )
  } else {
    formattable(tab,
                list(
                  model = formatter(
                    "span",
                    style = x ~ style(
                      display = "block",
                      "border-radius" = "4px",
                      "padding-right" = "4px",
                      "background-color" = sapply(x, function(xx) {
                        highlight_text(xx)$color
                      })
                    ) ,
                    x ~ sapply(x, function(xx) {
                      highlight_text(xx)$text
                    })
                  ),
                  train = color_bar(color = "lightgray"),
                  test = color_bar(color = "lightgray")
                ))
  }

}

#' @title make_roc_curve
#' @param type one of 'roc' or 'pr' for AUCROC or precision and recall
#' @export
#' @import PRROC
make_classification_curve<-function(mod,test=TRUE,type='roc'){


  #test if it is a classification model before trying
  #needs to be binary

  if(test){
    preds<-data.frame(actual=mod$data$test.data %>% select(mod$y) %>% unlist(),pred=mod$test_pred)
    preds<-preds == mod$test_conf_mat$positive
    preds<-data.frame(preds)
  } else {
    preds<-data.frame(actual=mod$data$train.data %>% select(mod$y) %>% unlist(),pred=mod$train_pred)
    preds<-preds == mod$train_conf_mat$positive
    preds<-data.frame(preds)
  }

  if(type == 'roc'){
    roc.curve(scores.class0=preds$actual %>% as.numeric(),weights.class0=preds$pred %>% as.numeric(), curve=TRUE)
  } else {
    pr.curve(scores.class0=preds$actual %>% as.numeric(),weights.class0=preds$pred %>% as.numeric(), curve=TRUE)
  }

}

#' @title multi_make_roc_curve
#' @export
multi_classification_curve<-function(mod,test=TRUE,type='roc'){

  if(!'multi_model_list' %in% class(mod)){
    mod<-list(model=mod) #TODO make multi and single consistant
  }

  lapply(1:length(mod),function(i){
    #check if it is appropriet
    roc <- tryCatch(make_classification_curve(mod[[i]],test=test,type=type),error=function(e){NULL})
    if(is.null(roc)) return()
    out <- roc$curve[,1:2] %>% data.frame()

    if(type == 'roc'){
      colnames(out) <- c('FPR','Sensitivity')
      auc <- roc$auc
    }

    if(type == 'pr'){
      colnames(out) <- c('Recall','Precision')
      auc <- roc$auc.integral
    }

    out$AUC<-auc
    out$model <- names(mod)[i]
    out$'Model (AUC)' <- paste0(names(mod)[i], ' (',round(auc, 2),')' )
    out

  }) %>%
    do.call('rbind',.)
}

#' @title plot_classification_curve
#' @details plot or create and plot
#' @export
#' @import ggplot2
plot_classification_curve<-function(obj,test=TRUE,curve='roc',create=TRUE,...){

  if(create){
    obj<-multi_classification_curve(obj,test=test,type=curve)
    if(is.null(obj)) return()
  }

  if(curve == 'roc'){
    .p<-obj %>%
      ggplot(aes(x=FPR, y=Sensitivity, colour=`Model (AUC)`))
  }

  if(curve == 'pr'){
    .p<-obj %>%
      ggplot(aes(x=Recall, y=Precision, colour=`Model (AUC)`))
  }

  title<-ifelse(curve == 'roc','AUROC','Precision Recall Curve')

  .p +
    geom_line(size=1) +
    scale_color_brewer(palette = 'Set1') +
    theme_classic()  +
    ggtitle(title)
}


#test function
test<-function(){

  library(dave.ml.app)
  library(dave.stat) # for the data
  # library(dave)
  data('dave_data')

  #
  # #small testing data
  # #----------------
  data("mtcars")
  tmp<-mtcars
  #binary
  tmp$am<-factor(tmp$am %>% make.names())
  y<-'am'

  # #multi
  tmp$cyl<-factor(tmp$cyl %>% make.names())
  y<-'cyl'


  # #larger test data
  # #--------------

  library(dave.preproc)
  data("dave_")

  tmp<-dave_ %>% dplyr::select(-age,-label)
  tmp[is.na(tmp)]<-1
  y<-'class'


  #create model
  #------------
  .metric<-'Accuracy'
  .data <- create_model_data(tmp,y)
  classProbs<-TRUE
  tuneN<-1
  fitControl <- create_fit_control("repeatedcv",2,2,classProbs=classProbs,verboseIter = TRUE)

  # # #single model
  # # #---------------
  .method<-'rf'#'pls'#AdaBoost.M1'#'pls'
  mod<-multi_create_predictive_model(.data,y, metric=.metric,method = .method,fitControl = fitControl,tuneN=tuneN)
  summary(mod)

  #summary
  res<-get_model_perf(mod,select_best='test')

  #plot
  #type=c('performance', 'model','importance','confusion')
  plot(mod,type='performance')
  plot(mod,type='classification')
  plot(mod,type='model')
  plot(mod,type='importance')
  plot(mod,type='importance')
  plot(mod,type='confusion',percent=FALSE)

  #plot labels
  var_names<-data.frame(id=make.names(colnames(mtcars)),names=paste('var',1:ncol(mtcars),sep='_'))
  plot(mod,type='importance',var_names=var_names)

  #multiple models
  #---------------
  #classification tests
  #--------------------
  # n_tests<-5
  # ## all methods
  # .methods<-get_models_by_y_type(type='Classification',passing=TRUE)
  # .method <- .methods[sample(1:length(.methods), n_tests)]
  .method<-c('rf','pls','svmRadial') # error 'bstTree'

  mod<-multi_create_predictive_model(.data,y, metric=.metric,method = .method,
                                       fitControl = fitControl,tuneN=tuneN,plan='sequential')

  #plot
  plot(mod,type='classification',curve='pr')

  #sequential
  start<-Sys.time()
  # plan('sequential')
  mods1<-multi_create_predictive_model(.data,y, metric=.metric,method = .method,
                                       fitControl = fitControl,tuneN=tuneN,plan='sequential')
  serial<-Sys.time()-start

  #multicore
  #only unix
  plan('multicore')
  options('mc.cores'=4)
  start<-Sys.time()
  mods2<-multi_create_predictive_model(.data,y, metric=.metric,method = .method,fitControl = fitControl,tuneN=tuneN,plan='multicore',ncores=4)
  parallel<-Sys.time()-start

  #multiprocess .... multiple R sessions
  start<-Sys.time()
  mods2<-multi_create_predictive_model(.data,y, metric=.metric,method = .method,fitControl = fitControl,tuneN=tuneN,plan='multiprocess',ncores=4)
  (multi<-Sys.time()-start)

  #cluster
  cl <- parallel::makeCluster(c("n1", "n2", "n3"))
  plan(cluster, workers = cl)
  start<-Sys.time()
  mods2<-multi_create_predictive_model(.data,y, metric=.metric,method = .method,fitControl = fitControl,tuneN=tuneN,plan= plan(cluster, workers = cl),ncores=4)
  multi<-Sys.time()-start
  parallel::stopCluster(cl)

  identical(mods1,mods2)

  #summarise
  res<-get_model_perf(mods)
  #summary
  res$best$description
  res$description
  res$results

  plot(mods,type='performance')
  plot(mods,type='importance',select_best='test')
  plot(mods,type='model') # on
  plot(mods,type='confusion') # only one model


  #debug importance
  plot(mods,type='importance',select_best='test')#,noplot=TRUE)
  plot(mod,type='importance',select_best='test')#,noplot=TRUE)

  #benchmark serial vs parallel
  #strange that parallel is slower
  start<-Sys.time()
  out<-list()
  for(i in .method){
    out[[i]]<-create_predictive_model(.data,y, metric=.metric,method = i,fitControl = fitControl,tuneN=tuneN)
  }
  serial<-Sys.time()-start

  start<-Sys.time()
  mods<-multi_create_predictive_model(.data,y, metric=.metric,method = .method,fitControl = fitControl,tuneN=tuneN,plan='sequential')

  parallel<-Sys.time()-start

  #-----------
  #RFE tests
  #-----------

  #
  # #small testing data
  # #----------------
  data("mtcars")
  .data<-mtcars
  #binary
  .data$am<-factor(.data$am %>% make.names())
  y<-'am'
  subset<-seq(1,ncol(.data),by=5)
  func<-'rfFuncs'
  tuneLength<-1

  #local mode
  library(dave.ml)
  ctrl<-create_rfe_control(func) # add cv inputs
  rfe <- create_rfe(.data,y,subset,ctrl,tuneLength) # add tune inputs

  # plot(rfe) # default caret
  # summary(rfe) # absent
  #

  #pick subset
  best<- "PickSizeBest" #'pickSizeTolerance' #"PickSizeBest"#'pickSizeTolerance'
  metric<-'ROC'

  best<- 'pickSizeTolerance'
  tolerance<-5


  .rfe<-rebuild_rfe(rfe,best, metric, tolerance)

  plot(.rfe,metric = metric)
  var_names<-data.frame(id=make.names(colnames(mtcars)),names=paste('var',1:ncol(mtcars),sep='_'))
  plot(.rfe,type='importance',func=func,var_names=var_names)
  #get table
  tab<-plot(.rfe,type='importance',noplot=TRUE,func=func,var_names=var_names)

  tab %>% arrange(median) %>%
    .[.$selected %>% as.logical(),] %>%
    select(one_of(c('variable','importance'))) %>%
    mutate(importance=round(importance,1)) %>%
    formattable(.,list(
      importance= color_bar(color = "lightgray")))


  #summary
  #need more variables for summary
  #ugly collection
  mod_info<-list( func = func,
        method = ctrl$method,
        repeats = ctrl$repeats,
        number = ctrl$number,
        tuneLength =tuneLength,
        best_subset = best,
        metric = metric,
        tolerance = tolerance)

  main<-c(mod_info,.rfe)
  class(main)<-'model_rfe'

  summary(obj=main)





  #OLDER TESTS
  #-----------
  {
  # #summary based on caret capture summary capture
  # mod_summary(mod)
      #################################################################################
  #fit multiple models in parallel
  library(future)

  #class
  y <- "cyl" # for some classif model this needs to be numeric?
  .metric<-'Accuracy'

  .data <- create_model_data(tmp,y)
  classProbs<-TRUE
  tuneN<-1
  #cv cant be 1 or has to be nrow(data)/cv fold > ceiling 2
  fitControl <- create_fit_control("repeatedcv",2,2,classProbs=classProbs,verboseIter = TRUE)

  #class
  #opts<-get_models_by_y_type() %>% matrix()
  mods<-get_model_info() %>% filter(type == "Classification") %>% dplyr::select(name)
  opts<-mods[,1] %>% matrix()
  .metric<-'Accuracy'
  .method <- opts
  .method<-.method[-19] #remove blackboost(crashing the system)
  y <- "cyl" # "am" (two class classification) for some classif model this needs to be numeric?



  #Detach packages after model run
  #check pathway module
  plan("multicore")
  options(mc.cores = 4)
  multi_mod_class<- future_lapply(1:length(.method), function(i) {
    set.seed(123)
    cat(.method[i])
    tim<-system.time(clas<-tryCatch(create_predictive_model(.data,y,vars=colnames(tmp)[c(-1,-2)], metric=.metric,method = .method[i],fitControl = fitControl,tuneN=tuneN),
             error=function(e){e}))
    list(tim=tim,clas=clas)
    #unloadNamespace(.method[i])
  }) %>%
    setNames(.,.method)

  time_c <- as.data.frame(t(sapply(multi_mod_class,function(x) x[[1]])))
  class_res<-get_model_perf(lapply(multi_mod_class,function(x) x[[2]]))
  passing_class<-class_res$results %>% na.omit() %>% .$model

  time_c$model<-row.names(time_c)
  res_c<-merge.data.frame(class_res$results,time_c)

  plot_ly(res_c,x= ~elapsed, y= ~train, text = ~paste("Model: ", model))

  save(passing_class,file='data/passing_class.rda')
  save(multi_mod_class, file='data/multi_mod_class2.rda')

  load(file='inst/tests/multi_mod_class2.rda')

  load(file='data/passing_class.rda')
#--------------------------------------------------------------------
  #reg
  y <- "mpg"
  .metric<-'RMSE'
# =======
#   # #reg
#
#   #dave
#   library(dave.preproc)
#   data("dave_")
#
#   tmp<-dave_ %>% dplyr::select(-age,-label)
#   y<-'class'
# #


  .data <- create_model_data(tmp,y)
  classProbs<-TRUE
  tuneN<-2
  .metric<-'Accuracy'
  method <- 'xgbTree'# 'xgbTree'
  #cv cant be 1 or has to be nrow(data)/cv fold > ceiling 2
  fitControl <- create_fit_control("repeatedcv",2,2,classProbs=classProbs,verboseIter = TRUE)

  ##########################################################
  #reg
  #opts<-get_models_by_y_type(type='Regression') %>% matrix()
  mods<-get_model_info() %>% filter(type == "Regression") %>% dplyr::select(name)
  opts<-mods[,1] %>% matrix()
# =======
#
#   mod<-create_predictive_model(.data,y,vars=colnames(tmp), metric=.metric,method = method,fitControl = fitControl,tuneN=tuneN)
#
#   summary(mod)
#
#   #multi model summary
#   mod<-list(mod) %>% setNames(.,method)
#   res<-get_model_perf(mod)
#
#   # #summary based on caret capture summary capture
#   # mod_summary(mod)
#
#   #install required packages
#   packages<-getModelInfo() %>%
#     lapply(.,function(x){ x$library}) %>%
#     unlist() %>% unique()
#   lapply(1:length(packages),function(i){
#     if(! require(packages[i],character.only = TRUE)){
#      install.packages(packages[i])
#     }
#   })
#
#   #get package documentation
#   p_link<-function(topic,package){
#     paths <- system.file(unpackage=package)
#   }
#
#   link('ada')
#
#   #fit multiple models in parallel
#   #class
#   opts<-get_models_by_y_type(passing=FALSE)
#   .method <- opts
#   .metric<-'Accuracy'
#   #reg
#   opts<-get_models_by_y_type(type='Regression',passing=FALSE) %>% matrix()
# >>>>>>> 6d42384bc69c3c18ec1b0aa69cd8be098b2f1d7c
  .metric<-'RMSE'
  .method <- opts
  y <- "mpg"

  plan(multiprocess) # parallel
  multi_mod_reg<- future_lapply(1:length(.method), function(i) {
    set.seed(123)
    cat(.method[i])
    tim<-system.time(reg<-tryCatch(create_predictive_model(.data,y,vars=colnames(tmp)[c(-1,-2)], metric=.metric,method = .method[i],fitControl = fitControl,tuneN=tuneN),
             error=function(e){e}))
    list(tim=tim,reg=reg)
    #unloadNamespace(.method[i])
  })%>%
    setNames(.,.method)

  time_r <- as.data.frame(t(sapply(multi_mod_reg,function(x) x[[1]])))
  reg_res<-get_model_perf(lapply(multi_mod_reg,function(x) x[[2]]))

  time_r$model<-row.names(time_r)
  res_r<-merge.data.frame(reg_res$results,time_r)

  plot_ly(res_r,x= ~elapsed, y= ~train, text = ~paste("Model: ", model))

  passing_reg<-reg_res$results %>% na.omit() %>% .$model
  save(multi_mod_reg,file='data/multi_mod_reg2.rda')
  save(passing_reg,file='data/passing_reg.rda')
################################################################################

  #saved mtcars tests
  # save(multi_mod,file='inst/tests/mtcars_reg')
  # load(file='inst/tests/mtcars_reg')
  # load(file='inst/tests/mtcars_class')

  res<-get_model_perf(multi_mod)

  #add multiple elements to an existing list

  tmp<-list(bar='foo')
  new<-list(bar=list('baz'),foo='bar')

  tmp[names(new)]<-new

#   #collect passing model names
#   #might want to re-evaluate later?
   # passing_reg<-res$results %>% na.omit() %>% .$model
   # passing_class<-res$results %>% na.omit() %>% .$model
   # passing_models<-list(regression=passing_reg,classification=passing_class)
   # save(passing_models,file='data/passing_models.rda')
   #
  # passing_reg<-res$results %>% na.omit() %>% .$model
  passing_class<-res$results %>% na.omit() %>% .$model
#   passing_models<-list(regression=passing_reg,classification=passing_class)
#   save(passing_models,file='data/passing_models.rda')

  #need to check all models
  #capture error to debug later
  #for classif: character


  #get model summary
  tmp<-mod$model
  tmp$modelInfo$label

  paste(paste(names(tmp$bestTune),unlist(tmp$bestTune), sep=' = '), collapse=", ")


    #debug ggplotly confusion
  p<-plot_confusion_matrix(mod,for_plotly = FALSE)
  plotly::ggplotly(p)


  #RFE tests
  #----------
  .data<-aq_data[,1:200]
  subset<-seq(1,ncol(.data),by=10)

  ctrl<-create_rfe_control('rfFuncs') # add cv inputs
  rfe <- create_rfe(.data,"cellType",subset,ctrl) # add tune inputs
  #pick subset
  best<-"PickSizeBest"
  metric<-'ROC'
  tolerance<-.5
  y<-NULL
  .rfe<-rebuild_rfe(rfe,best, metric, tolerance)

  plot(.rfe,metric = metric)

  #RFE summary
  obj<-list(rfe=.rfe,
      best_subset = best,
      metric = metric,
      tolerance = tolerance,
      func = 'rfFuncs',
      method = 'repeated_cv',
      repeats = 3,
      number = 3,
      tuneLength = 1)
  class(obj)<-'model_rfe'
  summary(obj)

  model<-'ada'
  metric<-'ROC' # needs special return fun caret::twoClassSummary()  set in train
  classProbs<-TRUE
  tuneN<-1
  fitControl <- create_fit_control("repeatedcv",7,3,classProbs=classProbs,verboseIter = TRUE)
  cmod<-create_predictive_model(.data,y,method=model,metric=metric,tuneN=tuneN,fitControl=fitControl)



  library(dave.rf)

  #view all available models
  avail<-get_model_info()

  #small data
  data(mtcars)
  data<-mtcars
  var<-'am'
  #need to check y for valid levels if classification
  data[[var]]<-factor(data[,var]) %>% fix_factor(.,var) #make.names()#fix_factor(.,var)
  y<-'am'
  fitControl <- create_fit_control("repeatedcv",28,3,classProbs=classProbs,verboseIter = TRUE)
  create_predictive_model(.data,y,vars='.', method = 'rf',fitControl = fitControl)


  #custom classification model
  #--------------------------
  .data<-create_model_data(data,y)
  model<-'ada'
  #need to add fun which checks if model
  #will support classification or regression
  #an add error handling

  metric<-'ROC' # needs special return fun caret::twoClassSummary()  set in train
  classProbs<-TRUE
  tuneN<-1
  fitControl <- create_fit_control("repeatedcv",3,2,classProbs=classProbs,verboseIter = TRUE)
  cmod<-create_predictive_model(.data,y,method=model,metric=metric,tuneN=tuneN,fitControl=fitControl)

  #model can error if varImp absent when called from train
  #get importance externally
  #install.packages('pROC') # need this..for ROC
  cmod$model %>% varImp()

  #regression
  #--------------------------
  data<-mtcars
  y<-'mpg'

  #custom classification model
  #--------------------------
  .data<-create_model_data(data,y)
  model<-'pls'
  metric<-'RMSE' # needs special return fun caret::twoClassSummary()  set in train
  classProbs<-FALSE
  tuneN<-1
  fitControl <- create_fit_control("repeatedcv",3,2,classProbs=classProbs,verboseIter = TRUE)
  create_predictive_model(.data,y,method=model,metric=metric,tuneN=tuneN,fitControl=fitControl)

  #classification 2 class
  data$am<-factor(mtcars$am)
  y<-'am'
  model<-'ada'
  metric<-'ROC'

  .data<-create_model_data(data,y)
  cmod<-create_predictive_model(.data,y,method=model,metric=metric)

  #classification >2 class
  #using fit control
  data$cyl<-factor(mtcars$cyl)
  y<-'cyl'
  .data<-create_model_data(data,y)
  fitControl <- create_fit_control("repeatedcv",7,3)
  #rf
  rf<-create_predictive_model(.data,y, fitControl = fitControl)
  #svm
  svm<-create_predictive_model(.data,y, method = 'svm',fitControl = fitControl)

  #custom classification model
  #--------------------------
  data$am<-factor(mtcars$am)
  y<-'am'
  .data<-create_model_data(data,y)
  model<-'ada'
  metric<-'ROC'
  classProbs<-TRUE
  fitControl <- create_fit_control("repeatedcv",7,3,classProbs=classProbs)
  cmod<-create_predictive_model(.data,y,method=model,metric=metric,fitControl=fitControl)

  #regression
  y<-'vs'
  .data<-create_model_data(data,y)

  rmod<-create_predictive_model(data = .data,y=y,fitControl = fitControl)

  #plot importance
  plot_importance(cmod)
  plot_importance(cmod2)
  plot_importance(rmod)

  #plot confusion matrix
  conf_mat<-cmod$test_conf_mat
  conf_mat<-cmod$train_conf_mat
  plot_confusion_matrix(conf_mat,percent=FALSE)

  #plot model # remake for plotly
  plot(cmod$model)

  ctrl<-create_rfe_control()
  rf <- create_rfe(aq_data,"cellType",ctrl)
  }

}


