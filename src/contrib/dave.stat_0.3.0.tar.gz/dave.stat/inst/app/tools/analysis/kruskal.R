#...wtf
contains<-dplyr::contains

## choice lists for plots
kruskal_plots <- c("Violin" = "violin", "Volcano" = "volcanoe")

# main fun kruskal
## list of function arguments
kruskal_args <- as.list(formals(init_data))

## list of function inputs selected by user
kruskal_inputs <- reactive({
  ## loop needed because reactive values don't allow single bracket indexing
  # kruskal_args$arg<-input$something
  # kruskal_args$

  for (i in r_drop(names(kruskal_args)))
    kruskal_args[[i]] <- input[[paste0("kruskal_",i)]]
  kruskal_args
})

#global store
kruskal_values<-reactiveValues()


###############################
# Left menu
###############################

#list of columns for test
#tries row-meta
output$ui_test_factor <- renderUI({
  if (is.null(input$dataset)) return()
  vars<- .getdata_row_meta() %>% colnames()

  selectInput(inputId = "kruskal_test_var",
              label = "Sample group",
              choices = vars,
              selected = state_single("kruskal_test_var",vars),
              multiple = TRUE)
})

output$ui_kruskal_labels <- renderUI({
  if (is.null(input$dataset)) return()
  # browser()
  vars<- .getdata_col_meta() %>% colnames()
  selectInput(inputId = "kruskal_labels",
              label = "Variable names",
              choices = vars,
              selected = state_single("kruskal_labels",vars),
              multiple = FALSE)
})

#Filter by
#created based on the results
output$ui_kruskal_filter<-renderUI({
  vars <- NULL # get dynamically
  fluidRow(
    column(12,
           div(style="display: inline-block;vertical-align:top; width: 135px;min-height:34px; !important",
               selectInput("kruskal_filter_by", "p-values", choices  = vars, multiple = FALSE)),
           div(style="display: inline-block;vertical-align:top; width: 75px !important;min-height:34px; !important",
               numericInput('kruskal_filter_var',label =HTML('&#x2264'), min=0, max=1, value=0.05, step=0.01))))#,
    # column(12,
    #        helpText('Select variables with p-values less than or equal to the significance cut off.'))
    # )

})


#Show unique variables
#plotting # update after filter step
output$ui_kruskal_var <- renderUI({

  #browser()
  .names<-colnames(.getdata())
  .vars<-NULL
  if(!is.null(kruskal_values[['kruskal']])){
    id<-kruskal_values[['kruskal']]$kruskal_selected
    .vars<-kruskal_values[['kruskal']]$variables[id] %>% make.unique()
    .names<-.names[id]
  }

  if(is.null(.vars) )  .vars<-.names


  .vars<-.names %>% setNames(.,.vars)

  selectInput("ks_plot_var_list", "Variables:", choices = .vars,
              multiple = TRUE, selectize = TRUE) #size = min(8, length(vars)),
})

outputOptions(output, "ui_kruskal_filter", suspendWhenHidden = FALSE)
outputOptions(output, "ui_kruskal_var", suspendWhenHidden = FALSE)



#Store data
output$ui_kruskal_save<-renderUI({
  kruskal_dataset <- input$dataset
  fluidRow(
    column(12,
           #h3("Save"),
           checkboxInput('filter_kruskal_data','keep selected',value=FALSE),
           tags$table(
             tags$td(textInput("kruskal_dataset", "Name:", kruskal_dataset)),
             tags$td(actionButton("kruskal_save", "Save"), style="padding-top:30px;")
           )
    )
  )
})

###############################
# renderUI output
###############################
output$ui_kruskal <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel(condition = "input.tabs_kruskal == 'Calculate'",
                     tagList(
                         fluidRow(column(12,actionButton("kruskal_calculate", "Calculate",icon=icon('check')))),
                         br(),
                         bs_accordion(id="kruskal_collapse_panel") %>%
                           bs_append(title = tags$label(class='bsCollapsePanel', icon("user-circle-o") , "Design"),
                                     content=
                                       fluidRow(column(12,
                                                       uiOutput("ui_test_factor"),
                                                       uiOutput('ui_kruskal_labels')
                                                )
                                       )
                           ) %>%
                           bs_append(title = tags$label(class='bsCollapsePanel', icon("filter") , "Filter"),
                                     content=
                                       uiOutput("ui_kruskal_filter")
                           ) %>%
                           bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                                     content=
                                       uiOutput("ui_kruskal_save")
                           )
                     #  )
                     )
    ),
    conditionalPanel(condition = "input.tabs_kruskal != 'Calculate'",
                     tagList(
                       bs_accordion(id="kruskal_plot_collapse_panel") %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("bar-chart") , "Plot"),
                                   content=
                                     fluidRow(column(12,
                                       selectizeInput(inputId = "kruskal_plots", label = "Select plots:",
                                                      choices = kruskal_plots,
                                                      selected = state_multiple("kruskal_plots", kruskal_plots, "violin"),
                                                      multiple = FALSE,
                                                      options = list(plugins = list('remove_button', 'drag_drop'))),
                                       conditionalPanel(condition = "input.kruskal_plots == 'violin'",
                                       uiOutput("ui_kruskal_var")
                                       ),
                                       conditionalPanel(condition = "input.kruskal_plots == 'volcanoe'",
                                                        #FC_lim
                                                        fluidRow(column(12,
                                                          numericInput(inputId = "volcanoe_fc_lim",label="Fold change limit",
                                                                       value = 3,min = 1,max = 10,step = 1
                                                          ),
                                                          #p-value
                                                          # numericInput(inputId = "volcanoe_p_value",label="Select p-value",
                                                          #              value = 0.05,min = 0,max = 1,step = 0.05
                                                          # ),
                                                          #size
                                                          numericInput(inputId = "volcanoe_size",label="Size",
                                                                       value = 4,min = 1,max = 10,step = 1.5
                                                          ),
                                                          #alpha
                                                          numericInput(inputId = "volcanoe_alpha",label="Alpha",
                                                                       value = 0.5,min = 0,max = 1,step = 0.1
                                                          )#,
                                                          #checkboxInput('kruskal_FC_select','Filter data',value = FALSE)
                                                        )
                                                        )
                                       )
                                     ))
                    )
                  )
      ),
    fluidRow(
      column(12,align="right",modalModuleUI(id="kruskal_help")))
  )
})

#setup plot
kruskal_plot <- reactive({
  lx <- ifelse (not_available(input$ks_plot_var_list) || isTRUE(input$viz_combx), 1, length(input$ks_plot_var_list))
  nr <- lx * 2
  if (lx > 1){
    plh <- (600/2) * ceiling(nr / 2)
    plw <- 1200
  }else{
    plh <- 800
    plw <- 1200
  }
  list(plot_width = plw, plot_height = plh)
})

kruskal_plot_width <- function()
  kruskal_plot() %>% { if (is.list(.)) .$plot_width else 1200 }

kruskal_plot_height <- function()
  kruskal_plot() %>% { if (is.list(.)) .$plot_height else 800 }

#initialize data
kruskal_init<-reactive({
  #collect meta data cube
  #and arguments
  isolate({

    data_cube<-.getdata_cube()

    # browser()

    group <- data_cube$row_meta[,input$kruskal_test_var,drop=FALSE]


    #update data with labels
    data<-data_cube$data
    # vars<-colnames(data)
    # if(!is.null(input$kruskal_labels)){
    #   vars<- .getdata_col_meta() %>% select(one_of(input$kruskal_labels)) %>% unlist() %>% as.character()
    #   #colnames(data)<-make.unique(vars) # could carry separately
    # }

    test_args<-list(data=data, group=group, post.hoc=TRUE, FDR="BH") # specific args...should be dynamic funs not redundant store

    return(list(test_args=test_args,filter_by=input$kruskal_filter_by, # filter updates...
              cutoff=input$kruskal_filter_var,data_cube=data_cube))

  })


})

kruskal_available <- reactive({
  if(is.null(input$kruskal_calculate) || input$kruskal_calculate ==0) {
    return("Calculate differences between groups defined by test factors.")
  }
  if (is.na(input$kruskal_calculate))
    return("Please select a test factor.")
  if (is.null(input$kruskal_test_var))
    return("Sample group not found")

  "available"
})

###############################
# main functions
###############################



observeEvent(input$kruskal_calculate, {


  # isolate({
  #   now<-kruskal_init()$test_args
  #   unchanged<-tryCatch(do.call('have_seen',list(now,kruskal_test_gate)), error = function(e){FALSE})
  # })
  #
  #
  # if(!unchanged) {
  #   kruskal_test_gate<<- now
  # } else {
  #   print('\n-------exiting kruskal unchanged------\n')
  #   return()
  # }

  #wtf init bug avoiding first call
  # f <-memoise::memoise(ocpuclient:::.ocpu_post)

  isolate({
    cat('\n----------in calculate btn observer---\n')
    if(!kruskal_available() == 'available') return()


    #send dynamic message to shiny
    res<-withCallingHandlers({

      shinyjs::html("kruskal_busy_mssg", "")
      tryCatch(do.call('kruskal_test', kruskal_init()$test_args),error=function(e){NULL})
      #need call to ocpu with pckg specific fun

      #weird non memosied init call
#
#         x<-f(
#           fun = 'ocpu_kruskal_test',
#           body = kruskal_init()$test_args,
#           pkg_url = getOption('dave.stat_url'),
#           base_url = getOption('open_cpu_url')
#         )
#
#       #call fun asis no API
#       tryCatch(x$results  %>% ocpuclient::ocpu_fromJSON(),error=function(e){NULL})

    },
    message = function(m) {
      shinyjs::html(id = "kruskal_busy_mssg", html = m$message, add = FALSE)
    })

    #set message to null after finish
    shinyjs::html("kruskal_busy_mssg", "")


    #block bad calculation
    if(is.null(res)) {
      kruskal_values[['test_obj_message']]<-paste(input$dataset,'is not compatible with this method')
    } else{

      kruskal_values[['test_obj_message']]<-'Calculate to view results'

    }

    kruskal_values[['test_obj']]<-res

    #update filter UI
    vars<-colnames(kruskal_values[['test_obj']]$test)
    updateSelectInput(session,"kruskal_filter_by",  choices  = vars)

  })


})


#get reactive test values
.get_test_object<-reactive({

  shiny::validate(need(!is.null(kruskal_values[['test_obj']])==TRUE,kruskal_values[['test_obj_message']]))
  return(kruskal_values[['test_obj']])
})

.kruskal<-reactive({


    test_obj<-.get_test_object() #triggers results retreval
    # if(is.null(test_obj)) return (NULL)
    obj<-kruskal_init()

    # isolate({ # need for summary to update
      filter_by<-input$kruskal_filter_by
      if(is.null(filter_by) || filter_by == '') return()
      cutoff<-input$kruskal_filter_var

      vars<-NULL

      if(!is.null(input$kruskal_labels)){
        #browser()
        vars<- .getdata_col_meta() %>% select(one_of(input$kruskal_labels)) %>% unlist() %>% as.character()
        names<-obj$data_cube$data %>% colnames()
        vars<-vars %>% setNames(.,names)
      }


    #need to update data_cube
    kruskal_values[['kruskal']]<-kruskal_test_results(test_obj,data_cube=obj$data_cube,
                                                      filter_by,cutoff,variables=vars)
                                                      # fold_change = fold_change,
                                                      # alpha = alpha)

    #browser()
  return(kruskal_values[['kruskal']])

    # })

})

#TODO fix broken
eventReactive(.kruskal(),{
  .names<-colnames(.getdata())
  if(!is.null(kruskal_values[['kruskal']])){
    id<-kruskal_values[['kruskal']]$kruskal_selected #
    .vars<-kruskal_values[['kruskal']]$variables[id] %>% make.unique()
    .names<-.names[id]
  }

  .vars<-.names %>% setNames(.,.vars)

  updateSelectInput(session=session,"ks_plot_var_list",  choices  = .vars)
},ignoreNULL = TRUE,ignoreInit = TRUE)

#get results as a table
kruskal_get_DT_data<-reactive({
  if(!kruskal_available() == 'available') return()
  isolate({
    obj<- .kruskal()
    if(is.null(obj)){return()}
    # if(is.null(input$kruskal_labels)) {
    #   .labels<-rownames(obj$test_obj$test)
    # } else {
    #   .labels<- .getdata_cube()$col_meta[[input$kruskal_labels]] %>% as.character()
    # }
    # browser()
    kruskal_values[['volcanoe_args']]<-obj$variables #full object ? why here?

    tmp<-data.frame(
                    variable=obj$variables,
                    obj$test_obj$summary,
                    obj$test_obj$test)

    id<-obj$kruskal_selected  #TODO
    filter_by<-obj$filter_by


    .tmp<-tmp[id,,drop=FALSE] %>% arrange_(.dots=filter_by) %>%
      purrr::map_if(is.numeric,signif,3) %>%
      do.call(cbind,.) %>% data.frame()
    #bring back numeric
    #
    is_num<-function(x){
      any(!is.na(as.numeric(x)))
    }
    id<-sapply(.tmp,is_num)
    #using purrr blocks dplyr

    .tmp<-.tmp %>%
      purrr::map_if(id,as.numeric) %>%
      do.call(cbind,.) %>% data.frame()
    #round ...can also  do in table
    #keep relevant column names

    contains<-dplyr::contains # so annoying!


    out<-.tmp %>% arrange_(.dots=filter_by) %>%
      dplyr::select(variable,contains('mean_and_sd'),contains('FC'),contains('p.values')) %>%
      mutate_at(.,vars(contains('p.values')),funs(signif_format_fun(.)))


      kruskal_values[['top_vars']]<-out

      return (kruskal_values[['top_vars']])
  })
})

#create datatable of results
output$kruskal_DT<- DT::renderDataTable(

  datatable(
    kruskal_get_DT_data(),rownames = FALSE, filter = 'top', options = list(
    pageLength = 10, autoWidth = TRUE,scrollX = TRUE,fontColor='black')
  )
)

.summary_kruskal <-reactive({
  if (kruskal_available() != "available") {
      kruskal_values[['summary']]<-html_text_format(kruskal_available())
      return(kruskal_values[['summary']])
  }

  #can get NULLS
  tmp<-.kruskal()
  if(is.null(tmp)) return()
  kruskal_values[['summary']]<- summary(tmp) %>% html_paragraph_format(.)
  return(kruskal_values[['summary']])

})

#summary and table
output$summary_kruskal_ui<-renderUI({

  #don't duplicate error messages
  if (kruskal_available() == "available"){
    table<-DT::dataTableOutput('kruskal_DT')
  } else{
    table<-NULL
  }

  fluidRow(column(12,
      textOutput("kruskal_busy_mssg"), # dynamic out put of console messages
      HTML(.summary_kruskal()),
      br(),
      table
  ))
})

.plot_kruskal <- reactive({
  #if (kruskal_available() != "available") return(kruskal_available())
  #browser()
  if(input$kruskal_plots =='violin'){
    validate(need(!is.null(input$ks_plot_var_list) == TRUE, 'Select variables to plot.'))
  }

  if(input$kruskal_plots =='volcanoe') {
    validate(need(!is.null(kruskal_values[['test_obj']]) == TRUE, 'Calculate test to view plot.'))
  }

  #allow plotting before calculation
  if(is.null(kruskal_values[['test_obj']])){

    obj<-list()
    obj$data_cube<-.getdata_cube()
    if(is.null(input$kruskal_test_var)) {
      obj$group<-NULL
    } else {
      obj$group<-obj$data_cube$row_meta[,input$kruskal_test_var,drop=FALSE]
    }

    class(obj)<-"kruskal_results"
  } else {
    obj<-.kruskal()
  }

  plotly<-FALSE
  if(input$tabs_kruskal == "Explore") plotly<- TRUE

  if(input$kruskal_plots =='volcanoe') {
    # browser()
    if(is.null(input$kruskal_labels)) return() # has not loaded yet
    .labels<-obj$variables # srt in main calc fun ...should be the same but created later?
    if(is.null(.labels))   .labels<-.getdata_cube()$col_meta[[input$kruskal_labels]]

    kruskal_values[['volcanoe_args']]<-.labels
    plot(obj, plots = input$kruskal_plots,
       plot.vars = input$ks_plot_var_list,
       labels = .labels,
       FC_lim = input$volcanoe_fc_lim,
       p.value.lim = input$volcanoe_p_value,
       size = input$volcanoe_size,
       alpha = input$volcanoe_alpha,
       shiny = TRUE,plotly=plotly)
  }else{
    # set titles based on the label
    # browser()
    #ugly hack to accept cutom label?
    plot(obj, plots = input$kruskal_plots,
         plot.vars = input$ks_plot_var_list,
         shiny = TRUE,plotly=plotly,base_size=ifelse(plotly,16,24))
  }

})

#limit to single variable if plotly violin
observe({

  if(is.null(input$tabs_kruskal) | is.null(input$ks_plot_var_list) | is.null(input$kruskal_plots)) return()

  if(input$tabs_kruskal == "Explore" & length(input$ks_plot_var_list)>1 & input$kruskal_plots == 'violin') {
    shiny::showNotification("Use the 'Plot' tab to create violin plots for more than one variable.")
  }

})

#plotly
output$plotly_kruskal <- renderPlotly({
  if(input$tabs_kruskal != "Explore") return()
  obj<-tryCatch(.plot_kruskal(),error=function(e){NULL})
  validate(need(!is.null(obj)==TRUE || is.character(obj)==TRUE ,'Not available'))

  ggplotly(obj)
})



###############################
# output is called from the main dave ui.R
###############################
output$kruskal <- renderUI({
  register_print_output("summary_kruskal", ".summary_kruskal" )
  register_plot_output("plot_kruskal", ".plot_kruskal",
                       height_fun = "kruskal_plot_height", width_fun = "kruskal_plot_width")

  # two separate tabs
  kruskal_output_panels <- tabsetPanel(
    id = "tabs_kruskal",
    tabPanel("Calculate",icon = icon("sliders"),
             uiOutput('summary_kruskal_ui')
    ),
    tabPanel("Explore",icon=icon('pencil-square-o'),
             plotlyOutput("plotly_kruskal", height = "100%")),
    tabPanel("Plot",icon = icon("bar-chart"),
             plot_downloader("kruskal", height = kruskal_plot_height()),
             plotOutput("plot_kruskal", height = "100%")),
    tabPanel("Report",icon=icon('file-text-o'),
             reportGeneratorUI('kruskal'))
  )
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('superscript'),as.character(" Statistics")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('superscript'),as.character(" Kruskal-Wallis")))),
                 tool_ui = "ui_kruskal",
                 output_panels = kruskal_output_panels)
})

# ###############################
# # observeEvent for actionButton
# ###############################
# #report
# observeEvent(input$kruskal_report, {
#   figs <- FALSE
#   outputs <- c("summary")
#   inp_out <- list()
#   if (length(input$kruskal_plots) > 0) {
#     outputs <- c("summary","plot")
#     inp_out[[2]] <- list(plots = input$kruskal_plots, plot.vars = input$ks_plot_var_list)
#     figs <- TRUE
#   }
#   update_report(inp_main = clean_args(kruskal_inputs(), kruskal_args),
#                 fun_name = ".kruskal",
#                 inp_out = inp_out, outputs = outputs, figs = figs,
#                 fig.width = kruskal_plot_width(),
#                 fig.height = kruskal_plot_height())
# })

#save
observeEvent(input$kruskal_save, {

  msg<-'\u2713 Saving...'#tags$label('Saving',icon('check')) %>% as.character() %>% HTML()
  withProgress(message=msg,value=1,{
    Sys.sleep(.15)
  ## not sure if want to save as a new object?
  dataset <- input$kruskal_dataset
  #saved obj names
  .names<-list(data=dataset,
               row=paste0(dataset,'_row_meta'),
               col=paste0(dataset,'_col_meta'))

  #creates filter index
  cat('\n--------saving-----\n')
  main<-.kruskal() # think about do we want to filter or create filter index

  #overwrite poor choice in index


  if(input$filter_kruskal_data){
    obj<-col_filt_obj(main$data_cube,main$kruskal_selected) # now col_meta has the filter
  } else {
    #need selected...others already added?
    obj<-main$data_cube
  }

  #update data and col meta data
  #based on the filter results
  # if (is.null(r_data[[dataset]])) {
  r_data[[.names$data]] <- obj$data
  r_data[[.names$row]] <- obj$row_meta
  r_data[[.names$col]] <- obj$col_meta

  #update avialebale data objects
  #need to split update from create
  .names<-r_data[['datasetlist']] %>% c(unlist(.names),.) %>% unique()
  r_data[['datasetlist']] <-.names

  })

})


