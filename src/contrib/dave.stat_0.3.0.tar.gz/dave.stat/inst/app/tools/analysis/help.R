stats_help_lookup <-
  list(
    url = 'https://creativedatasolutions.github.io/dave.docs/partial/stats.html',
    stats = list(
      Calculate = 'calculate',
      Plot = 'explore-and-plot',
      Explore = 'explore-and-plot',
      Report = 'report'
    )
  )

map_stats_help <-
  function(tab = input$tabs_kruskal,
           id = 'stats',
           lookup = stats_help_lookup,
           url = stats_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }



callModule(modalModule,id='kruskal_help',content=map_stats_help)
