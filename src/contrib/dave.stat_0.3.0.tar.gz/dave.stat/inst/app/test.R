
opts <- list(DAVE_APP = "dave.stat")

dave.app::run_dave_app(opts,app=opts$DAVE_APP)



# # # create data

# .path<-'C:/Users/think/Desktop/dave_data.csv'
# dave_data<-read.csv(.path, header = TRUE)
# usethis::use_data(
#   dave_data,
#   overwrite = TRUE
# )
#
# .path<-.path<-'C:/Users/think/Desktop/dave_data_col_meta.csv'
# dave_data_col_meta<-read.csv(.path, header = TRUE)
# usethis::use_data(
#   dave_data_col_meta,
#   overwrite = TRUE
# )
#
# .path<-.path<-'C:/Users/think/Desktop/dave_data_row_meta.csv'
# dave_data_row_meta<-read.csv(.path, header = TRUE)
# usethis::use_data(
#   dave_data_row_meta,
#   overwrite = TRUE
# )





