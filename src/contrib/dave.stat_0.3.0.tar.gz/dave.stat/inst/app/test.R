
opts <- list(DAVE_APP = "dave.stat")

dave.app::run_dave_app(opts,app=opts$DAVE_APP)



# # # create data
# # usethis::use_data("foo")
# .path<-'C:/Users/think/Desktop/new.csv'
# dave_stat<-read.csv(.path, header = TRUE)
# usethis::use_data(
#   dave_stat,
#   overwrite = TRUE
# )
#
# .path<-'C:/Users/think/Desktop/new_col_meta.csv'
# dave_stat_col_meta<-read.csv(.path, header = TRUE)
# usethis::use_data(
#   dave_stat_col_meta,
#   overwrite = TRUE
# )
#
# .path<-'C:/Users/think/Desktop/new_row_meta.csv'
# dave_stat_row_meta<-read.csv(.path, header = TRUE)
# usethis::use_data(
#   dave_stat_row_meta,
#   overwrite = TRUE
# )
#
#
#
#

