

#return function results or is_NA
dsafe<-function(fun,...,is_NA=NA){

  tryCatch(fun(...), error=function(e){is_NA})
}

#create names from named vector or data frame
dnames_func <- function(x, column = TRUE) {

  if (column) {
    paste(names(x), x, sep = ':') %>%
      paste0(., collapse = '_')
  } else {
    paste0(x, collapse = '_')
  }

}

#get linear model residuals
#' @export
dave_lm_adjust<-function(data,formula,test_vars,adjust=TRUE,progress=TRUE){

  if (progress == TRUE){ pb <- txtProgressBar(min = 0, max = ncol(data), style = 3)} else {pb<-NULL}

  out <- lapply(1:length(test_vars), function(i) {
    if (progress == TRUE) {
      setTxtProgressBar(pb, i)
    }


    mod <-
      tryCatch(
        lm(as.formula(paste0(
          "data[,'", test_vars[i], "']~", formula
        )), data = data),
        error = function(e) {
          NULL
        }
      )

    if (is.null(mod)) {
      out<-NA
    } else {
      out<-residuals(mod)
    }

    if (progress == TRUE) {
      close(pb)
    }
    out
  }) %>%
    do.call("cbind", .)


  if(adjust){
    min <- apply(out, 2, min, na.rm = T)
    out <- lapply(1:ncol(out), function(i)
    {
      out[, i, drop = F] + abs(min[i])
    }) %>%
      do.call("cbind", .)
  }


  colnames(out)<-test_vars

  return(out)

}

#linear  model with FDR
#' @export
dave_lm<-function(data,formula,test_vars,FDR='BH'){

  f<-function(data,formula){


    mod<-lm(as.formula(formula),data=data)
    res<-anova(mod)

    data.frame(res$'Pr(>F)' %>% t()) %>%
      setNames(.,rownames(res))
  }

  res<-lapply(test_vars, function(x) {
    .formula <- paste(x, '~', formula)
    tryCatch(f(data, .formula),error=function(e){NA})
  }) %>%
    do.call('rbind', .)

  if(!is.null(FDR)){

    fdr<-lapply(1:ncol(res), function(i){

      .name<-paste0(colnames(res)[i],'_pFDR')
      data.frame(p.adjust(res[,i], method = FDR)) %>%
        setNames(.,.name)
    }) %>%
      do.call('cbind',.)

  } else {
    fdr<-NULL
  }


  cbind(data.frame(variables = test_vars),res,fdr)
}

#' @export
dave_group_stats<-function(data,group,test_vars=colnames(data),func=c(mean=function(x){dsafe(mean,x,na.rm=TRUE)},stdev=function(x){dsafe(sd,x,na.rm=TRUE)})){

  obj<-data %>%
    group_by_at(group) %>%
    select(one_of(test_vars)) %>%
    summarise_all(.,.funs=func)

  attr(obj,'group')<-group

  return(obj)

}

#conduct iterative filter on filter(names(filter) = filter)
#' @export
dave_filter_group<-function(data,filter){

  #create expression
  .data<-data
  for(i in 1:length(filter)){
    .data<-.data %>%

      filter((!!sym(names(filter)[i])) == filter[i])
  }

  return(.data)

}

#replace relative to use relevel?

#' @param
#' @details for columns select(contains(stat)) calculate fold change for values in data split on group relative to the denominator
#' @import tidyr
#' @export
dave_FC <-function(means,relative,names_func = function(x){dnames_func(x,column=FALSE)}){
  .group <- attr(means, 'group')

  .means_names <- means %>% select(one_of(.group)) %>%
    apply(.,1,names_func)

  .means<-means %>%
    ungroup() %>%
    select(-one_of(.group))

  .relative <- dave_filter_group(means, relative)

  .relative_names <- .relative %>% select(.,one_of(.group)) %>%
    apply(.,1,names_func)

  .relative<-.relative %>%
    ungroup() %>%
    select(-one_of(.group))

  #means / relative
  .names <- paste0(.means_names %>% unlist(), '_vs_', .relative_names) %>%
    data.frame(FC = .)

  out <- sweep(as.matrix(.means), 2, as.matrix(.relative), "/") %>%
    data.frame()

  #need to not overwrite
  res<-cbind(.names, out)

  return(res)

}

#replace NA
#' @export
#' @details for each column replace NA based on func(column)
dave_replace_NA<-function(data, func=function(x){dsafe(fun=median,unlist(x),na.rm=TRUE)}){

  lapply(1:ncol(data), function(i){

    obj<-data[,i,drop=FALSE]
    update<-is.na(obj)
    obj[update,]<-func(obj)
    obj

  }) %>%
    do.call('cbind',.) %>%
    data.frame() %>%
    setNames(.,colnames(data))

}

#score uniqueness
dave_score<-function(x,test_vars,cutoff=0.05,suffix='_score'){

  #coercion shenanigans required  for post sweep cbind
  meta.names<-colnames(x) %>% {.[!. %in% test_vars]}

  meta<- x %>%
    select(-one_of(test_vars)) %>%
    data.frame() %>%
    setNames(.,meta.names)

  out.names<- paste0(test_vars,suffix)
  out<-x %>%
    ungroup() %>%
    select(one_of(test_vars)) %>%
    {.<=cutoff } %>%
    sweep(.,rowSums(.),'/',MARGIN = 1) %>%
    data.frame() %>%
    setNames(.,out.names)


  #account for division errors
  out[out == 'NaN']<-0 # 0/0
  out[out == 'Inf']<-1 # 1/0

  suppressMessages(out %>%
                     cbind(meta,.))
}

#Tukey HSD pairwise changes
#' @title dave_tukeyHSD
#' @export
dave_tukeyHSD<-function(data,formula,keep=c('p.adj')){

  #extract final results
  get_res <- function(obj,keep=c('p.adj')) {

    if(is.na(obj)) return(NA)


    .names<-names(obj)
    tmp<-lapply(1:length(obj),function(i){
      x<-obj[[i]] %>% data.frame()
      x$test<-.names[i]
      x$contrast<-rownames(x)
      x
    })

    do.call('rbind',tmp) %>%
      data.frame() %>%
      select(one_of(c('test','contrast',keep)))

  }

  #never error
  tryError<-function(...,.error=function(e){NA}){
    tryCatch(...,error=.error)
  }

  res<-lapply(1:ncol(data),function(i){
    .formula<-as.formula(paste("data[,",i,"]~",formula,sep=""))
    model<-tryError(aov(.formula,data=data))
    tHSD<-tryError(TukeyHSD(model))
    tryError(get_res(tHSD,keep))
  })

  #convert to data frame and account for errors
  f<-function(x){all(is.na(x))}
  .errors<-lapply(res,f) %>%
    unlist()

  pad<-res[!.errors] %>% {.[!sapply(.,is.null)]} %>% .[[1]]
  pad[,colnames(pad) %in% keep]<-NA
  .names<-colnames(data)
  #can't vector replace
  .res<-lapply(1:length(.errors),function(i){

    x<-.errors[i]
    out<-if(x) {pad }else{ res[[i]]}
    out$variable<-.names[i]
    out
  })

  do.call('rbind',.res)

}

#' @details format factor levels to replace '_' and ':'
dave_format_levels <-
  function(x,
           replace = c('-', ':'),
           with = c('\\.', '\\.')) {

    f <- function(x) {

      .x <- x
      for (i in 1:length(replace)) {
        .x <- .x %>% gsub(replace[i], with[i], .)
      }

      .x[[length(x)]]

    }

    #switch between data.frame and vector
    lapply(x, f) %>% unlist()

  }

#' @details create contrast objects from formula
dave_make_contasts <- function(opts) {

  f <- function(opts, n) {
    .opts <- utils::combn(opts, n)

    res <- lapply(1:ncol(.opts), function(i) {
      .opts[, i] %>%
        unlist() %>%
        paste0(., collapse = ':')
    }) %>%
      unlist()

    res
  }

  lapply(1:length(opts),function(n){
    f(opts, n)
  })


}


# utils -------------------------------------------------------------------


add_suffix <- function(x, suffix) {
  paste0(x, suffix)
}

regex_replace<-function(x,replace='_pFDR_score',with=''){
  gsub(paste0(replace,'(.*)'),with,x)
}

make_obj<-function(res,tmp,.name){
  assign(.name,tmp)
  tmp<-list(tmp) %>%
    setNames(.,.name)
  c(res,tmp)

}

# plotting ----------------------------------------------------------------
#' @export
#' @details plot set intersections
make_upset<-function(mask){

  colnames(mask)<-regex_replace(colnames(mask))

  #remove invariant
  f<-function(x){tryCatch(sd(x,na.rm = TRUE), error=function(e){0})}
  keep<-mask %>%
    lapply(.,f) > 0

  plot<-tryCatch(mask %>%
                   {.[,keep,drop=FALSE]} %>%
                   upset(
                     .,
                     nsets = ncol(.),
                     # set.metadata = set.metadata ,
                     order.by = "freq",
                     mb.ratio = c(0.5, 0.5),
                     mainbar.y.label = "Number of lipids"
                   ), error=function(e){})

  data<-mask %>%
    {.[,keep,drop=FALSE]}

  return(list(plot=plot, data=data))

}



test<-function(){

  source('src/dave_stats.R')
  load(file = 'data/upsert_res') # res
  load(file='data/data')
  library(dplyr)
  library(tidyr)
  library(purrr)


  #all factors
  formula<-'treatment*genotype*tissue'
  pair_stats<-dave_tukeyHSD(data,formula)

  #sanitize levels
  x<-'foo-bar:baz'
  dave_format_levels(x)
  vars<-c('genotype','treatment','time','tissue')
  .vars<-data %>%
    select(one_of(vars)) %>%
    map(~dave_format_levels(.)) %>%
    do.call('cbind',.) %>%
    data.frame() %>%
    setNames(.,vars)

  .data<- data %>%
    select(-one_of(vars)) %>%
    cbind(.vars,.)

  #create stats comparisons
  .formula<-"treatment*genotype*tissue"
  opts<-strsplit(.formula,'\\*') %>%
    unlist()

  dave_make_contasts(opts)


}
