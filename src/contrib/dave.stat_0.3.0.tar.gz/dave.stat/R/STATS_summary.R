
#old funs to rewrite for stats summary
# relative standard deviation
#redo calc.stat using dplyr
calc.rsd<-function(data,factor,sig.figs=2){
  d.list<-split(data,as.factor(factor))
  res<-do.call("cbind",lapply(1:length(d.list),function(i){
    obj<-d.list[[i]]
    means<-apply(obj,2,mean,na.rm=T)
    sd<-apply(obj,2,sd,na.rm=T)
    signif(sd/means,sig.figs)*100
  }))
  colnames(res)<-paste0("RSD_",names(d.list))
  return(as.data.frame(res))
}

#fold change of means
calc.FC<-function(data,factor,denom=levels(factor)[1],sig.figs=1,log=FALSE){
  #rel is the order of the level which will be in the denominator
  #convert factors to numeric
  data<-data.frame(do.call("cbind",lapply(data.frame(data),fixln)))
  d.list<-split(as.data.frame(data),as.factor(factor))
  res<-do.call("cbind",lapply(1:length(d.list),function(i){
    obj<-d.list[[i]]
    apply(obj,2,mean,na.rm=TRUE)
  }))
  colnames(res)<-names(d.list)
  rel=match(denom,colnames(res))
  fc<-fold.change(res,log=log,rel=rel)
  colnames(fc)<-paste0("FC_",colnames(fc),"_",rep(denom,ncol(fc)))
  return(data.frame(round(fc[,-rel,drop=FALSE],sig.figs)))
}

# redo using dplyr!
calc.stat<-function(data,factor,stat,...)
{
  d.list<-split(data,as.factor(factor))
  #function to calculate (ddply, stopped working after update? not obvious why)
  calc<-function(d.list,stat,...){
    out<-sapply(1:length(d.list),function(i)
    {
      obj<-d.list[[i]]
      apply(obj,2,get(stat),...) #to avoid NA's in stats
    })
    out<-data.frame(matrix(out,ncol=length(d.list)))
    colnames(out)<-paste(stat, "_",names(d.list), sep="")
    out
  }
  #wrapper to calculate stats from a list (fix later using all plyr fxns)
  output<-do.call("cbind",lapply(1:length(stat),function(i)
  {
    what<-stat[i]
    name.what<-paste(what,"_",sep="")
    calc(d.list,stat[i],...)
  }))
  return(as.data.frame(output))
}

# break string and get object into colummns by position in original string position
str.get<- function(obj, sep=",",get=1)
{
  do.call("cbind",lapply(1:ncol(obj),function(i)
  {
    tmp<-as.character(obj[,i])
    as.numeric(t(as.data.frame(strsplit(tmp,sep)))[,get])
  }))
}

#calculate fold change relative to column
fold.change<-function(obj,rel=1,log=FALSE)
{
  if(log==FALSE){
    rel<-obj[,rel]
    obj/rel
  } else {
    rel<-obj[,rel]
    obj-rel
  }
}


#collapse columns as strings (why am I not using paste collapse?)
join.columns<-function(obj=formatted$row.metadata[,4:6],char="|",quote.last=FALSE)
{

  if(class(obj)=="list"){obj<-as.matrix(obj[[1]])} else {obj<-as.matrix(obj)}
  #used to binf 2 columns try to generalize to more
  .local<-function(obj,char,quote.last)
  {

    if(length(obj)==0)
    {
      return(NULL)
    }else{
      if(ncol(as.matrix(obj))>=2)
      {
        n<-ncol(obj)
        out<-data.frame()
        sobj<-obj
        i<-1
        for(i in 1:(n-1))
        {
          if(quote.last==TRUE)
          {
            sobj[,i]<-paste(as.character(obj[,i]),paste("'",as.character(obj[,i+1]),"'",sep=""),sep=char)
          } else {
            sobj[,i]<-paste(as.character(obj[,i]),as.character(obj[,i+1]),sep=char)
          }
        }
        sobj[,-n]
      }else{
        obj
      }
    }
  }
  if (ncol(obj)>2)
  {
    tmp<-obj[,1:2]
    for(i in 1:(ncol(obj)-1)) {
      tmp2<-.local(tmp, char=char,quote.last=quote.last)
      if(i < (ncol(obj)-1)){
        tmp<-cbind(tmp2,obj[,(i+2),drop=FALSE])
      }
    }
    tmp2

  } else {
    .local(obj=obj,char=char,quote.last=quote.last)
  }
}

# function to extract data based on non-missing in index
sub.data<-function(data,index)
{
  #input = data object with rows the dimension to be split
  #index specifying groups for comparison with ordered same a sample rows
  #returns list [1] = index
  # [2] data
  keep.id<-!is.na(index)
  list(factor= index[keep.id],data=data[keep.id,])
}

#get group-wise summary statistics including fold change
#TODO rewrite using dplyr
#' @title stats_summary
#' @param data data.frame of input data
#' @param comp.obj list of groups to base comparisons on
#' @param sigfigs
#' @param log FALSE calculate base don log values
#' @param rel calculate FC relative to what factor level in comp.obj
#' @export
#Kruskal-Wallis test with post hoc for data.frames
stats_summary <- function(data,comp.obj,sigfigs=3,log=FALSE,rel=1,...){

  #data should be numeric coerce
  .class<-sapply(data,class)
  id<-.class == 'factor' | .class == 'character'
  data[,id]<-NA

  test.obj<-join.columns(comp.obj)
  #get summary by splitting data by each column of meta.data
  data.summary<-function(data,test.obj,log,sigfigs,...)
  {
    #split data
    tmp<-sub.data(data,test.obj)
    if(!is.factor(tmp[1])) {
      fct<-factor(as.character(unlist(tmp[1])))# create factors
    } else {
      fct<-tmp[1]
    }
    tmp.data<-data.frame(tmp[[2]])

    # get means sd, fold change
    means<-calc.stat(tmp.data,factor=fct,stat=c("mean"),...)
    sds<-calc.stat(tmp.data,factor=fct,stat=c("sd"),...)
    fc<-fold.change(means,log=log,rel)
    fc_names<-paste(colnames(fc),rep(colnames(fc)[rel],ncol(fc)), sep="_") %>%
      gsub('_mean_','_',.) %>%
      gsub('mean','FC',.)
    colnames(fc)<-fc_names

    #format output from means and sd
    names<-paste(unlist(as.data.frame(strsplit(colnames(means),"_"))[2,]),"_mean_and_sd" , sep="_")
    mean.sd<-matrix(paste(unlist(signif(means,sigfigs)), " +/- ", unlist(signif(sds,sigfigs-1)),sep=""), ncol=ncol(means))
    colnames(mean.sd)<-names
    #bind with fold change
    res<-data.frame(means,sds,cbind(mean.sd,round(fc[,-rel,drop=FALSE],2)))
    tryCatch(rownames(res)<-colnames(data),error=function(e){NULL})
    return(res)
  }

  res<-data.summary(data,test.obj,sigfigs=sigfigs,log=log,na.rm=TRUE)

  #clean up
  res[res=='NaN']<-NA
  res[res=="Inf"]<-NA
  res[res=="-Inf"]<-NA

  return(res)
}


test<-function(){

  library(dave.preproc)
  library(dave.stat)
  library(dplyr)
  data(aq_data)
  group<-'cellType'
  meta_vars<-c('cellType')
  row_meta<-aq_data %>% dplyr::select(one_of(meta_vars))
  data<-aq_data %>% dplyr::select(-one_of(meta_vars))

  #need to make sure data and col_meta are validated and merged
  obj<-list(data=data,
            col_meta=data.frame(var=colnames(data)),
            row_meta=row_meta)

  #calculate
  group<-obj$row_meta %>% dplyr::select(one_of(group))

  #get summary<-
  .sum<-stats_summary(data,comp.obj=group,formula=colnames(group),sigfigs=3,log=FALSE,rel=1)


}
