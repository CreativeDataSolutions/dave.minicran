#' @title kruskal_test
#' @param data data.frame of input data
#' @param factor list of groups
#' @param label variable name
#' @param post.hoc logical to conduct
#' @param FDR method name for p.adjust
#' @factor.name string of test factor name
#' @return list
#' @import PMCMR reshape2
#' @importFrom stats kruskal.test
#' @importFrom reshape2 melt
#' @export
#Kruskal-Wallis test with post hoc for data.frames
kruskal_test<-function(data, group, post.hoc=TRUE, FDR="BH"){
  #formula = formula excluding repeated terms
  #meta data  = all factors
  #repeated name of factor for repeated measures

  # check.get.packages(c("PMCMR","reshape2"))

  #add error checking
  if(is.null(group)) {
    out <-NULL
  } else {
    f_name<-paste0(colnames(group),collapse="_")
    factor<-unlist(group) # to do fix inside

    results<-list(p.value=vector("list",ncol(data)),post.hoc=vector("list",ncol(data)))
    for(i in 1:ncol(data)){
      message(paste0('Calculating: ',i ,'\r')) # can out put to user
      k.pval<-tryCatch(stats::kruskal.test(data[,i] ~ factor)$p.value, error=function(e){1})

      #post-hoc
      if (post.hoc){
        error.mat<-function(factor) { # mimic natural output for errors
          tmp<-matrix(1,ncol=length(unique(factor)),length(unique(factor)))
          dimnames(tmp)<-list(unique(factor),unique(factor))
          tmp[upper.tri(tmp,diag=TRUE)]<-NA
          return(tmp)
        }
        ph<-tryCatch(posthoc.kruskal.nemenyi.test(x=data[,i], g=factor, method="Tukey")$p.value,error=function(e){error.mat(factor)})
        # need to format into rows
        melted<-na.omit(reshape2::melt(ph))
        #format for column-wise output
        .names<-paste("post.hoc",melted$Var1,melted$Var2,sep="_")
        post.h<-t(data.frame(melted$value))
        colnames(post.h)<-.names #breaks on bad
      } else {
        post.h<-NULL
      }

      results$p.value[[i]]<-k.pval
      results$post.hoc[[i]]<-post.h

    }
    tmp<-do.call("rbind",results$p.value)
    FDR.p<-data.frame(FDR.p.values=sapply(1:ncol(tmp), function(i) p.adjust(tmp[,i],method=FDR)))
    colnames(FDR.p)<-paste(f_name,colnames(FDR.p), sep="_")
    colnames(tmp)<-paste(f_name, "p.values",sep="_")
    p.vals<-data.frame(p.values=tmp,FDR.p.values=FDR.p)

    #add rownames
    post.h<-do.call("rbind",results$post.hoc)
    rownames(post.h)<-rownames(p.vals)<-colnames(data)

    #get object summary
    .sum<-stats_summary(data,comp.obj=group,formula=colnames(group),sigfigs=3,log=FALSE,rel=1)

    out <-list(test=p.vals,post_hoc=post.h,group=group,summary=.sum)
  }

  class(out)<-"kruskal_test"
  return(out)
}

#' @title kruskal_test_results
#' @param data test_obj created by kruskal_test
#' @param data_cube list of data col_meta and row_meta
#' @param filter_by numeric vector to filter based on
#' @param cutoff select filter_by less than or eaqual to cutoff
#' @return test_obj, filtered data_cube other args for summary and test... should jut be passed?
#' @export
kruskal_test_results<-function(test_obj,data_cube,filter_by=NULL,cutoff=NULL,variables=NULL,selected=NULL){


  if(is.null(variables)) {
    variables<-data_cube$data %>% colnames()
    variables<-list(variables) %>% setNames(.,.)
  }

  # #TODO handle obj w/ same names!!

  #argh....id special in networks..too fragile
  #need to update object same names

  #filter
  if(!is.null(filter_by)){
    id<-test_obj$test[,filter_by]<=cutoff
    id[is.na(id)]<- FALSE
    #.data_cube<-col_filt_obj(data_cube,id)
  } else {
   # .data_cube<-data_cube
    id<-rep(TRUE,nrow(test_obj$test))
  }

  #add stats to col meta
  #check for existing names and update
  #replace in current
  data_cube$col_meta <-
    merge_df(
      data_cube$col_meta,
      data.frame(
        test_obj$summary,
        test_obj$test,
        test_obj$post_hoc,
        kruskal_selected = id
      )
    )


  # giving back full for plotting?
  out<-list(test_obj=test_obj,
            filter_by=filter_by,
            cutoff=cutoff,
            kruskal_selected = id,
            variables=variables, # does not need to be here since there is no filter?
            group=test_obj$group,
            data_cube=data_cube)
  #TODO deal with multi group tests
  class(out)<-"kruskal_results"
  return(out)
}

#collect arguments
#and make final object kruskall_results

#' Summary method
#' @param obj of class kruskal_results
#' @export
#' @details summarise data object
summary.kruskal_results<-function(obj,.print=TRUE){

  res<-paste0('Kruskal Wallis non-parametric analysis of variance, ',
              'followed by Nemenyi-tests for multiple comparisons of (mean) ',
              'rank sums of independent samples according to Tukey were conducted. ',
              ' Significant differences between ',
              paste0(colnames(obj$group),collapse=' vs. '),
              ' were determined based on ',obj$filter_by,
              ' less-than or equal to ',obj$cutoff,'.')
              # ' Fold change limit was set to maximum of ',
              # fold_change, ' alpha value ', alpha,'.')

  #number of selected variables
  tmp<-table(obj$kruskal_selected) %>%
    data.frame() %>%
    setNames(.,c('selected','number'))

  tvars<-sum(tmp$number)
  if(TRUE %in% tmp$selected){
    svars<-tmp$number[tmp$selected %in% TRUE]
    msg<-paste0('A total of ',svars,' variables of ',tvars,' were significantly altered based on the test criteria.')
  } else {
    msg<-paste0('No variables, out of ',tvars,' tested, were significantly altered based on the test criteria.')
  }

  out<-list(description=res,selected=msg)

  if(.print)  print(out) else return(out)

}

#' Plot method
#' @param obj of class kruskal_results
#' @export
#' @importFrom gridExtra arrangeGrob
#' @details plot
#' @S3method plot kruskal_results
plot.kruskal_results<-function(obj, plots="violin", plot.vars,labels=NULL,
                               FC_lim = 3,p_value=0.05,size=2,alpha=0.5,
                               plotly=FALSE,base_size=16,...){

  if(plots =='volcanoe'){ #

    FC<-obj$test_obj$summary %>% dplyr::select(contains('FC')) %>%
       .[,1,drop=TRUE] %>%
      unlist() %>%
      as.numeric() %>%
      data.frame(FC=.)

    if(is.null(obj$test_obj$filter_by)){
      p.value<-obj$test_obj$test %>% dplyr::select(contains('p.value')) %>%
        .[,1,drop=TRUE] %>%
        unlist() %>%
        as.numeric() %>%
        data.frame(p.value=.)
    } else {
      p.value<-obj$test_obj$test %>% dplyr::select(one_of(obj$test_obj$filter_by)) %>%
      .[,1,drop=TRUE] %>%
      unlist() %>%
      as.numeric() %>%
      data.frame(p.value=.)
    }

    #print(str(p.value))

    if(is.null(labels)){ # this is also in the obj$variables
      labels<-obj$variables
    }


    return(volcanoe_plot(FC,p.value,labels,FC.lim=FC_lim, p.value.lim=p_value,size=size,alpha=alpha,plotly=plotly))
  }

  if(plots == 'violin'){ # this should be for a data cube

    data<-data.frame(obj$data_cube$data)

    if(!is.null(obj$group)) {
       data<-data.frame(obj$group,data)
       .names<-colnames(obj$group)[1] # TODO: handle many groups
    } else {
      .names<-NULL
    }

    #get names for variables

    p_title<-obj$variables[names(obj$variables) %in% plot.vars]

    if(plotly){

      return(violin.ggplot(data, group=.names, varname = plot.vars[1],title=p_title,size=base_size))

    } else {

      plot_list <-  list()
      yvars <- plot.vars
      for(i in 1:length(yvars)){
        if(i>1) extra<-list(theme(legend.position="none")) else extra<-list(theme(legend.position="bottom"))
        plot_list[[i]] <- violin.ggplot(data, group=.names, varname = yvars[i],
                                        title=p_title[i],size=base_size,extra=extra,print=FALSE)
      }
      do.call(gridExtra::grid.arrange, c(plot_list, list(ncol = min(length(plot_list), 2))))
      # p<-do.call(gridExtra::arrangeGrob, c(plot_list, list(ncol = min(length(plot_list), 2))))
      # plot(p)

    }
  }

}


#check for packages and attempt to download if not found
check.get.packages<-function(pkg){
  options(warn=-1)
  res<-character()
  need<-as.matrix(sapply(1:length(pkg),function(i)
  {
    if(require(pkg[i],character.only = TRUE)==FALSE)
    {
      res<-c(res,pkg[i])
    }
  }))
  need<-as.character(unlist(need[!is.null(need)]))
  if(length(need)>0)
  {
    x<-sapply(need,install.packages,dependencies = TRUE)
    lib.fun<-function(need){
      sapply(1:length(need), function(i){
        out<-tryCatch(library(need[i], character.only= TRUE), error=function(e){need[i]})
        if(all(out==need[i])){need[i]}
      })
    }
    out<-as.character(unlist(lib.fun(need)))
    #try bioconductor
    if(length(out)>0){
      cat(paste("Package not found, trying Bioconductor..."),"\n")
      source("http://bioconductor.org/biocLite.R")
      lib.fun.bioc<-function(need){
        sapply(1:length(need), function(i){
          tryCatch( biocLite(need[i],ask=FAlSE),
                    error=function(e){need[i]})
        })
      }
      tmp<-lib.fun.bioc(out)
      final<-lib.fun(tmp)
      if(length(final)>0){cat(paste("could not find package: ",paste(as.character(unlist(final)),collapse=", "),sep=""),"\n")}
    }
  }
}


#violin plot
#' @export
violin.ggplot <- function(data,group, varname, title=NULL,size=16,extra=NULL,print=FALSE){

  if(!is.null(group)){
    if(!is.factor(data[,group])) data[,group]<-factor(data[,group])
    p <- ggplot(data, aes_string(x=group, y=varname, fill=group)) +
      guides(fill=guide_legend(title=group))
  } else {
    p <- ggplot(data, aes(x=1, y=data[,varname])) +
      xlab(varname) +
      scale_fill_manual(values='gray')
  }

  if(is.null(title)) title<-varname

  p <- p + labs(title=title, x=group, y='Value') +
    geom_violin() + stat_summary(fun.y=mean, geom="point", shape=23, size=2) +
    stat_summary(fun.y=min, geom="point", shape=23, size=2) +
    stat_summary(fun.y=max, geom="point", shape=23, size=2) +
    theme_classic(base_size = size) +
    extra

  if(print) print(p) else return(p)
}


#volcano plot
#' @title volcanoe_plot
#' @import ggplot2 ggrepel
#' @export
volcanoe_plot<-function(FC,p.value,labels,FC.lim=3, p.value.lim=.05,size=2,alpha=.5,plotly=FALSE,...){

  #convert to log (non-log makes less sense
  #and is harder to implement
  t.p.lim<--log(p.value.lim)
  t.FC.lim<-log2(FC.lim)
  y.lab<-ylab('-log10 Statistic')
  x.lab<-xlab('log2 Fold Change')
  FC<-log(FC,base=2)
  p.value<--log(p.value)
  factor<-factor(FC>=t.FC.lim&p.value>t.p.lim|FC<(t.FC.lim*-1)&p.value>t.p.lim)
  factor[is.na(factor)]<-FALSE

  labels[factor!=TRUE]<-""

  .theme<- theme(
    axis.line = element_line(colour = 'gray', size = .75),
    panel.background = element_blank(),
    plot.background = element_blank(),
    panel.grid.minor = element_line(colour="gray", size=0.05,linetype=2),
    panel.grid.major = element_line(colour="gray", size=0.05,linetype=2),
    legend.background=element_rect(fill='white'),
    legend.key = element_blank()
  )

  tmp<-data.frame(FC,p.value,labels,factor)
  p<-ggplot(tmp, aes_string(x="FC",y="p.value",color="factor"))

  #special text labels
  if(!plotly){
    labels_text<-geom_text_repel(aes( label = labels),size=size+1,show.legend=FALSE)
  } else {
    labels_text<-geom_text(aes(x=FC,y=p.value,label=labels),color="black", size=size+1,show.legend = FALSE)
  }

  p<-p +
    geom_point(alpha=alpha,size=size) +
    labels_text +
    geom_vline(xintercept = t.FC.lim*c(-1,1),linetype=2,size=.75,color="red") +
    geom_hline(yintercept = t.p.lim,linetype=2,size=.75,color="red")+
    scale_color_manual(name="Selected", values=c("blue","orange")) +
    y.lab + x.lab +.theme + guides(color = guide_legend(override.aes = list(size = 5))) + ggtitle(paste0(sum(na.omit(factor==TRUE))," variables selected"))

  return(p)
}


#tests
tests<-function(){

  library(dave.stat)
  library(dplyr)

  #update existing names
  #data frame and list?

  merge_df<-function(start,end){


    start_names<-colnames(start)
    end_names<-colnames(end)
    merge_names<-start_names[start_names %in% end_names]
    new_names<-end_names[!end_names %in% merge_names]

    #update
    start[,merge_names]<-end[,merge_names]

    #create
    data.frame(start,end[,new_names,drop=FALSE])

  }

  start<-data.frame(a=1:5,b=rnorm(5))
  set.seed(1)
  end<-data.frame(a='s',c=2,b=rnorm(5))

  merge_df(start,end)

  merge_list<-function(start,end){
    #look up list item by name and
    #update colnames or create
    start_names<-names(start)
    end_names<-names(end)
    merge_names<-start_names[start_names %in% end_names]
    new_names<-end_names[!end_names %in% merge_names]


    #loop over list
    #vector list replace
    #how to vector all?

    for(i in 1:length(merge_names)){
      .start<-start[[merge_names[i]]]
      .end<-end[[merge_names[i]]]
      start[[merge_names[i]]]<-merge_df(.start,.end)
    }

    new<-end[!names(end) %in% merge_names]
    c(start,new)

  }

  #update list based on names and values
  start<-data.frame(a=1:5,b=rnorm(5))
  set.seed(1)
  end<-data.frame(a='s',c=2,b=rnorm(5))
  start<-list(foo=start,bar=data.frame(z='1'))
  end<-list(foo=data.frame(z='2'),bar=end)

  merge_list(start,end)

  start<-data.frame(a=1:5,b=rnorm(5))
  set.seed(1)
  end<-data.frame(a='s',c=2,b=rnorm(5))
  start<-list(fooz=start,bar=data.frame(z='1'))
  end<-list(foo=data.frame(z='2'),bar=end)

  merge_list(start,end)


  #dave
  data(dave_data)
  data(dave_data_row_meta)

  row_meta<-dave_data_row_meta
  col_meta<-dave_data_col_meta
  data<-dave_data

  #need to make sure data and col_meta are validated and merged
  obj<-list(data=data,
            col_meta=data.frame(var=colnames(data)),
            row_meta=row_meta)

  #calculate
  .group<-'class'
  group<-obj$row_meta %>% dplyr::select(one_of(.group))
  label<-'name'
  .labels<-col_meta %>%
    dplyr::select(one_of(label)) %>%
    unlist() %>% as.character() %>%
    setNames(.,colnames(obj$data))

  #API version
  test_obj<-kruskal_test(data=obj$data, group=group, post.hoc=TRUE, FDR="BH")

  #bad inputs
  #calculate
  label<-group<-NULL
  test_obj<-kruskal_test(data=obj$data, group=group, post.hoc=TRUE, FDR="BH")



  #results for summary and plotting
  #filter and add to meta
  filter_by<-colnames(test_obj$test)[1]
  cutoff<-.05
  res<-kruskal_test_results(test_obj,data_cube=obj,filter_by,cutoff,variables=.labels)

  summary(res)
  plot(res,plots='volcanoe',labels=  res$variables,plotly=FALSE)
  i<-sample(1:length(.labels),2)
  plot(res,plots='violin',plot.vars = .labels %>% names() %>% .[i],
       plotly=FALSE,title=.labels %>% .[i],base_size=16)


  #dave
  data(aq_data)
  group<-'cellType'
  meta_vars<-c('SampleID','cellType')
  row_meta<-aq_data %>% dplyr::select(one_of(meta_vars))
  data<-aq_data %>% dplyr::select(-one_of(meta_vars))

  #need to make sure data and col_meta are validated and merged
  obj<-list(data=data,
            col_meta=data.frame(var=colnames(data)),
            row_meta=row_meta)

  #calculate
  group<-obj$row_meta %>% select(one_of(group))
  test_obj<-kruskal_test(data=obj$data, group=group, post.hoc=TRUE, FDR="BH")


  #results for summary and plotting
  #filter and add to meta
  filter_by<-colnames(test_obj$test)[1]
  cutoff<-.2
  res<-kruskal_test_results(test_obj,data_cube=obj,filter_by,cutoff)

  summary(res)
  plot(res,plots='violin',plot.vars = colnames(res$data_cube$data)[1:2],plotly=TRUE)

  traceback()

  plot(res,plots='volcanoe',plot.vars = colnames(res$data_cube$data)[1:2],plotly=TRUE)

  #no group test
  .obj<-list()
  .obj$data_cube<-obj
  class(.obj)<-'kruskal_results'
  plot(obj=.obj,plots='violin',group=NULL,plot.vars = colnames(.obj$data_cube$data)[1:2],plotly=FALSE)


  #stats summary need to add to the meta data
  summary_obj<-stats_summary(data,comp.obj=group,formula=colnames(group),sigfigs=3,log=FALSE,rel=1)


  #volcanoe plot
  #create volcanoe plot
  FC<-summary_obj %>% select(dplyr::contains('FC_'))
  names(FC)<- "FC"
  p.value<-test_obj$test %>% select(dplyr::contains('_p.values'))
  log<-FALSE
  FC.lim<-3
  p.value.lim<-1
  labels<-rownames(summary_obj)
  p<-volcano_plot(FC,p.value,labels,FC.lim,p.value.lim)
  plotly::ggplotly(p)


  #generic col_filt
  col_filt_obj<-function(obj,id){ # lots oF ASSUMPTIONS...MIGHT NEED JOIN
    obj$data<-obj$data[,id,drop=FALSE]
    obj$col_meta<-obj$col_meta[id,,drop=FALSE]
    class(obj)<-c('data_cube','list')
    return(obj)
    # # environment() %>% as.list %>% set_class(c("cer_obj",class(.)))
    # obj %>% set_class(c("cer_obj",class(.)))
  }
  lapply(obj,function(x) {x[id,]})

}

