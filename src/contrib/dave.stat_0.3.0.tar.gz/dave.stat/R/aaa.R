#' dave.stat
#'
#' @name dave.stat
#' @docType package
#' @import ggplot2 shiny dplyr
NULL

#' Stat data
#' @details Stat data set for dave_data
#' @docType data
#' @keywords datasets
#' @name dave_stat
#' @usage data(dave_stat)
#' @format A data frame with 188 rows and 15 columns
NULL

#' Stat data mimicking col_meta input
#' @details Stat data set col_meta for dave_data
#' @docType data
#' @keywords datasets
#' @name dave_stat_col_meta
#' @usage data(dave_stat_col_meta)
#' @format A data frame with 188 rows and 15 columns
NULL


#' Sample data
#' @details Sample data based PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_data
#' @usage data(dave_data)
NULL

#' Sample  meta data
#' @details Sample data based PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_data_row_meta
#' @usage data(dave_data_row_meta)
NULL

#' Variable meta data
#' @details Sample data based PMID: 25852003
#' @docType data
#' @keywords datasets
#' @name dave_data_col_meta
#' @usage data(dave_data_col_meta)
NULL


