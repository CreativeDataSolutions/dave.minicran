#plotting 

#' Title
#'
#' @param obj returned by /code{hca_clustering}
#' @param ... 
#'
#' @return
#' @export
#' @import iheatmapr 
#'
#' @examples
dvm_iheatmap <- function(obj,...) {
  UseMethod("dvm_iheatmap")
}


#' Title
#' @param obj obj returned by /code{hca_clustering}
#' @param name legend label for data magnitude e.g.value (default) or 'correlations
#' @param scale convert all variables to mean = 0  and standard deviation =1
#' @param plot return plot or object to plot
#' @param col_labels vector of strings for column labels
#' @param row_labels vector of strings for row labels
#' @export dvm_iheatmap.hclust_obj
#' @import iheatmapr
dvm_iheatmap.hclust_obj <- function(obj,
                         name = 'value',
                         plot = TRUE,
                         col_labels = TRUE,
                         row_labels = TRUE) {
  #get args
  .data <- as.matrix(obj$data) # need for iheatmapr
  dimnames(.data)<-dimnames(obj$data)
  
  name<-if(!is.null(obj$method$cor)) 'correlation' else 'value'
  
  row_annot <- obj$row_group
  col_annot<- obj$col_group
  row_clust <- obj$row_clust
  col_clust<- obj$col_clust
  
  .plot<-main_heatmap(.data, name = name) 
  if(!is.null(row_clust)){ .plot<-.plot %>%  add_row_dendro(row_clust) }
  if(!is.null(col_clust)){ .plot<-.plot %>%  add_col_dendro(col_clust) } 
  if(!is.null(col_annot)){ .plot<-.plot %>%  add_col_annotation(col_annot) }
  if(!is.null(row_annot)){ .plot<-.plot %>%  add_row_annotation(row_annot) } 
  if(col_labels) { .plot<-.plot %>% add_col_labels() } 
  if(row_labels) { .plot<-.plot %>% add_row_labels() } 
  
  if(plot){
    print(.plot)
  } else {
    return(.plot)
  }
  
}


#' Title
#'
#' @param obj returned by /code{hca_clustering}
#' @param ... 
#'
#' @return
#' @export
#' @import iheatmapr 
#'
#' @examples
dvm_dendrogram <- function(obj,...) {
  UseMethod("dvm_dendrogram")
}

#' Title
#'
#' @param obj returned by /code{hca_clustering}
#' @param plot TRUE (default) print else return plot object
#' @param ... 
#'
#' @return
#' @export dvm_dendrogram.hclust_obj
#'
#' @examples
dvm_dendrogram.hclust_obj<-function(obj,plot=TRUE,...){
  
  #plot object can not be returned? plots by default
  type<-obj$method$type
  
  if (type == 'both') {
    obj$method$type <- 'row'
    .row <- dvm_dendrogram.hclust_obj(obj, plot)
    obj$method$type <- 'column'
    .col <- dvm_dendrogram.hclust_obj(obj, plot)
    
    return(list(row = .row,
                column = .col))
  }
  
  #annotation
  group <- switch(type,
                  'column' = obj$col_group,
                  'row' = obj$row_group)
  
  #hclust obj
  clust<-switch(type,
                'column' = obj$col_clust,
                'row' = obj$row_clust)
  #labels
  .names<-switch(type,
                 'column' = colnames(obj$data),
                 'row' = rownames(obj$data))
  
  tmp<-matrix(rep(0,length.out=length(.names)),nrow=1)
  colnames(tmp)<-.names 
  
  
  
  .plot<-main_heatmap(tmp, name = 'groups',show_colorbar=FALSE) %>%
    add_col_dendro(clust,size=4) %>%
    add_col_annotation(group,side = 'bottom',size=1) %>%
    add_col_labels()
  
  if(plot){
    print(.plot)
  } else {
    return(.plot)
  }
  
}

#' Title
#'
#' @param obj obj returned by /code{hca_clustering}
#' @param type one of heatmap (default) or dendrogram
#' @param plot print (default) or return object
#' @param ... passed to plotting
#'
#' @return
#' @export plot.hclust_obj
#'
#' @examples
plot.hclust_obj <- function(obj, type = 'heatmap',plot=TRUE, ...) {
  
  if (type == 'heatmap') {
    p<-dvm_iheatmap(obj = obj, ...)
    
  }
  
  if (type == 'dendrogram') {
    p<-dvm_dendrogram(obj,...)
  }
  
  if(plot){
    print(p)
  } else{
    return(p)
  }

}

#' Title
#'
#' @param obj to plot 
#'
#' @return
#' @export
#'
#' @examples
annotate_obj <- function(obj,...) {
  UseMethod("annotate_obj")
}

#' Title
#'
#' @param obj obj returned by /code{hca_clustering}
#' @param row_group data.frame to display matching obj rows
#' @param col_group data.frame to display matching obj columns
#' @param row_labels string vector of row labels
#' @param col_labels string vector of row labels
#'
#' @return hca_clust object
#' @export annotate_obj.hclust_obj
#'
#' @examples
annotate_obj.hclust_obj <-
  function(obj,
           row_group = NULL,
           col_group = NULL,
           row_labels = NULL,
           col_labels = NULL) {
    
    #if _group is present add or replace columns else create group
    #row
    tmp <- row_group
    if (!is.null(tmp)) {
      target <- obj$row_group
      if (!is.null(target)) {
        if (nrow(tmp) == nrow(target)) {
         
            for (i in 1:ncol(tmp)) {
              .name <- colnames(tmp)[i]
              target[, .name] <- tmp[, i]
            }
          
          obj$row_group<-target
        }
      } else {
        if(nrow(obj$data) == nrow(tmp)) obj$row_group <- tmp
        
      }
    }
    
    #col
    tmp <- col_group
    if (!is.null(tmp)) {
      target <- obj$col_group
      if (!is.null(target)) {
        if (nrow(tmp) == nrow(target)) {
            for (i in 1:ncol(tmp)) {
              .name <- colnames(tmp)[i]
              target[, .name] <- tmp[, i]
            }
          obj$col_group<-target
        }
      } else {
        if(ncol(obj$data) == nrow(tmp)) obj$col_group <- tmp
      }
    }
    
    #update dimnames
    to_string <-
      function(x) {
        if(is.null(x)) return()
        matrix(x) %>% unlist() %>% as.character()
      }
    
    #row
    tmp <- to_string(row_labels)
    if (!is.null(tmp)) {
      if (length(tmp) == nrow(obj$data)) {
        rownames(obj$data) <- tmp
      } 
    }
    
    #column
    tmp <- to_string(col_labels)
    if (!is.null(tmp)) {
      if (length(tmp) == ncol(obj$data)) {
        colnames(obj$data) <- tmp
      } 
    }
    
    return(obj)
    
  }
