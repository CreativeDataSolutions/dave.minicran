#iheatmap tests
test<-function(){

  
  library(dave.cluster) 
  library(dave.preproc)  #for data
  
  #example data
  data("dave_data")
  data("dave_var_meta")
  .data<-dave_data
  
  #TODO plot summary
  
  
  # obj1<-do.call('hca_clustering',list(data=.data,type='column',cor.opt=NULL,scale=TRUE))
  
  
  obj<-hca_clustering(.data,type='column',cor.opt=NULL,scale=TRUE) 
  obj<-hca_clustering(.data,type='column',cor.opt='spearman')
  
  obj<-hca_clustering(.data,type='row',cor.opt=NULL) 
  obj<-hca_clustering(.data,type='row',cor.opt='spearman')
  
  obj<-hca_clustering(.data,type='both',cor.opt=NULL, scale=TRUE) 
  obj<-hca_clustering(.data,type='both',cor.opt='spearman') # no cor
  
  #get clusters
  obj<-cut(obj,k=5)

  
  #groups
  row_group<- dave_data_row_meta %>% select(class,age)
  col_group<-NULL
  col_labels<-dave_data_col_meta %>% select(name) 
  row_labels<-dave_data_row_meta %>% select(label) 
  
  
  obj <-
    annotate_obj(
      obj,
      col_labels = col_labels,
      row_labels = row_labels,
      row_group = row_group,
      col_group = col_group
    )
  
  
  p<-plot(obj,type='heatmap',plot=FALSE)
  plot(obj,type='dendrogram')
  
  obj<-summary(obj)
  
  
  
  #heatmap
  p<-dvm_iheatmap(obj,name='value')
  
  #dendrogram only version
  dvm_dendrogram.clust_obj(obj)
  
  
  #non-interactive
  #need phantomjs - screenshot
  # install.packages('webshot')
  library(webshot)
  # install_phantomjs()
  .plot %>% save_iheatmap("myplot.png") 
  
}

