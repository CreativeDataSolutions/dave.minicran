
## ui for design menu in dave
do.call(navbarPage,
        c("dave.report",
          getOption("dave.nav_ui"),
          getOption("report_ui"),
          getOption("dave.shared_ui")
        )
)
