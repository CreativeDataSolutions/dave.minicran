r_url_list <- getOption("dave.url.list")


r_url_list[["report"]] <-  list("tabs_report" = list("Report" = "report/report/"))
options(dave.url.list = r_url_list); rm(r_url_list)

options(report_ui =
  tagList(
      tabPanel("Report",icon=icon('file-text-o'),
                 # shinyjs::useShinyjs(),# not using
                 fluidRow(column(12,offset = 1, uiOutput("dave_report_ui")))

      )
  )
)
