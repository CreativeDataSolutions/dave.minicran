
library(shiny)
library(dave)
#setup
envs<-list(
  SHINYPROXY_USERNAME="test", #location to save files in app
  USER_DATA='user',
  APP_NAME='report',
  USE_DAVE=FALSE
)

do.call('Sys.setenv',envs)
library('dave.report')

runApp('inst/app/')
