
#' @export
available_report_order <- function() {
  c(
    'preproc_report',
    'preproc_filter',
    'kruskal',
    'hclust',
    'pca',
    'rfe',
    'model',
    'pathway',
    'network_mapping',
    'keggmap',
    'pubchemmap',
    'corrmap',
    'network'
  )
}


#' @export
get_report_obj<-function(.package = 'dave.stat',
                         report_name='kruskal_report.Rmd',
                         rmd_load_path = './', # from package
                         rmd_save_path='./', # copied to local
                         html_save_path='./'){

  #report source from w/in package
  report<-system.file(paste0(rmd_load_path,report_name),package = .package)

  #local report
  rmd_name<-normalizePath(paste0(rmd_save_path,report_name),winslash='/')
  #package report
  pkg_rmd_name<-normalizePath(system.file(paste0('app/report/',report_name),package=.package),winslash='/')


  if (file.exists(rmd_name)) {

    #check if files match package version
    local_obj<-digest(readLines(rmd_name))
    pckg_obj<-digest(readLines(pkg_rmd_name))

    if (local_obj != pckg_obj ) {
      message('Updating package report .Rmd')
      file.copy(report, rmd_name, overwrite = TRUE)
    }
  } else{
    message('Copying package report .Rmd')
    file.copy(report, rmd_name, overwrite = TRUE)
  }


  #save html
  html_name<- report %>% basename() %>%
    gsub('Rmd','html',.) %>%
    paste0(html_save_path,.) %>%
    normalizePath(.,winslash='/')



  # #get custom css if it exists
  # .css<-system.file(paste0('app/report/style.css'),package = .package)

  list(rmd=rmd_name,
       html=html_name)
}


#get and order reports
#' @export
report_files<-function(path,ord=available_report_order(),files=NULL,remove=FALSE){

  .files<-dir(path)
  .files<-.files[tools::file_ext(.files)=='html']

  if(!is.null(files)){
    .files<-.files[.files %in% files ]
  }

  #want to match and filter
  id<-lapply(ord,function(x){grep(x,.files)})
  out<-.files[id %>% unlist()]

  #delete
  if(remove){
    if(path=='.') path<-'' # .rethink
    tmp<-normalizePath(paste0(path,out))
    lapply(tmp,unlink,force=TRUE)
    out<-character()
  }

  return(out)
}

#get files
#' @export
get_report_html_files<-function(path){
  .files<-report_files(path)
  if(length(.files)==0) return(NULL)
  .files %>%
    paste(path,.,sep="/") %>%
    normalizePath(.,winslash = "/")
}

#combine html fragments at a path
#' @export
#' @import tools
combn_html<-function(path,files=NULL,stand_alone=FALSE){

  .files<-get_report_html_files(path)

  if(!is.null(files)){
    .names<-basename(.files)
    obj<-left_join(data.frame(id=files),data.frame(id=.names,path=.files),by='id')
    .files<-obj$path
  }

  #.html might need a header
  out<-lapply(.files,readLines) %>%
    unlist() %>%
    paste(.,collapse="")

  if(stand_alone){
    out<-paste0('<!DOCTYPE html>
      <html>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <head>
      <title>Data Analysis Report</title>
      </head>
      <body>',
      out,
      '</body>
      </html>')
  }

  return(out)
}



test<-function(){

  library(dave.report)

  #opts
  .package<-'dave.report'
  report_name='preproc_report.Rmd'
  rmd_load_path = 'app/tests/' # from package
  rmd_save_path='inst/app/tests/reports/' # copied to local
  html_save_path='inst/app/tests/user/partial/'

  #get report template fropm package
  #set rmd and html output paths
  .report_obj<-get_report_obj(.package = .package,
                           report_name= report_name,
                           rmd_load_path = rmd_load_path, # from package
                           rmd_save_path = rmd_save_path, # copied to local
                           html_save_path = html_save_path)

  #get files and match report order
  path<-dirname(.report_obj$html)
  .files<-report_files(path,ord=available_report_order(),files=NULL,remove=FALSE)

  #get html files
  html<-files<-get_report_html_files(path)

  #combine many html files into a single document
  combn_html(path)
}

#using html_fragment() fixes this
# #get iframe.. other versions of rendering report break navbar
# #need to add resource to iframe files
# get_report_iframe<-function(name,path){
#   #name?
#   tmp<-basename(tempfile())
#   addResourcePath(tmp,path)
#   #includeHTML('test1.html')# breaks navbar menue
#   tags$iframe(src=paste0(tmp,'/',name),seamless="seamless",scrolling="no",width='100%',height='100%')
# }


test<-function(){

  rmd_load_path<-'app/report/'
  report_name<-'rfe_report.Rmd'
  rmd_save_path<-'/srv/shiny-server/app/report/'
  .package<-'dave.rf'

  get_package_report_Rmd<-function(rmd_load_path,report_name,rmd_save_path,.package,replace=TRUE){
    #report source from w/in package
    report<-system.file(paste0(rmd_load_path,report_name),package = .package)

    #bad design need to wipe files to update?
    # write .Rmd report to local
    rmd_name<-normalizePath(paste0(rmd_save_path,report_name),winslash='/')


    file.copy(report,rmd_name)


  }



}
