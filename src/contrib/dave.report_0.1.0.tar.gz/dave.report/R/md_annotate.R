

# edit markdown -----------------------------------------------------------


#' @import shiny
#' @import shinyAce
#' @export
mdEditUI <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("main_ui"))
  )
}





#' @import shiny
#' @import markdown
#' @export
mdEditServer <- function(id,
                         value = '',
                         theme = "github",
                         height = "400px",
                         class = "",
                         open=function(){TRUE}
                         ){
  moduleServer(id,
               function(input, output, session) {


                 vals<-reactiveValues()

                 #attempt to purify md of all html tags
                 strip_tags <- function(x) {
                   gsub('<[^>]*>', '', x, perl = TRUE)

                 }

                 #getmd
                 .get_md<-function(md){

                   if(is.null(md)) '' else strip_tags(md)
                 }

                 observe({
                   open()
                   vals$md <-.get_md(input$mdInput)

                 })



                 get_md <- reactive({

                   open() # make sure update before closing
                   return(vals$md)

                 })

                 output$main_ui<-renderUI({

                   ns <- session$ns
                   tagList(
                     shinyWidgets::materialSwitch(
                       inputId = ns("edit_switch"),
                       label = "Edit",
                       status = "info",
                       value = open()
                     ),
                     uiOutput(ns("result"))
                   )

                 })

                 output$result <- renderUI({
                   ns <- session$ns

                   if (input$edit_switch) {
                     isolate({
                      #could be a reactivity issue with outside here
                       shinyAce::aceEditor(
                         ns("mdInput"),
                         value = value(), # can't call here directly?
                         mode = "markdown",
                         theme = theme,
                         height = height
                       )
                     })

                   } else {
                     req(input$mdInput)
                     shiny::div(class = class,
                                shiny::withMathJax(shiny::HTML(
                                  markdown::markdownToHTML(text =  get_md(),
                                                           fragment.only = TRUE)
                                )))

                   }
                 })

                 return(get_md)


               })
}





# custom code annotate ----------------------------------------------------

#' @import shiny
#' @export
mdAnnotateUI <- function(id) {
  ns <- NS(id)
  fluidRow(column(4,
                  uiOutput(ns('main_ui'))),
           column(12,
                  mdEditUI(ns("mdEdit"))), )
}


#' @import shiny
#' @import markdown
#' @export
mdAnnotateServer <- function(id) {
  moduleServer(id,
               function(input, output, session) {
                 output$main_ui <- renderUI({
                   ns <- session$ns

                   fluidRow(
                       column(
                       6, selectInput(
                         ns('annotate_position'),
                         'position',
                         choices = c('top', 'bottom')
                       )
                     )
                     )
                 })

                 #control
                 mdEditvals <- reactiveValues()



                 get_mdEdit_value <- reactive({
                    mdEditvals[['value']]
                 })

                 mdEditvals[['value']] <-
                   mdEditServer("mdEdit",value=get_mdEdit_value()) #,open =.open

                 reactive({
                   list(md = get_mdEdit_value(), # get_mdEdit_value()
                        position = input$annotate_position)

                 })

               })
}

test <- function() {



  library(dave.report)
  setwd('inst/app/')
  source('global.R') # set main params

  # md_annotate in report ---------------------------------------------------
  ui <- fluidPage(fluidRow(column(12,
                                  tagList(
                                    reportGeneratorUI('md_annotate')
                                  ))))


  server <- function(input, output, session) {
    #report
    md_annotate_report_obj <- function() {
      # .package<-'dave.report'
      # report_name<-'md_annotate.Rmd'
      # rmd_load_path = 'app/report/'
      # rmd_save_path=getOption("dave.report.rmd.path")
      # html_save_path= getOption('dave.report.html.path')
      #
      # .report_obj<-get_report_obj(.package = .package,
      #                             report_name= report_name,
      #                             rmd_load_path = rmd_load_path,
      #                             rmd_save_path = rmd_save_path,
      #                             html_save_path = html_save_path)

      list(rmd = 'C:/Users/think/Dropbox/Software/dave/dave/dave.report/inst/app/report/md_annotate.Rmd',
           html = 'C:/Users/think/Dropbox/Software/dave/dave/dave.report/inst/app/report/partial/md_annotate.html')

      # return(.report_obj)
    }


    md_annotate_available <- reactive({
      'available'
    })

    md_annotate_report_params <- reactive({
      list(md = '## Foo',
           position = 'top',
           code = NULL)

    })

    name <- 'md_annotate'
    md_annotate_report <- callModule(
      reportGenerator,
      name,
      report_params = md_annotate_report_params,
      report_obj = md_annotate_report_obj(),
      .available = md_annotate_available
    )


  }

  shinyApp(ui, server)


  # md_annote + report ------------------------------------------------------


  ui <- fluidPage(fluidRow(column(
    12,
    tagList(
      reportGeneratorUI('md_annotate'),
      dropdownButton(
        mdAnnotateUI("custom"),
        circle = FALSE,
        status = "info",
        icon = icon("pen"),
        width = "100%",
        tooltip = tooltipOptions(title = "Add custom text"),
        inputId = 'custom_edit'
      ),
      tippy::tippy_this("'custom_edit'", "Add custom description", placement = "bottom")
    )
  )))


  server <- function(input, output, session) {
    md_annotate_vals <- reactiveValues()


    #custom annotation
    md_annotate_vals$module <- mdAnnotateServer("custom")


    #report
    md_annotate_report_obj <- function() {
      # .package<-'dave.report'
      # report_name<-'md_annotate.Rmd'
      # rmd_load_path = 'app/report/'
      # rmd_save_path=getOption("dave.report.rmd.path")
      # html_save_path= getOption('dave.report.html.path')
      #
      # .report_obj<-get_report_obj(.package = .package,
      #                             report_name= report_name,
      #                             rmd_load_path = rmd_load_path,
      #                             rmd_save_path = rmd_save_path,
      #                             html_save_path = html_save_path)

      list(rmd = 'C:/Users/think/Dropbox/Software/dave/dave/dave.report/inst/app/report/md_annotate.Rmd',
           html = 'C:/Users/think/Dropbox/Software/dave/dave/dave.report/inst/app/report/partial/md_annotate.html')

      # return(.report_obj)
    }


    md_annotate_available <- reactive({
      'available'
    })

    md_annotate_report_params <- reactive({
      list(
        md = md_annotate_vals$module()$md(),
        position = md_annotate_vals$module()$position,
        code = NULL
      )

    })

    name <- 'md_annotate'
    md_annotate_report <- callModule(
      reportGenerator,
      name,
      report_params = md_annotate_report_params,
      report_obj = md_annotate_report_obj(),
      .available = md_annotate_available
    )


  }

  shinyApp(ui, server)



  # mdAnnotate --------------------------------------------------------------

  ui <- fluidPage(mdAnnotateUI("custom"))
  server <- function(input, output, session) {
    mdAnnotateServer("custom")

  }
  shinyApp(ui, server)



  # mdEdit ------------------------------------------------------------------


  ui <- fluidPage(mdEditUI("mdEdit"))
  server <- function(input, output, session) {
    mdEditvals <- reactiveValues()

    get_mdEdit_value <- reactive({
      mdEditvals$value
    })

    mdEditvals$value <-
      mdEditServer("mdEdit", value = get_mdEdit_value())

  }
  shinyApp(ui, server)


}
