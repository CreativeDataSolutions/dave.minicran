#' @title reportGeneratorUI
#' @export
#' @import shiny
reportGeneratorUI <- function(report_name) {

  ns <- NS(report_name)
  #download test
  tagList(
    fluidRow(
      column(12,uiOutput(ns('report_ui')))
    )
  )
}

#' @title reportGenerator
#' @export
#' @import shiny rmarkdown shinyWidgets
reportGenerator<-function(input, output, session,report_params,report_obj,.available){

# report generator --------------------------------------------------------
  #compile to .html and combine
  # better to dynamically combine in one .Rmd ?
  #so can be render dynamically



  report_vals<-reactiveValues(params = report_params)

  # add to params custom text -------------------------------------------------------------


  #custom annotation
  report_vals$annotate<-mdAnnotateServer("custom")



  get_params<-reactive({

    .params <-report_vals$params()
    .params$annotate$md <-report_vals$annotate()$md()
    .params$annotate$position <- report_vals$annotate()$position

    .params

  })

  #report for html
  observeEvent(input$report_refresh,{

    params<-get_params() #report_params()
    #block empty report
    if(is.null(params)) return()


    #omitting css for now
    withProgress(message = "Creating report", value = 1, {
      rmarkdown::render(report_obj$rmd,
                      output_format=html_fragment(),
                      output_file = report_obj$html, # partial html save location
                      params=params,encoding="UTF-8")
    })
  })


  #download test
  output$DL_btn <- renderUI({

    ns<-session$ns

    fluidRow(column(12,
                    fluidRow(tags$table(
                      tags$td(
                        dropdownButton(
                          mdAnnotateUI(ns("custom")),
                          circle = FALSE,
                          status = "info",
                          icon = icon("pen"),
                          width = "600px",
                          tooltip = tooltipOptions(title = "Add custom text"),
                          # not working
                          inputId = ns('custom_edit')
                        ),
                        tippy::tippy_this(ns('custom_edit'), "Add custom description", placement = "bottom")
                      ),
                      tags$td(
                        actionButton(ns('report_refresh'), '', icon = icon('refresh')),
                        tippy::tippy_this(ns('report_refresh'), "Update report", placement = "bottom")
                      ),
                      tags$td(
                        downloadButton(ns('report_DL'), ""),
                        tippy::tippy_this(ns('report_DL'), "Download report", placement = "bottom"),
                      )
                    ))))
  })


  #report to pdf
  output$report_DL <- downloadHandler(

    filename = function() {
      'report.pdf'
    },
    content = function(file) {

      #check if  dependancies to create pdf are installed -- can be slow
      if(!tinytex::is_tinytex()){
        shiny::showNotification('Installing pdf conversion tools: tinytex', type='warning')
        tinytex::install_tinytex(force = FALSE)
      }

      params<-get_params()
      if(is.null(params)) return()

      shiny::showNotification('Converting report for download ...')
      tempReport <- file.path(tempdir(), basename(report_obj$rmd))
      file.copy(report_obj$rmd, tempReport, overwrite = TRUE)

      rmarkdown::render(tempReport,
                        output_format = pdf_document(),
                        output_file = file,
                        params = params,encoding="UTF-8")
    }
  )

  output$report_html<-renderUI({
    input$calculate
    input$report_refresh

    .html<-tryCatch(readLines(report_obj$html),error=function(e){NULL}) # init value
    # if(is.null(.html)) return()

    shiny::validate(need(!is.null(.html) == TRUE,'Refresh to view the report.'))
    fluidRow(
      column(12,
             HTML(.html)
      )
    )
  })

  output$report_ui<-renderUI({
    ns<-session$ns

    #show report by default

    shiny::validate(need(.available() == "available",'Calculate to generate report.'))

    fluidRow(
      column(12,
             uiOutput(ns('DL_btn')),
             uiOutput(ns('report_html'))
      )
    )
  })
}

custom_annotate<-function(params,position='top'){

  .position<-params$annotate$position
  md<-params$annotate$md

  if(!all(is.null(.position), is.null(md)) && .position == position) cat(md)


}


test<-function(){


  params<-list( annotate=list( md='hi', position='top'))
  custom_annotate(params)


  library(dave.report)
  setwd('inst/app/')
  source('global.R') # set main params

  library(shiny)

  # tell shiny to log all reactivity
  library(reactlog)
  reactlog_enable()

  # md_annotate in report ---------------------------------------------------
  ui <- fluidPage(fluidRow(column(12,
                                  tagList(
                                    reportGeneratorUI('md_annotate')
                                  ))))


  server <- function(input, output, session) {


    #report
    md_annotate_report_obj<-function(){
      # .package<-'dave.report'
      # report_name<-'md_annotate.Rmd'
      # rmd_load_path = 'app/report/'
      # rmd_save_path=getOption("dave.report.rmd.path")
      # html_save_path= getOption('dave.report.html.path')
      #
      # .report_obj<-get_report_obj(.package = .package,
      #                             report_name= report_name,
      #                             rmd_load_path = rmd_load_path,
      #                             rmd_save_path = rmd_save_path,
      #                             html_save_path = html_save_path)

      list(rmd = 'C:/Users/think/Dropbox/Software/dave/dave/dave.report/inst/app/report/md_annotate.Rmd',
           html = 'C:/Users/think/Dropbox/Software/dave/dave/dave.report/inst/app/report/partial/md_annotate.html')

      # return(.report_obj)
    }


    md_annotate_available<-reactive({
      'available'
    })

    md_annotate_report_params<-reactive({

      list( time = Sys.time())

    })

    name <- 'md_annotate'
    md_annotate_report<-callModule(reportGenerator, name,
                                   report_params = md_annotate_report_params,
                                   report_obj= md_annotate_report_obj(),
                                   .available = md_annotate_available)

    return(md_annotate_report_params)


  }

  shinyApp(ui, server)


  shiny::reactlogShow()

}
