
#pckg down
usethis::use_pkgdown()
library("pkgdown")

build_home()
build_articles()
pkgdown::build_site()



#test POST
library(ocpuclient)

base_url<-'http://localhost/ocpu/'

#debug
endpoint<-'library/CTSgetR/R/api_debug'
url<-paste0(base_url,endpoint)

post_ocpu(url=url)
post_ocpu(url=url,return_value = FALSE)

#db
db_name<-'/ctsgetr/inst/ctsgetr.sqlite'
endpoint<-'library/CTSgetR/R/db_stats'
url<-paste0(base_url,endpoint)
body<-list(data=FALSE, db_name=db_name)

post_ocpu(url=url,body=body)

#translate
endpoint<-'library/CTSgetR/R/CTSgetR'
url<-paste0(base_url,endpoint)

id <-
  c("C15973",
    "C00026")
from <- "KEGG"
to <- "PubChem CID"

body<-list(id=id,from=from,to=to,db_name=db_name)


post_ocpu(url=url,body=body)
