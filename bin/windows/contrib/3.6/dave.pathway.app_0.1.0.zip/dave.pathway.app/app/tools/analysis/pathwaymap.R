
#main UI is shown in calculate_enrichment


slice <- dplyr::slice #throws up error otherwise

if(!exists('pathway_values')) pathway_values<-reactiveValues()

# main fun pathwaymap
## list of function arguments
pathwaymap_args <- as.list(formals(init_data))

## list of function inputs selected by user
pathwaymap_inputs <- reactive({
  ## loop needed because reactive values don't allow single bracket indexing
  # pathwaymap_args$arg<-input$something
  # pathwaymap_args$

  for (i in r_drop(names(pathwaymap_args)))
    pathwaymap_args[[i]] <- input[[paste0("pathwaymap_",i)]]
  pathwaymap_args
})

## get global input dataset
pathwaymap_datasetlist <- reactive({
  input$dataset
})




#FC column
output$ui_FC_col <- renderUI({
  vars<- .getdata_col_meta() %>% colnames() # actually col_meta
  selectInput(inputId = "FC_col", label = "Fold-change:",
              choices = vars,
              selected=state_single("FC_col",vars), multiple = T)
})


#Show results
output$ui_pathwaymap_results<-renderUI({
  vars <- names(.pathwaymap()$pathway.map)
  tagList(
    hr(),
    h4("Save result"),
    p("Select pathwaymap result to save."),
    selectInput("pathwaymap_results", "pathwaymap results:", vars, multiple = FALSE))
})

#Store data
output$ui_pathwaymap_save<-renderUI({
  vars <- names(.pathwaymap())
  tags$table(
    tags$td(textInput("pathwaymap_dataset", "Save result in:", paste0("result_",input$pathwaymap_results))),
    tags$td(actionButton("pathwaymap_save", "Save"), style="padding-top:30px;")
  )
})



#setup plot
#not sizing
pathwaymap_plot <- reactive({
  plh <- 800
  plw <- 1000
  list(plot_width=plw, plot_height=plh)
})

pathwaymap_plot_width <- function()
  pathwaymap_plot() %>% { if (is.list(.)) .$plot_width else 1000 }

pathwaymap_plot_height <- function()
  pathwaymap_plot() %>% { if (is.list(.)) .$plot_height else 800 }

#initialize data
pathwaymap_init<-reactive({
  # browser()
  msdata <- .getdata_col_meta()
  keggCol <- input$kegg_var
  FCCol <- input$FC_col
  pathway_values[['pathway_name']] <- names(which(get_kegg_paths(path_info)==input$kegg_pathway_name))
  pathwayId <- paste0('ko',input$kegg_pathway_name)
  organismId <- 'ko'#input$kegg_organism_name
  saveDir <- getOption('dave.path_save_dir')
  suffix <- paste("Map",pathwaymap_datasetlist(),sep = "_")
  return(
    list(
      data = msdata,
      kegg.col = keggCol,
      cpd.FC = FCCol,
      pathway.code = pathwayId,
      organism.code = organismId,
      suffix = suffix,
      save.dir = saveDir,
      kegg.dir = '/dave_pathway/figures'
    )
  )
})

pathwaymap_available <- reactive({
  if(is.null(input$pathwaymap_calculate) || input$pathwaymap_calculate ==0) {
    return("This analysis is used to link compatible sample and variable meta data. Select accordingly and then calculate.")
  }
  if (is.na(input$pathwaymap_calculate))
    return("Please choose a comparison value")
  "available"
})


###############################
# main functions
###############################
.pathwaymap <- eventReactive(input$pathwaymap_calculate, {

  obj<-withProgress(message = "Calculating", value = 1, {

    .<-pathwaymap_init()
    body<-list(data=.$data,
               kegg.col = .$kegg.col,
               cpd.FC = .$cpd.FC,
               pathway.code = .$pathway.code,
               organism.code = .$organism.code,
               suffix  = .$suffix,
               kegg.dir = .$kegg.dir)

    dave.ocpu.client::ocpu_pathway_mapping(
      dave_path_connection,
      body,
      save.dir = .$save.dir
    )

    # do.call(pathway.mapping, pathwaymap_init())
  })


  #need to save image name
  # tmp<-pathwaymap_init()
  # name<-paste0(tmp$save.dir,"/",tmp$pathway.code,'.',tmp$suffix,'.png')
  name<-obj$inputs$image

  #allow storage of multiple pathway images for report
  #hash name based on pathway and data name

  pathway_hash <- names(which(get_kegg_paths(path_info)==input$kegg_pathway_name))

  dave_statcol_meta<-read.csv(.path, header = TRUE)
  usethis::use_data(
    dave_statcol_meta,
    overwrite = TRUE
  )
  #init empty list
  #store in list
  pathway_values[['images']][[pathway_hash]]<-name %>% normalizePath(.,winslash = '/')

#  pathway_values[['images']]<-unique(c(pathway_values[['images']],name))

  return(obj)
})

.summary_pathwaymap <-reactive({
  if (pathwaymap_available() != "available") return(pathwaymap_available())
  summary(.pathwaymap())
})

.plot_pathwaymap <- reactive({
  if (pathwaymap_available() != "available") return(pathwaymap_available())
  plot(.pathwaymap(), shiny = TRUE)$src
})

#show image
output$image_pathwaymap <- renderImage({
  #createing placeholder image
  #could block with validate message!
  if (pathwaymap_available() != "available"){
    outfile <- tempfile(fileext='.png')
    # Generate an empty png
    png(outfile, width=400, height=400)
    dev.off()
    return(list(src = outfile, alt = "No pathway available"))
  }else{
    plot(.pathwaymap(), shiny = TRUE)
  }
}, deleteFile = FALSE)

#save
observeEvent(input$pathwaymap_save, {
  ## saving to a new dataset if specified
  dataset <- input$pathwaymap_dataset
  pathwaymapdf <- .pathwaymap()$pathway.map[[input$pathwaymap_results]]
  r_data[[dataset]] <- pathwaymapdf
  r_data[[paste0(dataset,"_descr")]] <- r_data[[paste0(input$dataset,"_descr")]]
  r_data[['datasetlist']] %<>% c(dataset,.) %>% unique
})
