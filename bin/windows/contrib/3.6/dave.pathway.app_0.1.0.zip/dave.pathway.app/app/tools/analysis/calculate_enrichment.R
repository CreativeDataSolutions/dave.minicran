#TODO save UI state in sesison
#selected = state_single("cluster_group_dim_names",vars)




#generic list of pathways
output$ui_kegg_pathways<-renderUI({

  if(!exists('path_info')){data('path_info')}
  #need to update to selected
  vars <- get_kegg_paths(path_info)
  if(!is.null(pathway_values[['enrich']])){
    tmp<-path_enrich()$path_enrich
    id<-{vars} %in% {tmp$map %>% gsub('map','',.)}
    vars<-vars[id]

  }

  selectInput(inputId = "kegg_pathway_name", label = "Select pathway:", choices = vars, multiple = F)
})

#update available based on enrichment
observeEvent(input$path_enrich_keep_selected,{

  if(is.null(pathway_values[['enrich']])) return()
  tmp<-path_enrich()$path_enrich
  vars<-get_kegg_paths(path_info)
  id<-{vars} %in% {tmp$map %>% gsub('map','',.)}
  vars<-vars[id]
  updateSelectInput(session=session,"kegg_pathway_name", choices = vars)


})


# #Show results
# output$ui_pathwaymap_results<-renderUI({
#   vars <- names(.pathwaymap()$pathway.map)
#   tagList(
#     hr(),
#     h4("Save result"),
#     p("Select pathwaymap"),
#     selectInput("pathwaymap_results", "pathwaymap results:", vars, multiple = FALSE))
# })
#
# #Store data
# output$ui_pathwaymap_save<-renderUI({
#   vars <- names(.pathwaymap())
#   tags$table(
#     tags$td(textInput("pathwaymap_dataset", "Save result in:", paste0("result_",input$pathwaymap_results))),
#     tags$td(actionButton("pathwaymap_save", "Save"), style="padding-top:30px;")
#   )
# })



#############################################################################
#ui elements
#kegg id columns
output$kegg_var_ui <- renderUI({
  vars<- .getdata_col_meta() %>% colnames()
  #selected = state_single("cluster_group_dim_names",vars)
  selectInput(inputId = "kegg_var", label = "KEGG Id", choices = vars,selected=state_single("kegg_var",vars), multiple = F)
  # selectInput(inputId = "kegg_var", label = "KEGG Id", choices = vars, multiple = F)
})

#p value data filter
output$p_value_var_ui <- renderUI({
  vars<- .getdata_col_meta() %>% colnames()
  fluidRow(column(12,
    selectInput(inputId = "p_value_var", label = "p-values",
                choices = vars, selected=state_single("p_value_var",vars),multiple = F),
    numericInput(inputId = "p_value_val",label="cutoff",value = 0.05,min = 0.005,max=1,step = 0.01),
    helpText('Select and filter data for enrichment analysis')
  ))
})

#p-value filter for enrichment
output$pval_filter_ui <- renderUI({
  vars<- .getdata_col_meta() %>% colnames() # actually col_meta
  fluidRow(
    column(12,
           tags$table(
             tags$col(width='40%'),
             tags$col(width='60%'),
             tags$td(numericInput(inputId = "pval_var", label = "p-value cutoff",
                                   min=0,max=1, step =.005,value = .05 )),
             tags$td(uiOutput('path_enrich_p_val_ui'))
           ),
           helpText('Filter enrichment results')
    )
  )
})

#checkbox ui
output$path_enrich_p_val_ui<-renderUI({
  fluidRow(
    br(),
    br(),
    column(12,offset=1, checkboxInput(inputId = "fdr_pval_var", label = "FDR adjust",value = TRUE )),
    column(12,offset=1, checkboxInput(inputId = "path_enrich_keep_selected",
                                      label = "Keep selected",value = TRUE ))
  )
})

#used in other p[laces]
outputOptions(output, "kegg_var_ui", suspendWhenHidden = FALSE) #pathwaymap
outputOptions(output, "pval_filter_ui", suspendWhenHidden = FALSE)
outputOptions(output, "path_enrich_p_val_ui", suspendWhenHidden = FALSE)

output$path_enrich_calculate_ui<-renderUI({
  fluidRow(
    column(12,actionButton('path_enrich_calculate',label='Calculate',icon=icon('check')))
  )
})

output$ui_report_top_n_enrichment_filter <- renderUI({
numericInput("report_top_n_enrichment",label = "Show top pathways",
             value = 10,min = 1,step = 1,max = 100,width = "100%")
})

#update report pathway names
report_pathway_names<-reactive({
  names(pathway_values[['images']])
})

output$ui_report_pathway_selection <- renderUI({
  vars<-NULL
  selectizeInput('report_pathway_selection','Show pathways',choices=NULL,multiple=TRUE,
                 options = list(plugins = list('remove_button', 'drag_drop')))


})

outputOptions(output, "ui_report_pathway_selection", suspendWhenHidden = FALSE)

observe({

  vars<- report_pathway_names()
  if(is.null(vars)) return()
  updateSelectInput(session,'report_pathway_selection',choices = vars,selected=vars)
  tippy::tippy_this('report_pathway_selection', "Plot pathways to add to report", placement = "bottom")
})

#create help for report_pathway_selection

#all to save
observe({

  obj<- path_enrich()
  if(is.character(obj)) return()
  obj<-obj$path_enrich
   # browser()

   #get passing pathways and map to names
   tmp<-path_enrich_init()$path_info %>%
     left_join(data.frame(map=obj$map),.) %>%
     .[!duplicated(.$map),,drop=FALSE]


  vars<-tmp$map %>%
    # as.character(.) %>%
    setNames(.,tmp$path)

  updateSelectizeInput(session,'pathway_path_enrich_save',choices = vars,selected=vars[1:5] %>% na.omit())
})


output$path_enrich_save_ui<-renderUI({
  # tags$table(
  #   # tags$td(numericInput("n_path_enrich_save", "top results",min=1,value = 5)),
  #   tags$td(
  #           selectizeInput('pathway_path_enrich_save','pathways',choices=NULL,multiple=TRUE,
  #                          options = list(plugins = list('remove_button', 'drag_drop')))),
  #   tags$td(actionButton("path_enrich_save", "Save"), style="padding-top:30px;")
  # )
  fluidRow(
    column(12,
              selectizeInput('pathway_path_enrich_save','pathways',choices=NULL,multiple=TRUE,
                             options = list(plugins = list('remove_button', 'drag_drop'))),
              actionButton("path_enrich_save", "Save")
    )
  )

})

outputOptions(output, "path_enrich_save_ui", suspendWhenHidden = FALSE)


#full ui adding pathwaymap
output$path_enrich<-renderUI({
  tagList(
    conditionalPanel(condition = "input.tabs_path_enrich == 'Calculate'",
                     uiOutput('path_enrich_calculate_ui'),
                     tags$br(),
                     bs_accordion(id="enrichment_collapse_panel") %>%
                       bs_append(title = tags$label(class='bsCollapsePanel', icon("user-circle-o") , "Kegg Enrichment"),
                                 content = fluidRow(
                                   column(12,uiOutput('kegg_var_ui')),
                                   column(12,uiOutput('p_value_var_ui'))

                                 )
                       ) %>%
                       bs_append(title = tags$label(class='bsCollapsePanel', icon("filter") , "Filters"),
                                 content = fluidRow(
                                 column(12,uiOutput('pval_filter_ui'))
                                 )
                       ) %>%
                       bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                                 content=fluidRow(column(12,uiOutput('path_enrich_save_ui')))
                       )
    ),
    conditionalPanel(condition = "input.tabs_path_enrich == 'Plot'",
                     actionButton("pathwaymap_calculate", "Calculate"),
                     tags$br(),tags$br(),
                     bs_accordion(id="pathway_collapse_panel") %>%
                       bs_append(title = tags$label(class='bsCollapsePanel', icon("eye") , "Pathway visualization"),
                                 content = fluidRow(
                                   column(12,uiOutput("ui_kegg_pathways")),
                                   column(12,uiOutput("ui_FC_col"))
                                   #column(12,uiOutput("ui_pathwaymap_results"))
                                   #column(12,uiOutput("ui_pathwaymap_save"))
                                   )
                       )
    ),
    conditionalPanel(condition = "input.tabs_path_enrich == 'Report'",
                     tagList(
                       tagList(
                         bs_accordion(id="pathway_report_collapse_panel") %>%
                           bs_append(title = tags$label(class='bsCollapsePanel', icon('file-text-o'), "Pathways"),
                                     content = fluidRow(
                                       column(12,
                                            uiOutput("ui_report_top_n_enrichment_filter"),
                                            uiOutput("ui_report_pathway_selection")
                                       )
                                     )
                           )
                       ))
    ),
    fluidRow(
      column(12,align="right",modalModuleUI(id="pathway_help")))
  )
})

#
# #nthis is for the plot download?
# #setup plot
# pathwaymap_plot <- reactive({
#   plh <- 600
#   plw <- 800
#   list(plot_width=plw, plot_height=plh)
# })
#
# pathwaymap_plot_width <- function()
#   pathwaymap_plot() %>% { if (is.list(.)) .$plot_width else 800 }
#
# pathwaymap_plot_height <- function()
#   pathwaymap_plot() %>% { if (is.list(.)) .$plot_height else 600 }

#register for DAVe
output$path_enrich_ui <- renderUI({
  #previous methods
  # register_print_output("summary_path_enrich", ".summary_path_enrich" )
  # register_plot_output("plot_pathwaymap", ".plot_pathwaymap",
  #                      height_fun = "pathwaymap_plot_height", width_fun = "pathwaymap_plot_width")


  # two separate tabs
  path_enrich_output_panels <- tabsetPanel(
    id = "tabs_path_enrich",
    tabPanel("Calculate", icon=icon("sliders"),uiOutput('.summary_path_enrich_ui')),
    tabPanel("Plot",icon = icon("bar-chart"),
             imageOutput("image_pathwaymap",width='120%')),
    tabPanel("Report",icon=icon('file-text-o'),
             reportGeneratorUI('pathway')) #uiOutput('pathway_report_ui')
  )
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('flask'),as.character(" Pathway")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('sort'),as.character(" Enrichment")))),
                 tool_ui = "path_enrich",
                 output_panels = path_enrich_output_panels)
})

path_enrich_available<-reactive({

  if(is.null(input$path_enrich_calculate) || input$path_enrich_calculate ==0) {
    return("Calculate pathway enrichment based on the hypergeometric test.")
  }
  if (is.na(input$path_enrich_calculate)) return()

  "available"

})

path_enrich_init<-eventReactive(input$path_enrich_calculate,{
  #collect arguments
  .data<-.getdata_col_meta()

  pval_var<-input$p_value_var
  pval_val<-input$p_value_val

  #Filter by p_value threshold
  id<-.data[which(.data[pval_var]>=pval_val),input$kegg_var]
  #cat(str(id))
  id<-id[!id==""] %>%
    na.omit(.) %>%
    unlist() %>%
    as.character()

  if(!exists('path_info')){data(path_info)}
  if(!exists('path_summary')){data(path_summary)}

  return(list(kegg=id,path_info=path_info,path_summary=path_summary))

})

#
#calculate enrichment
path_enrich<-reactive({
  if (path_enrich_available() != "available") return(path_enrich_available())
  # browser()
  tmp<-path_enrich_init()

  paths<- get_cpd_paths(tmp$kegg,tmp$path_info)

  path_data<-get_path_data(paths,tmp$path_summary)

  p.values<-pathway_enrichment(path_data,cpd=length(tmp$kegg)) %>%
    filter_path_enrich(.,fdr=input$fdr_pval_var,limit=input$pval_var)

  # #pretty format p-values
  # p.values$path_enrich<-p.values$path_enrich %>% mutate_at(.,vars(contains('p.value')),funs(signif_format_fun(.)))

  pathway_values[['enrich']]<-p.values

  return(pathway_values[['enrich']])
})

pathway_get_DT_data<-reactive({
  obj<- path_enrich()

  filter_by<-input$p_value_var

  if(obj!="Calculate pathway enrichment based on the hypergeometric test."){

    path_data<-summary(obj)$results
    path_data$p_value<-as.numeric(path_data$p_value) #%>%
      #format(.,scientific=T)# hacky to keep scientific notation ans sorting...
    #need to set in table... to keep numeric

    pathway_values[['top_vars']]<-path_data  #head(arrange(path_data,p_value), n = 10)
    #format for UI output and report
    # options(scipen = -20)
    # browser()
    # options(scipen = -5)
    if(nrow(pathway_values[['top_vars']])>0){
      return(pathway_values[['top_vars']])
    }
    else{
      return()
    }
  }else(
    return()
  )

})

create_enrich_DT<-reactive({
  obj<-pathway_get_DT_data()
  if(is.null(obj)) return(NULL)

  obj<-obj %>% arrange(p_value) %>% data.frame(rank=1:nrow(.),.)
  obj$p_value<-obj$p_value %>% signif_format_fun(.)
  #no way to sort on scientific notation formatted p-values
  #hack rank sort

  datatable(
    obj,rownames = FALSE, filter = 'top', options = list(
      pageLength = 10, autoWidth = TRUE,scrollX = TRUE,fontColor='black')
  ) %>%
    formatStyle(
      'prct',
      background = styleColorBar(obj$prct, 'steelblue'),
      backgroundSize = '100% 90%',
      backgroundRepeat = 'no-repeat',
      backgroundPosition = 'center'
    )
})

#create datatable of results
output$pathway_DT<- DT::renderDataTable(
  create_enrich_DT()
)

.summary_path_enrich<-reactive({
  if (path_enrich_available() != "available") return(path_enrich_available() %>% html_text_format(.))
  summary(path_enrich())$description %>% html_paragraph_format(.) # could cache here for report?
})

output$.summary_path_enrich_ui<-renderUI({

  fluidRow(
    column(12,
      HTML(.summary_path_enrich()),
      DT::dataTableOutput('pathway_DT')
    )
  )

})

#save path info for each cpd
observeEvent(input$path_enrich_save, {

  # browser()
  ## saving to a new dataset if specified
  dataset <- input$dataset
  obj <- path_enrich()

  .names<-list(data=dataset,
               row=paste0(dataset,'_row_meta'),
               col=paste0(dataset,'_col_meta'))

  msg<-'\u2713 Saving...'#tags$label('Saving',icon('check')) %>% as.character() %>% HTML()
  withProgress(message=msg,value=1,{
    Sys.sleep(.1)
    .data<-.getdata()
    .row<-.getdata_row_meta()
    #add pathway infor for top 10 pathways
    maps<-input$pathway_path_enrich_save
    .kegg<-.getdata_col_meta()[,input$kegg_var]

    .info<-cpd_paths_mat(.kegg %>% .[!.==""],path_info,maps )
    names(.info)[1]<-input$kegg_var
    .info<-left_join(.getdata_col_meta(),.info)
    .info[is.na(.info)]<-FALSE
    #needs to be logical

    .col<-merge_df(.getdata_col_meta(),.info)

    #update data and col meta data
    #based on the filter results
    # if (is.null(r_data[[dataset]])) {
    r_data[[.names$data]] <- .data
    r_data[[.names$row]] <- .row
    r_data[[.names$col]] <- .col

    #update avialebale data objects
    #need to split update from create
    .names<-r_data[['datasetlist']] %>% c(unlist(.names),.) %>% unique()
    r_data[['datasetlist']] <-.names
  })
})


