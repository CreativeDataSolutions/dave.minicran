
opts <- list(DAVE_APP = "dave.pathway.app")

dave.app::run_dave_app(opts,app=opts$DAVE_APP)
