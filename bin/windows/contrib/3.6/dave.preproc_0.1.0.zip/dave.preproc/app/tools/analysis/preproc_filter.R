#preproc_filter
## choice lists for compare means
preproc_filter_plots <- c("overview" = "overview", "missing"= "missing","summary" = "summary")

# main fun preproc_filter
## list of function arguments
preproc_filter_args <- as.list(formals(init_data))

## list of function inputs selected by user
preproc_filter_inputs <- reactive({
  ## loop needed because reactive values don't allow single bracket indexing
  # preproc_filter_args$arg<-input$something
  # preproc_filter_args$

  for (i in r_drop(names(preproc_filter_args)))
    preproc_filter_args[[i]] <- input[[paste0("preproc_filter_",i)]]
  preproc_filter_args
})


preproc_filter_values<-reactiveValues()


###############################
# filter merged data
###############################
output$ui_preproc_filter <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel(condition = "input.tabs_preproc_filter  == 'Calculate'",
      tagList(
       fluidRow(column(12,
        actionButton("preproc_filter_calculate", "Calculate",icon=icon('check')))),
      br(),
      bs_accordion(id="preproc_filter_collapse_panel") %>%
        bs_append(title = tags$label(class='bsCollapsePanel', icon("filter") , "Filter"),
                  content =
                    fluidRow(column(12,
                          uiOutput('preproc_filter_UI')
                      )
                    )) %>%
        bs_append(title = tags$label(class='bsCollapsePanel', icon("dot-circle") , "Impute"),
                  content =
                    fluidRow(column(12,
                                    uiOutput('impute_UI')
                    )
                    )) %>%
        bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                  content =
                    fluidRow(column(12,
                                    uiOutput('preproc_filter_store')
                    )
                    )
        )
      )
    ),
    conditionalPanel(condition = "input.tabs_preproc_filter  == 'Plot'| input.tabs_preproc_filter  == 'Explore'",
                     tagList(
                       bs_accordion(id="preproc_filter_plot_collapse_panel") %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("bar-chart") , "Plot"),
                                   content = fluidRow(column(12,
                                                             tagList(
                                                               selectizeInput(inputId = "preproc_filter_plots", label = "Plot type",
                                                                              choices = preproc_filter_plots,
                                                                              selected = state_multiple("preproc_filter_plots", preproc_filter_plots, "summary"),
                                                                              multiple = FALSE,
                                                                              options = list(plugins = list('remove_button', 'drag_drop'))),
                                                               conditionalPanel("input.preproc_filter_plots == 'missing'",
                                                                                checkboxInput('preproc_filter_par_coords',label = 'sample trends',value=TRUE)
                                                               )
                                                             )
                                   )
                                   ))
                     )
    ),
    tags$style(".modal-lg{
            width: 1100px !important;
          }"),
    fluidRow(
      column(12,align="right",modalModuleUI(id="preproc_filter_help")))
    )
})


#impute missing values UI
#TODO move this to its own menue later
output$impute_UI<-renderUI({
  fluidRow(column(12,
    selectInput('impute_type','method',c('none','value','min','max','mean','median'),selected='none'),
    conditionalPanel(condition = "input.impute_type  == 'value'",
                     numericInput('impute_type_value','value',value =0)
    ),
    conditionalPanel(condition = "input.impute_type !='none' && input.impute_type != 'value'",
                     numericInput('impute_type_scalar','scalar',value=1)
    )
    )
  )
})

preproc_impute_data<-reactive({

  data<-preproc_filter_init()$data
  if(is.null(input$impute_type) || input$impute_type == 'none') return(data)

  if(input$impute_type == 'value'){
    data[is.na(data)]<-input$impute_type_value
    return(data)
  }

  tryCatch(impute_missing(data,input$impute_type,input$impute_type_scalar),error=function(e){NULL})


})


#initialize data
preproc_filter_init<-reactive({

  #control recalculate after save
  # isolate({
    .data<-r_data[[input$dataset]]

    out<-list(data=.data,
         row_meta=.getdata_row_meta(),
         col_meta=.getdata_col_meta())
    class(out)<-'data_cube'
    out

  # })

})


#group factor
output$ui_preproc_filter_row_factor <- renderUI({
  #req(input$dataset)

  #if meta data exists use this
  # vars<- colnames(r_data[[input$dataset]])
  #browser()
  vars<-.getdata_row_meta() %>% colnames() %>%
    c('none',.)

  selectizeInput(inputId = "preproc_row_filter_factor",
              label = "Group",
              choices = vars,
              selected = state_single("preproc_row_factor",vars),
              multiple = FALSE,
              options = list(plugins = list('remove_button')))
})


preproc_filter_available <- reactive({

  if( is.null(input$preproc_filter_calculate) || input$preproc_filter_calculate ==0) {
    return("This analysis is used to filter variables based on missing values.")
  }

  if(is.null(preproc_filter_init())){
    return('This analysis requires merged data,\n which is calculated in Prepare >> Merge.')
  }

  # if(is.null(preproc_filter_data())){
  #   return('Calculate missing values before filtering.')
  # }

  # browser()
  "available"
})


#filter data
#calculates the number of missing values
#optionally per group
preproc_filter_data<-reactive({

  #create stored list of var name/types to handle
  row_meta<-.getdata_row_meta()
  if(input$preproc_row_filter_factor %in% c('none','')){
    group<-NULL
    data<-preproc_filter_init()$data
  } else {
    .group<-row_meta[,input$preproc_row_filter_factor,drop=FALSE]
    group<-input$preproc_row_filter_factor
    data<-data.frame(preproc_filter_init()$data,.group)
  }
  #remove too many w/ missing
  filter_missing(data,group=group)





})


#main fun
#shared in filter
.preproc_filter <- reactive({

  check<-preproc_filter_available()
  validate(need(check == 'available', check))

  isolate({
    obj<-preproc_filter_init() #needs to be cer object to update meta data
    filt<-tryCatch(preproc_filter_data(), error=function(e){NULL})
    # browser()
    validate(need(!is.null(filt) == TRUE, 'The data could not be filtered'))

    id<-filt$percent$full<=input$preproc_filter_missing*100

    #remove zero variance variables
    # browser()
    if(!is.null(input$preproc_filter_zero_sd)){
     .id<-apply(obj$data,2,sd, na.rm=TRUE ) !=0
     id<-id & .id
    }
    # browser()
    #impute all
    imputed<-preproc_impute_data()
    validate(need(!is.null(imputed) == TRUE, 'The data could not be imputed'))
    #keep remove original w/ too many missing
    obj$data<-imputed
    tmp<-tryCatch(col_filt_obj(obj,id), error=function(e){NULL})
    # browser()
    validate(need(!is.null(tmp) == TRUE, 'The data could not be filtered'))

    preproc_filter_values[['preproc_filter']]<-list(filter=filt,data=tmp,starting_data=obj,thresh=input$preproc_filter_missing*100)

    return(list(data=tmp,starting_data=obj))
  })
})

.summary_preproc_filter <-reactive({
  if (preproc_filter_available() != "available") {
    preproc_filter_values[['summary']]<-html_text_format(preproc_filter_available())
    return(preproc_filter_values[['summary']])
  }

  isolate({
    msg<-'\u2713 Calculating...'
    withProgress(message=msg,value=1,{
      Sys.sleep(.1)

      #TODO... fix
      main<-.preproc_filter()$data #need this to trigger calculation?

      x<-summary(preproc_filter_data(),thresh=input$preproc_filter_missing*100)$description
      #add impute message
      if(!is.null(input$impute_type)){
        x<-paste0(x,' ', summary_impute_missing(input$impute_type,value=input$impute_type_value,input$impute_type_scalar))
      }

      # browser()
      preproc_filter_values[['summary']]<-x %>%
        html_paragraph_format(.)
      return(preproc_filter_values[['summary']])

    })
  })
})

output$summary_preproc_filter_ui<-renderUI({
  .summary_preproc_filter() %>% HTML()
})

.plot_preproc_filter <- reactive({

  #strange plotting problems

  if (preproc_filter_available() != "available") return(preproc_filter_available())
  if(!input$tabs_preproc_filter == "Explore" & !input$tabs_preproc_filter == "Plot") return() # need plot button else will trigger plot on tab change (should cache image)
  .plotly<-FALSE
  if(input$tabs_preproc_filter == "Explore"){ .plotly<- TRUE}


  type<-input$preproc_filter_plots
  # browser()
  #need to better bundle plot arguments


  # #allow if a data cube
  # #problem needsa
  # obj<-.preproc()
  # # if(!'data_cube' %in% +class(obj)) return(preproc_available())
  #
  # p<-plot(obj,type=type)


  if(type == 'overview'){
    # browser()
    # p<-plot(.preproc_filter()$starting_data,.print=.plotly)
    obj<-.preproc_filter()$starting_data # how to select for which class to plot

  }

  if(type == 'missing'){
    # browser()
    # p<-plot(.preproc_filter()$starting_data,.print=.plotly)
    obj<-.preproc_filter()$data # how to select for which class to plot

  }

  if(type == 'summary'){
    # p<-plot(preproc_filter_data(),thresh=input$preproc_filter_missing*100,.print=.plotly)
    obj<-preproc_filter_data()
  }

  plot_args<-list(obj=obj,
                  thresh=input$preproc_filter_missing*100,
                  type=type,
                  par_coords=input$preproc_filter_par_coords,
                  .print=.plotly)

  p<-do.call('plot',plot_args)

  if(.plotly) return(p) else print(p)

})

#plotly
output$plotly_preproc_filter <- renderPlotly({
  #browser()

  validate(need( preproc_filter_available() == "available", preproc_filter_available()))
  msg<-'\u2713 Plotting...'#tags$label('Saving',icon('check')) %>% as.character() %>% HTML()
  withProgress(message=msg,value=1,{
    obj<-.plot_preproc_filter()
    #browser()
    validate(need(!is.null(obj)==TRUE && is.character(obj) != TRUE,'Not available'))
    ggplotly(obj)
  })
})

#generics
preproc_filter_plot <- reactive({
  list(plot_width = 650, plot_height = 400 * length(input$preproc_filter_plots))
})

preproc_filter_plot_width <- function()
  preproc_filter_plot() %>% { if (is.list(.)) .$plot_width else 650 }

preproc_filter_plot_height <- function()
  preproc_filter_plot() %>% { if (is.list(.)) .$plot_height else 400 }

# output is called from the main dave ui.R
output$preproc_filter <- renderUI({

  register_print_output("summary_preproc_filter", ".summary_preproc_filter" )
  register_plot_output("plot_preproc_filter", ".plot_preproc_filter",
                       height_fun = "preproc_filter_plot_height")

  # two separate tabs
  preproc_filter_output_panels <- tabsetPanel(
    id = "tabs_preproc_filter",
    # tabPanel("Calculate", verbatimTextOutput("summary_preproc_filter"),icon = icon("sliders")),
    tabPanel("Calculate", uiOutput("summary_preproc_filter_ui"),icon = icon("sliders")),
    tabPanel("Explore",icon=icon('pencil-square-o'),plotlyOutput("plotly_preproc_filter", height = "100%")),
    tabPanel("Plot",icon = icon("bar-chart"),
             plot_downloader("preproc_filter", height = preproc_filter_plot_height()),
             plotOutput("plot_preproc_filter", height = "100%")),
    tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('preproc_filter'))
  )

  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('scissors'),as.character(" Preprocess")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('filter'),as.character(" Missing")))),
                 tool_ui = "ui_preproc_filter",
                 output_panels = preproc_filter_output_panels)
})



#ui for missing data filter
output$preproc_filter_UI<-renderUI({
  tagList(
    uiOutput('ui_preproc_filter_row_factor'),
    numericInput('preproc_filter_missing',label = 'missing cutoff', min=0,max=1,value=.5,step=0.05),
    helpText('Filter variables based on percent missing or zero values per group.'),
    checkboxInput('preproc_filter_zero_sd','remove zero variance',value=TRUE)
  )
})

#problems with panels not opening
outputOptions(output, "preproc_filter_UI", suspendWhenHidden = FALSE)

#ui for store data filter
output$preproc_filter_store<-renderUI({
  preproc_dataset <-input$dataset
  tags$table(
    tags$td(textInput("preproc_dataset", "Save as", preproc_dataset)),
    tags$td(actionButton("preproc_store", "Save"), style="padding-top:30px;")
  )
})

observeEvent(input$preproc_store, {

  #TODO fix update... losing data when it changes dims
  ## not sure if want to save as a new object?
  dataset <- input$preproc_dataset

  obj<-.preproc_filter()$data #
  .data<-obj$data
  .row_meta<-obj$row_meta
  .col_meta<-obj$col_meta
  #cer_names
  .names<-list(data=input$preproc_dataset,
            row=paste0(input$preproc_dataset,'_row_meta'),
            col=paste0(input$preproc_dataset,'_col_meta'))

  #update data and col meta data
  #based on the filter results
  # if (is.null(r_data[[dataset]])) {
    r_data[[.names$data]] <- .data
    r_data[[.names$row]] <- .row_meta
    r_data[[.names$col]] <- .col_meta
    #inherit description, for now not used
    # r_data[[paste0(dataset,"_descr")]] <- r_data[[paste0(input$dataset,"_descr")]]
    r_data[['datasetlist']] %<>% c(unlist(.names),.) %>% unique

    msg<-'\u2713 Saving...'
    withProgress(message=msg,value=1,{
      updateSelectInput(session = session, inputId = "dataset", selected = .names$data)
      Sys.sleep(.1)
    })

  # }
  #not sure need to update now?
  #maybe give message of sucess
  #updateSelectInput(session = session, inputId = "preproc_data_list", selected = NULL)
})


