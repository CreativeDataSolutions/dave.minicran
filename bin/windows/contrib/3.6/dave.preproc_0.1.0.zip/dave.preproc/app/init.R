r_url_list <- getOption("dave.url.list")
#TODO:? add entry for filter
r_url_list[["preproc"]] <-
  list("tabs_preproc" = list("Summary" = "preproc/preproc/", "Plot" = "preproc/preproc/plot/"))
r_url_list[["preproc_filter"]] <-
  list("tabs_preproc_filter" = list("Summary" = "preproc/preproc_filter/", "Plot" = "preproc/preproc_filter/plot/"))
options(dave.url.list = r_url_list); rm(r_url_list)


options(preproc_ui =
    tagList(
        navbarMenu(title="Preprocess",icon=icon('scissors'),
           tabPanel("Merge", uiOutput("preproc"),icon=icon('tasks')),
           tabPanel("Missing", uiOutput("preproc_filter"),icon=icon('filter')),
           tabPanel("Normalize", icon= icon('star'),
                    make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE))
          )
    )
)
