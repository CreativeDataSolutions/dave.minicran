shinyServer(function(input, output, session) {
  
  
  source(system.file(package='dave.app','app/src/local/server.R'),local = TRUE)
  
  
})