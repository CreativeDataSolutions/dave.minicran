# report ------------------------------------------------------------------
dave_vis_report_params <- reactive({
  list(plot = get_dave_vis_module_output())
})



dave_vis_report_obj<-function(){
  
  .package<-'dave.vis'
  report_name<-'dave_vis_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path=getOption("dave.report.rmd.path")
  html_save_path= getOption('dave.report.html.path')
  
  .report_obj<-get_report_obj(.package = .package,
                              report_name= report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)
  
  return(.report_obj)
  
}




#report with explicit meomization
name <- 'dave_vis'
# 
# dave_vis_report<-callModule(reportGenerator, name,
#                             report_params = dave_vis_report_params,
#                             report_obj= dave_vis_report_obj(),
#                             .available = dave_vis_available)

# with memozation - entering 3 times :(
# ----
dave_vis_report_hash<-reactiveValues(hash='')

observe({


  input$tabs_dave_vis
  isolate({

    if(is.null(input$tabs_dave_vis)) return()
    if(!input$tabs_dave_vis %in% c('Report')) return()

  })

  .obj<-tryCatch(dave_vis_report_params(), error = function(e){})
  if(is.null(.obj)) return() # exit if entering here too early


  is_changed<-has_changed(.obj, dave_vis_report_hash[['hash']])


  if(is_changed$changed){
    dave_vis_report_hash[['hash']]<-is_changed$hash
  } else {
    return()
  }


dave_vis_report<-callModule(reportGenerator, name,
                          report_params = dave_vis_report_params,
                          report_obj= dave_vis_report_obj(),
                          .available = dave_vis_available)

})
