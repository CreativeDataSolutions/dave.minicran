
# source(system.file(package='dave.app','app/src/local/global.R'),local = TRUE)

source(system.file(package='dave.app','app/global.R'),local = TRUE)


