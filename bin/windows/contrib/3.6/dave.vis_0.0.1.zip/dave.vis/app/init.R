
options(dave_vis_ui =
  tagList(
    navbarMenu("Plot", icon=icon('braille'), #'eye'
               shinyjs::useShinyjs(),
               tabPanel("Explore", uiOutput("dave_vis_ui"),icon=icon('eye'))
    )
  )
)
