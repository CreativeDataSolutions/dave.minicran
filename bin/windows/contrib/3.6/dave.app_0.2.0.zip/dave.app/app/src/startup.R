#loaded in app/global.R

# user settings -----------------------------------------------------------

normalize_path<-function(x){paste0(x,'/')}


#working directory
user_folder<-getOption('USER_DATA') # e.g. '/app/'
user<-getOption('USERNAME')
user_path<-getOption('USER_PATH')

#USER specific controls
#---------------------
if(user_folder == '') user_folder <-'.'
user<-normalize_path(paste0(c(user_path,user_folder,user),collapse='/'))


shared_folder<-user# shared folder contains global data among users, not relevant for local deployment


#testing lack of trailing slash
f<-function(user,path){
  paste0(normalizePath(paste(user,path,sep='/')),"/")
}


#save user environment
options(dave.user.session = f(user,'session'))

#report paths
options(dave.report.save.path = f(user,'report/saved')) #full saved reports
options(dave.report.rmd.path = f(user,'report')) # templates from packages will be saved here
options(dave.report.html.path = f(user,'report/partial')) #user created partial-reports

#pathway analysis
options(dave.path_save_dir = normalizePath(paste(user,"pathview/user",sep='/')))


#create user folders based on options
#------------------------------------
folders<-c(getOption('dave.user.session'),
           getOption('dave.report.save.path'),
           getOption('dave.report.rmd.path'),
           getOption('dave.report.html.path'),
           getOption('dave.path_save_dir'))


#create folders if absent
check_user_folders(folders)
