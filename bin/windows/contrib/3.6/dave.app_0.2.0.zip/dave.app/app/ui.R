

message('Loading app UI')


# #resource added in global.R
# dave_icon <-  'dave_img/icon.png'
#
#
# options(dave.path.css = system.file('app/www/css/styles.css', package = 'dave.app'))


make_dave_ui()
