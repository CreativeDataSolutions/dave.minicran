

model_help_lookup <-
  list(
    url = 'https://creativedatasolutions.github.io/dave.docs/partial/model.html',
    model = list(
      Calculate = 'calculate',
      Plot = 'plot-and-explore',
      Explore = 'plot-and-explore',
      Report = 'model'
    ),
    rfe = list(
      Calculate = 'calculate-1',
      Plot = 'plot-and-explore-1',
      Explore = 'plot-and-explore-1',
      Report = 'feature-selection'
    )
  )

map_model_model_help <-
  function(tab = input$tabs_ml,
           id = 'model',
           lookup = model_help_lookup,
           url = model_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }

map_model_rfe_help <-
  function(tab = input$tabs_rfe,
           id = 'rfe',
           lookup = model_help_lookup,
           url = model_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }


#help for tabs
callModule(modalModule,id='ml_help',content=map_model_model_help)
callModule(modalModule,id='rfe_help',content=map_model_rfe_help)

#help model methods
model_method_help<-reactive({#function(){#

  fun<-input$model_type[1]
  if(is.null(fun)) return(HTML('Select modeling method to view info'))

  #use library
  lib<-getModelInfo(fun,regex=FALSE)[[1]]$library

  body<-list(fun = fun,lib=lib)
  res<-tryCatch(ocpu_get_help_html(dave_ml_connection,body),error=function(e){NULL})$results

  if(is.null(res)){
    body<-list(fun=lib,lib=lib)
    res<-tryCatch(ocpu_get_help_html(dave_ml_connection,body),error=function(e){NULL})$results

  }

  if(is.null(res)){
    res<-'Description not found. The model is not available.'
  }

  return(res %>% HTML())
})

callModule(modalModule,id='ml_method_help',content=model_method_help)
