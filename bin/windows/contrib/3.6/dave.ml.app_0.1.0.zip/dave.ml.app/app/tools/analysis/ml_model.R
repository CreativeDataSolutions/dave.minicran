
#select can be over written...
slice<-dplyr::slice # overwritten by xgboost

#Initiate reactiveValue for dave_ml
dave_ml_values<-reactiveValues()

# main fun ml
## list of function arguments
ml_args <- as.list(formals(init_data))

## list of function inputs selected by user
ml_inputs <- reactive({

  for (i in r_drop(names(ml_args)))
    ml_args[[i]] <- input[[paste0("ml_",i)]]
  ml_args
})

###############################
# Left menu

# #handled by cache models checkbox
# output$clear_ml_model_cache_ui<-renderUI({
#
#   tagList(
#     actionButton("clear_ml_model_cache", "Delete model", icon = icon('close')),
#     tippy::tippy_this('clear_ml_model_cache', 'Reset all models',placement = "right")
#   )
# })
#
#
#
# observeEvent(input$clear_ml_model_cache_ui,{
#   dave_ml_values<-reactiveValues()
# },ignoreInit = TRUE)

#module
#create model data based on combining x and y
.get_model_data<-reactive({
  if (is.null(input$dataset)) return()
  if (is.null(input$ml_dependent_var)) return()
  if (is.null(input$ml_dependent_var_type)) return()

  # can trigger when in another tab an error
  #TODO need to block error for bad data

  .data<-r_data[[input$dataset]]

  #upstream does not block error here
  .y<-get_model_data_by_type()$y_data %>% dplyr::select(one_of(input$ml_dependent_var))



  return(list(data=data.frame(.data),y=data.frame(.y),full=data.frame(.y,.data)))

})

#costly copying so many data versions...
#complicated if a number with few categories could be a factor?
#complicated diffrentiate data from data meta merge (later does not work well w/ col meta data yet)
#cant react here because setting init?
get_model_data_by_type<-reactive({

  if(is.null(input$ml_dependent_var_type)) return(NULL)
  limit_numeric<-FALSE
  if(input$ml_dependent_var_type == 'regression'){
    data<-cbind( .getdata_row_meta(),r_data[[input$dataset]])
    limit_numeric<-TRUE
  } else {
    data<- .getdata_row_meta()
  }

  validate(need(!is.null(data),'The data is not ready for modeling; preprocess it first.'))

  vars<- data %>% colnames()
  .class<-sapply(data,class)
  names(vars) <- paste0(vars," (",.class,")")

  if(limit_numeric){
    keep<-.class %in% c("numeric","integer")
    data<-data[,keep,drop=FALSE]
    vars<-vars[keep]
  }


  list(names=vars,y_data=data)
})

#module
#Choose dependent varaible
output$ui_ml_dependent_select <- renderUI({
  if (is.null(input$dataset)) return()
  # dat <- r_data[[input$ml_measured_data]]
  # vars<- as.list(colnames(dat))
  #this is for
  vars<- get_model_data_by_type()$names


  fluidRow(
    column(12,
          selectInput(inputId = "ml_dependent_var",
          label = "",
          choices = vars,
          selected = state_single("ml_dependent_var",vars),
          multiple = FALSE)
    )
  )
})

#separating update linkage hell
output$ml_dependent_var_type_ui<-renderUI({
  radioButtons('ml_dependent_var_type','Select variable to predict',choices = c('classification','regression'),inline = TRUE)
})

output$ui_ml_dependent_var <- renderUI({
  fluidRow(
    column(12,
         uiOutput('ml_dependent_var_type_ui'),
         uiOutput('ui_ml_dependent_select')
    )
  )

})

#allow classification or regression
observeEvent(input$ml_dependent_var_type,ignoreNULL = TRUE,{

    vars<-get_model_data_by_type()$names

    if(is.null(vars)) return()

    #sho
    updateSelectInput(session= session,'ml_dependent_var',choices=vars,selected='Random Forest')

})

#module
#Choose independent varaibles #select all by default
output$ui_independent_var <- renderUI({

  vars<-create_independent_var()
  select_vars<-get_ml_independent_select_vars()

  if(is.null(vars)) vars<-''
  #this should be based on logical or custom input
  fluidRow(column(12,
    selectInput(inputId = "ml_independent_vars",
                label = "Select X variables ",
                choices = vars,
                selected = vars,
                selectize = FALSE,
                multiple = TRUE,size = 5)
  ))
})

# #custom or logical variables
# output$independent_var_choose_ui<-renderUI({
#   radioButtons('independent_var_type',choices = c('custom','selected'),selected= 'custom' ,inline = TRUE)
# })

output$ml_independent_select_vars_ui<-renderUI({

  vars<-get_ml_independent_select_vars()

  fluidRow(column(12,
    radioButtons('independent_var_type','Filter:',choices = c('custom','selected'),selected= 'custom' ,inline = TRUE),
    conditionalPanel(condition = 'input.independent_var_type == "selected"',
              selectInput(inputId = "ml_independent_select_vars",
                label = "Filter variables",
                choices = vars,
                selectize = TRUE,
                multiple = TRUE)
    )
  ))


})

create_independent_var<-reactive({
  if (is.null(input$dataset)) return()

  dat <- .get_model_data()$data

  validate(need(!is.null(dat),'See "preprocess tab" to prepare data for modeling'))
  #Add a validate condition to avoid error message due to late loading
  validate(
    need(nrow(dat)!= 0, "Please select a data set"),
    need(input$ml_dependent_var != "", "Loading X variables..")
  )


  if(is.null(input$independent_var_type)) return()


  selected <- input$ml_dependent_var
  dat <- dat %>% dplyr::select(-one_of(selected))
  vars<- as.list(colnames(dat))
  names(vars) <- paste0(colnames(dat)," (",sapply(dat,class),")")


  return(vars)
})

#logical col meta data
get_ml_independent_select_vars<-reactive({
  if (is.null(input$dataset)) return()

  vars<- .getdata_col_meta()

  #allow logicals
  allowed<-sapply(vars,is.logical)
  out<-colnames(vars)[allowed]
  # if(length(out) ==0)
  # validate(need(length(out) != 0,'No filter variables available'))
  return(out)

})

#select x variables based on filter var
observeEvent(input$ml_independent_select_vars,{


  if (is.null(input$ml_independent_select_vars)) return()

  #get variable from the col meta and identify selected variables
  #then update input$ml_independent_vars
  id<-.getdata_col_meta() %>%
    select(input$ml_independent_select_vars) %>%
    mutate(selected=apply(.,1,any)) # allow multiple columns

  opts<-create_independent_var()[id$selected]

  updateSelectInput(session= session,'ml_independent_vars',choices=opts,selected = opts)


})


#Model type
#will need to observe the dependent variable
output$ui_model_type <- renderUI({
  if (is.null(input$dataset)) return()

  dependent.var <- .get_model_data()$y
  if(is.null(dependent.var)) return()

  #if(class(dependent.var[,1]) %in% c("numeric","integer")){
  if(input$ml_dependent_var_type == 'regression'){
    .models<-get_models_by_y_type("Regression")
  }else{
    .models<-get_models_by_y_type("Classification")
  }
  fluidRow(
    column(12,
     tags$table(
       tags$td(width="90%",
        selectInput(inputId = "model_type",
                    label = "Select Algorithm",
                    choices = .models,
                    selected = "rf",
                    multiple = TRUE
        )),
     tags$td(width="10%",
      fluidRow(
        column(12,align="right",
          br(),
          modalModuleUI(id="ml_method_help")

          #actionButton('help_model_btn','',icon=icon('question-circle'))
        )
      )
    ))
    )
  )
})

output$ui_model_param <- renderUI({
  if (is.null(input$dataset)) return()
  if (is.null(input$model_type)) return()

  model <- input$model_type
  if(is.null(model)) return()

  model_params <- getModelInfo(model)[[model]]$parameters
  if(nrow(model_params > 0)){
    wellPanel(
      lapply(1:nrow(model_params), function(i) {
        if(model_params[i,2]=="numeric"){
          numericInput(inputId = as.character(model_params[i,1]),
                       label=paste0(as.character(model_params[i,3])," (",as.character(model_params[i,1]),")"),
                       value=5,step = 1)
        }else if(model_params[i,2]=="logical"){
          checkboxInput(inputId = as.character(model_params[i,1]),
                        label=paste0(as.character(model_params[i,3])," (",as.character(model_params[i,1]),")"),
                        value = FALSE)
        }else{
          textInput(inputId = as.character(model_params[i,1]),
                    label=paste0(as.character(model_params[i,3])," (",as.character(model_params[i,1]),")"),
                    "")
        }
      })
    )
  }
})

#Train test percentage
output$ui_ml_train_percent <- renderUI({
  if (is.null(input$dataset)) return()
  sliderInput(inputId = "ml_train_percent",
              label = "Set Train:Test ratio",
              min = 0.1, max = 0.99, step = 0.05,
              value = 0.7)
})

#Set seed
output$ui_ml_set_seed <- renderUI({
  if (is.null(input$dataset)) return()
  numericInput(inputId = "ml_set_seed",
               label = "Random seed",
               value = 1234,step = 1)
})


#Tune length
output$ui_ml_tune_length <- renderUI({
  if (is.null(input$dataset)) return()
  numericInput(inputId = "ml_tune_length",
               label = "grid size",
               value = 1)
})

#Model metric
output$ui_model_metric <- renderUI({
  if (is.null(input$dataset)) return()
  dependent.var <- .get_model_data()$y #
  if(is.null(dependent.var)) return()

  if(input$ml_dependent_var_type == 'regression'){
  #if(class(dependent.var[,1]) %in% c("numeric","integer")){ #TODO eventually deal with multiple Y
    options = c("RMSE","Rsquared")
  }else{
    options = c('Accuracy','Kappa', 'ROC','Sensitivity','Specificity')
  }
  selectInput(inputId = "model_metric",
              label = "Select metric",
              choices = options,multiple=F)
})

#select best model
output$ui_model_select_best<-renderUI({
  radioButtons('model_select_best','optimize for',choices = c('train data'='train','test data'='test'),inline = TRUE)
})

#Plot type to render
output$ui_ml_plot_type <- renderUI({
  if (is.null(input$dataset)) return()
  fluidRow(column(12,
    selectInput(inputId = "plot_type", label = "plot type",
                choices = c('performance', 'model','importance','confusion','classification'),
                selected='performance',multiple = F),
    conditionalPanel(condition = 'input.plot_type == "classification"',
                     selectInput(inputId = "classification_curve",
                                 label = "curve type",
                                 choices = c('ROC'='roc',"precision and recall"='pr'),selected = 'pr')
    ),
    conditionalPanel(condition = 'input.plot_type == "confusion"',
                     selectInput(inputId = "confusion_plot_metric",
                                 label = "show metric",
                                 choices = c('count'=FALSE,"percent"=TRUE),selected = TRUE)
    )
  ))
})

#variable names for plotting
#TODO should set this at a high level?
output$ui_ml_variable_names<-renderUI({

  if(is.null(input$plot_type)) return()
  if(!input$plot_type == 'importance') return()
  vars<-.getdata_col_meta() %>% colnames()

  if(is.null(vars)) return()

  selectInput('ml_variable_names','Variable names',choices=vars)

})

output$ui_top_nvars_ml<-renderUI({
  if(is.null(input$plot_type)) return()
  if(!input$plot_type == 'importance') return()
  numericInput('top_nvars_ml','top number',min=1,value=10)
})

#Auto tuning toggle
output$ui_tune_toggle <- renderUI({
  if (is.null(input$dataset)) return()
  radioButtons(inputId = "tune_toggle",
               label = "Cross-validation",
               choices = c("Auto", "Manual"),
               selected = "Auto",inline = TRUE
  )
})

#Model parameter tuning toggle
output$ui_model_param_toggle <- renderUI({
  if (is.null(input$dataset)) return()
  radioButtons(inputId = "model_param_toggle",
               label = "Tune model",
               choices = c("Auto", "Manual"),
               selected = "Auto",inline = TRUE
  )
})

#no manual if multiple models
observeEvent(input$model_type,{
  if(is.null(input$model_type)) return()

  if(length(input$model_type)>1){
    updateRadioButtons(session,'model_param_toggle','',choices='Auto', selected='Auto')
  }

})

#resampling method
output$ui_resampling_method <- renderUI({
  if (is.null(input$dataset)) return()
  selectInput(inputId = "resampling_method",
              label = "Resampling method",
              choices = c("repeatedcv" = "repeatedcv",
                          "cv" = "cv",
                          "adaptive_cv" = "adaptive_cv",
                          "none" = "none"
              ),
              selected = "repeatedcv"
  )
})

#number of resampling iterations
output$ui_resampling_iterations <- renderUI({
  if (is.null(input$dataset)) return()
  numericInput(inputId = "resampling_iterations",
               label = "Number of folds",
               value = 3)
})

#repeats for k fold cross validation
output$ui_cv_repeats <- renderUI({
  if (is.null(input$dataset)) return()
  numericInput(inputId = "cv_repeats",
               label = "Repeat sampling",
               value = 1)
})


#Store data
output$ui_ml_save<-renderUI({
  ml_dataset <- input$dataset

  fluidRow(column(12,
                  # h5("Model"),
                  checkboxInput('cache_models','cache models',value=TRUE),
                  tippy::tippy_this('cache_models', 'Use stored calculations or recalculate models',placement = "right"),
                  selectInput('save_model','Select models',choices=NULL,multiple=TRUE),
                  # checkboxInput('filter_ml_data','keep selected',value=FALSE),
                  # h5('Results'),
                  tags$table(
                    tags$td(textInput("ml_dataset", "Save result in:", ml_dataset)),
                    tags$td(actionButton("ml_save", "Save"), style="padding-top:30px;")
                  )
  ))
})

outputOptions(output, "ui_ml_save", suspendWhenHidden = FALSE)
outputOptions(output, 'ui_ml_variable_names', suspendWhenHidden = FALSE) # used in report


#progress indicator
progress_gif<-system.file('app/www/imgs/loading.gif',package='dave.app')

output$ml_progress_gif<-renderImage({
  list(
    src = progress_gif
  )
},deleteFile=FALSE)

outputOptions(output, 'ml_progress_gif', suspendWhenHidden=FALSE)

#update report model names
report_mod_names<-reactive({
  names(dave_ml_values[['model']][[input$dataset]])
})

#report model selection ui
output$ui_report_model_selection<-renderUI({
  vars<-NULL
  selectInput('report_model','Select models',choices=NULL,multiple=TRUE)
})

# observeEvent(input$ml_calculate,{
observe({
  vars<- report_mod_names()
  if(is.null(vars)) return()
  updateSelectInput(session,'report_model',choices = vars,selected=vars) #
  updateSelectInput(session,'save_model',choices = vars,selected=vars) #
})

###############################
# renderUI output
###############################
output$ml_ui <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel(condition = "input.tabs_ml == 'Calculate'",
                     tagList(
                       fluidRow(
                         column(12,
                                actionButton("ml_calculate", "Calculate",icon=icon('check'))
                         )
                       ),
                       br(),
                       bs_accordion(id="model_collapse_panel") %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("folder-open") , "Data"),
                                   content=
                          fluidRow(column(12,
                                uiOutput("ui_ml_dependent_var"),
                                uiOutput('ml_independent_select_vars_ui'),
                                uiOutput("ui_independent_var")
                                )
                          )
                        ) %>%
                       bs_append(title = tags$label(class='bsCollapsePanel', icon("university") , "Model"),
                                 content=
                                   fluidRow(column(12,
                                     uiOutput("ui_model_type"),
                                     uiOutput("ui_model_param_toggle"),
                                     conditionalPanel(
                                       condition = "input.model_param_toggle == 'Manual'",
                                       uiOutput("ui_model_param")
                                     ),
                                     uiOutput("ui_ml_tune_length"),
                                     uiOutput("ui_model_metric"),
                                     uiOutput('ui_model_select_best')
                                   )
                                  )
                         ) %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("random") , "Train control"),
                                   content=
                                     fluidRow(column(12,
                                       uiOutput("ui_ml_set_seed"),
                                       uiOutput("ui_ml_train_percent"),
                                       uiOutput("ui_tune_toggle"),
                                       conditionalPanel(
                                         condition = "input.tune_toggle == 'Manual'",
                                         uiOutput("ui_resampling_method"),
                                         uiOutput("ui_resampling_iterations"),
                                         uiOutput("ui_cv_repeats")
                                       )
                                      )
                                     )
                         ) %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                                   content=
                                     uiOutput("ui_ml_save")
                         )
    )),
    conditionalPanel(condition = "input.tabs_ml != 'Calculate'",
                     tagList(
                       tagList(
                         bs_accordion(id="model_report_collapse_panel") %>%
                           bs_append(title = tags$label(class='bsCollapsePanel', icon('file-text-o'), "Models"),
                                     content =
                            uiOutput("ui_report_model_selection")
                       )
                     ))
    ),
    conditionalPanel(condition = "input.tabs_ml  == 'Plot'| input.tabs_ml  == 'Explore'",
                     tagList(
                       bs_accordion(id="model_plot_collapse_panel") %>%
                         bs_append(title = tags$label(class='bsCollapsePanel', icon("bar-chart"), "Plot"),
                                   content=
                                     fluidRow(
                                       column(12,
                                        uiOutput("ui_ml_plot_type"),
                                        uiOutput('ui_ml_variable_names'),
                                        uiOutput('ui_top_nvars_ml')
                                       )
                                     )
                       )
                     )
    ),
    fluidRow(
      column(12,align="right",modalModuleUI(id="ml_help")))

  )
})


# #Renders the controls even while the collapse panel is unopened
#TODO: I wonder if this needs to be conditional on the tab to not slow the app?
outputOptions(output, "ui_model_type", suspendWhenHidden = FALSE)
outputOptions(output, "ui_ml_tune_length", suspendWhenHidden = FALSE)
outputOptions(output, "ui_model_metric", suspendWhenHidden = FALSE)
outputOptions(output, "ui_model_param_toggle", suspendWhenHidden = FALSE)
outputOptions(output, "ui_ml_set_seed", suspendWhenHidden = FALSE)
outputOptions(output, "ui_ml_train_percent", suspendWhenHidden = FALSE)
outputOptions(output, "ui_tune_toggle", suspendWhenHidden = FALSE)
outputOptions(output, "ui_report_model_selection", suspendWhenHidden = FALSE)
outputOptions(output, "ui_model_select_best", suspendWhenHidden = FALSE)



#module
#setup plot
ml_plot <- reactive({
  lx <- ifelse (not_available(input$list_of_var) || isTRUE(input$viz_combx), 1, length(input$list_of_var))
  nr <- lx * 2
  if (lx > 1){
    plh <- (600/2) * ceiling(nr / 2)
    plw <- 1200
  }else{
    plh <- 400
    plw <- 600
  }
  list(plot_width = plw, plot_height = plh)
})

#module
ml_plot_width <- function()
  ml_plot() %>% { if (is.list(.)) .$plot_width else 600 }

#module
ml_plot_height <- function()
  ml_plot() %>% { if (is.list(.)) .$plot_height else 400 }

#initialize data######################
ml_init<-reactive({

  msdata <- .get_model_data()$full
  dependent.var <- input$ml_dependent_var
  train.percent <- input$ml_train_percent
  set_seed_val <- input$ml_set_seed
  resampling_method <- input$resampling_method
  resampling_iterations <- input$resampling_iterations
  cv_repeats <- input$cv_repeats
  tune_type <- input$tune_toggle
  metric <- input$model_metric


  #API version
  body <-
    list(
      data = msdata,
      y = dependent.var,
      prop = train.percent,
      seed = set_seed_val
    )

  #may need to memmoise
  #fix ml_method_help
  model_data <- ocpu_create_model_data(dave_ml_connection , body = body)

  #save to use in rfe
  dave_ml_values[['data']][[input$dataset]]<- model_data
  # get_ocpu_obj(ocpu_session(model_data))


  # model_data <- create_model_data(msdata, dependent.var,
  #                                 train.percent, set_seed_val)

  classProbs = TRUE
  if(metric %in% c('RMSE','Rsquared')){ # should not need any more

    # sumFunction = defaultSummary
    classProbs = FALSE
  }else{
    # sumFunction = twoClassSummary
    classProbs = TRUE
  }

  if(tune_type == "Auto"){
    #API version
    body<-list(method="repeatedcv",num=7,rep=3,classProbs=classProbs)
    fitControl <- ocpu_create_fit_control(dave_ml_connection ,body=body)

    # fitControl <- create_fit_control("repeatedcv",7,3,summaryFunction = sumFunction,
    #                                  classProbs = classProbs)
  }else{

    #API version
    body<-list(method=resampling_method,num=resampling_iterations,rep=cv_repeats,classProbs=classProbs)
    fitControl <- ocpu_create_fit_control(dave_ml_connection ,body=body)

    # fitControl <- create_fit_control(resampling_method,resampling_iterations,
    #                                  cv_repeats,summaryFunction = sumFunction,
    #                                  classProbs = classProbs)
  }

  return(list(mdata=model_data, control = fitControl))

})

ml_available <- reactive({
  if(is.null(input$ml_calculate) || input$ml_calculate ==0) {
    return("This analysis is used for predictive modeling of selected variable profiles. Select accordingly and then calculate.")
  }

  if (is.na(input$ml_calculate)) return("Choose a dependent variable.")

  if(is.null(input$model_type)) return('Use Model menue to select an algorithm first.')
  "available"
})

create_tune_grid <- reactive({
  model<-input$model_type
  if(is.null(model)) return()

  model_params <- getModelInfo(model)[[model]]$parameters
  if(nrow(model_params > 0)){
    input_list<-lapply(1:nrow(model_params), function(i) {
      input[[as.character(model_params[i,1])]]
    })
    param_names<-lapply(1:nrow(model_params), function(i) {
      as.character(model_params[i,1])
    })
    names(input_list)<-param_names
    return(expand.grid(input_list))
  }else{
    return(NULL)
  }
})

###############################
# main functions
###############################
.ml <- eventReactive(input$ml_calculate, {
  #do.call(random.forest.list, ml_init())
  method <- input$model_type
  dependent.var <- input$ml_dependent_var
  independent.vars <- input$ml_independent_vars
  tune.length <- input$ml_tune_length
  metric <- input$model_metric
  set.seed.val <- input$ml_set_seed


  if(input$model_param_toggle == 'Manual'){
    tune_grid <- create_tune_grid() # problem if ui is not opened
  }else{
    tune_grid <- NULL
  }

  #TODO add smarter cacheing allowing tune vars to
  #be modified but save/combine results by model type
  if(input$cache_models){
    #check if model already exists
    #should save values across sessions?
    if(!is.null(names( dave_ml_values[['model']][[input$dataset]]))){
      .mnames<-function(data,model){paste(data,model,sep = '_')}
      mnames<-.mnames(input$dataset,input$model_type)
      onames<-.mnames(input$dataset,names( dave_ml_values[['model']][[input$dataset]]))

      check<-mnames[!mnames %in% onames]
      if(length(check)== 0 ) return(dave_ml_values[['model']][[input$dataset]])

      #remove existing models from request
      #method could be out of order w/ data ?
      drop<-mnames[mnames %in% onames] %>%
        strsplit(.,'_') %>%
        lapply(.,function(x){x[length(x)]}) %>% # hopefully model name has no _
        unlist()

      method<-method[!method %in% drop]
    }
  }

  shinyjs::show('ml_progress_gif')
  #API based model calculation
  main_obj<- ml_init() # collect training data and cv method

  # create model
  # # #---------------
  body <-
    list(
      data = main_obj$mdata,
      y = dependent.var,
      vars = independent.vars,
      fitControl = main_obj$control,
      method = method,
      metric = metric,
      tuneN = tune.length,
      tuneGrid = tune_grid,
      seed = set.seed.val
    )


  withProgress(message = "Calculating models...", value = 1, {
    mod<-ocpu_multi_create_predictive_model(dave_ml_connection ,body = body)
  })

  #this fetches the model from tha API
  #ideally we reference the created session and pull dynamically
  #pulling the model now makes it possible to store individual model types in a list
  res<-get_ocpu_obj(ocpu_session(mod),open_cpu_url=dave_ml_connection$url)

  # create dataset if empty; else storage will fail
  if(is.null(dave_ml_values[['model']][[input$dataset]])) {
    dave_ml_values[['model']][[input$dataset]]<-list()
  }

  if('multi_model_list' %in% class(res)) {
    for(i in 1:length(res)){
      dave_ml_values[['model']][[input$dataset]][method[i]]<-res[i]
      # class(dave_ml_values[['model']][[input$dataset]][method[i]])<-'model_list' #strange oop land
    }
    class(dave_ml_values[['model']][[input$dataset]])<-c('multi_model_list','model_list')
  } else {
    dave_ml_values[['model']][[input$dataset]][[method]]<-res
    #class(dave_ml_values[['model']][[input$dataset]][method])<-'model_list' #strange oop land
  }

  #retained for multi
  if(length(dave_ml_values[['model']][[input$dataset]]) == 1){
    class(dave_ml_values[['model']][[input$dataset]])<-c('multi_model_list','model_list') #lost
  }

  shinyjs::hide('ml_progress_gif')
  return(dave_ml_values[['model']][[input$dataset]])
})


.summary_ml <-reactive({
  if (ml_available() != "available") return(ml_available() %>% html_text_format(.) %>% list(description=.))

  #multiple model summary
  tmp<-.ml()

  body<-list(tmp)
  # mod_res<-ocpu_get_model_perf(dave_ml_connection ,body = body) # API call
  mod_res<-get_model_perf(tmp,select_best=input$model_select_best) # select_best='train'

  #show best summary
  list(
    description = paste0(mod_res$description, mod_res$best$description, collapse = ' ') %>% html_paragraph_format(.),
    table = mod_res$results[,-(ncol(mod_res$results)), drop = FALSE],
    best = list(
      description = mod_res$best$description %>% html_paragraph_format(.),
      table = mod_res$best$table
    )
  ) #%>% html_paragraph_format(.)
  # description is last column

})

#create DT for test results
create_summary_ml_DT<-reactive({
  obj<-.summary_ml()

  if(is.null(obj$table)) return(NULL)

  out<-obj$table %>% mutate_if(is.numeric,funs(round(.,3))) %>%
    select(-one_of('maximize'))

  ml_model_perf_table(out,obj$best) %>%
    as.datatable(.,rownames = FALSE, filter = 'top', options = list(
      pageLength = 5, autoWidth = TRUE,scrollX = TRUE,fontColor='black'))


})

#create datatable of results
output$summary_ml_DT<- DT::renderDataTable(
  create_summary_ml_DT()
)


output$.summary_ml_ui<-renderUI({

  fluidRow(
    column(12,
           # textOutput("ml_busy_mssg"), # dynamic out put of console messages
           HTML(.summary_ml()$description ),
           DT::dataTableOutput('summary_ml_DT')
    )
  )

})

.data_plot_ml<-reactive({
  if(is.null(input$plot_type)) return()
  #don't need here? or block if triggered from here?
  validate(
    need(ml_available() == "available", "Create model to view")
  )

  obj<-.ml()
  validate(need(!is.null(obj),'Calculate to view'))

  #this retriggers draw
  id<-names(obj) %in% input$report_model # controls for report only needed for single model plots? e.g. confusion

  validate(need(any(id),'Select model(s) to plot'))


  #if this drops to class?
  out<-obj[id]
  if('list' %in% class(out)) {
    class(out)<-c('multi_model_list','model_list') # need enherits method!
  }

  return(out)

})

get_variable_names<-reactive({

  if(!is.null(input$ml_variable_names)){
    id<-.get_model_data()$data %>% colnames()
    names<-.getdata_col_meta()[,input$ml_variable_names]
    var_names<-data.frame(id,names)
  } else {
    var_names<-NULL
  }
  var_names
})

#TODO add to global plot args
get_nvars<-reactive({

  if(is.null(input$top_nvars_ml)) 10 else input$top_nvars_ml

})

get_ml_plot_args<-reactive({

  #not clear why gate this?
  if(is.null(input$plot_type) || !input$plot_type %in% c('importance','classification','confusion'))  return(dave_ml_values[['args']])


  dave_ml_values[['args']]<-list(var_names=get_variable_names(),
                                 nvar=get_nvars(),
                                 curve=input$classification_curve,
                                 percent=input$confusion_plot_metric,
                                 test=ifelse(input$model_select_best == 'test',TRUE,FALSE))

  return(dave_ml_values[['args']])

})

.plot_ml <- reactive({
  #TODO unify with plotly
  available<-ml_available()
  validate(need(available == "available",available))

  # plot(.data_plot_ml(), type = input$plot_type,var_names=get_variable_names(),nvars=get_nvars())
  p<-tryCatch(do.call('plot',c(list(.data_plot_ml(), type = input$plot_type),get_ml_plot_args())),error=function(e){list(result=NULL,error=as.character(e))})

  msg<-if(!is.null(p$error)){
    if(p$error == "Error in plot.window(...): need finite 'xlim' values\n") 'Loading ...' else p$error
  }
  validate(need(is.null(p$error), msg))
  return(p)

})


#plotly
output$plotly_ml <- renderPlotly({
  available<-ml_available()
  validate(need(available == "available",available))

  # p<-tryCatch(plot(.data_plot_ml(), type = input$plot_type,for_plotly=TRUE,print=FALSE,var_names=get_variable_names()), error=function(e){}) # get infinite lims?

  p<-tryCatch(do.call('plot',c(list(.data_plot_ml(), type = input$plot_type,for_plotly=TRUE,print=FALSE),get_ml_plot_args())),error=function(e){list(result=NULL,error=as.character(e))})

  #if(is.null(p)) return()
  msg<-if(!is.null(p$error)){
    if(p$error == "Error in plot.window(...): need finite 'xlim' values\n") 'Loading ...' else p$error
  }

  validate(need(is.null(p$error), msg))
  ggplotly(p)

})

###############################
# output is called from the main dave ui.R
###############################
output$ml <- renderUI({
  register_print_output("summary_ml", ".summary_ml")
  register_plot_output("plot_ml",
                       ".plot_ml",
                       height_fun = "ml_plot_height",
                       width_fun = "ml_plot_width")

  # two separate tabs
  ml_output_panels <- tabsetPanel(
    id = "tabs_ml",
    tabPanel(
      "Calculate",
      icon = icon("sliders"),
      uiOutput('.summary_ml_ui'),
      shiny::tags$div(hidden(imageOutput('ml_progress_gif', height ="100")),style = "text-align: center;")
    ),
    tabPanel(
      "Explore",
      icon = icon('pencil-square-o'),
      plotlyOutput("plotly_ml", height = "100%")
    ),
    tabPanel(
      "Plot",
      icon = icon("bar-chart"),
      plot_downloader("ml", height = ml_plot_height()),
      plotOutput("plot_ml", height = "100%")
    ),
    tabPanel("Report", icon = icon('file-text-o'),
             reportGeneratorUI('ml'))#

  )
  stat_tab_panel(
    menu = tags$span(class = 'cer_menue', HTML(paste0(
      icon('university'), as.character(" Model")
    ))),
    tool = tags$span(class = 'cer_menue', HTML(paste0(
      icon('mortar-board'), as.character(" Train")
    ))),
    tool_ui = "ml_ui",
    output_panels = ml_output_panels
  )
})



#save
observeEvent(input$ml_save, {

  dataset <- input$dataset

  #main objects
  mod<-dave_ml_values[['model']][[input$dataset]][input$save_model]

  #TODO add joint importance for multiple models

  if(is.null(mod)) return()

  #save and update data cube
  obj<-.getdata_cube()
  .names<-c(list(data=input$ml_dataset),.makedata_cube_names(input$ml_dataset))

  withProgress(message = "Saving...", value = 1, {
    #need to account for variables dropped from X
    full<-data.frame(var=colnames(obj$data))
    for(i in 1:length(mod)){
      .imp<-mod[[i]]$importance$importance
      if(!is.null(.imp)){
        imp_name<-paste0(names(mod)[i],'_importance')
        obj$col_meta[,imp_name]<-left_join(full,data.frame(var=rownames(.imp),.imp))[,-1]
      }
    }

    if(length(mod)>1){
      #get overall importance
      class(mod)<-c('multi_model_list','model_list')
      out<-plot_importance(mod,nvar=nrow(full),noplot=TRUE) %>%
        left_join(full,.,by=c('var'='variable'))
      obj$col_meta$overall_rank<-as.integer(out$median)
      obj$col_meta$overall_importance<-out$importance
    }
  })
  #update data and col meta data
  #based on the filter results
  # if (is.null(r_data[[dataset]])) {
  r_data[[.names$data]] <- obj$data
  r_data[[.names$row]] <- obj$row_meta
  r_data[[.names$col]] <- obj$col_meta
  #inherit description, for now not used
  # r_data[[paste0(dataset,"_descr")]] <- r_data[[paste0(input$dataset,"_descr")]]
  r_data[['datasetlist']] %<>% c(unlist(.names),.) %>% unique

})

