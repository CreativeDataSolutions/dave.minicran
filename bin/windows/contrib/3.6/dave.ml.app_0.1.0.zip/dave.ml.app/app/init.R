r_url_list <- getOption("dave.url.list")


r_url_list[["ml"]] <-  list("tabs_ml" = list("Summary" = "ml/ml/", "Plot" = "ml/ml/plot/", "Interactive" = "ml/ml/interactive/"))
options(dave.url.list = r_url_list); rm(r_url_list)



options(ml_ui =
  tagList(
    navbarMenu("Model",icon=icon('university'),
               shinyjs::useShinyjs(),
               tabPanel("Model", icon=icon('mortar-board'),uiOutput("ml")),
               tabPanel("Select", icon= icon('filter'),uiOutput("rfe")),
               tabPanel("Interpret", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE))
    )
  )
)
