kruskal_params<-reactive({

  # browser()
  list(obj=kruskal_values[['kruskal']],#.kruskal(),
       summary=kruskal_values[['summary']],
       test_obj=kruskal_values[['test_obj']],
       plot_vars=input$ks_plot_var_list,
       top_vars=kruskal_values[['top_vars']],
       #volcanoe args
       labels= kruskal_values[['volcanoe_args']])
})


kruskal_report_obj<-function(){
  .package<-'dave.stat'
  report_name<-'kruskal_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path=getOption("dave.report.rmd.path")
  html_save_path= getOption('dave.report.html.path')

  .report_obj<-get_report_obj(.package = .package,
                              report_name= report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)

  return(.report_obj)
}



name<-'kruskal'

kruskal_report<-callModule(reportGenerator, name,
                      report_params = kruskal_params,
                      report_obj = kruskal_report_obj(),
                      .available = kruskal_available)
