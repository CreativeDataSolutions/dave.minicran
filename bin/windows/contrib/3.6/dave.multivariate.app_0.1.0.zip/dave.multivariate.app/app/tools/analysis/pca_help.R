multivariate_help_lookup <-
  list(
    url = 'https://creativedatasolutions.github.io/dave.docs/partial/multivariate.html',
    multivariate = list(
      Calculate = 'calculate',
      Plot = 'explore-and-plot',
      Explore = 'explore-and-plot',
      Report = 'report'
    )
  )

map_multivariate_help <-
  function(tab = input$tabs_pca,
           id = 'multivariate',
           lookup = multivariate_help_lookup,
           url = multivariate_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }


callModule(modalModule,id='pca_help',content=map_multivariate_help )
