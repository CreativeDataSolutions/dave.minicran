

#worth using this?
get_obj_fun_mextrans <- function(name, rv) {
  obj <- reactiveValuesToList(rv)[[name]]
  list(results = obj$results, summary = obj$summary,input = obj$input)
}



metxtrans_module_values<-reactiveValues()


# calculate ---------------------------------------------------------------

## get global input dataset
metxtrans_dataset<- reactive({
  input$dataset
})


# translation module ------------------------------------------------------
#output :metxtrans_calculate_tab_ui

metxtrans_module_input <- reactive({

  .getdata_cube()$col_meta

})

metxtrans_module_trigger <- reactive({

  input$metxtrans_calculate

})

#call module server function
metxtrans_module_call <-
  dave.network.app:::mod_CTSgetR_trigger_server("translate",
                                       data = metxtrans_module_input,
                                       trigger = metxtrans_module_trigger,
                                       connection = ctsgetr_connection)



output$metxtrans_progress_gif_ui<-renderUI({

  imageOutput('metxtrans_progress_gif',class='hiden_progress')
})

output$metxtrans_progress_gif<-renderImage({
  list(
    src = system.file('app/www/imgs/loading.gif',package='dave.app')
  )
},deleteFile=FALSE)

outputOptions(output, 'metxtrans_progress_gif', suspendWhenHidden=FALSE)




observeEvent(input$metxtrans_calculate, {


    showNotification(paste("fetching translations"),type='message', duration = 2)
    shinyjs::show('metxtrans_progress_gif')
    rv <- metxtrans_module_values
    name <- 'metxtrans_module'
    f <- metxtrans_module_call
    
    .tmp <- f$summary()
    rv[[name]]$summary$method <- .tmp$summary
    rv[[name]]$input <- .tmp$input
    
    tmp <- f$results()
    rv[[name]]$results <- tmp
    rv[[name]]$summary$results <- CTSgetR_summary(obj = tmp)
    
    return(NULL)
})



get_metxtrans_summary_obj<-reactive({
  
  tmp<-get_metxtrans_module_obj()$summary
  
  if(is.null(tmp$results)) return()
  
  paste0(tmp$method,tmp$result,collapse=' ')
  
})

get_metxtrans_module_obj<-reactive({

    rv<-metxtrans_module_values
    req(get_obj_fun_mextrans(name='metxtrans_module',rv=rv))
})



metxtrans_available <- reactive({
  if(is.null(input$metxtrans_calculate) || input$metxtrans_calculate == 0) {
    return('Select options for metabolite identifier translation')

  }

  "available"
})



#calculate tabpanel output
output$.summary_metxtrans_results <- renderUI({

  obj<-tryCatch(metxtrans_available(),error=function(e){})
  if(obj != 'available') {

    return(html_text_format(obj) %>% HTML())
  }


  # validate(need( obj == 'available',obj))
  obj<-get_metxtrans_summary_obj()

  req(obj) #,error=function(e){as.character(e)})

  shinyjs::hide('metxtrans_progress_gif')

  HTML(html_paragraph_format(obj))

})

metxtrans_get_DT_data<-reactive({
  
  obj<-tryCatch(metxtrans_available(),error=function(e){})
  validate(need( obj == 'available',obj))
  obj<-get_metxtrans_module_obj()

  req(obj$results)

})



#needs to b eseparate to show
output$metxtrans_calculating_ui<-renderUI({
  hidden(imageOutput('metxtrans_progress_gif', height ="100"))
})


#summary and table
output$.summary_metxtrans_ui<-renderUI({

  #don't duplicate error messages
  if (metxtrans_available() == "available"){
    table<-DT::dataTableOutput('metxtrans_DT')
  } else{
    table<-NULL
  }

  fluidRow(column(12,
                  # hidden(imageOutput('metxtrans_progress_gif', height ="100")),
                  uiOutput('.summary_metxtrans_results'),
                  br(),
                  table
  ))
})

#create datatable of results
output$metxtrans_DT<- DT::renderDataTable(

  datatable(
    metxtrans_get_DT_data(),rownames = FALSE, filter = 'top', options = list(
      pageLength = 10, autoWidth = TRUE,scrollX = TRUE,fontColor='black')
  )
  # %>% formatStyle(
  #   names(df),
  #   background = styleColorBar(range(df), 'lightblue'),
  #   backgroundSize = '98% 88%',
  #   backgroundRepeat = 'no-repeat',
  #   backgroundPosition = 'center'
  # )
)




#main sidebar ui
output$ui_metxtrans_calculate_sidebar <- renderUI({
  dave.network.app:::mod_CTSgetR_trigger_ui("translate")
})


#compute network
output$ui_metxtrans_calculate <- renderUI({
  fluidRow(
    column(4,#TODO get align to work
           div(actionButton("metxtrans_calculate", "Calculate",icon=icon('check')))),
    column(12,hr())
  )
})



#ui
output$metxtrans_calculate_tab_ui <- renderUI({
  req(input$dataset)
  tagList(
    uiOutput("ui_metxtrans_calculate"),
    bs_accordion(id="metxtrans_collapse_panel") %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("arrows-alt-h") , "Translate"),
                content =
                  fluidRow(column(12,
                    uiOutput("ui_metxtrans_calculate_sidebar")
                    )
                  )
      ) %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                content =
                  fluidRow(column(12,uiOutput("ui_metxtrans_save")))
      )
    )
})



# report ------------------------------------------------------------------
get_metxtrans_report_params<-reactive({

    isolate({
      rv <- metxtrans_module_values
      list(summary = reactiveValuesToList(rv)$metxtrans_module$summary %>%
             html_paragraph_format())
    })

})

#collect report object
metxtrans_report_params<-reactive({

  get_metxtrans_report_params()

})

# # visualization module ------------------------------------------------------------------
#
# metxtrans_plot_controls<-callModule(network_visInput,'metxtrans',data_obj=metxtrans_network_object)
#
# #network plot
# #need to block NULL exec
# metxtrans_plot_obj<-callModule(network_vis_plotInput,'metxtrans',data_obj=metxtrans_plot_controls)



#tab pabnel
output$ui_metxtrans <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel('input.tabs_metxtrans == "Calculate"',
                     uiOutput('metxtrans_calculate_tab_ui')
    ),
    # conditionalPanel('input.tabs_metxtrans == "Visualize"',
    #
    # ),
    conditionalPanel('input.tabs_metxtrans == "Report"'),
    fluidRow(column(
      12, align = "right", modalModuleUI(id = "metxtrans_help")
    ))
  )
})

output$metxtrans <- renderUI({

  # #main panel
  metxtrans_output_panels <- tabsetPanel(
    id = "tabs_metxtrans",
    tabPanel("Calculate", icon = icon("sliders"),
             uiOutput('metxtrans_calculating_ui'),
               uiOutput('.summary_metxtrans_ui')
             ),
    tabPanel("Visualize",icon=icon('eye'), make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE)), #call vis methods
    tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('metxtrans'))# TODO
  )



  #
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('arrows-alt-h'),as.character(" Translation")))),
                 tool_ui = "ui_metxtrans",
                 output_panels = metxtrans_output_panels)
})





# save --------------------------------------------------------------------
#TODO add to object col meta

output$ui_metxtrans_save<-renderUI({
  actionButton("metxtrans_save", "Save")
})

observeEvent(input$metxtrans_save, {
  
  #default to calculate edges
  isolate({
      available <- metxtrans_available()
    validate(need(available == 'available', 'No objects available'))
    
    
    dataset <- input$dataset
    #saved obj names
   
    .name <- .makedata_cube_names(dataset)$col
    
    #add translations to col_meta
    rv <- metxtrans_module_values
    name <- 'metxtrans_module'
    trans <- na.omit(rv[[name]]$results)
    controls <- rv[[name]]$input
    col_meta <- .getdata_cube()$col_meta
    
    showNotification(paste("'\u2713 Saving...'"),
                     type = 'message',
                     duration = 2)
  
    .by <- c('id') %>% setNames(controls['from_obj', drop = TRUE])
    
    save_obj <-
      left_join(col_meta,
                trans[!duplicated(trans$id),],
                by = .by,
                suffix = c('', '_trans'))
    
    
    r_data[[.name]] <- save_obj
  })
  
})



# # debug promises resolution -----------------------------------------------
# 
# # module ------------------------------------------------------------------
# mod_server <- function(id, trigger=NULL) {
#   
#   moduleServer(
#     id,
#     function(input, output, session) {
#       
#       
#       output$sidebar_ui <- renderUI({
#         
#         ns <- session$ns
#         
#         fluidRow(column(
#           12,
#           numericInput(ns('sleep'),'sleep time',1)
#         ))
#         
#       })
#       
#       get_input<-reactive({
#         
#         input$sleep
#         
#       })
#       
#       get_rv<-reactive({
#         
#         #main fun
#         # f<-function(sleep){
#         #   start<-Sys.time()
#         #   Sys.sleep(sleep)
#         #   list(start=start,end=Sys.time(),diff = Sys.time()- start)
#         # }
#         
#         #api call
#         f<-function(){
#           endpoint<-'library/CTSgetR/R/db_stats'
#           url<-paste0('http://localhost:8084/ocpu/',endpoint)
#           body<-list(data=FALSE, db_name='/ctsgetr/inst/ctsgetr.sqlite')
#           
#           post_ocpu(url=url,body=body)
#         }
#         
#         trigger<-trigger()
#         
#         if(is.null(trigger) || trigger == 0) {
#           f<-function(...){
#             'Start sleeping'
#           }
#         }
#         
#         
#         
#         isolate({
#           args <- get_input()
#           
#           
#           # if(is.null(args)) {
#           #   f<-function(...){
#           #     'Start sleeping'
#           #   }
#           # }
#           
#           
#           future({
#             f()
#           })   %...>%
#             (function(e) {
#               e
#             }) %...!%
#             (function(e) {
#               warning(e)
#               return(NULL)
#             })
#           
#         })
#       })
#       
#       return(get_rv)
#       
#     }
#   )
# }
# 
# mod_ui<-function(id) {
#   ns <- NS(id)
#   
#   tagList(uiOutput(ns('sidebar_ui')))
#   
# }
# 
# sleep1 <- mod_server('sleep', trigger= metxtrans_module_trigger)
# # debug promises resolution -----------------------------------------------
# 
# # module ------------------------------------------------------------------
# mod_server <- function(id, trigger=NULL) {
#   
#   moduleServer(
#     id,
#     function(input, output, session) {
#       
#       
#       output$sidebar_ui <- renderUI({
#         
#         ns <- session$ns
#         
#         fluidRow(column(
#           12,
#           numericInput(ns('sleep'),'sleep time',1)
#         ))
#         
#       })
#       
#       get_input<-reactive({
#         
#         input$sleep
#         
#       })
#       
#       get_rv<-reactive({
#         
#         #main fun
#         # f<-function(sleep){
#         #   start<-Sys.time()
#         #   Sys.sleep(sleep)
#         #   list(start=start,end=Sys.time(),diff = Sys.time()- start)
#         # }
#         
#         #api call
#         f<-function(){
#           endpoint<-'library/CTSgetR/R/db_stats'
#           url<-paste0('http://localhost:8084/ocpu/',endpoint)
#           body<-list(data=FALSE, db_name='/ctsgetr/inst/ctsgetr.sqlite')
#           
#           post_ocpu(url=url,body=body)
#         }
#         
#         trigger<-trigger()
#         
#         if(is.null(trigger) || trigger == 0) {
#           f<-function(...){
#             'Start sleeping'
#           }
#         }
#         
#         
#         
#         isolate({
#           args <- get_input()
#           
#           
#           # if(is.null(args)) {
#           #   f<-function(...){
#           #     'Start sleeping'
#           #   }
#           # }
#           
#           
#           future({
#             f()
#           })   %...>%
#             (function(e) {
#               e
#             }) %...!%
#             (function(e) {
#               warning(e)
#               return(NULL)
#             })
#           
#         })
#       })
#       
#       return(get_rv)
#       
#     }
#   )
# }
# 
# mod_ui<-function(id) {
#   ns <- NS(id)
#   
#   tagList(uiOutput(ns('sidebar_ui')))
#   
# }
# 
# sleep1 <- mod_server('sleep', trigger= metxtrans_module_trigger)
