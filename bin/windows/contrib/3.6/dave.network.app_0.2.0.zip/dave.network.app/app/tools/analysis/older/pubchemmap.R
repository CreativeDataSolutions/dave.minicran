# # main fun pubchemmap
# ## list of function arguments
# pubchemmap_args <- as.list(formals(init_data))
# 
# ## list of function inputs selected by user
# pubchemmap_inputs <- reactive({
#   ## loop needed because reactive values don't allow single bracket indexing
#   # pubchemmap_args$arg<-input$something
#   # pubchemmap_args$
#   
#   for (i in r_drop(names(pubchemmap_args)))
#     pubchemmap_args[[i]] <- input[[paste0("pubchemmap_",i)]]
#   pubchemmap_args
# })
# 
# ## get global input dataset
# pubchemmap_datasetlist <- reactive({
#   input$dataset
# })
# 
# ###############################
# # Left menu
# ###############################
# #Structural similarity calculation
# output$ui_struc_cal <- renderUI({
#   vars <- .getdata_col_meta() %>% colnames()
#   
#   selectInput(inputId = "cid_col",
#               label = "Select CID column:",
#               choices = vars,
#               selected = state_single("cid_col",vars), #TODO
#               multiple = FALSE)
# })
# 
# output$ui_struct_net_index <- renderUI({
#   vars <- .getdata_col_meta() %>% colnames()#colnames(r_data[[keggmap_datasetlist()]])
#   selectInput(inputId = "struct_net_index",
#               label = "Network index:",
#               choices = vars,
#               selected = state_single("struct_net_index",vars),
#               multiple = FALSE)
# })
# 
# #compute network
# output$ui_pubchemmap_calculate <- renderUI({
#   actionButton("pubchemmap_calculate", "Calculate")
# })
# #Store data
# output$ui_pubchemmap_save<-renderUI({
#   tags$table(
#     tags$td(textInput("pubchemmap_dataset", "Save result in:", paste0("similarity_network"))),
#     tags$td(actionButton("pubchemmap_save", "Save"), style="padding-top:30px;")
#   )
# })
# 
# ###############################
# # renderUI output
# ###############################
# output$ui_pubchemmap <- renderUI({
#   req(input$dataset)
#   tagList(
#     fluidRow(column(12,
#                     uiOutput("ui_pubchemmap_calculate")
#     )),
#     br(),
#     bs_accordion(id="pubchemmap_collapse_panel") %>%
#       bs_append(title = tags$label(class='bsCollapsePanel', icon("cogs") , "Methods"),
#                 content = 
#                   fluidRow(column(12,
#                     helpText("PubChem CID based chemical similarity"),
#                     uiOutput("ui_struc_cal"),
#                     uiOutput('ui_struct_net_index'),
#                     numericInput("pubchemmap_edge_cutoff", 
#                                  label = "Edge Cut off:", min = 0, max = 1, 
#                                  value = state_init("pubchemmap_edge_cutoff",.7), step = .01)
#                   ))
#       ) %>%
#     bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
#               content =
#                 fluidRow(column(12,
#                   uiOutput("ui_pubchemmap_save")
#                 ))
#       ),
#     fluidRow(
#       column(12,align="right",modalModuleUI(id="chemmap_help")))
#     )
# })
# 
# #setup plot
# pubchemmap_plot <- reactive({
#   plh <- 600
#   plw <- 800
#   list(plot_width=plw, plot_height=plh)
# })
# 
# pubchemmap_plot_width <- function()
#   pubchemmap_plot() %>% { if (is.list(.)) .$plot_width else 800 }
# 
# pubchemmap_plot_height <- function()
#   pubchemmap_plot() %>% { if (is.list(.)) .$plot_height else 600 }
# 
# #initialize data
# pubchemmap_init<-reactive({
#   input_nodes <- .getdata_cube()$col_meta 
#   cid_col <- input$cid_col
#   net_index<-input$struct_net_index
#   type<-'CID'
#   DB<-getOption('dave.network.CID.DB')
#   
#   return(list(data=input_nodes, idcolumn=cid_col,net_index=net_index,type=type,DB=DB))
# })
# 
# pubchemmap_available <- reactive({
#   if(is.null(input$pubchemmap_calculate) || input$pubchemmap_calculate ==0) {
#     return("This analysis is used to link compatible sample and variable meta data. Select accordingly and then calculate.")
#   }
#   if (is.na(input$pubchemmap_calculate))
#     return("Please choose a comparison value")
#   "available"
# })
# 
# ###############################
# # main functions
# ###############################
# .pubchemmap <- reactive({
#   withProgress(message = "Calculating", value = 1, {
#     # do.call(network.structure, pubchemmap_init())
#     #browser()
#     do.call(metabolic_network,pubchemmap_init()) # consitent w/ bio edge
#   })
# })
# 
# #hide plot or use plot to trigger report rebuild?
# 
# .summary_pubchemmap <-reactive({
#   # if (pubchemmap_available() != "available") return(pubchemmap_available())
#   
#   if (pubchemmap_available() != "available") return(pubchemmap_available() %>% html_text_format(.) %>% list(description=.))
# 
#   
#   #TODO gate with main fun: summary.cer_el
#   summary.kegg_obj(type='CID',CID_cutoff = input$pubchemmap_edge_cutoff) %>% 
#     html_paragraph_format(.) %>%
#     list(description=.)
#   # summary(.pubchemmap(), edge_cutoff = input$pubchemmap_edge_cutoff)
# })
# 
# output$.summary_pubchemmap_ui<-renderUI({
#   # 
#   # fluidRow(
#   #   column(12,
#            HTML(.summary_pubchemmap()$description)
#   #   )
#   # )
#   
# })
# 
# .plot_pubchemmap <- reactive({
#   
#   if (pubchemmap_available() != "available") {
#     #block character render
#     msg<-pubchemmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   withProgress(message = "Plotting", value = 1, {
#     plot(.pubchemmap(), edge_cutoff = input$pubchemmap_edge_cutoff, shiny = TRUE)
#   })
# })
# 
# #plotly
# output$plotly_pubchemmap <- renderPlotly({
#   if (pubchemmap_available() != "available") {
#     #block character render
#     msg<-pubchemmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   withProgress(message = "Plotting", value = 1, {
#     plot_g <- plot(.pubchemmap(), edge_cutoff = input$pubchemmap_edge_cutoff,curvature=0)
#     ggplotly(plot_g)
#   })
# })
# #visNetwork
# output$network_pubchemmap <- renderVisNetwork({
#   if (pubchemmap_available() != "available") {
#     #block character render
#     msg<-pubchemmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   withProgress(message = "Plotting", value = 1, {
#     network.visnetwork(.pubchemmap(), edge_cutoff = input$pubchemmap_edge_cutoff)
#   })
# })
# 
# output$pubchemmap_explore_ui<-renderUI({
#   
#   fluidRow(
#     column(12,radioButtons("pubchemmap_explore_plot_type",'', 
#                            c("static" = "static", "dynamic" = "dynamic"), selected = 'static', inline=T)),
#     column(12,
#            conditionalPanel(condition = "input.pubchemmap_explore_plot_type == 'dynamic'", visNetworkOutput("network_pubchemmap")),
#            conditionalPanel(condition = "input.pubchemmap_explore_plot_type == 'static'", plotlyOutput("plotly_pubchemmap"))
#     )
#   )
#   
# })
# 
# ###############################
# # output is called from the main dave ui.R
# ###############################
# output$pubchemmap <- renderUI({
#   register_print_output("summary_pubchemmap", ".summary_pubchemmap" )
#   register_plot_output("plot_pubchemmap", ".plot_pubchemmap",
#                        height_fun = "pubchemmap_plot_height", width_fun = "pubchemmap_plot_width")
#   
#   # two separate tabs
#   pubchemmap_output_panels <- tabsetPanel(
#     id = "tabs_pubchemmap",
#     tabPanel("Calculate", icon = icon("sliders"),uiOutput('.summary_pubchemmap_ui')),
#     tabPanel("Explore",icon=icon('pencil-square-o'),uiOutput('pubchemmap_explore_ui')),
#     tabPanel("Plot",icon = icon("bar-chart"),
#              plotOutput("plot_pubchemmap", height = "100%")),
#     tabPanel("Report", icon=icon('file-text-o'),reportGeneratorUI('pubchem')) # uiOutput('pubchemmap_report_ui')
#   )
#   stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
#                  tool = tags$span(class='cer_menue',HTML(paste0(icon('flask'),as.character(" Structural similarity")))),
#                  tool_ui = "ui_pubchemmap",
#                  output_panels = pubchemmap_output_panels)
# })
# 
# ###############################
# # observeEvent for actionButton
# ###############################
# #report
# observeEvent(input$pubchemmap_report, {
#   figs <- FALSE
#   outputs <- c("summary")
#   inp_out <- list(list(show = input$pubchemmap_show, edge_cutoff=input$pubchemmap_edge_cutoff))
#   if (length(input$pubchemmap_plots) >= 0) {
#     outputs <- c("summary","plot")
#     inp_out[[2]] <- list(plot.setup = pubchemmap_plot(), plot.type="ggplot", edge_cutoff=input$pubchemmap_edge_cutoff)
#     #inp_out[[3]] <- list(path = "", edge_cutoff=input$pubchemmap_edge_cutoff)
#     figs <- TRUE
#   }
#   update_report(inp_main = clean_args(pubchemmap_inputs(), pubchemmap_args),
#                 fun_name = ".pubchemmap",
#                 inp_out = inp_out, outputs = outputs, figs = figs,
#                 fig.width = pubchemmap_plot_width(),
#                 fig.height = pubchemmap_plot_height())
# })
# #save
# observeEvent(input$pubchemmap_save, {
#   
#   ## saving to a new dataset if specified
#   withProgress(message = "Saving", value = 1, {
#     dataset <- input$pubchemmap_dataset
#     tmp <- .pubchemmap()
#   
#     el_name<-paste0(dataset,'_edges')
#     node_name<-paste0(dataset,'_nodes')
#     el <- tmp$edges[tmp$edges$value >= input$pubchemmap_edge_cutoff,,drop=FALSE]
#     node<- tmp$nodes
#     r_data[[el_name]] <- el
#     r_data[[node_name]] <- node
#     obj<-c(el_name,node_name)
#   
#     r_data[['datasetlist']] %<>% c(obj,.) %>% unique()
#     r_data[['datasetlist']] %<>% c(dataset,.) %>% unique
#   })
# })