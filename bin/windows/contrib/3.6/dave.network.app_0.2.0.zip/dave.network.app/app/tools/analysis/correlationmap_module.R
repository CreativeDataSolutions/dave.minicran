
corrmap_values<-reactiveValues()

# calculate ---------------------------------------------------------------

# #network index
# output$ui_corr_net_index <- renderUI({
#   vars <- .getdata_col_meta() %>% colnames()
#   selectInput(inputId = "corr_net_index",
#               label = "Network index:",
#               choices = vars,
#               selected = state_single("corr_net_index",vars),
#               multiple = FALSE)
# })

#corr specific UIs
output$ui_corr_method <- renderUI({
  vars<-c('spearman','pearson','kendall')
  selectInput(inputId = "corr_cor_method",
              label = "Method:",
              choices = vars,
              selected = state_single("corr_cor_method",vars),
              multiple = FALSE)
})

output$ui_corr_p_value_FDR <- renderUI({
 checkboxInput('corr_p_value_FDR',label = 'FDR',value = TRUE)
})

output$ui_corr_p_value_cutoff <- renderUI({
  numericInput('corr_p_value_cutoff',label = 'p-value',value = .05, min=0,max=1)
})

#compute network
output$ui_corrmap_calculate <- renderUI({
  fluidRow(
    column(4,
           div(actionButton("corrmap_calculate", "Calculate",icon=icon('check')))),
    column(12,hr())
  )
})


output$ui_corr_cor<-renderUI({
  tagList(
    fluidRow(
      column(12,
        # uiOutput('ui_corr_net_index'),
        uiOutput('ui_corr_method'),
        uiOutput('ui_corr_p_value_FDR'),
        uiOutput('ui_corr_p_value_cutoff')
      )
    )
  )
})

#HUGE regularization ui
output$ui_huge_opt<-renderUI({
  selectInput('huge_opt_method','Optimization',choices = c('none','manual','ric','stars'))
})

output$ui_huge_lambda<-renderUI({
  conditionalPanel(condition = "input.huge_opt_method == 'manual'",
    selectInput('huge_lambda','lambda',choices = '')
  )
})

#compute network
output$ui_huge_calculate <- renderUI({
  fluidRow(
    column(4,
           div(actionButton("huge_calculate", "Calculate",icon=icon('check')))),
    column(12,hr())
  )
})

output$ui_cor_huge<-renderUI({
  tagList(
    column(12,uiOutput('ui_huge_calculate')),
    fluidRow(
      column(12,
        uiOutput('ui_huge_opt'),
        uiOutput('ui_huge_lambda')
      )
    )
  )
})




###############################
# renderUI output
###############################
output$corrmap_calculate_tab_ui <- renderUI({
  req(input$dataset)
  tagList(
    uiOutput("ui_corrmap_calculate"),
    bs_accordion(id="corrmap_collapse_panel") %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("cogs") , "Correlation"),
                content = 
                  fluidRow(column(12,uiOutput("ui_corr_cor")))
    ) %>%
    bs_append(title = tags$label(class='bsCollapsePanel', icon("filter") , "Regularize"),
              content = 
                fluidRow(column(12,uiOutput("ui_cor_huge")))      
    ) %>%
    bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
              content =
                fluidRow(column(12,uiOutput("ui_corrmap_save")))
    )
  )
})


#initialize data
corrmap_init<-reactive({
  
  list(
    data = .getdata_cube()$data, 
    net_index = 'id', #input$corr_net_index, avoid validation issues
    cor_method = input$corr_cor_method,
    cor_FDR = input$corr_p_value_FDR,
    cor_cutoff = input$corr_p_value_cutoff,
    type = 'corr',
    lambda = input$huge_lambda, # make responsive
    check = tryCatch(check_corr(.getdata_cube()$data),error=function(e){NULL})
  )
  
})

corrmap_available <- reactive({
  if(is.null(input$corrmap_calculate) || input$corrmap_calculate ==0) {
    return("Calculate and regularize correlations between variables.")
  }
 
  isolate({
    check<-corrmap_init()$check
    if(!is.null(check$valid) && !check$valid ) return(check$msg)
  })
  
  "available"
})

#huge filter
.get_huge_filter<-reactive({
  
  el<-corrmap_values[[input$dataset]][['huge']][['huge_el']]

  # # want to warn thet first calculate is to fetch lambda ... API use forces this double step
  # if(is.null(el) && input$huge_opt_method == 'manual' && input$huge_lambda != '') {
  #   validate(need('a' != 'a' ,'Next select a lambda, where 0  is no regularization, and re-calculate to view filtered network.'))
  # }
  
  if(!is.null(el) && input$huge_opt_method == 'manual' && input$huge_lambda != '') {
    validate(need(el != "[]" ,'If regularization method is manual; next select lambda calculate. Else try a less restrictive (smaller) lambda.'))
  }
  
  el
                       
  
  
})

#filter obj
.get_network_el<-reactive({
  
 isolate({
    obj<-corrmap_values[[input$dataset]] #applies reactiveValuesToList
   
 })
  
  shiny::validate(need(!is.null(obj)==TRUE,'Calculate to view results'))
  .results<-tryCatch(obj[['cor']][['cor_obj']],error=function(){})

 #new error entering here too early
 if(is.null(.results)) return()
  
  init<-corrmap_init()
 
  el<-withProgress(message = "Creating network", value = 1, {
    #regularized
    el<-.get_huge_filter() 

    if(is.null(el) || nrow(el) == 0){ 
      el <-obj$edges 
    } else {
      #get correlation data for kept edges
      el<-get_cor_edges(obj[['cor']][['cor_obj']],edge_list=el)
    } 
    return(el)
  })
 

  return(list(obj=obj,edges=el))

})

corrmap_network_obj<-reactive({
  
  #problems with isolation
  obj<-corrmap_available()
  validate(need(obj == 'available',obj))

  input$huge_calculate #need for summary update

  isolate({
   
    init<-corrmap_init()
    tmp<-.get_network_el() #get huge filtered edges
    obj<-tmp$obj
    el<-tmp$edges 
    var<-if(init$cor_FDR) {'fdr.p.value'} else {'p.value'}
    id<-el[[var]]<=init$cor_cutoff
    edges<-el[id,,drop=FALSE] %>% remove_edge_dupes(.)
    class(edges)<-class(el)
    attr(edges,'lambda')<-corrmap_values[[input$dataset]][['huge']][['lambda']]
    corrmap_values[[input$dataset]][['obj']]<-format_net_obj(obj$nodes,edges, net_index = init$net_index) # being done already
  })
  
  return(reactiveValuesToList(corrmap_values))
})

###############################
# main functions
###############################
.corrmap <- eventReactive(input$corrmap_calculate,{

  obj<-corrmap_network_obj()
 
  shiny::validate(need(!is.null(obj)==TRUE,'Calculate to view results'))
  return(obj)
})

#check if correlations can be calculated
#TODO rethink all calculations
check_corr<-function(data){
  valid<-TRUE
  msg<-''
  is.num<-sapply(data,is.numeric)
  if(!all(is.num)){
    valid<-FALSE
    msg<-'The data needs to be numeric to calculate correlations.'
  }
  return(list(valid=valid,msg=msg))
}

observeEvent(input$corrmap_calculate, {
  
  tmp<-corrmap_available()
  if(tmp != 'available') {return(tmp)}
  
  main<-withProgress(message = "Calculating correlations", value = 1, {
   
    obj<-corrmap_init()
   
    #API call
    args<-list(data=obj$data,id=.getdata_col_meta()$id)
 
    cor_obj <-
      ocpu_get_cor_mat(dave_network_connection, body = args,return_value = TRUE)

    validate(need(cor_obj$meta$status ==201,cor_obj$paths))
    cor_obj<- cor_obj$results
    # cor_obj<-get_cor_mat(obj$data,id=.getdata_col_meta()$id) #local mode
   
    cor_el<-get_cor_edges(cor_obj$cor) #
    list(obj=obj,cor_obj=cor_obj$cor,cor_el=cor_el,nodes=cor_obj$node)
  })
  
  corrmap_values[[input$dataset]][['cor']]<-list(cor_obj=main$cor_obj,cor_el = main$cor_el,node=main$nodes)
  corrmap_values[[input$dataset]][['edges']]<-main$cor_el
  .nodes<-.getdata_col_meta()
  
   #need to add id as column names
  .nodes$id<-main$node$id %>% as.character()#to avoid cor colnames issue use numeric #colnames(obj$data)
  corrmap_values[[input$dataset]][['nodes']]<-.nodes
   
})

#huge regularization fun
observeEvent(input$huge_calculate, {
  
  lambda<-NULL
  opt_method<-input$huge_opt_method
  
  main<-withProgress(message = "Conducting regularization", value = 1, {
  
  
  if(input$huge_opt_method == 'none'){
    return()
  }
    
  #gate for init lambda
  if(input$huge_opt_method == 'manual' & input$huge_lambda == '') {
    opt_method <- 'manual' # get possible lambda
  }
    
  if(input$huge_opt_method == 'manual' & input$huge_lambda != '') {
    opt_method <- NULL
    lambda<-as.numeric(input$huge_lambda) # calculate with specified lambda
  }
    
  #check if cached object exists
  obj<-corrmap_values[[input$dataset]][['huge_obj']]
  
  if(is.null(obj)){
    message('Creating huge object')
    body <-
      list(
        data = .getdata_cube()$data,
        nlambda = 10,
        paranorm = TRUE,
        lambda.min.ratio = .1,
        check.cor = FALSE
      )
    
    
   tmp<-
      ocpu_get_huge_obj(dave_network_connection,
                        body = body,
                        return_value = TRUE)# need for lambda, could extract specifically and not the rest
   
   corrmap_values[[input$dataset]][['huge_obj']]<-tmp
   #update for manual selection
   updateSelectInput(session,'huge_lambda',choices =  round(tmp$results$lambda,4))
  }
  
  
  body <-
    list(
      huge_obj=corrmap_values[[input$dataset]][['huge_obj']],
      lambda=lambda,
      opt=opt_method
    )
  
  message('Calculating huge edges')
  huge_el<-
    ocpu_get_huge_edges(dave_network_connection,
                        body = body)
  
  validate(need(huge_el$meta$status ==201,huge_el$paths))
  
  lambda <- corrmap_values[[input$dataset]][['huge_obj']]$results$lambda # available lambda for calculations
  #user supplied lambda comes from the UI
  
  #deserialize
  f<-function(el){
    el$source<-as.numeric(el$source)     
    el$target<-as.numeric(el$target)  
    el
  }
   
  
  list(huge_el = tryCatch(f(huge_el$results),error=function(e){NULL}), lambda = lambda)
      
      
  })
  
  corrmap_values[[input$dataset]][['huge']]<-main
  
  # if(input$huge_opt_method == 'manual' & input$huge_lambda ==""){
  #   #should show controls, if here
  #   shinyjs::show(id = 'huge_lambda', anim = TRUE)
  #   updateSelectInput(session,'huge_lambda',choices =  main$lambda)
  # }
  
  #update

  if(nrow(corrmap_values[[input$dataset]][['huge']][['huge_el']]) == 0){
    # withProgress(message = "No connections found, try a smaller lambda. Defaulting to previous edge list.", value = 1, {Sys.sleep(2)})
    showNotification(
      "No connections found, try a smaller lambda. Defaulting to previous edge list.",
      action = NULL,
      duration = 5,
      closeButton = TRUE,
      id = NULL,
      type = c("error"),
      session = getDefaultReactiveDomain()
    )
    corrmap_values[[input$dataset]][['huge']][['huge_el']]<-NULL
  } else{
    
    #TODO debug: sym.mat.to.edge.list
    corrmap_values[[input$dataset]][['huge']][['huge_el']] <-
      get_cor_edges(corrmap_values[[input$dataset]][['cor']][['cor_obj']], main$huge_el, FDR = 'BH')
  }

})


# observeEvent(input$huge_opt_method,{
#   
#     browser()
#     if(input$huge_opt_method == 'manual' ){
#       shinyjs::show(id = 'huge_lambda', anim = TRUE)
#     } else {
#       shinyjs::hide(id = 'huge_lambda', anim = TRUE)
#     }
#   
#     # main<-corrmap_values[[input$dataset]][['huge']]
#     # if(is.null( main)) return()
#     # 
#     # if(input$huge_opt_method == 'manual'){
#     #   
#     #   updateSelectInput(session,'huge_lambda',choices =  main$lambda)
#     # } else {
#     #   updateSelectInput(session,'huge_lambda',choices =  NULL)
#     # }
# })
  
corrmap_network_object<-reactive({

  
  #collect the final edgelist
  #post corr and huge
  obj<-corrmap_network_obj()[[input$dataset]]$obj
  
  #hack for negative vs/. positive corr
  obj$edges$type<-ifelse(sign(obj$edges$value) == 1,'positive_corr','negative_corr')
  obj$edges$value<-abs(obj$edges$value)
  
  #need to harmonize network index types between edges and nodes
  #this should be done generically
  
  #check and/or format component types
  checked<-check_network(nodes = obj$nodes,edges = obj$edges)
  
  list(
    nodes = checked$nodes,
    edges = checked$edges,
    names = list(row = NULL, col = colnames(obj$nodes))
  )
  
})

.summary_corrmap <-reactive({
  
  # if (corrmap_available() != "available") return(corrmap_available())
  if(corrmap_available() != "available") return(corrmap_available() %>% html_text_format(.) %>% list(description=.))
 
 
  # input$corrmap_calculate
  input$huge_calculate
  
  #TODO add isolation
    # isolate({
    args<-corrmap_init()
    #should collect after main calculation
    if(!is.null(corrmap_values[[input$dataset]][['huge']])) {
      #need to calculate to set
      args$huge_method<-input$huge_opt_method
      args$lambda<- as.numeric(input$huge_lambda)
      if(input$huge_opt_method != 'none' & input$huge_opt_method != 'manual') {
        args$lambda<- as.numeric(corrmap_values[[input$dataset]][['huge']]$lambda)
      }
   
      if(is.null(args$lambda) || is.na(args$lambda)) args$lambda<-NULL
    } else {
      args$huge_method<-'none'
      args$lambda<-NULL
    }
   
    
    #filter summary
    filter_summary<-NULL
    network_summary<-corrmap_network_object()
  
    #need to trigger on update of 

    #then filtered edges if present
    available<-corrmap_plot_controls()$available() # source reactive from module
    
    #filtering inside plot controls
    if(!is.null(available) && available == 'available') {
      filter_summary<-corrmap_plot_controls()$summary # no source?
      network_summary<-corrmap_plot_controls()$init
    }
    
    #report on edge_list post regularization
    isolate({
      if(!is.null(corrmap_values[[input$dataset]][['huge_obj']]) && is.null(corrmap_values[[input$dataset]][['huge']][['huge_el']])){
        args$huge_NULL <- TRUE
      } else {
        args$huge_NULL <- FALSE
      }
    })

    c(summary.cor_obj(args),
      filter_summary,
      generic_network_summary(network_summary)) %>%
    # paste(.,collapse =' ') %>% 
    html_paragraph_format(.) %>%
    list(description=.)
        
    # })
})

output$.summary_corrmap_ui<-renderUI({
  
     HTML(.summary_corrmap()$description)

})


# module ------------------------------------------------------------------
corrmap_plot_controls<-callModule(network_visInput,'corrmap',data_obj=corrmap_network_object)

#network plot
corrmap_plot_obj<-callModule(network_vis_plotInput,'corrmap',data_obj=corrmap_plot_controls)

#tab panel
output$ui_corrmap <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel('input.tabs_corrmap == "Calculate"',
                     uiOutput('corrmap_calculate_tab_ui') 
    ),
    conditionalPanel('input.tabs_corrmap == "Visualize"',
                     network_visUI('corrmap') 
    ),
    conditionalPanel('input.tabs_corrmap == "Report"'),
    fluidRow(
      column(12,align="right",modalModuleUI(id="corrmap_help"))
    )
  )
})

output$corrmap <- renderUI({
  
  # #main panel
  corrmap_output_panels <- tabsetPanel(
    id = "tabs_corrmap",
    tabPanel("Calculate", icon = icon("sliders"),uiOutput('.summary_corrmap_ui')),
    tabPanel("Visualize",icon=icon('eye'),network_vis_plotUI('corrmap')),
    tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('corr'))
  )
  
  
  
  #
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('flask'),as.character(" Correlation")))),
                 tool_ui = "ui_corrmap",
                 output_panels = corrmap_output_panels)
})


# report ------------------------------------------------------------------

#collect report object
corrmap_report_params<-reactive({
  
  list(
    plot_obj = tryCatch(corrmap_plot_obj(),error=function(e){NULL}),
    summary_obj =  .summary_corrmap()$description
  )
  
})


# save --------------------------------------------------------------------

#Store data
output$ui_corrmap_save<-renderUI({
  tags$table(
    tags$td(textInput("corrmap_dataset", "Save result in:", paste0("corr_network"))),
    tags$td(actionButton("corrmap_save", "Save"), style="padding-top:30px;")
  )
})

#save
observeEvent(input$corrmap_save, {
  

  #default to calculate edges 
  available<-corrmap_available()
  validate(need(available == 'available','No objects available'))
  init<-corrmap_network_object()
  
  #then filtered edges if present
  available<-corrmap_plot_controls()$available() # source reactive from module
  if(!is.null(available) && available == 'available') init<-corrmap_plot_controls()$init # no source?
  

  withProgress(message = "Saving", value = 1, {
    dataset <- input$corrmap_dataset
    el_name<-paste0(dataset,'_edges')
    node_name<-paste0(dataset,'_nodes')
    
    
    el <- init$edges
    node<- init$nodes
    r_data[[el_name]] <- el
    r_data[[node_name]] <- node
    obj<-c(el_name,node_name)
    
    r_data[['datasetlist']] %<>% c(obj,.) %>% unique()
  })
})


