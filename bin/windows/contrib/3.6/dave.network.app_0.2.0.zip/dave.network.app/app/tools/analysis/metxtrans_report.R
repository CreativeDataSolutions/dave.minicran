#params in main


metxtrans_report_obj<-function(){
  .package<-'dave.network.app'
  report_name<-'metxtrans_report.Rmd'
  rmd_load_path = 'app/report/'
  rmd_save_path=getOption("dave.report.rmd.path")
  html_save_path= getOption('dave.report.html.path')
  
  .report_obj<-get_report_obj(.package = .package,
                              report_name= report_name,
                              rmd_load_path = rmd_load_path,
                              rmd_save_path = rmd_save_path,
                              html_save_path = html_save_path)
  
  return(.report_obj)
}



name<-'metxtrans'

metxtrans_report<-callModule(reportGenerator, name,
                           report_params = metxtrans_report_params,
                           report_obj = metxtrans_report_obj(),
                           .available = metxtrans_available)
