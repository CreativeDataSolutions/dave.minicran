
# calculate ---------------------------------------------------------------

## get global input dataset
keggmap_datasetlist <- reactive({
  input$dataset
})


#KEGG calculation
output$ui_kegg_cal <- renderUI({
  vars <- .getdata_col_meta() %>% colnames()#colnames(r_data[[keggmap_datasetlist()]])
  fluidRow(column(12,
  selectInput(inputId = "kegg_col",
              label = "KEGG id:",
              choices = vars,
              selected = state_single("kegg_col",vars),
              multiple = FALSE)
  ))
})

# #network index
# output$ui_kegg_net_index <- renderUI({
#   vars <- .getdata_col_meta() %>% colnames()#colnames(r_data[[keggmap_datasetlist()]])
#   selectInput(inputId = "kegg_net_index",
#               label = "Network index:",
#               choices = vars,
#               selected = state_single("kegg_net_index",vars),
#               multiple = FALSE)
# })


#compute network
output$ui_keggmap_calculate <- renderUI({
  fluidRow(
    column(4,#TODO get align to work
           div(actionButton("keggmap_calculate", "Calculate",icon=icon('check')))),
    column(12,hr())
  )
})



#ui
output$keggmap_calculate_tab_ui <- renderUI({
  req(input$dataset)
  tagList(
    uiOutput("ui_keggmap_calculate"),
    bs_accordion(id="keggmap_collapse_panel") %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("cogs") , "Biochemical"),
                content = 
                  fluidRow(column(12,
                    uiOutput("ui_kegg_cal")#,
                    #uiOutput('ui_kegg_net_index')
                    )
                  )
      ) %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                content =
                  fluidRow(column(12,uiOutput("ui_keggmap_save")))
      )
    )
})


#initialize data
keggmap_init<-reactive({
  
  input_nodes <-.getdata_col_meta()  
  kegg_col <- input$kegg_col
  net_index<-'id' #input$kegg_net_index
  type<-'KEGG'

  #need to 
  
  #enforce unique net index?
  return(list(
    data = input_nodes,
    idcolumn = kegg_col,
    net_index = net_index,
    type = type
  ))

})

keggmap_available <- reactive({
  if(is.null(input$keggmap_calculate) || input$keggmap_calculate == 0) {
    return("Identify biochemical relationships between variables.")
  }

  "available"
})


.keggmap <- eventReactive(input$keggmap_calculate,{

  message('Calculating biochemical connectoins based on KEGG IDs. ')
  
  withProgress(message = "Calculating biochemical relationships.", value = 1, {
    out<-ocpu_metabolic_network(dave_network_connection,body=keggmap_init())
    # do.call(metabolic_network,keggmap_init())
  })
  
  validate(need(out$meta$status == 201, out$path))
  
  out$results
  
})


keggmap_network_object<-reactive({
  
  obj<-.keggmap()
  
  #converted to network_viz in plot module
  list(
    nodes = obj$nodes,
    edges = obj$edges,
    names = list(row = NULL, col = colnames(obj$nodes))
  )
  
})


# summary -----------------------------------------------------------------


.summary_keggmap <-reactive({
  
  if (keggmap_available() != "available") return(keggmap_available() %>% html_text_format(.) %>% list(description=.))
  
  #collect module summary
  #filter summary
  # network summary
  filter_summary<-NULL
  network_summary<-keggmap_network_object()
  
  #then filtered edges if present
  available<-keggmap_plot_controls()$available() # source reactive from module
  
  if(!is.null(available) && available == 'available') {
    filter_summary<-keggmap_plot_controls()$summary # no source?
    network_summary<-keggmap_plot_controls()$init
  }
  
  c(summary.kegg_obj(type = 'KEGG'),
    filter_summary,
    generic_network_summary(network_summary)) %>%
    html_paragraph_format(.) %>%
    list(description = .)
})

output$.summary_keggmap_ui<-renderUI({
  
     HTML(.summary_keggmap()$description)

})


# report ------------------------------------------------------------------


#collect report object
keggmap_report_params<-reactive({
  
  #browser()
  
  list(
    plot_obj = tryCatch(keggmap_plot_obj(),error=function(e){NULL}),
    summary_obj =  .summary_keggmap()$description 
  )
  
})

# module ------------------------------------------------------------------

keggmap_plot_controls<-callModule(network_visInput,'keggmap',data_obj=keggmap_network_object)

#network plot
#need to block NULL exec 
keggmap_plot_obj<-callModule(network_vis_plotInput,'keggmap',data_obj=keggmap_plot_controls)




#tab pabnel
output$ui_keggmap <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel('input.tabs_keggmap == "Calculate"',
                     uiOutput('keggmap_calculate_tab_ui') 
    ),
    conditionalPanel('input.tabs_keggmap == "Visualize"',
                     network_visUI('keggmap') 
    ),
    conditionalPanel('input.tabs_keggmap == "Report"'),
    fluidRow(column(
      12, align = "right", modalModuleUI(id = "keggmap_help")
    ))
  )
})

output$keggmap <- renderUI({
  
  # #main panel
  keggmap_output_panels <- tabsetPanel(
    id = "tabs_keggmap",
    tabPanel("Calculate", icon = icon("sliders"),uiOutput('.summary_keggmap_ui')),
    tabPanel("Visualize",icon=icon('eye'),network_vis_plotUI('keggmap')),
    tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('kegg'))
  )
  
  
  
  #
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('flask'),as.character(" Biochemical")))),
                 tool_ui = "ui_keggmap",
                 output_panels = keggmap_output_panels)
})





# save --------------------------------------------------------------------


output$ui_keggmap_save<-renderUI({
  tags$table(
    tags$td(textInput("keggmap_dataset", "Save result in:", paste0("biochem_network"))),
    tags$td(actionButton("keggmap_save", "Save"), style="padding-top:30px;")
  )
})

observeEvent(input$keggmap_save, {
 
 
  #default to calculate edges 
  available<-keggmap_available()
  validate(need(available == 'available','No objects available'))
  init<-keggmap_network_object()

  #then filtered edges if present
  available<-keggmap_plot_controls()$available() # source reactive from module
  if(!is.null(available) && available == 'available') init<-keggmap_plot_controls()$init # no source?
 
  
  withProgress(message = "Saving", value = 1, {
    dataset <- input$keggmap_dataset
    el_name<-paste0(dataset,'_edges')
    node_name<-paste0(dataset,'_nodes')
    el <- init$edges
    node<- init$nodes
    r_data[[el_name]] <- el
    r_data[[node_name]] <- node
    obj<-c(el_name,node_name)
  
    r_data[['datasetlist']] %<>% c(obj,.) %>% unique()
  })
})