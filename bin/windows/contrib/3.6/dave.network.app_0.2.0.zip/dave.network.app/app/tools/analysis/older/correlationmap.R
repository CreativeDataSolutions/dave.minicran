# # main fun corrmap
# ## list of function arguments
# corrmap_args <- as.list(formals(init_data))
# 
# ## list of function inputs selected by user
# corrmap_inputs <- reactive({
#   ## loop needed because reactive values don't allow single bracket indexing
#   # corrmap_args$arg<-input$something
#   # corrmap_args$
#   
#   for (i in r_drop(names(corrmap_args)))
#     corrmap_args[[i]] <- input[[paste0("corrmap_",i)]]
#   corrmap_args
# })
# 
# corrmap_values<-reactiveValues()
# 
# 
# ###############################
# # Left menu
# ###############################
# 
# #network index
# output$ui_corr_net_index <- renderUI({
#   vars <- .getdata_col_meta() %>% colnames()#colnames(r_data[[corrmap_datasetlist()]])
#   selectInput(inputId = "corr_net_index",
#               label = "Network index:",
#               choices = vars,
#               selected = state_single("corr_net_index",vars),
#               multiple = FALSE)
# })
# 
# #corr specific UIs
# output$ui_corr_method <- renderUI({
#   vars<-c('spearman','pearson','kendall')
#   selectInput(inputId = "corr_cor_method",
#               label = "Method:",
#               choices = vars,
#               selected = state_single("corr_cor_method",vars),
#               multiple = FALSE)
# })
# 
# output$ui_corr_p_value_FDR <- renderUI({
#  checkboxInput('corr_p_value_FDR',label = 'FDR',value = TRUE)
# })
# 
# output$ui_corr_p_value_cutoff <- renderUI({
#   numericInput('corr_p_value_cutoff',label = 'p-value',value = .05, min=0,max=1)
# })
# 
# #compute network
# output$ui_corrmap_calculate <- renderUI({
#   actionButton("corrmap_calculate", label = "Calculate", icon=icon('check'))
# })
# 
# 
# output$ui_corr_cor<-renderUI({
#   tagList(
#     fluidRow(
#       column(12,uiOutput("ui_corrmap_calculate"))),
#     br(),
#     fluidRow(
#       column(12,
#         uiOutput('ui_corr_net_index'),
#         uiOutput('ui_corr_method'),
#         uiOutput('ui_corr_p_value_FDR'),
#         uiOutput('ui_corr_p_value_cutoff')
#       )
#     )
#   )
# })
# 
# #HUGE regularization ui
# output$ui_huge_opt<-renderUI({
#   selectInput('huge_opt_method','Optimization',choices = c('none','manual','ric','stars'))
# })
# 
# output$ui_huge_lambda<-renderUI({
#   selectInput('huge_lambda','lambda',choices = '')
# })
# 
# #compute network
# output$ui_huge_calculate <- renderUI({
#   actionButton("huge_calculate", label = "Calculate", icon=icon('check'))
# })
# 
# output$ui_cor_huge<-renderUI({
#   tagList(
#     fluidRow(
#       column(12,uiOutput('ui_huge_calculate'))),
#     br(),
#     fluidRow(
#       column(12,
#         uiOutput('ui_huge_opt'),
#         uiOutput('ui_huge_lambda')
#       )
#     )
#   )
# })
# 
# 
# #Store data
# output$ui_corrmap_save<-renderUI({
#   tags$table(
#     tags$td(textInput("corrmap_dataset", "Save result in:", paste0("corr_network"))),
#     tags$td(actionButton("corrmap_save", "Save"), style="padding-top:30px;")
#   )
# })
# 
# ###############################
# # renderUI output
# ###############################
# output$ui_corrmap <- renderUI({
#   req(input$dataset)
#   tagList(
#     bs_accordion(id="corrmap_collapse_panel") %>%
#       bs_append(title = tags$label(class='bsCollapsePanel', icon("cogs") , "Correlation"),
#                 content = 
#                   fluidRow(column(12,uiOutput("ui_corr_cor")))
#     ) %>%
#     bs_append(title = tags$label(class='bsCollapsePanel', icon("filter") , "Regularize"),
#               content = 
#                 fluidRow(column(12,uiOutput("ui_cor_huge")))      
#     ) %>%
#     bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
#               content =
#                 fluidRow(column(12,uiOutput("ui_corrmap_save")))
#     ),
#     fluidRow(
#       column(12,align="right",modalModuleUI(id="corrmap_help")))
#   )
# })
# 
# #setup plot
# corrmap_plot <- reactive({
#   plh <- 600
#   plw <- 800
#   list(plot_width=plw, plot_height=plh)
# })
# 
# corrmap_plot_width <- function()
#   corrmap_plot() %>% { if (is.list(.)) .$plot_width else 800 }
# 
# corrmap_plot_height <- function()
#   corrmap_plot() %>% { if (is.list(.)) .$plot_height else 600 }
# 
# #initialize data
# corrmap_init<-reactive({
#   
#   list(
#     data = .getdata_cube()$data, 
#     net_index = input$corr_net_index,
#     cor_method = input$corr_cor_method,
#     cor_FDR = input$corr_p_value_FDR,
#     cor_cutoff = input$corr_p_value_cutoff,
#     type = 'corr',
#     lambda = input$huge_lambda, # make responsive
#     check = tryCatch(check_corr(.getdata_cube()$data),error=function(e){NULL})
#   )
#   
# })
# 
# corrmap_available <- reactive({
#   if(is.null(input$corrmap_calculate) || input$corrmap_calculate ==0) {
#     return("Calculate correlations between variables.")
#   }
#   if (is.na(input$corrmap_calculate))
#     return("Oops...we should not be here")
# 
#   
#   isolate({
#     check<-corrmap_init()$check
#     if(!is.null(check$valid) && !check$valid ) return(check$msg)
#   })
#   
#   "available"
# })
# 
# #huge filter
# .get_huge_filter<-reactive({
#   #extract correlations
#   # browser()
#   #send dynamic message to shiny
#  
#     el<-NULL
#     lambda<-NULL
#     obj<-corrmap_values[['huge']]
#     if(is.null(obj)) return()
#     args<-corrmap_init()
#     
#    
#     if(!is.null(args$lambda) && args$lambda !="") {
#       
#       el<-get_huge_edges(obj$huge_obj, lambda=args$lambda)
#       lambda<-attr(el,'lambda')
#     } else {
#       
#       el<-corrmap_values[['huge']][['huge_el']] # why is this empty
#       lambda<-attr(el,'lambda')
#       if(!is.null(el)) {
#         cor_obj<-corrmap_values[['cor']][['cor_obj']]
#         edge_list<-el
#         el<-get_cor_edges(cor_obj,edge_list,FDR='BH') 
#       }
# 
#     }
#     if(!is.null(el) && nrow(el) != 0 ){
#       corrmap_values[['huge']][['huge_el']]<-el
#     } else {
#       #record that the lambda yielded no edges
#       
#       
#     }
#    
#     return(list(edges=corrmap_values[['huge']][['huge_el']],lambda=lambda))
#  
#   
# })
# 
# #filter obj
# .get_network_el<-reactive({
#   
#  isolate({
#     obj<-reactiveValuesToList(corrmap_values)#
#  })
#   
#   shiny::validate(need(!is.null(obj)==TRUE,'Calculate to view results'))
#   init<-corrmap_init()
#  
#   el<-withProgress(message = "Creating network", value = 1, {
#     #regularized
#     .el<-.get_huge_filter() # start here huge edges are not used 
#     el<-.el$edges
# 
#     if(is.null(el)){ 
#       el <-obj$edges 
#     } else {
#       #get correlation data for kept edges
#       el<-get_cor_edges(obj[['cor']][['cor_obj']],edge_list=el)
#     } 
#     return(el)
#   })
#  
# 
#   return(list(obj=obj,edges=el,lambda=.el$lambda))
#   # var<-if(init$cor_FDR) {'fdr.p.value'} else {'p.value'}
#   # id<-el[[var]]<=init$cor_cutoff
#   # edges<-el[id,,drop=FALSE] %>% remove_edge_dupes(.)
#   # corrmap_values[['obj']]<-format_net_obj(obj$nodes,edges, net_index = init$net_index) # being done already
#   # 
#   # return(reactiveValuesToList(corrmap_values))
# })
# 
# .get_network_obj<-reactive({
#   
#   # browser()
#   #problems with isolation
#   input$corrmap_calculate
#   input$huge_calculate
#   isolate({
#     init<-corrmap_init()
#     tmp<-.get_network_el() #not using huge 
#     obj<-tmp$obj
#     el<-tmp$edges
#     var<-if(init$cor_FDR) {'fdr.p.value'} else {'p.value'}
#     id<-el[[var]]<=init$cor_cutoff
#     edges<-el[id,,drop=FALSE] %>% remove_edge_dupes(.)
#     class(edges)<-class(el)
#     attr(edges,'lambda')<-corrmap_values[['huge']][['lambda']]
#     corrmap_values[['obj']]<-format_net_obj(obj$nodes,edges, net_index = init$net_index) # being done already
#   })
#   return(reactiveValuesToList(corrmap_values))
# })
# 
# ###############################
# # main functions
# ###############################
# # .corrmap <- eventReactive(input$corrmap_calculate,{
# .corrmap <- reactive({
#   obj<-.get_network_obj()
#   shiny::validate(need(!is.null(obj)==TRUE,'Calculate to view results'))
#   return(obj)
# })
# 
# #check if correlations can be calculated
# #TODO rethink all calculations
# check_corr<-function(data){
#   valid<-TRUE
#   msg<-''
#   is.num<-sapply(data,is.numeric)
#   if(!all(is.num)){
#     valid<-FALSE
#     msg<-'The data needs to be numeric to calculate correlations.'
#   }
#   return(list(valid=valid,msg=msg))
# }
# 
# observeEvent(input$corrmap_calculate, {
#   
#   tmp<-corrmap_available()
#   if(tmp != 'available') {return(tmp)}
#   
#   main<-withProgress(message = "Calculating correlations", value = 1, {
#     #...rethink?
#     obj<-corrmap_init()
#     cor_obj<-get_cor_mat(obj$data)
#     cor_el<-get_cor_edges(cor_obj$cor)
#     list(obj=obj,cor_obj=cor_obj$cor,cor_el=cor_el,nodes=cor_obj$node)
#   })
#   # browser()
#   corrmap_values[['cor']]<-list(cor_obj=main$cor_obj,cor_el = main$cor_el,node=main$node)
#   corrmap_values[['edges']]<-main$cor_el
#   .nodes<-.getdata_col_meta()
#  
#    #need to add id as column names
#   .nodes$id<-main$node$id %>% as.character()#to avoid cor colnames issue use numeric #colnames(obj$data)
#   corrmap_values[['nodes']]<-.nodes
#  
# })
# 
# #huge regularization fun
# observeEvent(input$huge_calculate, {
#   
#   if(input$huge_opt_method == 'none'){
#     corrmap_values[['huge']]<-NULL
#     return()
#   }
#   
#   lambda<-NULL
#   #this is not returning and edgelist
#   main<-withProgress(message = "Conducting regularization", value = 1, {
#     
#     res<-withCallingHandlers({ # does not work because fxn is printing...
#       shinyjs::html("corrmap_busy_mssg", "")
# 
#       huge_obj<- get_huge_obj(.getdata_cube()$data)
#       huge_el<-NULL
#      
#       if(input$huge_opt_method != 'manual'){
#         huge_el<-tryCatch(get_huge_edges(huge_obj, opt=input$huge_opt_method), error=function(e){NULL}) 
#         lambda<-attr(huge_el,'lambda')
#         if(!is.null(huge_el) && nrow(huge_el) == 0 ) {
#           
#           huge_el<-NULL
#           
#         }
#       }  
#       list(huge_obj=huge_obj, huge_el=huge_el,lambda=lambda)
#       
#       
#     },
#     message = function(m) {
#       shinyjs::html(id = "corrmap_busy_mssg", html = m$message, add = FALSE)
#     })
#     return(res)
#     
#   })
#   
# 
#   #set message to null after finish
#   shinyjs::html("corrmap_busy_mssg", "")
# 
#   # browser()
#   corrmap_values[['huge']]<-main
# 
#   if(input$huge_opt_method == 'manual'){
#     updateSelectInput(session,'huge_lambda',choices =  main$huge_obj$lambda)
#   } 
#   
# })
# 
# 
# observeEvent(input$huge_opt_method,{
# # observe({
#   
#   # input$huge_opt_method
#   # 
#   # isolate({
#     main<-corrmap_values[['huge']][['huge_obj']]
#     if(is.null( main)) return()
#     
#     if(input$huge_opt_method == 'manual'){
#       updateSelectInput(session,'huge_lambda',choices =  main$lambda)
#     } else {
#       updateSelectInput(session,'huge_lambda',choices =  NULL)
#     }
# })
#   
# 
# 
# .summary_corrmap <-reactive({
#   
#   # if (corrmap_available() != "available") return(corrmap_available())
#   if(corrmap_available() != "available") return(corrmap_available() %>% html_text_format(.) %>% list(description=.))
#  
#   
#  
#   input$corrmap_calculate
#   input$huge_calculate
#  
#   #TODO add isolation
#     isolate({
#     args<-corrmap_init()
#     #should collect after main calculation
#     if(!is.null(corrmap_values[['huge']])) {
#       #need to calculate to set
#       args$huge_method<-input$huge_opt_method
#       args$lambda<- as.numeric(input$huge_lambda)
#       if(input$huge_opt_method != 'none' & input$huge_opt_method != 'manual') {
#         args$lambda<- as.numeric(corrmap_values[['huge']]$lambda)
#       }
#    
#       if(is.na(args$lambda)) args$lambda<-NULL
#     } else {
#       args$huge_method<-'none'
#       args$lambda<-NULL
#     }
#     # browser()
#     edge_summary<-.get_network_obj()$obj$edges
#     
#       c(summary.cor_obj(args),
#              summary.cer_el(edge_summary)) %>%
#         paste(.,collapse =' ') %>% 
#         html_paragraph_format(.) %>%
#         list(description=.)
#     })
# })
# 
# output$.summary_corrmap_ui<-renderUI({
#   
#   # fluidRow(
#   #   column(12,
#            HTML(.summary_corrmap()$description)
#   #   )
#   # )
#   
# })
# 
# .plot_corrmap <- reactive({
#   if (corrmap_available() != "available") {
#     #block character render
#     msg<-corrmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#  
#   withProgress(message = "Plotting", value = 1, {
#     plot(.corrmap()$obj)
#   })
# })
# 
# #plotly
# output$plotly_corrmap <- renderPlotly({
#   if (corrmap_available() != "available") {
#     #block character render
#     msg<-corrmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   #browser()
#   withProgress(message = "Plotting", value = 1, {
#     plot_g <- plot(.corrmap()$obj,curvature=0)
#     ggplotly(plot_g)
#   })
# })
# 
# #visNetwork
# #TODO add warn modal for large networks
# #
# output$network_corrmap <- renderVisNetwork({
#   if (corrmap_available() != "available") {
#     #block character render
#     msg<-corrmap_available()
#     validate(need(!is.character(msg),msg))
#   }
#   withProgress(message = "Plotting", value = 1, {
#     network.visnetwork(.corrmap()$obj)
#   })
# })
# 
# #create controls for multiple explore
# output$corrmap_explore_ui<-renderUI({
#   
#   fluidRow(
#     column(12,radioButtons("corrmap_explore_plot_type",'', 
#                            c("static" = "static", "dynamic" = "dynamic"), selected = 'static', inline=T)),
#     column(12,
#            conditionalPanel(condition = "input.corrmap_explore_plot_type == 'dynamic'", visNetworkOutput("network_corrmap")),
#            conditionalPanel(condition = "input.corrmap_explore_plot_type == 'static'", plotlyOutput("plotly_corrmap"))
#     )
#   )
#   
# })
# 
# ###############################
# # output is called from the main dave ui.R
# ###############################
# output$corrmap <- renderUI({
#   register_print_output("summary_corrmap", ".summary_corrmap" )
#   register_plot_output("plot_corrmap", ".plot_corrmap",
#                        height_fun = "corrmap_plot_height", width_fun = "corrmap_plot_width")
#   
#   # two separate tabs
#   corrmap_output_panels <- tabsetPanel(
#     id = "tabs_corrmap",
#     tabPanel("Calculate",icon = icon("sliders"),
#              textOutput("corrmap_busy_mssg"),
#              uiOutput('.summary_corrmap_ui')),
#     tabPanel("Explore",icon=icon('pencil-square-o'),uiOutput('corrmap_explore_ui')),
#     tabPanel("Plot",icon = icon("bar-chart"),
#              plotOutput("plot_corrmap", height = "100%")),
#     tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('corr'))#uiOutput('corrmap_report_ui'))
#   )
#   stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
#                  tool = tags$span(class='cer_menue',HTML(paste0(icon('superscript'),as.character(" Correlation")))),
#                  tool_ui = "ui_corrmap",
#                  output_panels = corrmap_output_panels)
# })
# 
# ###############################
# # observeEvent for actionButton
# ###############################
# #report
# observeEvent(input$corrmap_report, {
#   figs <- FALSE
#   outputs <- c("summary")
#   inp_out <- list(list(show = input$corrmap_show))
#   if (length(input$corrmap_plots) >= 0) {
#     outputs <- c("summary","plot")
#     inp_out[[2]] <- list(plot.setup = corrmap_plot(), plot.type="ggplot")
#     #inp_out[[3]] <- list(path = "")
#     figs <- TRUE
#   }
#   update_report(inp_main = clean_args(corrmap_inputs(), corrmap_args),
#                 fun_name = ".corrmap",
#                 inp_out = inp_out, outputs = outputs, figs = figs,
#                 fig.width = corrmap_plot_width(),
#                 fig.height = corrmap_plot_height())
# })
# #save
# observeEvent(input$corrmap_save, {
#   ## saving to a new dataset if specified
#   #save edges and associated node attributes
#   # browser()
#   withProgress(message = "Saving", value = 1, {
#     dataset <- input$corrmap_dataset
#     el_name<-paste0(dataset,'_edges')
#     node_name<-paste0(dataset,'_nodes')
#     el <- .corrmap()$obj$edges
#     node<- .corrmap()$obj$nodes
#     r_data[[el_name]] <- el
#     r_data[[node_name]] <- node
#     obj<-c(el_name,node_name)
#    
#     r_data[['datasetlist']] %<>% c(obj,.) %>% unique()
#   })
# })