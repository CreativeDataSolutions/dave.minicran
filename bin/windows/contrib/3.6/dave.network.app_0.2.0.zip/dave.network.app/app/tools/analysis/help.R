#map help to tabs
#create reactive
#select appropriate url and section based on the selected tab

network_help_lookup <-
  list(
    url='https://creativedatasolutions.github.io/dave.docs/partial/network.html',
    translate = list(
      Calculate = 'calculate',
      Visualize = 'visualize',
      Report = 'translate'
    ),
    mapping = list(
      Calculate = 'calculate-1',
      Visualize = 'visualize',
      Report = 'mapping'
    ),
    correlation = list(
      Calculate = 'calculate-2',
      Visualize = 'visualize',
      Report = 'correlation'
    ),
    biochemical = list(
      Calculate = 'calculate-3',
      Visualize = 'visualize',
      Report = 'biochemical'
    ),
    structural = list(
      Calculate = 'calculate-4',
      Visualize = 'visualize',
      Report = 'structural'
    ),
    enrich = list(
      Calculate = 'calculate-5',
      Visualize = 'visualize',
      Report = 'enrich'
    )
  )


#individual functions - could detect tab based on NULL
map_network_translate_help <-
  function(tab = input$tabs_metxtrans,
           id = 'translate',
           lookup = network_help_lookup,
           url = network_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }

map_network_mapping_help <-
  function(tab = input$tabs_network_mapping,
           id = 'mapping',
           lookup = network_help_lookup,
           url = network_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }

map_network_keggmap_help <-
  function(tab = input$tabs_keggmap,
           id = 'biochemical',
           lookup = network_help_lookup,
           url = network_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }

map_network_pubchemmap_help <-
  function(tab = input$tabs_pubchemmap,
           id = 'structural',
           lookup = network_help_lookup,
           url = network_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }

map_network_corrmap_help <-
  function(tab = input$tabs_corrmap,
           id = 'correlation',
           lookup = network_help_lookup,
           url = network_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }

map_network_enrich_help <-
  function(tab = input$tabs_networkmap,
           id = 'enrich',
           lookup = network_help_lookup,
           url = network_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }




callModule(modalModule, id = 'corrmap_help', content = map_network_corrmap_help)
callModule(modalModule, id = 'keggmap_help', content = map_network_keggmap_help)
callModule(modalModule, id = 'pubchemmap_help', content = map_network_pubchemmap_help)
callModule(modalModule, id = 'network_mapping_help', content = map_network_mapping_help)
callModule(modalModule, id = 'vismap_help', content = map_network_enrich_help)
callModule(modalModule, id = 'metxtrans_help', content = map_network_translate_help)

