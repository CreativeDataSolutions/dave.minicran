################################################################################
## functions to set initial values and take information from r_state
## when available
################################################################################


#TODO fix namespace overwritting, using importFrom
# hack for now
select<-dplyr::select

remove_session_files <- function(st = Sys.time()) {
  fl <- list.files(normalizePath(getOption('dave.user.session')), pattern = "*.rds",
                   full.names = TRUE)

  for (f in fl) {
    if (difftime(st, file.mtime(f), units = "days") > 7)
      unlink(f, force = TRUE)
  }
}


#options(dave.user.session = normalizePath('session'))
most_recent_session_file <- function() {
  fl <- list.files(normalizePath(getOption('dave.user.session')), pattern = "*.rds",
                   full.names = TRUE)

  if (length(fl) > 0) {
    data.frame(fn = fl, dt = file.mtime(fl)) %>% arrange(desc(dt)) %>%
    dplyr::slice(1) %>% .[["fn"]] %>% as.character %>% basename %>%
    gsub("r_(.*).rds","\\1",.)
  } else {
    NULL
  }
}



#function to reload project from a file
loadProject<-function(r_sessions,r_ssuid){

 if (!is.null(r_sessions[[r_ssuid]]$r_data)) {
   suppressWarnings(rm(r_data, r_state, envir = .GlobalEnv))
    r_data  <<- do.call(reactiveValues, r_sessions[[r_ssuid]]$r_data)
    r_state <<- r_sessions[[r_ssuid]]$r_state
  }

}



## 'sourcing' dave's package functions in the server.R environment
if (!"package:dave.data.app" %in% search() && getOption("dave.data.path.app") == "..") {
  ## for shiny-server and development
  for (file in list.files("../../R", pattern="\\.(r|R)$", full.names = TRUE))
    source(file, encoding = getOption("dave.encoding"), local = TRUE)
} else {
  ## for use with launcher
  dave.data.app::copy_all(dave.data.app)
}
