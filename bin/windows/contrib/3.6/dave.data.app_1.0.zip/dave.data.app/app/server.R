shinyServer(function(input, output, session) {

  ## source shared functions
	source("init.R", encoding = getOption("dave.encoding"), local = TRUE)
	source("dave.R", encoding = getOption("dave.encoding"), local = TRUE)

  ## packages to use for example data
  options(dave.example.data = "dave.data.app")
  # r_example_data = "dave.data"

	## source data & analysis tools
  for (file in list.files(c("tools/app","tools/data"), pattern="\\.(r|R)$", full.names = TRUE))
  	source(file, encoding = getOption("dave.encoding"), local = TRUE)

  ## save state on refresh or browser close
  saveStateOnRefresh(session)
})
