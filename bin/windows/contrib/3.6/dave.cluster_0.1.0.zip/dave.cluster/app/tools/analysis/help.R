

cluster_help_lookup <-
  list(
    url = 'https://creativedatasolutions.github.io/dave.docs/partial/cluster.html',
    cluster = list(
      Calculate = 'calculate',
      Plot = 'explore-and-plot',
      Explore = 'explore-and-plot',
      Report = 'report'
    )
  )

map_cluster_help <-
  function(tab = input$tabs_hclust,
           id = 'cluster',
           lookup = cluster_help_lookup,
           url = cluster_help_lookup$url) {
    map_help(tab, id, lookup, url)
  }


hclust_help<-callModule(modalModule,id='hclust_help',content=map_cluster_help)