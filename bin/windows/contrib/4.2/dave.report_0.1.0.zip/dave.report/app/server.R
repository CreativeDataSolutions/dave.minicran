shinyServer(function(input, output, session) {


  source(system.file(package='dave','app/src/local/server.R'),local = TRUE)


})
