#path to reports
#created
.get_html_report_path<-getOption('dave.report.html.path' )
#template
.get_rmd_report_path<-getOption('dave.report.rmd.path' )

report_available<-reactive({

  if(input$nav_dave != 'Report') return('No reports available')
  #reset
  input$dave_report_remove_btn # watch event
  input$dave_report_refresh_btn
  #matching report files
  .files<-tryCatch(get_report_html_files(.get_html_report_path), error=function(e){NULL})
  if(!is.null(.files)) return('available') else return('No reports available')
})


#available reports
output$available_reports_ui<-renderUI({

  #issues with update after delete
  if(input$nav_dave != 'Report') return()
  input$dave_report_remove_btn
  input$dave_report_refresh_btn

  isolate({
    reports<-report_files(path=.get_html_report_path,ord=available_report_order())
  })

  validate(need(length(reports) != 0,''))
  selectizeInput('available_reports','Reports',choices=reports,selected=reports,multiple=TRUE,options = list(plugins = list('remove_button', 'drag_drop')))
})


.selected_reports<-reactive({
  input$available_reports
})

# #issues with rendering controls after report delete
# outputOptions(output,'available_reports_ui', suspendWhenHidden=FALSE)
#
# #update after render
# observe({
#   if(input$nav_dave != 'Report') return()
#   browser()
#   isolate({
#    reports<-report_files(path=.get_html_report_path,ord=available_report_order())
#    validate(need(length(reports) != 0,'No reports avialable'))
#    updateSelectizeInput(session=session,inputId='available_reports',choices=reports,selected=reports)
#   })
# })

#download test
output$dave_report_DL_ui <- renderUI({

  fluidRow(
    column(12,
      downloadButton("dave_report_DL_btn", "")
    )
  )
})

#delete button
#download test
output$dave_report_remove_ui <- renderUI({

  fluidRow(
    column(12,
           actionButton("dave_report_remove_btn", "",icon=icon('remove'))
    )
  )
})

observeEvent(input$dave_report_remove_btn,{

  #get specific reports
  reports<-.selected_reports()

  tryCatch(report_files(path=.get_html_report_path,ord=available_report_order(),files=reports,remove=TRUE), error=function(e){NULL})

  #update avialable
  reports<-report_files(path=.get_html_report_path,ord=available_report_order())
  updateSelectizeInput(session=session,'available_reports',choices =reports,selected=reports)

})

observeEvent(input$dave_report_refresh_btn,{

  #get specific reports
  reports<-.selected_reports()

  tryCatch(report_files(path=.get_html_report_path,ord=available_report_order(),files=reports), error=function(e){NULL})

  #update avialable
  reports<-report_files(path=.get_html_report_path,ord=available_report_order())
  updateSelectizeInput(session=session,'available_reports',choices = reports,selected=reports)

})

output$dave_report_html<-renderUI({

  #update is broken
  input$dave_report_refresh_btn
  obj<-report_available()

  # browser()
  # isolate({
    reports<-.selected_reports()
    check<-!is.null(reports) || !length(reports)==0
    validate(need(check,'No reports available'))
    obj<-report_available()
    if(obj != 'available') return() # misses afer delete
    reports<-.selected_reports()
    .reports<-report_files(path=.get_html_report_path,ord=available_report_order())
    reports<-reports[reports %in% .reports]
    if(length(reports)==0) return()

    combn_html(.get_html_report_path,files=reports) %>%HTML()
  # })
})

output$dave_report_html_ui<-renderUI({
  fluidRow(
    column(12,
           uiOutput('dave_report_html')
    )
  )
})

#save report
#ui via modal
report_save_modal <- function() {

  .name<-paste0('Analysis_report_',Sys.Date())
  modalDialog(
  fluidRow(
    column(12,
      h3('Save Report'),
      textInput('save_report_name','Name',value=.name)
    )
  ),
  footer = tagList(
    modalButton("Cancel"),
    actionButton("save_report_btn", "Save",icon=icon('check')),
    downloadButton('report_DL', 'Download',icon=icon('download'))
  ),
  size = "s",
  easyClose = TRUE
  )
}

#save button
output$dave_report_save_ui<-renderUI({
  fluidRow(
    column(12,
           actionButton("dave_report_download_btn", "",icon=icon('save'))
    )
  )
})

#update not working post delete
output$dave_report_refresh_ui<-renderUI({
  fluidRow(
    column(12,
           actionButton("dave_report_refresh_btn", "",icon=icon('refresh'))
    )
  )
})

#open modal to set name and confirm
observeEvent(input$dave_report_download_btn, {
  showModal(report_save_modal())
})

#shared save/download report maker
get_standalone_report<-reactive({
  #create reports
  reports<-.selected_reports()
  validate(need(!is.null(reports)==TRUE,'No reports available'))
  obj<-report_available()
  if(obj != 'available') return() # misses afer delete
  reports<-.selected_reports()
  .reports<-report_files(path=.get_html_report_path,ord=available_report_order())
  reports<-reports[reports %in% .reports]
  if(length(reports)==0) return()

  out<-combn_html(.get_html_report_path,files=reports,stand_alone = TRUE) %>%HTML()
  .save<-paste0(getOption('dave.report.save.path'),input$save_report_name,".html")

  list(report=out,name=.save)
})

#modal logic
observeEvent(input$save_report_btn, {
  # Check that data object exists and is data frame.
  if (!is.null(input$save_report_name)) {

    #create reports
    obj<-get_standalone_report()
    cat(obj$report,file=normalizePath(obj$name))

    removeModal()
  }


})

#load saved reports
#allow download or deletion
#save button
output$dave_report_view_ui<-renderUI({
  fluidRow(
    column(12,
           actionButton("dave_report_view_btn", "",icon=icon('eye'))
    )
  )
})

#open modal to set name and confirm
observeEvent(input$dave_report_view_btn, {
  showModal(report_saved_view_modal())
})


report_saved_view_modal <- function() {

  .name<-getOption('dave.report.save.path') %>% dir(pattern = '.html')
  modalDialog(
      if(length(.name)==0){
        span('No saved reports available')
      } else {
        fluidRow(
          column(12,
                 h3('Select Report'),
                 selectInput('view_saved_report_name','Name',choices=.name),
                 uiOutput('saved_report_preview')
          )
        )
    },
    footer = tagList(
      modalButton("Cancel"),
      downloadButton('report_DL_view', 'Download',icon=icon('download'))
    ),
    size = "s",
    easyClose = TRUE
  )
}

.selected_saved_reports<-reactive({
  input$view_saved_report_name
})

get_standalone_saved_report<-reactive({
  #create reports
  reports<-.selected_saved_reports()
  validate(need(!is.null(reports)==TRUE,'No reports available'))
  if(length(reports)==0) return()

  out<-readLines(paste0(getOption('dave.report.save.path'),reports)) %>%
    paste0(.,collapse='')
  .save<-reports

  list(report=out,name=.save)
})

output$saved_report_preview<-renderUI({

  obj<-get_standalone_saved_report()$report
  if(is.null(obj)) return()
  obj %>% HTML()
})

#download report in view
output$report_DL_view <- downloadHandler(
  # For PDF output, change this to "report.pdf"
  filename = function() {
    get_standalone_saved_report()$name
  },
  content = function(file) {
  # browser()
    obj<-get_standalone_saved_report()
    cat(obj$report,file=file)
    myfile <- normalizePath(paste0(getOption('dave.report.save.path'),obj$name))
    file.copy(myfile, file)
  }
)

#download current report
output$report_DL <- downloadHandler(
  # For PDF output, change this to "report.pdf"
  filename = function() {
    paste0(input$save_report_name,'.html')
  },
  content = function(file) {

      obj<-report_available()
      reports<-.selected_reports()
      check<-!is.null(reports) || !length(reports)==0
      validate(need(check,'No reports available'))
      obj<-report_available()
      if(obj != 'available') return() # misses afer delete
      reports<-.selected_reports()
      .reports<-report_files(path=.get_html_report_path,ord=available_report_order())
      reports<-reports[reports %in% .reports]
      if(length(reports)==0) return()

      combn_html(.get_html_report_path,files=reports) %>% cat(.,file=file)

  }
)

output$dave_report_ui<-renderUI({
  obj<-report_available()
  # validate(need(obj == "available",obj))
  fluidRow(
    column(12,
    tags$table(
      tags$td(uiOutput('dave_report_refresh_ui')),
      tags$td(uiOutput('dave_report_save_ui')),
      tags$td(uiOutput('dave_report_remove_ui')),
      tags$td(uiOutput('dave_report_view_ui'))
      )
    ),
    column(12,
      uiOutput('available_reports_ui')
    ),
    column(8,
      uiOutput('dave_report_html_ui')
    )
  )
})

