

#worth using this?
get_obj_fun <- function(name, rv) {
  obj <- reactiveValuesToList(rv)[[name]][[input$dataset]]
  list(results = obj$results, summary = obj$summary)
}



network_mapping_module_values<-reactiveValues()


# calculate ---------------------------------------------------------------
#output :network_mapping_calculate_tab_ui

network_mapping_module_input <- reactive({
  
  .getdata_col_meta()
  
})

network_mapping_module_trigger <- reactive({
  
  input$network_mapping_calculate
  
})

#call module server function
network_mapping_module_call <-
  dave.network.app:::mod_network_map_server("mapping",
                                            obj = network_mapping_module_input,
                                            trigger = network_mapping_module_trigger)


observeEvent(input$network_mapping_calculate, {
  
  
  showNotification(paste("mapping variables"),type='message', duration = 1)

  rv <- network_mapping_module_values
  name <- 'network_mapping_module'
  f <- network_mapping_module_call

  #add to existing
  .tmp <- f$summary()
  
  rv[[name]][[input$dataset]]$summary <- unique(c(rv[[name]][[input$dataset]]$summary,.tmp))
  
  
  tmp <- f$results()

  cur<-rv[[name]][[input$dataset]]$results
  
  #update existing column or create new
  if (is.data.frame(cur)) {
    for (i in colnames(tmp)) {
      cur[, i] <- tmp[, i]
    }
    
    tmp <- cur
    
  } 
  
  rv[[name]][[input$dataset]]$results<-tmp
 
  # <- tmp
  
  return(NULL)
})



get_network_mapping_summary_obj<-reactive({
  
  tmp<-get_network_mapping_module_obj()$summary
  
  if(is.null(tmp)) return()
  
  paste0(tmp,collapse=' ')
  
})

get_network_mapping_module_obj<-reactive({
  
  rv<-network_mapping_module_values
  req(get_obj_fun('network_mapping_module',rv))
})



network_mapping_available <- reactive({
  if(is.null(input$network_mapping_calculate) || input$network_mapping_calculate == 0) {
    return('Select options to create mapped variables.')
    
  }
  
  "available"
})



#calculate tabpanel output
output$.summary_network_mapping_results <- renderUI({
  
  obj<-tryCatch(network_mapping_available(),error=function(e){})
  if(obj != 'available') {
    
    return(html_text_format(obj) %>% HTML())
  }
  
  # validate(need( obj == 'available',obj))
  obj<-get_network_mapping_summary_obj()

  req(obj) #,error=function(e){as.character(e)})
  
  HTML(html_paragraph_format(obj))
  
})

network_mapping_get_DT_data<-reactive({
  
  obj<-tryCatch(network_mapping_available(),error=function(e){})
  validate(need( obj == 'available',obj))
  obj<-get_network_mapping_module_obj()
  
  req(obj$results)
  
})





#summary and table
output$.summary_network_mapping_ui<-renderUI({
  
  #don't duplicate error messages
  if (network_mapping_available() == "available"){
    table<-DT::dataTableOutput('network_mapping_DT')
  } else{
    table<-NULL
  }
  
  fluidRow(column(12,
                  # hidden(imageOutput('network_mapping_progress_gif', height ="100")),
                  uiOutput('.summary_network_mapping_results'),
                  br(),
                  table
  ))
})

#create datatable of results
output$network_mapping_DT<- DT::renderDataTable(
  
  datatable(
    network_mapping_get_DT_data(),rownames = FALSE, filter = 'top', options = list(
      pageLength = 10, autoWidth = TRUE,scrollX = TRUE,fontColor='black')
  )
)




#main sidebar ui
output$ui_network_mapping_calculate_sidebar <- renderUI({
  dave.network.app:::mod_network_map_ui("mapping")
})


#compute network
output$ui_network_mapping_calculate <- renderUI({
  fluidRow(
    column(4,#TODO get align to work
           div(actionButton("network_mapping_calculate", "Calculate",icon=icon('check')))),
    column(12,hr())
  )
})



#ui
output$network_mapping_calculate_tab_ui <- renderUI({
  req(input$dataset)
  tagList(
    uiOutput("ui_network_mapping_calculate"),
    bs_accordion(id="network_mapping_collapse_panel") %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("map") , "Mapping"),
                content =
                  fluidRow(column(12,
                                  uiOutput("ui_network_mapping_calculate_sidebar")
                  )
                  )
      ) %>%
      bs_append(title = tags$label(class='bsCollapsePanel', icon("save") , "Save"),
                content =
                  fluidRow(column(12,uiOutput("ui_network_mapping_save")))
      )
  )
})



# report ------------------------------------------------------------------
get_network_mapping_report_params<-reactive({
  
  isolate({
    rv <- network_mapping_module_values
    list(summary = reactiveValuesToList(rv)$network_mapping_module[[input$dataset]]$summary %>%
           html_paragraph_format())
  })
  
})



#tab pabnel
output$ui_network_mapping <- renderUI({
  req(input$dataset)
  tagList(
    conditionalPanel('input.tabs_network_mapping == "Calculate"',
                     uiOutput('network_mapping_calculate_tab_ui')
    ),
    conditionalPanel('input.tabs_network_mapping == "Report"'),
    fluidRow(column(
      12, align = "right", modalModuleUI(id = "network_mapping_help")
    ))
  )
})

output$network_mapping <- renderUI({
  
  # #main panel
  network_mapping_output_panels <- tabsetPanel(
    id = "tabs_network_mapping",
    tabPanel("Calculate", icon = icon("sliders"),
             uiOutput('network_mapping_calculating_ui'),
             uiOutput('.summary_network_mapping_ui')
    ),
    tabPanel("Visualize",icon=icon('eye'), make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE)), #call vis methods
    tabPanel("Report",icon=icon('file-text-o'),reportGeneratorUI('network_mapping'))
  )
  
  
  
  #
  stat_tab_panel(menu = tags$span(class='cer_menue',HTML(paste0(icon('share-alt'),as.character(" Network")))),
                 tool = tags$span(class='cer_menue',HTML(paste0(icon('map'),as.character(" Mapping")))),
                 tool_ui = "ui_network_mapping",
                 output_panels = network_mapping_output_panels)
})





# save --------------------------------------------------------------------
#TODO add to object col meta

output$ui_network_mapping_save<-renderUI({
  actionButton("network_mapping_save", "Save")
})

observeEvent(input$network_mapping_save, {
  #default to calculate edges
  isolate({
    available <- network_mapping_available()
    validate(need(available == 'available', 'No objects available'))
    
    
    dataset <- input$dataset
    #saved obj names
    
    .name <- .makedata_cube_names(dataset)$col
    
    #add translations to col_meta
    rv <- network_mapping_module_values
    name <- 'network_mapping_module'
    res <- rv[[name]][[input$dataset]]$results
    
    
    save_obj <- .getdata_cube()$col_meta
    
    showNotification(paste("'\u2713 Saving...'"),
                     type = 'message',
                     duration = 1)
    
    #update values
    for (i in colnames(res)) {
      save_obj[, i] <- res[, i]
    }
   
    r_data[[.getdata_meta_names()$col]] <- save_obj
    
  })
  
})


