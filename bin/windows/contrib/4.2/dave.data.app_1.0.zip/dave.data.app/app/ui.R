## ui for data menu in dave
tagList(
  tags$head(
    tags$link(rel = "shortcut icon", href = "imgs/icon.png")
  ),
  do.call(navbarPage,
    c(list(title='<div><img src="imgs/icon.png" width=55px/> DAVe</div>' %>% HTML()),
      getOption("dave.nav_ui"),
      getOption("dave.shared_ui"))
  )
)
