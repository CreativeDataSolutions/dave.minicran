#######################################
# Shiny interface for data tabs
#######################################

## show error message from filter dialog
output$ui_filter_error <- renderUI({
  if (is_empty(r_data$filter_error))
    return()
  helpText(r_data$filter_error)
})

#pass data and data_cube info

callModule(data_summary_Input,
           'data_view',
           module_data = .getdata,
           data_cube = .getdata_cube)

output$data_overview_ui <- renderUI({
  if (is.null(.getdata()))
    return()
  fluidRow(column(12,
                  data_summary_UI('data_view')))
})

#removing additional UI
output$ui_data <- renderUI({
  tagList(includeCSS(file.path(
    getOption("dave.data.path.app"), "app/www/style.css"
  )),
  sidebarLayout(
    sidebarPanel(
      conditionalPanel("input.tabs_data != 'About'",
                       wellPanel(uiOutput("ui_datasets"))),
      conditionalPanel("input.tabs_data == 'Overview'", uiOutput("ui_Manage")),
      conditionalPanel("input.tabs_data == 'About'", uiOutput('ui_about_version')),
      fluidRow(column(
        12, align = "right", modalModuleUI(id = "data_help")
      ))
    ),
    mainPanel(
      tabsetPanel(
        id = "tabs_data",
        tabPanel("Overview", uiOutput('data_overview_ui')),
        tabPanel(
          "Explore",
          icon = icon('star'),
          make_alert(
            message = 'In progress! Check back soon.',
            color = '#3399FF',
            remove = FALSE
          )
        ),
        tabPanel(
          "Wrangle",
          icon = icon('star'),
          make_alert(
            message = 'In progress! Check back soon.',
            color = '#3399FF',
            remove = FALSE
          )
        ),
        tabPanel("About", uiOutput('ui_about_info'))
      )
    )
  ))
})
