# #
# library(dave.report)

r_url_list <- getOption("dave.url.list")


r_url_list[["kruskal"]] <-  list("tabs_kruskal" = list("Summary" = "kruskal/kruskal/", "Plot" = "kruskal/kruskal/plot/", "Interactive" = "kruskal/kruskal/interactive/"))
options(dave.url.list = r_url_list); rm(r_url_list)



options(stat_ui =
  tagList(
    navbarMenu("Statistics", icon=icon('superscript'),
               shinyjs::useShinyjs(),
               tabPanel("two-class", uiOutput("kruskal"),icon=icon('superscript')),
               tabPanel("multi-class", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE)),
               tabPanel("mixed-effects", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE))
    )
  )
)
