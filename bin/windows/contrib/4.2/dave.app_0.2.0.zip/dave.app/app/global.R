#this loads the bare minimum for faster initialization
#----------------------------
#see slow_global.R for the rest


#components to load
library(dave.app)

DAVE_PKGS<-getOption('DAVE_PKGS')


#TODO figure out where this is called
end_s3_data<-function(){print(getwd())}

#encoding, have need for non "UTF-8"
options(encoding="UTF-8") #bad for global use enc2native() locally


#sync folders with s3 or create
source(system.file(package='dave.app','app/src/startup.R'),local = TRUE)


# API endpoints -----------------------------------------------------------
#gate based on packages needing API endpoints e.g. any with names dave._.app
if(any(grepl('app',DAVE_PKGS))){
  message('Initializing app APIs')
 source(system.file(package='dave.app','app/src/API.R'),local = TRUE)
}

#load data -- should be in defaults?
#this is required by all apps
options(dave.data.path.app = system.file(package = "dave.data.app"))
source(file.path(getOption("dave.data.path.app"), "app/global.R"), encoding = getOption("dave.encoding", default = "UTF-8"), local = TRUE)


#UI elements
options(dave.path.css=system.file('app/www/css/styles.css',package='dave.app'))
addResourcePath('dave_img',system.file('app/www/imgs',package='dave.app'))
options('google_analytics_js' = system.file('app/www/js/google-analytics.js',package='dave.app'))
addResourcePath('dave_js',system.file('app/www/js',package='dave.app'))


# specify paths to dave packages
set_DAVE_path(DAVE_PKGS)

# load UIs
load_DAVE_UI(DAVE_PKGS)
