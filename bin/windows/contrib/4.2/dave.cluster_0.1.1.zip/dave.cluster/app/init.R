# r_url_list <- getOption("dave.url.list")
# 
# r_url_list[["hclust"]] <-  list("tabs_hclust" = list("Summary" = "hclust/hclust/", "Plot" = "hclust/hclust/plot/", "Interactive" = "hclust/hclust/interactive/"))
# options(dave.url.list = r_url_list); rm(r_url_list)

options(cluster_ui =
  tagList(
    navbarMenu("Cluster", icon=icon('snowflake-o'),
               tabPanel("Hierarchical",icon = icon('sitemap'),uiOutput("hclust")),
               tabPanel("K-means", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE)),
               tabPanel("Density", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE)),
               tabPanel("EM", icon= icon('star'),
                        make_alert(message='In progress! Check back soon.',color='#3399FF',remove=FALSE))
    )
  )
)
